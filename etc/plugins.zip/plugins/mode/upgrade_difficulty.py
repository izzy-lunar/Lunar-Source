def canUpgrade(player):
    return player.isMaxed() and player.playerTitle < 4 and player.isWieldingItems() and player.hasItem(995, 10000000)
	
def displayUpgrade(player):
    new_rank = player.playerTitle + 1
    player.dialogueQuestion("Prestige?", "Become a " + str(CombatConfig.getDifficulty(new_rank)) + ".", 92000 + new_rank, "No thanks", 58)