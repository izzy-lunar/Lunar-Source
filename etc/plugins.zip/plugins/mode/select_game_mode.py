def chat_9845200(p):#login option
  p.dialogueOption("Regular - Very fast combat Exp,7x Exp lamps", 9845201, "Champion - Fast combat Exp, 5x Exp lamps and plus 2% damage", 9845208,
  "Hero - Slow combat Exp, 3x Exp lamps and plus 3% damage", 9845207,
  "Legend - Very slow combat Exp, 1x Exp lamp and plus 4% damage", 9845206, "Try Ironman Mode", 9845202)

def chat_9845201(p):#gives novice rank and good starter pack, option to ::pure
  p.playerTitle = 1
  p.handleNewPlayer()
  p.boxMessage("You receive some items in your backpack. You can start to", "train combat and slayer in the beginner dungeon at @blu@::train@bla@.", "The main shops can be accessed via the @dre@Tradesmen@bla@ in", 
  "the bank of Edgeville.")

def chat_9845202(p):
    p.dialogueOption("Ironman - Very Slow and Restricted Trade", 9845203, "Ultimate Ironman - Ironman with no banking and 1 life.", 9845210, "Show other modes", 9845200)
  
def chat_9845203(p):
  p.boxMessage("@dre@Ironman is not for the bravehearted!@bla@ You are unable to trade",
  "other players access most shops or receive PK loot.", 
  "Don't choose this option without careful consideration!")
  p.nextChat(9845204)

def chat_9845204(p):
  p.dialogueQuestion("Ironman mode?", "Yes I don't mind doing everything for myself.", 9845205, "No I'd rather select a different game mode", 9845200)

def chat_9845210(p):
  p.boxMessage("@dre@Ultimate Ironman is very difficult!@bla@ You are unable to trade",
 "other players access most shops or receive PK loot.", 
 "In addition you only have 1 life and cannot use banks.",
  "Don't choose this option without careful consideration!")
  p.nextChat(984511)

def chat_984511(p):
  p.dialogueQuestion("Ultimate mode?", "Accept - No Banking! No Dying! No Trading!", 9845209, "No I'd rather select a different game mode!", 9845200)

def chat_9845205(p):#gives ironman
  p.playerTitle = 9 + p.playerAppearance[0]
  p.handleNewPlayer()
  p.boxMessage("You select Ironman receive some items in your backpack.",
  "You can start to train combat and slayer in the", "beginner dungeon at @blu@::train@bla@.")
  
def chat_9845206(p):#gives legend
  p.playerTitle = 4
  p.handleNewPlayer()
  p.boxMessage("You select Legend and receive some items in your backpack.",
  "You can start to train combat and slayer in the", "beginner dungeon at @blu@::train@bla@.")

def chat_9845207(p):#gives hero
  p.playerTitle = 3
  p.handleNewPlayer()
  p.boxMessage("You select Hero and receive some items in your backpack.",
  "You can start to train combat and slayer in the", "beginner dungeon at @blu@::train@bla@.")

def chat_9845208(p):#gives champ
  p.playerTitle = 2
  p.handleNewPlayer()
  p.boxMessage("You select Champion and receive some items in your backpack.",
  "You can start to train combat and slayer in the", "beginner dungeon at @blu@::train@bla@.")

def chat_9845209(p):#gives ironman
  p.playerTitle = 24 + p.playerAppearance[0]
  p.handleNewPlayer()
  p.boxMessage("You select Ultimate and receive some items in your backpack.",
  "You can start to train combat and slayer in the", "beginner dungeon at @blu@::train@bla@.")
    