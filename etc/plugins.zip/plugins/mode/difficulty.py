### A plugin to handle difficulty levels ###

levels = ["Easy", "Champion", "Hero", "Legend"]
def setDifficulty(p, level):
    p.playerTitle = level
    p.getTask().loadSidebars()
    p.getTask().closeAllWindows()
	
def chat_89454(p):
    setDifficulty(p, 1)
	
def chat_89455(p):
    setDifficulty(p, 2)
	
def chat_89456(p):
    setDifficulty(p, 3)
	
def chat_89457(p):
    setDifficulty(p, 4)