#package: spells
#script: teleports.py

from com.ownxile.rs2 import Point

#city 1
lumbridge = Point(3222, 3218, 0)
varrock = Point(3212, 3428, 0)
falador = Point(2964, 3380, 0)
draynor = Point(3104, 3249, 0)
#city 2
canafis = Point(3493, 3483, 0)
yanille = Point(2560, 3090, 0)
ardougne = Point(2661, 3306, 0)
camelot = Point(2757, 3477, 0)
al_kharid = Point(3298, 3216, 0)

#town teleports
catherby = Point(2804, 3433, 0)
burthorpe= Point(2917, 3522, 0)
gnome_stronghold = Point(2466, 3493, 0)
lleyta = Point(2316, 3172, 0)
#more towns
taverly = Point(2896, 3460, 0)
port_phasmatys = Point(3661, 3497, 0)
brimhaven = Point(2802, 3156, 0)
rimmington = Point(2956, 3222, 0)

#alternative
slayer_tower = Point(3428, 3538, 0)
lunar_isle = Point(2110, 3915, 0)
relekka = Point(2660, 3656, 0)
shilo_village = Point(2846, 2962, 0)

sarim = Point(3019, 3263, 0)
entrana = Point(2827, 3336, 0)
goblin = Point(2956, 3492, 0)
barbarian_village = Point(3081, 3418, 0)
bandit_camp = Point(3170, 2991, 0)

#dungeon1
tzhaar = Point(2480, 5174, 0)
beginner = Point(2780, 10072, 0)
varrock_sewers = Point(3237, 9860, 0)
edgeville_dung = Point(3133, 9910, 0)

#dungeon2
taverly_dung = Point(2884, 9799, 0)
kalphite_cave = Point(3484, 9510, 2)
waterbirth_dung = Point(1890, 4409, 0)
brimhaven_dung = Point(2684, 9564, 0)
legends = Point(2377, 4685, 0)


#minigame1
barrows = Point(3565, 3316, 0)
pest_control = Point(2658, 2661, 0)
castle_wars = Point(2441, 3089, 0)
duel_arena = Point(3315, 3233, 0)
#minigame2
party_room = Point(2737, 3473, 0)
warriors_guild = Point(2878, 3546, 0)
champions_challenge = Point(3189, 9758, 0)
fight_pits = Point(2399, 5179, 0)
fight_caves = Point(2439, 5170, 0)


#boss 1
corporeal = Point(2897, 3618, 0)
inad = Point(1824, 5138, 6)
giant_mole = Point(1761, 5181, 0)
callisto = Point(3241, 3735, 0)

#boss 2
kree_arra = Point(2839, 5296, 2)
barrelchest = Point(3089, 3569, 0)
sea_troll = Point(3313, 3667, 0)
chaos_elemental = Point(3298, 3911, 0)

#boss 3
graardor = Point(2864, 5354, 2)
dag_kings = Point(1907, 4365, 0)
kbd = Point(2271, 4680, 0)
kalq = Point(3508, 9493, 0)
zilyana = Point(2904, 5264, 0)