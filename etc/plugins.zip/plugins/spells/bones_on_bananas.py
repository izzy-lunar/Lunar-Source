from  com.ownxile.rs2.combat.magic import MagicSpell

class bones_on_bananas(MagicSpell):

  def __init__(self):
    self.setLevelRequired(15)
    self.setAnimation(722)
    self.setGfx(141)
    self.setExperience(25)
    self.requireItem(561, 1)
    self.requireItem(557, 2)
    self.requireItem(555, 2)
    self.setSpellId(4135)
    
  def getSpecialRequirement(self, player):
    return False

  def handleSpecialAftermath(self, player):
    print 'success'