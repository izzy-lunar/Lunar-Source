##################################
###   Music plugin by OwnXile  ###
##################################

from com.ownxile.rs2 import Zone
from com.ownxile.rs2.content.music import Song
from com.ownxile.core import World

# Lumbridge #
lumbridge_zone = Zone(3200, 3250, 3150, 3250)
Song(76, lumbridge_zone)

# Edgeville #
edge_zone = Zone(3070, 3110, 3450, 3550)
Song(151, edge_zone)

# Varrock #
varr_zone = Zone(3176, 3300, 3377, 3500)
Song(106, varr_zone)

# Varrock wild #
varr_wild_zone = Zone(3120, 3350, 3500, 3600)
Song(177, varr_wild_zone)

# East wild #
east_wild_zone = Zone(3150, 3450, 3600, 3800)
Song(176, east_wild_zone)

# Camelot #
camelot_zone = Zone(2744, 2774, 3470, 3520)
Song(104, camelot_zone)

# Catherby #
catherby_zone = Zone(2775, 2835, 3429, 3470)
Song(119, catherby_zone)

# Falador #
falador_zone = Zone(2942, 3058, 3315, 3384)
Song(72, falador_zone)

# Al-kharid #
karid_zone = Zone(3269, 3322, 3149, 3220)
Song(34, karid_zone)

# Draynor manor #
dmanor_zone = Zone(3085, 3120, 3322, 3380)
Song(333, dmanor_zone)

# Zanaris #
zanaris_zone = Zone(1, 2, 1, 2)
Song(52, zanaris_zone)

# Canafis #
canafis_zone = Zone(3460, 3520, 3470, 3520)
Song(61, canafis_zone)

# Essence mine #
essmine_zone = Zone(2885, 2937, 4800, 4855)
Song(57, essmine_zone)

# Barbarian Village # 
barbv_zone = Zone(3067, 3100, 3395, 3454)
Song(141, barbv_zone)

# East Ardougne #
ardougne_zone = Zone(2558, 2690, 3260, 3365)
Song(116, ardougne_zone)

# Xmas workshop #
xmas_zone = Zone(1990, 2025, 4425, 4449)
Song(532, xmas_zone)

