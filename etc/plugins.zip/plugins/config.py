# A script to hold configuration variables
# Add anything you'd like to be implemented

#increase by 1 after latest quest is added
total_quests = 40