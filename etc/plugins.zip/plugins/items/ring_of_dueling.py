from com.ownxile.rs2 import Point

duel_arena_point = Point(3315, 3233, 0)
castle_wars_point = Point(2439, 3088, 0)

def handle_duel_ring(player):
	player.dialogueOption("Al Kharid Duel Arena.", 769245, "Castle Wars Arena.", 769246, "Nowhere.", 0)
	
def chat_769245(player):
	player.teleport(duel_arena_point)

def chat_769246(player):
	player.teleport(castle_wars_point)
	
def third_click_item_2552(player):
	handle_duel_ring(player)

def third_click_item_2567(player):
	handle_duel_ring(player)