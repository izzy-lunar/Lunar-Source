#handles fishing experience tomes
#author robbie

def click_item_7779(player):
    if player.hasItem(7779):
        player.deleteItem(7779)
        player.boxMessage("You receive 10,000 Fishing experience from the tome.")
        player.getFunction().addSkillXP(10000, player.playerFishing)

def click_item_7780(player):
    if player.hasItem(7780):
        player.deleteItem(7780)
        player.boxMessage("You receive 25,000 Fishing experience from the tome.")
        player.getFunction().addSkillXP(25000, player.playerFishing)

def click_item_7781(player):
    if player.hasItem(7781):
        player.deleteItem(7781)
        player.boxMessage("You receive 100,000 Fishing experience from the tome.")
        player.getFunction().addSkillXP(100000, player.playerFishing)