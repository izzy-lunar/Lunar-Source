                                #4447

def click_item_4447(player):
    player.dialogueOption("Agility XP", 847500000, "Runecrafting XP", 847500001, "Mining XP", 847500002, "Ranged XP", 847500003, "Slayer XP", 847500004)
    
def chat_847500000(player):
    if player.hasItem(4447):
        player.deleteItem(4447)
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.endChat()
        player.boxMessage("You are awarded 1M XP in @dre@Agility@bla@!")
        player.getFunction().addSkillXP(1000000, player.playerAgility)
    
def chat_847500001(player):
    if player.hasItem(4447):
        player.deleteItem(4447)
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.endChat()
        player.boxMessage("You are awarded 1M XP in @dre@Runecrafting@bla@!")
        player.getFunction().addSkillXP(1000000, player.playerRunecrafting)

def chat_847500002(player):
    if player.hasItem(4447):
        player.deleteItem(4447)
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.endChat()
        player.boxMessage("You are awarded 1M XP in @dre@Mining@bla@!")
        player.getFunction().addSkillXP(1000000, player.playerMining)

def chat_847500003(player):
    if player.hasItem(4447):
        player.deleteItem(4447)
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.endChat()
        player.boxMessage("You are awarded 1M XP in @dre@Ranged@bla@!")
        player.getFunction().addSkillXP(1000000, player.playerRanged)
		
def chat_847500004(player):
    if player.hasItem(4447):
        player.deleteItem(4447)
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.endChat()
        player.boxMessage("You are awarded 1M XP in @dre@Slayer@bla@!")
        player.getFunction().addSkillXP(1000000, player.playerSlayer)
                            