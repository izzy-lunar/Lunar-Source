#handles mining experience tomes
#author robbie

def click_item_7791(player):
    if player.hasItem(7791):
        player.deleteItem(7791)
        player.boxMessage("You receive 10,000 Mining experience from the tome.")
        player.getFunction().addSkillXP(10000, player.playerMining)

def click_item_7792(player):
    if player.hasItem(7792):
        player.deleteItem(7792)
        player.boxMessage("You receive 25,000 Mining experience from the tome.")
        player.getFunction().addSkillXP(25000, player.playerMining)

def click_item_7793(player):
    if player.hasItem(7793):
        player.deleteItem(7793)
        player.boxMessage("You receive 100,000 Mining experience from the tome.")
        player.getFunction().addSkillXP(100000, player.playerMining)