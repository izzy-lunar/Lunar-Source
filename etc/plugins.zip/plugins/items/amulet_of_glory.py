from com.ownxile.rs2 import Point
from com.ownxile.core import World

rellekka_glory_point = Point(2662, 3643, 0)
edge_glory_point = Point(3087, 3503, 0)
canafis_glory_point = Point(3483, 3474, 0)
phasmatys_glory_point = Point(3661, 3497, 0)
draynor_glory_point = Point(3104, 3249, 0)

def handle_glory_amulet(player):
	player.dialogueOption("Edgeville", 769259, "Canifis", 769260, "Draynor", 769261, "Phasmatys", 769262, "Rellekka", 769263)
	
def chat_769259(player):
	player.teleport(edge_glory_point)

def chat_769260(player):
	player.teleport(canafis_glory_point)

def chat_769261(player):
	player.teleport(draynor_glory_point)

def chat_769262(player):
	player.teleport(phasmatys_glory_point)

def chat_769263(player):
	player.teleport(rellekka_glory_point)

def third_click_item_1712(player):
	handle_glory_amulet(player)

def third_click_item_1704(player):
	handle_glory_amulet(player)