                                                                                                                                                                #################################################
###            Written by Robbie              ###
### A Plugin to handle requirements for items ###
#################################################

#              TODO              #
# *Slayer Equipment Requirements #
# *                              #
# *                              #

#Quest point cape
def wear_item_9813(player):
	if not player.getQuestFunction().hasCompletedAll():
		player.boxMessage("You have not completed all the quests.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)

#ava device		
def wear_item_10499(player):
	if player.getQuest(17).getStage() < 3 and player.playerTitle > 3:
		player.boxMessage("You must have completed Animal Magnetism to", "wear one of Ava's devices.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
#dlong		
def wear_item_1305(player):
	if player.getQuest(14).getStage() < 4 and player.playerTitle > 3:
		player.boxMessage("You must have completed Lost City to", "wield a Dragon longsword.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
#dds		
def wear_item_5698(player):
	if player.getQuest(14).getStage() < 4 and player.playerTitle > 3:
		player.boxMessage("You must have completed Lost City to", "wield a Dragon dagger (p++)")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
#dragon scimitar	
def wear_item_4587(player):
	if player.getQuest(19).getStage() < 4 and player.playerTitle > 3:
		player.boxMessage("You must have completed Monkey Madness to", "wield a Dragon Scimitar.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
#anchor
def wear_item_11887(player):
	if player.getLevel("attack") > 64:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.sendMessage("You require a level of 65 attack to wear this item.")

#black cav
def wear_item_2643(player):
	if player.getLevel("defence") > 0:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 1 defence to wear this item.")

#Crystal shield
def wear_item_4224(player):
	if player.getQuest(28).getStage() < 16:
		player.boxMessage("You must have completed @dre@Roving Elves@bla@ to", "wield this item.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
		
def wear_item_3204(player):
	if player.getQuest(28).getStage() < 16:
		player.boxMessage("You must have completed @dre@Roving Elves@bla@ to", "wield this item.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)
		
def wear_item_4212(player):
	if player.getQuest(28).getStage() < 16:
		player.boxMessage("You must have completed @dre@Roving Elves@bla@ to", "wield this item.")
	else:
		player.getItems().wearItem(player.wearId, player.wearSlot)

#Statius
def wear_item_13884(player):
	if player.getLevel("defence") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 defence to wear this item.")
		
def wear_item_13890(player):
	if player.getLevel("defence") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 defence to wear this item.")
		
def wear_item_13896(player):
	if player.getLevel("defence") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 defence to wear this item.")
		
#Morrigans
def wear_item_13870(player):
	if player.getLevel("ranged") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 ranged to wear this item.")
		
def wear_item_13873(player):
	if player.getLevel("ranged") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 ranged to wear this item.")
		
def wear_item_13876(player):
	if player.getLevel("ranged") > 77:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 78 ranged to wear this item.")
		
#Attack skillcape		
def wear_item_9748(player):
	if player.getLevel("attack") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 attack to wear this skillcape.")

#Strength skillcape		
def wear_item_9751(player):
	if player.getLevel("strength") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 strength to wear this skillcape.")

#Defence skillcape		
def wear_item_9754(player):
	if player.getLevel("defence") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 defence to wear this skillcape.")

#Ranging skillcape		
def wear_item_9757(player):
	if player.getLevel("ranged") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 ranged to wear this skillcape.")

#Prayer skillcape		
def wear_item_9760(player):
	if player.getLevel("prayer") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 prayer to wear this skillcape.")

#Magic skillcape		
def wear_item_9763(player):
	if player.getLevel("magic") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 magic to wear this skillcape.")
		
#Runecrafting skillcape		
def wear_item_9766(player):
	if player.getLevel("runecrafting") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 runecrafting to wear this skillcape.")
		
#Hitpoints skillcape		
def wear_item_9769(player):
	if player.getLevel("hitpoints") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 hitpoints to wear this skillcape.")
		
#Agility skillcape		
def wear_item_9772(player):
	if player.getLevel("agility") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 agility to wear this skillcape.")

#Herblore skillcape		
def wear_item_9775(player):
	if player.getLevel("herblore") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 herblore to wear this skillcape.")

#Thieving skillcape		
def wear_item_9778(player):
	if player.getLevel("thieving") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 thieving to wear this skillcape.")

#Crafting skillcape		
def wear_item_9781(player):
	if player.getLevel("crafting") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 crafting to wear this skillcape.")

#Fletching skillcape		
def wear_item_9784(player):
	if player.getLevel("fletching") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 fletching to wear this skillcape.")
		
#Slayer skillcape		
def wear_item_9787(player):
	if player.getLevel("slayer") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 slayer to wear this skillcape.")
		
#Mining skillcape		
def wear_item_9793(player):
	if player.getLevel("mining") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 mining to wear this skillcape.")
		
#Smithing skillcape		
def wear_item_9796(player):
	if player.getLevel("smithing") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 smithing to wear this skillcape.")

#Fishing skillcape		
def wear_item_9799(player):
	if player.getLevel("fishing") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 fishing to wear this skillcape.")
		
#Cooking skillcape		
def wear_item_9802(player):
	if player.getLevel("cooking") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 cooking to wear this skillcape.")
		
#Firemaking skillcape		
def wear_item_9805(player):
	if player.getLevel("firemaking") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 firemaking to wear this skillcape.")

#Woodcutting skillcape		
def wear_item_9808(player):
	if player.getLevel("woodcutting") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 woodcutting to wear this skillcape.")
		
#Farming skillcape		
def wear_item_9811(player):
	if player.getLevel("farming") > 98:
		player.getItems().wearItem(player.wearId, player.wearSlot)
	else:
		player.boxMessage("You require a level of 99 farming to wear this skillcape.")
                            
                            
                            
                            
                            