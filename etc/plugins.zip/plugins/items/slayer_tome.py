#handles slayer experience tomes
#author robbie

def click_item_7788(player):
    if player.hasItem(7788):
        player.deleteItem(7788)
        player.boxMessage("You receive 10,000 Slayer experience from the tome.")
        player.getFunction().addSkillXP(10000, player.playerSlayer)

def click_item_7789(player):
    if player.hasItem(7789):
        player.deleteItem(7789)
        player.boxMessage("You receive 25,000 Slayer experience from the tome.")
        player.getFunction().addSkillXP(25000, player.playerSlayer)

def click_item_7790(player):
    if player.hasItem(7790):
        player.deleteItem(7790)
        player.boxMessage("You receive 100,000 Slayer experience from the tome.")
        player.getFunction().addSkillXP(100000, player.playerSlayer)