from com.ownxile.config import GameConfig
from com.ownxile.util import Misc

def click_item_10586(player):
    player.dialogueOption("Attack Experience", 87305, "Strength Experience", 87306, "Defence Experience", 87307, "Ranged Experience", 87308, "Magic Experience", 87309)
    
def add_lamp_experience(level, player):
    if player.hasItem(10586):
        player.deleteItem(10586)
        player.endChat()
        name = GameConfig.SKILL_LEVEL_NAMES[level]
        amount = 125 + Misc.random(2000) + player.playerXP[level] / 50
        player.sendMessage("You rub the lantern and it crumbles to dust.")
        player.boxMessage("You receive " + str(amount) + " experience in " + name + "!")
        player.getFunction().addSkillXP(amount, level)
    
def chat_87305(player):
    level = player.playerAttack
    add_lamp_experience(level, player)
    
def chat_87306(player):
    level = player.playerStrength
    add_lamp_experience(level, player)

def chat_87307(player):
    level = player.playerDefence
    add_lamp_experience(level, player)

def chat_87308(player):
    level = player.playerRanged
    add_lamp_experience(level, player)

def chat_87309(player):
    level = player.playerMagic
    add_lamp_experience(level, player)