def second_click_item_3843(player):
    if player.hasItem(3835) and player.hasItem(3836) and player.hasItem(3837) and player.hasItem(3838):
        player.deleteItem(3843)
        player.deleteItem(3835)
        player.deleteItem(3836)
        player.deleteItem(3837)
        player.deleteItem(3838)
        player.addItem(3844)
        player.boxMessage("You add the pages to the book and create a book of balance.")
    else:
        player.boxMessage("You need all 4 Guthix pages before you can complete", "the book of balance.")
		
def second_click_item_3839(player):
    if player.hasItem(3827) and player.hasItem(3828) and player.hasItem(3829) and player.hasItem(3830):
        player.deleteItem(3839)
        player.deleteItem(3827)
        player.deleteItem(3828)
        player.deleteItem(3829)
        player.deleteItem(3830)
        player.addItem(3840)
        player.boxMessage("You add the pages to the book and create a Holy book.")
    else:
        player.boxMessage("You need all 4 Saradomin pages before you can complete", "the Holy book.")
		
def second_click_item_3841(player):
    if player.hasItem(3831) and player.hasItem(3832) and player.hasItem(3833) and player.hasItem(3834):
        player.deleteItem(3841)
        player.deleteItem(3831)
        player.deleteItem(3832)
        player.deleteItem(3833)
        player.deleteItem(3834)
        player.addItem(3842)
        player.boxMessage("You add the pages to the book and create a Unholy book.")
    else:
        player.boxMessage("You need all 4 Zamorak pages before you can complete", "the Unholy book.")