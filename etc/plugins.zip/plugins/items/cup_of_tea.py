#Author Parrot
def click_item_712(player):
    player.deleteItem(712, 1)
    player.addItem(1980, 1)
    player.forcedChat("Ah nothing like a nice cup of tea!")