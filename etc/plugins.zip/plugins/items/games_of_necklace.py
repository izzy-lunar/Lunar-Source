from com.ownxile.rs2 import Point

barrows_minigame_point = Point(3565, 3316, 0)
pest_point = Point(2658, 2661, 0)
warriors_point = Point(2881, 3547, 0)

def handle_games_necklace(player):
	player.dialogueOption("Barrows Minigame", 769247, "Pest Control", 769248, "Warriors Guild", 769249)
	
def chat_769247(player):
	player.teleport(barrows_minigame_point)

def chat_769248(player):
	player.teleport(pest_point)

def chat_769249(player):
	player.teleport(warriors_point)

def third_click_item_3853(player):
	handle_games_necklace(player)