def second_click_item_3842(player):
    player.dialogueOption("Wedding Ceremony", 55000, "Last Rites", 55001, "Blessing", 55002, "Preach", 55003)
	
def second_click_item_3840(player):
    player.dialogueOption("Wedding Ceremony", 55004, "Last Rites", 55005, "Blessing", 55006, "Preach", 55007)

def second_click_item_3844(player):
    player.dialogueOption("Wedding Ceremony", 55008, "Last Rites", 55009, "Blessing", 55010, "Preach", 55011)

#Zamorak preaching
def chat_55000(player):
    player.getFunction().bookPreach("Two great warriors, joined by hand,", "to spread destruction across the land.", "In Zamorak's name, now two are one.")
def chat_55001(player):
    player.getFunction().bookPreach("The weak deserve to die", "so the strong may flourish.", "This is the will of Zamorak.")
def chat_55002(player):
    player.getFunction().bookPreach("May your bloodthirst never be sated", "and may all your battles be glorious.", "Zamorak bring you strength noob.")
def chat_55003(player):
    player.getFunction().bookPreach("Strike fast, strike hard, strike true:", "The strength of Zamorak will be with you.", "Zamorak give me strength!")

#Saradomin preaching
def chat_55004(player):
    player.getFunction().bookPreach("In the name of Saradomin,", "protector of us all,", "I now join you in the eyes of Saradomin.")
def chat_55005(player):
    player.getFunction().bookPreach("Thy cause was false,", "thy skills did lack;", "see you in Lumbridge when you get back.")
def chat_55006(player):
    player.getFunction().bookPreach("Go in peace", "in the name of Saradomin;", "may his glory shine upon you like the sun.")
def chat_55007(player):
    player.getFunction().bookPreach("Show love to your friends, and mercy to your enemies,", "and know that the wisdom of Saradomin will follow.", "This is Saradomin's wisdom.")

#Guthix preaching
def chat_55008(player):
    player.getFunction().bookPreach("Light and dark, day and night,", "Balance arises from contrast.", "I unify thee in the name of Guthix.")
def chat_55009(player):
    player.getFunction().bookPreach("Thy death was not in vain,", "for it brought some balance to the world.", "May Guthix bring you rest.")
def chat_55010(player):
    player.getFunction().bookPreach("May you walk the path, and never fall,", "For Guthix walks beside thee on thy journey.", "May Guthix bring you peace.")
def chat_55011(player):
    player.getFunction().bookPreach("The trees, the earth, the sky, the waters:", "All play their part upon this land.", "May Guthix bring you balance.")