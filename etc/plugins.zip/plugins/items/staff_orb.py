
def click_item_1505(player):
    player.getTask().teleport(3107, 3160, 3)