######################################
###  Birds nest plugin by Dolphin  ###
###           05/09/2013           ###
######################################

from com.ownxile.rs2.items import GroundItemHandler
from com.ownxile.core import World

seed_birds_nest = 5073
ring_birds_nest = 5074
empty_nest = 5075
chance_of_receiving_nest = 50
birds_nests = [5073, 5074]
ring_nest_rewards = [1635, 1637, 1639, 1641, 1643]
seed_nest_rewards = [5312, 5313, 5314, 5315, 5316, 5283, 5284, 5285, 5286, 5287, 5288, 5289, 5290, 5317]

def click_item_5073(player):
	if player.hasItem(seed_birds_nest):
		player.deleteItem(seed_birds_nest, 1)
		player.addItem(empty_nest)
		bird_reward = random.choice(seed_nest_rewards)
		player.addItem(bird_reward, Misc.random(15))
		player.sendMessage("You open the birds nest and find some seeds.")
		
def click_item_5074(player):
	if player.hasItem(ring_birds_nest):
		player.deleteItem(ring_birds_nest, 1)
		player.addItem(empty_nest)
		bird_reward = random.choice(ring_nest_rewards)
		player.addItem(bird_reward, 1)
		player.sendMessage("You open the birds nest and find a ring.")

def receive_birds_nest(player):
	if Misc.random(chance_of_receiving_nest) == chance_of_receiving_nest:
		player.sendMessage("A bird's nest falls out of the tree!")
		nest = random.choice(birds_nests)
		GroundItemHandler.createGroundItem(player, nest, player.getX(),
			player.getY(), player.getZ(), 1, player.getId())