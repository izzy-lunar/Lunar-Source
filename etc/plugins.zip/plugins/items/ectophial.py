#4251
#4252

from com.ownxile.rs2 import Point

ecto_point = Point(3662, 3517, 0)

def click_item_4251(player):
	if player.teleport(ecto_point):
		player.deleteItem(4251)
		player.addItem(4252)
		
def item_4252_on_object_5282(player):
	player.deleteItem(4252)
	player.addItem(4251)
	player.sendMessage("You fill your ectophial.")
	player.startAnimation(827)
	player.turnPlayerTo(player.objectX, player.objectY)