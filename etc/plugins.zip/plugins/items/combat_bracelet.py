from com.ownxile.rs2 import Point

def handle_combat_bracelet(player):
	player.dialogueOption("Barrows Minigame", 769247, "Pest Control", 769248, "Warriors Guild", 769249)

def third_click_item_11118(player):
	handle_combat_bracelet(player)
	
def third_click_item_11126(player):
	handle_combat_bracelet(player)