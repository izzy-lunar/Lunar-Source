from com.ownxile.rs2 import Point

def third_click_item_11866(player):
	player.dialogueOption("Legends Dungeon", 869240, "Metal Dragons of Brimhaven", 869241, "Slayer Tower Top Floor", 869242,  "Slayer Master Duradel", 869243, "Slayer Master Torrcs", 869244)

def chat_869240(p):
    p.getFunction().spellTeleport(2377, 4685, 0)
def chat_869241(p):
    p.getFunction().spellTeleport(2709, 9471, 0)
def chat_869242(p):
    p.getFunction().spellTeleport(3412, 3550, 2)
def chat_869243(p):
    p.getFunction().spellTeleport(2869, 2980, 1)
def chat_869244(p):
    p.getFunction().spellTeleport(3423, 3525, 0)