#handles firemaking experience tomes
#author robbie

def click_item_7794(player):
    if player.hasItem(7794):
        player.deleteItem(7794)
        player.boxMessage("You receive 10,000 Firemaking experience from the tome.")
        player.getFunction().addSkillXP(10000, player.playerFiremaking)

def click_item_7795(player):
    if player.hasItem(7795):
        player.deleteItem(7795)
        player.boxMessage("You receive 25,000 Firemaking experience from the tome.")
        player.getFunction().addSkillXP(25000, player.playerFiremaking)

def click_item_7796(player):
    if player.hasItem(7796):
        player.deleteItem(7796)
        player.boxMessage("You receive 100,000 Firemaking experience from the tome.")
        player.getFunction().addSkillXP(100000, player.playerFiremaking)