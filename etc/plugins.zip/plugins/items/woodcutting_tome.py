#handles woodcutting experience tomes
#author robbie

def click_item_7797(player):
    if player.hasItem(7797):
        player.deleteItem(7797)
        player.boxMessage("You receive 10,000 Woodcutting experience from the tome.")
        player.getFunction().addSkillXP(10000, player.playerWoodcutting)

def click_item_7798(player):
    if player.hasItem(7798):
        player.deleteItem(7798)
        player.boxMessage("You receive 25,000 Woodcutting experience from the tome.")
        player.getFunction().addSkillXP(25000, player.playerWoodcutting)

def click_item_7799(player):
    if player.hasItem(7799):
        player.deleteItem(7799)
        player.boxMessage("You receive 100,000 Woodcutting experience from the tome.")
        player.getFunction().addSkillXP(100000, player.playerWoodcutting)