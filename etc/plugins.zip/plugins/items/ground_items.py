from com.ownxile.rs2.items import DefaultGroundItem

#only use for junk items
DefaultGroundItem(542, 1, 3059, 3487, 1)
DefaultGroundItem(544, 1, 3059, 3488, 1)

#Taverley
DefaultGroundItem(2162, 1, 2932, 3433, 0)
DefaultGroundItem(2162, 1, 2925, 3427, 0)
DefaultGroundItem(2162, 1, 2910, 3425, 0)
DefaultGroundItem(2162, 1, 2908, 3432, 0)
DefaultGroundItem(2162, 1, 2898, 3437, 0)
DefaultGroundItem(2162, 1, 2889, 3440, 0)
DefaultGroundItem(2162, 1, 2887, 3426, 0)
DefaultGroundItem(2162, 1, 2889, 3421, 0)
DefaultGroundItem(2162, 1, 2879, 3419, 0)
DefaultGroundItem(712, 1, 2886, 3412, 0)
DefaultGroundItem(712, 1, 2887, 3418, 0)
DefaultGroundItem(712, 1, 2903, 3441, 0)
DefaultGroundItem(712, 1, 2907, 3447, 0)

#Gertrudes house doogle leaves
DefaultGroundItem(1573, 1, 3150, 3399, 0)
DefaultGroundItem(1573, 1, 3151, 3401, 0)
DefaultGroundItem(1573, 1, 3152, 3397, 0)
DefaultGroundItem(1573, 1, 3153, 3400, 0)

#witches potion items
DefaultGroundItem(221, 1, 2948, 3216, 0)
DefaultGroundItem(300, 1, 2925, 3210, 0)

#Gnome Stronghold
DefaultGroundItem(2162, 1, 2427, 3507, 0)
DefaultGroundItem(2162, 1, 2428, 3510, 0)
DefaultGroundItem(2162, 1, 2424, 3515, 0)
DefaultGroundItem(2162, 1, 2417, 3514, 0)

#Red berries
DefaultGroundItem(1951, 1, 2947, 3415, 0)
DefaultGroundItem(1951, 1, 2948, 3415, 0)
DefaultGroundItem(1951, 1, 2947, 3414, 0)
DefaultGroundItem(1951, 1, 2947, 3414, 0)
DefaultGroundItem(1951, 1, 2952, 3447, 0)
DefaultGroundItem(1951, 1, 2942, 3455, 0)
#Jug
DefaultGroundItem(1935, 1, 2568, 3102, 0)


#home bones
DefaultGroundItem(526, 1, 3094, 3518, 0)

#xmas presents
#DefaultGroundItem(6542, 1, 2852, 2982, 0)
#DefaultGroundItem(11918, 1, 3159, 2980, 0)
#DefaultGroundItem(2522, 1, 2430, 3150, 0)
#DefaultGroundItem(7759, 1, 3544, 3506, 0)
#DefaultGroundItem(10508, 1, 3011, 3499, 0)