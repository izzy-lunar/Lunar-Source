from com.ownxile.core import World
def chat_1383958874(player):
    player.playerChat("Hey what's up bitch")
    player.nextChat(1383958875)

def chat_1383958875(player):
    player.npcChat("yo wag1 rastafari")
    player.nextChat(1383958876)

def first_click_npc_555(player):
    player.startChat(1383958874)
World.addNonCombatNpc(555, 3092, 3292, 0, 1)
