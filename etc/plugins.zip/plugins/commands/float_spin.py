def command_jjjdf(player):
    player.startAnimation(10498)