def command_land(player):
    if player.inWild():
	    player.sendMessage("This command cannot be used in the wilderness.")
    else:
        player.getFunction().spellTeleport(2143, 5534, 3)