def command_commands(player):
    player.sendMessage("@blu@Basic Commands:@bla@ ::vote, ::wiki, ::claim, ::players, ::changepassword, ::zoo, ::empty")
    player.sendMessage("::oxp, ::guides, ::donate ::staff, ::swamp ::iod")
    player.sendMessage("@dre@PK Commands:@bla@ ::explock, ::counter, ::pub ::toprated")
	