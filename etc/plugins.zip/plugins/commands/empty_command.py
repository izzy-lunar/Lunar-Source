def command_empty(player):
    if not player.playerIsBusy() and not player.inWild():
        player.dialogueQuestion("Empty?", "Yes, empty my inventory items.", 77500, "No thanks.", 58)
	
def chat_77500(player):
    player.getItems().deleteInventory()
    player.boxMessage("Your inventory has been cleared.")