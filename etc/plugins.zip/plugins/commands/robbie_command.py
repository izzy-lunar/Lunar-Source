def command_bearobbie(player):
    player.getFunction().spellTeleport(3109, 3514, 2)