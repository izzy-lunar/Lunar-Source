def command_pub(player):
    if player.inWild():
	    player.sendMessage("This command cannot be used in the wilderness.")
    else:
        player.getFunction().spellTeleport(3280, 3513, 0)