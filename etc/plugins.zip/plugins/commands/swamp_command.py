def command_swamp(player):
    if player.inWild():
	    player.sendMessage("This command cannot be used in the wilderness.")
    else:
        player.getFunction().spellTeleport(3217, 3177, 0)