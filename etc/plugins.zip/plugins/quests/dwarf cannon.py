# Quest Name: Dwarf Cannon
# Quest Authors: OwnXile
# Date Created: 19/10/13
# Quest Length: Medium
# Quest Difficulty: Easy

def configure_quest_21():
    quest_id = 21
    quest_name = "Dwarf Cannon"
    quest_stages = 7
    World.addNonCombatNpc(208, 2573, 3463, 0, 1)
    World.addNonCombatNpc(101, 2576, 3450, 0, 1)
    World.addNonCombatNpc(101, 2575, 3442, 0, 1)
    World.addNonCombatNpc(101, 2572, 3442, 0, 1)
    World.addNonCombatNpc(101, 2565, 3448, 0, 1)
    World.addNonCombatNpc(101, 2564, 3437, 0, 1)
    World.addNonCombatNpc(101, 2573, 3424, 0, 1)
    World.addNonCombatNpc(101, 2567, 3420, 0, 1)
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_21(player):
    stage = player.getQuest(21).getStage()
    if stage == 0: 
        player.getFunction().startInfo("Dwarf Cannon", "I can start this quest by speaking to @dre@Lawgof the Dwarven", "@dre@Captain of the Black Watch@bla@, he is defending an area", "@dre@North-west@bla@ of the Fishing guild against a goblin attack.", " ")
    elif stage == 1:
        player.boxMessage("I need to repair the broken railings.")
    elif stage == 2:
        player.boxMessage("I should speak to @dre@Captain Lawgof@bla@ again.")
    elif stage == 3:
        player.boxMessage("I need to investigate the watchtower and find Gilob.")
    elif stage == 4:
        player.boxMessage("I should speak to @dre@Captain Lawgof@bla@ again.")
    elif stage == 5:
        player.boxMessage("I need to repair the Captains broken cannon.")
    elif stage == 6:
        player.boxMessage("I should speak to @dre@Captain Lawgof@bla@ again.")
    elif stage == 7:
        player.boxMessage("I have completed the @dre@Dwarf Cannon @bla@quest.")
    
def first_click_npc_208(player):
    quest_stage = player.getQuest(21).getStage()
    if quest_stage == 0:
        player.startChat(1571288058)    
    elif quest_stage < 3:
        player.startChat(1571288071)
    elif quest_stage < 5:
        player.startChat(1571288080)
    elif quest_stage < 7:
        player.startChat(1615860715)
    else:
        player.startChat(5828287)

def chat_1571288058(player):
    player.playerChat("Hello.")
    player.nextChat(1571288059)

def chat_1571288059(player):
    player.npcChat("Guthix, be praised, the cavalry has arrived! Hero, how", "would you like to be made an honorary member of the", "Black Guard?")
    player.nextChat(1571288060)

def chat_1571288060(player):
    player.playerChat("The Black Guard, what's that?")
    player.nextChat(1571288061)

def chat_1571288061(player):
    player.npcChat("Hawhaw! 'What's that' he asks, what a sense of humour!", "The Black Guard is the finest regiment in the dwarven", "army. Only the best of the best are allowed to join it", "and then they receive months of rigorous training.")
    player.nextChat(1571288062)

def chat_1571288062(player):
    player.npcChat("However, we are currently in need of a hero, so for a", "limited time only I'm offering you, a human, a chance", "to join this prestigious regiment. What do you say?")
    player.nextChat(1571288063)

def chat_1571288063(player):
    player.playerChat("Sure, I'd be honoured to join.")
    player.nextChat(1571288064)

def chat_1571288064(player):
    player.npcChat("That's the spirit! Now trooper, we have no time to waste", "- the goblins are attacking from the forests to the", "South. There are so many of them, they are", "overwhelming my men and breaking through our")
    player.nextChat(1571288065)

def chat_1571288065(player):
    player.npcChat("perimiter defences; could you please try to fix the", "stockade by replacing the broken rails with these new", "ones?")
    player.nextChat(1571288066)

def chat_1571288066(player):
    player.playerChat("Sure, sounds easy enough...")
    player.nextChat(1571288069)

def chat_1571288067(player):
    player.boxMessage("The Dwarf Cpatain gives you six railings.")
    player.nextChat(1571288069)#skips hammer dialogue

def chat_1571288068(player):
    player.npcChat("You'll need this hammer too.")
    player.nextChat(1571288069)

def chat_1571288069(player):
    player.npcChat("Report back to me once you've fixed the railings.")
    player.nextChat(1571288070)

def chat_1571288070(player):
    player.playerChat("Yes Sir, Captain!")
    player.endChat()
    player.getQuest(21).setStage(1)
    player.refreshQuestTab()

def chat_1571288071(player):
    if player.getQuest(21).getStage() == 2:
        player.playerChat("I've fixed all these railings now.")
        player.nextChat(1571288072)
    else:
        player.npcChat("Have you fixed all the railings?")
        player.nextChat(1615860716)
    
def chat_1571288072(player):
    player.npcChat("Well done, trooper! The goblins seem to have stopped", "getting in. I think you've done the job!")
    player.nextChat(1571288073)

def chat_1571288073(player):
    player.playerChat("Great, I'll be getting on then.")
    player.nextChat(1571288074)

def chat_1571288074(player):
    player.npcChat("What? I'll have you jailed for desertion!")
    player.nextChat(1571288075)

def chat_1571288075(player):
    player.npcChat("Besides, I have another commission for you. Just", "before the goblins over-ran us we lost contact with our", "watch tower to the South, that's why the goblins", "managed to catch us unawares. I'd like you to perform")
    player.nextChat(1571288076)

def chat_1571288076(player):
    player.npcChat("a covert operation into enemy territory, to check up on", "the guards we have stationed there.")
    player.nextChat(1571288077)

def chat_1571288077(player):
    player.playerChat("Okay. I'll see what I can find out.")
    player.nextChat(1571288078)

def chat_1571288078(player):
    player.npcChat("Excellent! I have two men there, the dwarf-in-charge is", "called Gilob, find him and tell him that I'll send him a", "relief guard just as soon as we mop up these remaining", "goblins.")
    player.endChat()
    player.getQuest(21).setStage(3)

def chat_1571288079(player):
    player.playerChat("Hello.")
    player.nextChat(1571288080)

def chat_1571288080(player):
    player.npcChat("Have you been to the watch tower?")
    if player.getQuest(21).getStage() == 4:
        player.nextChat(1571288081)
    else:
        player.nextChat(1615860716)

def chat_1571288081(player):
    player.playerChat("I have some terrible news for you Captain, the goblins", "over ran the tower, your guards fought well but were", "overwhelmed.")
    player.nextChat(1571288082)

def chat_1571288082(player):
    player.boxMessage("You give the Dwarf Captain his subordinate's remains...")
    player.deleteItem(0)
    player.nextChat(1571288083)

def chat_1571288083(player):
    player.npcChat("I can't believe it, Gilob was the finest lieutenant I had!", "We'll give him a fitting funeral, but what of his", "command? His son, Lollk, was with him. Did you find", "his body too?")
    player.nextChat(1571288084)

def chat_1571288084(player):
    player.playerChat("No, there was only one body there, I searched pretty", "well.")
    player.nextChat(1571288085)

def chat_1571288085(player):
    player.npcChat("Such a pity, thank you for your help anyway.")
    player.nextChat(1086700194)
    
def chat_1086700194(player):
    player.playerChat("Always a pleasure to help.")
    player.nextChat(1086700195)

def chat_1086700195(player):
    player.npcChat("In that case could I ask one more favour of you...")
    player.nextChat(1086700196)

def chat_1086700196(player):
    player.npcChat("When the goblins attacked us some of them managed to", "slip past my guards and sabotage our cannon. I don't", "have anybody who understands how it works, could you", "have a look at it and see if you could get it working for")
    player.nextChat(1086700197)

def chat_1086700197(player):
    player.npcChat("us, please?")
    player.nextChat(1086700198)

def chat_1086700198(player):
    player.playerChat("Okay, I'll see what I can do.")
    player.nextChat(1086700200)

def chat_1086700200(player):
    player.npcChat("Report back to me if you manage to fix it.")
    player.endChat()
    player.getQuest(21).setStage(5)

def chat_1615860715(player):
    player.npcChat("Have you fixed the cannon?")
    if player.getQuest(21).getStage() == 5:
        player.nextChat(1615860716)
    else:
        player.nextChat(5828284)

def chat_1615860716(player):
    player.playerChat("No, not yet Captain.")
    player.endChat()
    
def chat_5828284(player):
    player.playerChat("I've fixed your cannon, should be perfectly good for", "destroying those invading goblins now!")
    player.nextChat(5828285)

def chat_5828285(player):
    player.npcChat("Excellent, you've been so helpful " + str(player.playerName) + ", how", "can the Black Guard repay you for your services?")
    player.nextChat(5828286)

def chat_5828286(player):
    player.playerChat("Well umm...")
    player.nextChat(5828287)

def chat_5828287(player):
    if player.getQuest(21).getStage() == 7:
        player.playerChat("I quite like your cannon, could I get one myself?")
    else:
        player.playerChat("How can I get one of those cannons again?")
    player.nextChat(5828288)

def chat_5828288(player):
    player.npcChat("There's a dwarf base near the Barbarian Village, a Dwarf", "there manufactors those things!", " Tell him Captain Lawgof sent you he'll happily sell you one", "I'm sure")
    player.nextChat(5828289)

def chat_5828289(player):
    player.npcChat("Good luck on your travels adventurer.")
    if player.getQuest(21).getStage() == 6:
        player.nextChat(5828290)
    else:
        player.endChat()

def chat_5828290(player):
    player.endChat()
    player.getQuest(21).setStage(7)
    player.addItem(6)
    player.addItem(2, 500)
    player.sendMessage("@dre@We are temporarily giving cannons and cannonballs as a reward, enjoy.")
    player.getFunction().addSkillXP(75324, player.playerCrafting)
    reward = QuestReward("1 Quest Point", "75,324 Crafting XP", "Ability to use a Dwarf Cannon")
    player.completeQuest("Dwarf Cannon", reward, 2)
