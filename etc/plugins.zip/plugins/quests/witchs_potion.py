
World.addNonCombatNpc(307, 2967, 3206, 0, 1)

def configure_quest_18():
    quest_id = 18
    quest_name = "Witch's Potion"
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)

def quest_button_18(player):
    quest_stage = player.getQuest(18).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Witch's Potion", "I can start this quest by speaking to @dre@Hetty@bla@ who", "lives in @dre@Rimmington@bla@, south west of @dre@Falador@bla@.", "","")
    elif quest_stage == 1 and has_potion_ingredients(player):
        player.boxMessage("I should take the ingredients to Hetty in Rimmington.")
    elif quest_stage == 1:
        player.boxMessage("I need to take Hetty an eye of newt,", "some grain, a cooked lobster and", "a rats tail.")
    elif quest_stage == 2:
        player.boxMessage("Hetty said I could drink from the Cauldron.")
    elif quest_stage == 3:
        player.boxMessage("I have completed the @dre@Witch's Potion@bla@ quest.")

def has_potion_ingredients(player):
    if player.hasItem(379) and player.hasItem(1947) and player.hasItem(221) and player.hasItem(300):
        return True
    else:
        return False

def first_click_object_2024(player):# cauldron
    quest_stage = player.getQuest(18).getStage()
    if quest_stage == 2:
        player.startChat(604024)
    else:
        player.playerChat("I don't I should be drinking from there!")

def first_click_npc_307(player):
    quest_stage = player.getQuest(18).getStage()
    if quest_stage == 1:
        player.startChat(604016)
    elif quest_stage == 2:
        player.sendMessage("Hetty told me to drink from the Cauldron.")
    else:
        player.startChat(604000)
    
    
def chat_604000(player):
    player.npcChat("What could you want with an old woman like me?")
    player.nextChat(604001)
    
def chat_604001(player):
    quest_stage = player.getQuest(18).getStage()
    if quest_stage == 0:
        player.playerChat("I am in search of a quest.")
        player.nextChat(604002)
    else:
        player.playerChat("I want your pussy.")
        player.nextChat(604026)

def chat_604002(player):
    quest_stage = player.getQuest(18).getStage()
    if quest_stage == 2:
        player.npcChat("I'm all out of quests I'm afraid babe.")
        player.endChat()
    else:
        player.npcChat("Hmmm... Maybe I can think of something for you.")
        player.nextChat(604003)
    
def chat_604003(player):
    player.npcChat("Would you like to become more proficient in the dark", "arts?")
    player.nextChat(604004)

def chat_604004(player):
    player.playerChat("What, you mean improve my magic?")
    player.nextChat(604005)
    
def chat_604005(player):
    player.boxMessage("The witch sighs.")
    player.nextChat(604006)

def chat_604006(player):
    player.npcChat("Yes, improve your magic...")
    player.nextChat(604007)

def chat_604007(player):
    player.npcChat("Do you have no sense of drama?")
    player.nextChat(604008)
    
def chat_604008(player):
    player.dialogueOption("Yes I'd like to improve my magic.", 604009, "No, I'm not interested.", 0)
    
def chat_604009(player):
    player.playerChat("Yes I'd like to improve my magic.")
    player.nextChat(604010)
    
def chat_604010(player):
    player.boxMessage("The witch sighs.")
    player.nextChat(604011)    

def chat_604011(player):
    player.npcChat("Ok I'm going to make a potion to help bring out your", "dark self.")
    player.nextChat(604012)
    
def chat_604012(player):
    player.npcChat("You will need certain ingredients.")
    player.nextChat(604013)

def chat_604013(player):
    player.playerChat("What do I need?")
    player.nextChat(604014)

def chat_604014(player):
    player.npcChat("You need an eye of newt, a rats tail, some grain... Oh", "and a cooked lobster.")
    player.nextChat(604015)
    
def chat_604015(player):
    player.playerChat("Great I'll go get them.")
    player.getQuest(18).setStage(1)
    player.refreshQuestTab()
    player.endChat()

def chat_604016(player):
    player.npcChat("So have you found the things for the potion?")
    if has_potion_ingredients(player):
        player.nextChat(604019)
    else:
        player.nextChat(604017)

def chat_604017(player):
    player.playerChat("I'm working on it.")
    player.nextChat(604018)

def chat_604018(player):
    player.npcChat("Potions don't make themselves you know!")
    player.endChat()
    
def chat_604019(player):
    player.playerChat("I have them all!")
    player.nextChat(604020)

def chat_604020(player):
    player.npcChat("Excellent, can I have them then?")
    player.nextChat(604021)

def chat_604021(player):
    player.boxMessage("You pass the ingredients to Hetty and she puts them all into her", "cauldron. Hetty closes her eyes and begins to chant. The cauldron", "bubbles mysteriously.")
    player.nextChat(604022)

def chat_604022(player):
    player.playerChat("Well, is it ready?")
    player.nextChat(604023)
    
def chat_604023(player):
    player.npcChat("Yes, now drink from the cauldron.")
    player.getQuest(18).setStage(2)
    player.deleteItem(379)
    player.deleteItem(1947)
    player.deleteItem(221)
    player.deleteItem(300)
    player.endChat()
    
def chat_604024(player):
    player.boxMessage("You drink from the cauldron, it tastes horrible! You feel yourself", "imbued with power")
    player.nextChat(604025)
    
def chat_604025(player):
    player.getQuest(18).setStage(3)
    player.getFunction().addSkillXP(250000, player.playerMagic)
    player.getFunction().addSkillXP(250000, player.playerHerblore)
    reward = QuestReward("1 Quest Point", "250,000 Magic XP", "250,000 Herblore XP")
    player.completeQuest("Witch's Potion", reward, 221)
    
def chat_604026(player):
    player.npcChat("I don't have a cat anymore I'm afraid.")
    player.nextChat(604027)
    
def chat_604027(player):
    player.playerChat("That wasn't what I... never mind.")
    player.endChat()