#This Quest was created by Hawk
#Quest Length = Long

#NPCs
inadequacy_id = 5902
squire_id = 606

#Items
ruby_id = 1604
iron_bar_id = 2352
steel_bar_id = 2354
cosmic_id = 564
void_mace_id = 8841
slime_id = 4286

from com.ownxile.core import World
def configure_quest_10():
    quest_id = 10
    quest_name = 'Old Religion'
    quest_stages = 5
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(squire_id, 2977, 3341, 0, 1)
    World.addCombatNpc(inadequacy_id, 1826, 5151, 2, 1, 350, 40, 350, 350)
    World.addCombatNpc(inadequacy_id, 1826, 5148, 6, 1, 550, 70, 450, 450)
	
	
    World.addCombatNpc(5903, 1817, 5148, 6, 1, 150, 10, 200, 200)
    World.addCombatNpc(5903, 1823, 5159, 6, 1, 150, 10, 200, 200)
    World.addCombatNpc(5903, 1833, 5152, 6, 1, 150, 10, 200, 200)
    #World.addCombatNpc(inadequacy_id, 1826, 5151, 0, 1) #If more than one demon is to be added in the fight
    #World.addCombatNpc(inadequacy_id, 1826, 5151, 0, 1) #If more than one demon is to be added in the fight
    
def quest_button_10(player):
    quest_stage = player.getQuest(10).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Old Religion", "I can start this quest by speaking to the @dre@Squire@bla@ who", "is located in the courtyard of the white knight", " castle in @dre@Falador@bla@. I will need a Runecrafting level", "of 30 and a Smithing level of 50 before I can start.")
    elif quest_stage == 1:
        player.boxMessage("I must bring the items to the Squire.") 
    elif quest_stage == 2:
        player.boxMessage("I must bring the items to the Squire.") 
    elif quest_stage == 3:
        player.boxMessage("I need to kill @dre@The Inadaquecy@bla@ and bring the", "slime to the Squire.") 
    elif quest_stage == 5:
        player.boxMessage("I have completed the @dre@Old Religion@bla@.")
        
def kill_npc_5902(player):
    quest_stage = player.getQuest(10).getStage()
    if quest_stage == 3:
        player.getQuest(10).setStage(4)
        player.playerChat("I should take the slime back to the Squire.")


def first_click_npc_606(player):
    smithing_level = player.getLevel("smithing")
    runecrafting_level = player.getLevel("runecrafting")
    quest_stage = player.getQuest(10).getStage()
    if quest_stage == 0 and runecrafting_level < 30:
        player.boxMessage("You need a Runecrafting level of 30 or higher to start this quest.")
    elif quest_stage == 0 and smithing_level < 40:
        player.boxMessage("You need a Smithing level of 40 or higher to start this quest.")  
    elif quest_stage == 0:
        player.startChat(50012348)
    elif quest_stage == 1 and player.hasItem(ruby_id, 5) and player.hasItem(iron_bar_id, 20) and player.hasItem(steel_bar_id, 100):
        player.startChat(50012317)
    elif quest_stage == 1:
        player.npcChat("Why are you back already?", "Hurry up and get me the items!")
    elif quest_stage == 2 and player.hasItem(cosmic_id, 200):
        player.startChat(50012351)
    elif quest_stage == 2:
        player.npcChat("I need those Runes, please hurry up!")
    elif quest_stage == 3 and player.hasItem(slime_id):
        player.startChat(50012358)
    elif quest_stage == 3:
        player.npcChat("I need you to slay the Inadaquecy and bring", "me the slime!")
    else:
        player.playerChat("I better not disturb the Squire.")
    
def chat_50012348(player):
    player.npcChat("Hello young adventurer, what brings you here?")
    player.nextChat(50012349)
    
def chat_50012349(player):
    player.dialogueOption("I'm looking for an adventure.", 50012310, "I don't know, bye.", 50012311)

def chat_50012310(player):
    player.playerChat("I'm looking for an adventure!")
    player.nextChat(50012312)
    
def chat_50012311(player):
    player.playerChat("To be honest I'm not sure, bye!")
    player.endChat()
    
def chat_50012312(player):
    player.npcChat("In that case you have come to the right place.", "I have a quest that only the bravest warrior can complete", "Are you still up for the challenge, adventurer?")
    player.nextChat(50012313)
    
def chat_50012313(player):
    player.dialogueOption("Yes", 50012314, "No", 50012315)
    
def chat_50012314(player):
    player.playerChat("Yes, of course!")
    player.nextChat(50412316)
    
def chat_50012315(player):
    player.playerChat("No thanks, it sounds too dangerous...")
    player.endChat()
    
def chat_50412316(player):
	player.npcChat("I sense great evil that only", "the mace of Guthix can neutralize")
	player.nextChat(50012316)
	
def chat_50012316(player):
    player.npcChat("Fortunately I can create this mace,", "bring me 5 cut rubys, 20 iron bars and 100 steel bars.")
    player.getQuest(10).setStage(1)
    player.refreshQuestTab()
    player.endChat()
    
def chat_50012317(player):
    player.npcChat("Hand over the items, we don't have much time")
    player.deleteItem(ruby_id, 5)
    player.deleteItem(iron_bar_id, 20)
    player.deleteItem(steel_bar_id, 100)
    player.getQuest(10).setStage(2)
    player.refreshQuestTab()
    player.nextChat(50012318)

def chat_50012318(player):
    player.npcChat("I need some runes to enchant the Ruby,", "Please bring me 200 Cosmic Runes!")
    player.nextChat(50012319)
    
def chat_50012319(player):
    player.playerChat("500 cosmic runes!?")
    player.nextChat(50012350)
    
def chat_50012350(player):
    player.npcChat("The spell is one of the old religion, it's the only way!")
    player.endChat()
    
def command_idkf(player):
    player.startChat(50012351)
def chat_50012351(player):
    player.playerChat("I have the 200 cosmic runes.")
    player.nextChat(50012352)
    
def chat_50012352(player):
    player.npcChat("Thanks you, these will come in handy.")
    player.deleteItem(cosmic_id, 5001234)
    player.getQuest(10).setStage(3)
    player.refreshQuestTab()
    player.nextChat(50012353)
    
def chat_50012353(player):
    player.npcChat("Come see me again when you", "are ready to fight the Inadequacy.")
    player.endChat()
    
def chat_554012350(player):
    player.npcChat("Are you ready to fight the Inadequacy?")
    player.nextChat(50012354)
    
def chat_50012354(player):
    player.dialogueOption("Yes", 50012355, "No", 50012356)

def chat_50012355(player):
    player.playerChat("Yes, take me to the Inadequacy!")
    player.nextChat(50012357)
    
def chat_50012356(player):
    player.playerChat("No, I'm not quite ready yet.")
    player.endChat()
    
def chat_50012357(player):
    player.npcChat("As you wish young adventurer.")
    player.nextChat(50123500)
	
def chat_50123500(player):
    player.getTask().teleport(1824, 5165, 2)
    player.endChat()
    
def chat_50012358(player):
    player.playerChat("Slaying the Inadequacy was a challenge.")
    player.nextChat(50012359)
    
def chat_50012359(player):
    player.npcChat("Wha.. what? I can't believe it!")
    player.nextChat(500123500)
    
def chat_500123500(player):
    player.playerChat("I brought you the Inadequacy's blood as a trophy.")
    player.nextChat(500123501)
    
def chat_500123501(player):
    player.npcChat("Thank you " + str(player.playerName) + ",", "you will never be forgotten!")
    player.nextChat(500123502)
    
def chat_500123502(player):
    player.playerChat("That's it? Don't I get a reward?")
    player.nextChat(500123503)
    
def chat_500123503(player):
    player.npcChat("Oh... I almost forgot!")
    player.nextChat(500123504)

def chat_500123504(player):
    player.endChat()
    player.getQuest(10).setStage(5)
    player.refreshQuestTab()
    player.deleteItem(slime_id, 1)
    player.addCash(5000000)
    player.addPoints(100)
    player.getFunction().addSkillXP(500000, 20)
    player.getFunction().addSkillXP(500000, 13)
    reward = QuestReward("5,000,000 coins", "500,000 Smithing XP", "500,000 Crafting XP", "100 OXP", "1 Quest Point")
    player.completeQuest("Old Religion", reward, 8843)