def configure_quest_26():
    quest_id = 26
    quest_name = 'Huntsman at Heart'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_26(player):
    quest_stage = player.getQuest(26).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Huntsman at Heart", "You can start this quest by speaking to the @dre@Combat Instructor", "after completing @dre@Barbaric Troubles@bla@.", " ", " ")
    elif quest_stage == 1:
        player.boxMessage("I need to obtain the fur of 5 bears and 5 wolves.")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Huntsman at Heart@bla@.")

def has_furs(player):
    return player.hasItem(948, 5) and player.hasItem(958, 5) or player.hasItem(949, 5) and player.hasItem(959, 5)
	
def chat_1321453391(player):
    quest_stage = player.getQuest(26).getStage()
    if quest_stage == 0:
        player.playerChat("So, can you train me to become a fearsome warrior", "now that I've helped you?")
        player.nextChat(1321453392)
    elif quest_stage == 1 and has_furs(player):
        player.playerChat("I've got all the furs you wanted.")
        player.nextChat(1195000956)
    elif quest_stage == 1:
        player.playerChat("Where can I find those bears and wolves again?")
        player.nextChat(1321453398)
    elif player.getQuest(27).getStage() == 0:
        player.playerChat("Surely I am ready now?")
        if player.combatLevel > 49:
            player.nextChat(1294369621)
        else:
            player.nextChat(1294369618)
    elif player.getQuest(27).getStage() == 1:
        if player.hasItem(546, 1) and player.hasItem(548, 1) and player.hasItem(1033, 1) and player.hasItem(1035, 1):
            player.playerChat("I did it, I actually did it!", "I slayed those evil wizards!")
            player.nextChat(1294369633)
        else:
            player.playerChat("What were those tips for killing the wizards?")
            player.nextChat(1294369627)
    elif player.getQuest(27).getStage() == 2:
        player.sendMessage("The instructor doesn't seem interested in you anymore.")

def chat_1321453392(player):
    player.npcChat("I'm afraid it's not that simple...")
    player.nextChat(1321453393)

def chat_1321453393(player):
    player.npcChat("... don't be disheartened though, you're making", "some great progress.")
    player.nextChat(1321453394)

def chat_1321453394(player):
    player.playerChat("I'll do whatever it takes.")
    player.nextChat(1321453395)

def chat_1321453395(player):
    player.npcChat("That's the spirit!")
    player.nextChat(1321453396)

def chat_1321453396(player):
    player.npcChat("Our local trader in fur is running low on stock.", "Perhaps you could slay 5 bears and 5 wolves and collect", "their furs as they're worth over 5,000 coins each!")
    player.nextChat(1321453397)

def chat_1321453397(player):
    player.playerChat("5k? That's good to know.")
    player.nextChat(1321453398)

def chat_1321453398(player):
    player.npcChat("You can find them to the east of the cave.")
    player.getQuest(26).setStage(1)
    player.refreshQuestTab()
    player.endChat()

def chat_1195000956(player):
    player.npcChat("Ah thank you, I'll pass them on to the fur trader.")
    player.nextChat(1195000957)

def chat_1195000957(player):
    player.playerChat("Great, how's my progress?")
    player.nextChat(1195000958)

def chat_1195000958(player):
    player.npcChat("You're nearly ready young one.")
    player.nextChat(1195000959)

def chat_1195000959(player):
    player.npcChat("I have a challenging task in mind for you next.")
    player.nextChat(1195000960)

def chat_1195000960(player):
    player.playerChat("Looking forward to it! Can I get my reward now?")
    player.nextChat(1195000961)

def chat_1195000961(player):
    player.npcChat("Oh yes I almost forgot.")
    player.nextChat(1195000962)
    
def chat_1195000962(player):#complete quest
    player.getQuest(26).setStage(2)
    player.addPoints(30)
    player.deleteItem(948, 5)
    player.deleteItem(958, 5)
    player.addItem(995, 500000)
    player.addItem(10586, 1)
    reward = QuestReward("Access to the Fur traders shop,", "500,000 coins and 30 ox points,", "a combat experience lamp", "and 1 quest point.")
    player.completeQuest("Huntsman at Heart", reward, 948)

