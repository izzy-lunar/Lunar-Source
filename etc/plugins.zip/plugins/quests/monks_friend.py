
prayer_experience = 14838
def configure_quest_40():
    quest_id = 40
    quest_name = 'Monks Friend'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addObject(1754, 2561, 3221, 0)#ladder
    World.addNonCombatNpc(279, 2606, 3209, 0, 1)#monk omad
    DefaultGroundItem(90, 1, 2570, 9604, 0)#blanket

def quest_button_40(player):
    quest_stage = player.getQuest(40).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Monks Friend", "I can start this quest by talking to @dre@Brother Omad@bla@ who is.", "located in the Monastery south of @dre@Ardougne@bla@.", "", "There are no requirements for this quest.")
    elif quest_stage == 1:
        player.boxMessage("Brother Omad has asked me to find the childs blanket.")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Monks Friend@bla@.")

def first_click_npc_279(player):
    quest_stage = player.getQuest(40).getStage()
    if quest_stage == 0:
        player.startChat(409341841)
    elif quest_stage == 1 and player.hasItem(90):
        player.startChat(409341857)
    elif quest_stage == 1:
        player.startChat(409341855)
    else:
        player.playerChat("He looks like he needs some rest.")
        player.endChat()
    

def chat_409341855(player):
    player.npcChat("Have you found the blanket yet?")
    player.nextChat(409341856)

def chat_409341856(player):
    player.playerChat("No I'm still looking!")
    player.endChat()
    
def chat_409341841(player):
    player.playerChat("Hello there. What's wrong?")
    player.nextChat(409341842)

def chat_409341842(player):
    player.npcChat("*yawn*... oh, hello... *yawn* I'm sorry! I'm just so tired!", "I haven't slept in a week!")
    player.nextChat(409341843)

def chat_409341843(player):
    player.dialogueOption("Why can't you sleep, what's wrong?", 409341844, "Sorry! I'm too busy to hear about your problems", 58)
    player.nextChat(409341844)

def chat_409341844(player):
    player.playerChat("Why can't you sleep, what's wrong?")
    player.nextChat(409341845)

def chat_409341845(player):
    player.npcChat("It's brother Androe's son! With his constant: Waaaaaah!", "Waaaaaaaah! Androe said it's natura, but it's so", "annoying!")
    player.nextChat(409341846)

def chat_409341846(player):
    player.playerChat("I suppose that's what kids do.")
    player.nextChat(409341847)

def chat_409341847(player):
    player.npcChat("He was fine, up until last week! Thieves broke in! They", "stole his favourite sleeping blanket!")
    player.nextChat(409341848)

def chat_409341848(player):
    player.npcChat("Now he won't rest until it's returned... ...and that", "means neither can I!")
    player.nextChat(409341849)

def chat_409341849(player):
    player.dialogueOption("Can I help at all?", 409341850, "I'm sorry to hear that! I hope you find his blanket.", 1)
    player.nextChat(409341850)

def chat_409341850(player):
    player.playerChat("Can I help at all?")
    player.nextChat(409341851)

def chat_409341851(player):
    player.npcChat("Please do. We won't be able to help you as we are", "peaceful men but we would be grateful for your help!")
    player.getQuest(40).setStage(1)
    player.refreshQuestTab()
    player.nextChat(409341852)

def chat_409341852(player):
    player.playerChat("Where are they?")
    player.nextChat(409341853)

def chat_409341853(player):
    player.npcChat("They hide in a secret cave in the forest. It's hidden", "under a ring of stones. Please, bring back the blanket!")
    player.endChat()

def chat_409341854(player):
    player.playerChat("I'm sorry to hear that! I hope you find his blanket.")
    player.endChat()

def chat_409341855(player):
    player.npcChat("Have you found the blanket yet?")
    player.nextChat(409341856)

def chat_409341856(player):
    player.playerChat("No I'm still looking!")
    player.endChat()

def chat_409341857(player):
    player.playerChat("Hello again monk.")
    player.nextChat(409341858)

def chat_409341858(player):
    player.npcChat("*yawn* ...oh, hello again... *yawn*")
    player.nextChat(409341859)

def chat_409341859(player):
    player.npcChat("Please tell me you have the blanket.")
    player.nextChat(409341860)

def chat_409341860(player):
    player.playerChat("Yes! I've recovered it from the clutches of the evil", "thieves!")
    player.nextChat(409341861)

def chat_409341861(player):
    player.boxMessage("You hand the monk the childs blanket.")
    player.nextChat(409341862)

def chat_409341862(player):
    player.npcChat("Really, that's excellent, well done! Maybe now I will be", "able to get some rest.")
    player.nextChat(409341863)

def chat_409341863(player):
    player.npcChat("*yawn*... I'm off to bed! Farewell brave traveller!")
    player.nextChat(409341864)
    
def chat_409341864(player):
    player.deleteItem(90)
    player.addItem(995, 2000000)
    player.getQuest(40).setStage(2)
    player.refreshQuestTab()
    player.getFunction().addSkillXP(14838, player.playerPrayer)
    player.endChat()
    reward = QuestReward("1 Quest Point", "2 Million Coins", "14,838 Prayer Exp")
    player.completeQuest("Monks Friend", reward, 90)