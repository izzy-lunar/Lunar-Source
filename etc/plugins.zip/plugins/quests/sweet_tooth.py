#Author Parrot
#Quest Length = Short

#NPCs
gypsy_aris_id = 882
caroline_id = 696

#Items
red_sweets = 4562

#Quest configuration
def configure_quest_5():
    quest_id = 5
    quest_name = 'Sweet Tooth'
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(gypsy_aris_id, 3203, 3424, 0, 1)
    World.addNonCombatNpc(caroline_id, 2675, 3308, 0, 1)

#Quest button
def quest_button_5(player):
    quest_stage = player.getQuest(5).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Sweet Tooth", "I can start this quest by talking to", "@dre@Gypsy Aris@bla@ near the Varrock fountain.", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should find Gypsy Aris's friend Caroline.")
    elif quest_stage == 2:
        player.boxMessage("I should tell Gypsy Aris that Caroline has the sweets.")
    elif quest_stage == 3:
        player.boxMessage("I have completed the @dre@Sweet Tooth@bla@ quest.")
        
#Red sweets
def click_item_4562(player):
    player.playerChat("These are for Caroline! I better not eat them.")
    player.endChat()
    
#Gypsy Aris
def first_click_npc_882(player):
    quest_stage = player.getQuest(5).getStage()
    if quest_stage == 0:
        player.startChat(92150)
    elif quest_stage == 1:
        player.startChat(92050)
    elif quest_stage == 2:
        player.startChat(92350)
    elif quest_stage == 3:
        handle_gypsy_party(player)
    else:
        player.playerChat("I better not disturb Gypsy Aris...")
        player.endChat()
#Caroline
def first_click_npc_696(player):
    quest_stage = player.getQuest(5).getStage()
    if quest_stage == 0:
        player.playerChat("She looks pretty upset...")
        player.endChat()
    elif quest_stage == 1:
        player.startChat(92200)
    elif quest_stage == 2:
        player.startChat(92400)
    elif quest_stage == 3:
        handle_caroline_party(player)
    else:
        player.playerChat("I better not disturb Caroline...")
        player.endChat()
        
#Stage 0
def chat_92150(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(92151)

def chat_92151(player):
    player.npcChat("Hi " + str(player.playerName) + ", what brings you to the", "city of Varrock today?")
    player.nextChat(92152)

def chat_92152(player):
    player.dialogueOption("Nothing much.", 92153, "I'm looking for quests!", 92154)
    
def chat_92153(player):
    player.playerChat("Nothing much.")
    player.endChat()

def chat_92154(player):
    player.playerChat("I'm looking for quests!")
    player.nextChat(92155)

def chat_92155(player):
    player.npcChat("I do have a little task for you actually.")
    player.nextChat(92156)

def chat_92156(player):
    player.playerChat("What would you like me to do?")
    player.nextChat(92157)

def chat_92157(player):
    player.npcChat("I have some sweets here for my friend.", "She's feeling a little upset at the moment and could", "do with a little cheering up!")
    player.nextChat(92158)

def chat_92158(player):
    player.playerChat("So you want me to give them to her?", "Why can't you do it?")
    player.nextChat(92159)

def chat_92159(player):
    player.npcChat("Well yes please! There's no way for me to get to her!")
    player.nextChat(92160)

def chat_92160(player):
    player.playerChat("Why? Where does she live?")
    player.nextChat(92161)

def chat_92161(player):
    player.npcChat("She lives in Ardougne, that's too far", "for me to travel alone.")
    player.nextChat(92162)

def chat_92162(player):
    player.dialogueOption("I can deliver the sweets to her.", 92163, "Sorry, that's too far for me.", 92164)

def chat_92163(player):
    player.playerChat("I can deliver the sweets to her.")
    player.nextChat(92167)

def chat_92164(player):
    player.playerChat("Sorry, that's too far for me.")
    player.nextChat(92165)

def chat_92165(player):
    player.boxMessage("She looks dissapointed, but nods her head.")
    player.nextChat(92166)

def chat_92166(player):
    player.npcChat("Not to worry.", "Feel free to come back if you change your mind.")
    player.endChat()

def chat_92167(player):
    player.npcChat("Excellent! Her name is Caroline, you'll find", "her situated in Ardougne.")
    player.nextChat(92168)

def chat_92168(player):
    player.playerChat("Okay, I'll try and find her!")
    player.nextChat(92169)

def chat_92169(player):
    if player.hasInventorySpace(1):
        player.addItem(red_sweets)
        player.getQuest(5).setStage(1)
        player.refreshQuestTab()
        player.npcChat("Oops, I nearly forgot! Here's the sweets she'll like...")
        player.nextChat(92170)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for these sweets.")

def chat_92170(player):
    player.playerChat("Phew, that was close.", "I'll let you know when she's received them!")
    player.endChat()
    
#Stage 1 (Gypsy)
def chat_92050(player):
    player.npcChat("Have you given her the sweets yet?")
    player.nextChat(92051)

def chat_92051(player):
    player.playerChat("Not yet!")
    player.endChat()

#Stage 2 (Caroline)
def chat_92200(player):
    player.playerChat("Hey Caroline!")
    player.nextChat(92201)

def chat_92201(player):
    player.npcChat("What do you want?")
    player.nextChat(92202)

def chat_92202(player):
    player.playerChat("I have a present from Gypsy Aris for you.")
    player.nextChat(92203)

def chat_92203(player):
    player.npcChat("What present?!")
    player.nextChat(92204)

def chat_92204(player):
    player.boxMessage("Her face lightens up a little.")
    player.nextChat(92205)

def chat_92205(player):
    player.playerChat("Some red sweets, she said you liked them.")
    player.nextChat(92206)

def chat_92206(player):
    player.npcChat("They are my favorite!")
    player.nextChat(92207)

def chat_92207(player):
    if player.hasItem(red_sweets):
        player.deleteItem(red_sweets)
        player.getQuest(5).setStage(2)
        player.refreshQuestTab()
        player.playerChat("Here you go then.")
        player.nextChat(92208)
    else:
        player.playerChat("Woops, I forgot to bring them. I'll be back soon.")
        player.endChat()

def chat_92208(player):
    player.boxMessage("She definitely looks happier, Gypsey Aris will be pleased.")
    player.endChat()

#Stage 3 (Gypsy)
def chat_92350(player):
    player.npcChat("Have you given her the sweets yet?")
    player.nextChat(92351)

def chat_92351(player):
    player.playerChat("Yes! She looks a lot happier now.")
    player.nextChat(92352)

def chat_92352(player):
    player.npcChat("Great! Thanks a lot.")
    player.nextChat(92353)

def chat_92353(player):
    player.endChat()
    player.getQuest(5).setStage(3)
    player.refreshQuestTab()
    player.addCash(150000)
    player.addPoints(20)
    player.addItem(10476, 100)
    reward = QuestReward("150,000 coins", "20 OXP", "100 Purple Sweets", "1 Quest Point")
    player.completeQuest("Sweet Tooth", reward, 10476)

def chat_92450(player):
    player.npcChat("Thanks for helping me out before!")
    player.nextChat(92451)

def chat_92451(player):
    player.playerChat("No problem, you're welcome.")
    player.endChat()

def chat_92400(player):
    player.npcChat("Thanks for delivering those sweets!")
    player.endChat()