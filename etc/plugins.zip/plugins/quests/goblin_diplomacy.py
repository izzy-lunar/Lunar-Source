
from com.ownxile.core import World

#Author Hawk
#Quest Length = Short

#NPCs
general_wartface_id = 4494
grubfoot_id = 4496

#Items
goblin_mail = 288

#Quest configuration
def configure_quest_9():
    World.addCombatNpc(100, 2954, 3503, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2959, 3500, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2953, 3499, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2950, 3504, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2961, 3505, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2953, 3506, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2950, 3501, 0, 1, 7, 1, 1, 1)
    World.addCombatNpc(100, 2956, 3496, 0, 1, 7, 1, 1, 1)
    quest_id = 9
    quest_name = "Goblin Diplomacy"
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(general_wartface_id, 2956, 3508, 0, 1)
    World.addNonCombatNpc(grubfoot_id, 3247, 3246, 0, 1)

def wear_item_288(player):
    player.sendMessage("That armour designed to fit goblins, not humans!")
    
#Quest button
def quest_button_9(player):
    quest_stage = player.getQuest(9).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Goblin Diplomacy", "I can start this quest by talking to", "@dre@General Wartface@bla@ at the goblin village.", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should find General Wartface's friend Grubfoot.")
    elif quest_stage == 2:
        player.boxMessage("I should tell general Wartface that Grubfoot has the Armour.")
    elif quest_stage == 3:
        player.boxMessage("I have completed the @dre@Goblin Diplomacy@bla@ quest.")
        
#Red sweets
def click_item_288(player):
    player.playerChat("I can't fit into this! It's way too small.")
    player.endChat()
    
#General Wartface
def first_click_npc_4494(player):
    quest_stage = player.getQuest(9).getStage()
    if quest_stage == 0:
        player.startChat(92151230)
    elif quest_stage == 1:
        player.startChat(92051230)
    elif quest_stage == 2:
        player.startChat(92351230)
    elif quest_stage == 3:
        player.startChat(92451230)
    else:
        player.npcChat("Go away pesky human!")
#Grubfoot
def first_click_npc_4496(player):
    quest_stage = player.getQuest(9).getStage()
    if quest_stage == 0:
        player.npcChat("I hate this f*cking dirty a$$ swamp.")
    elif quest_stage == 1:
        player.startChat(92201230)
    else:
        player.npcChat("Thanks for the armour, friend.")
        
#Stage 0
def chat_92151230(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(92151231)

def chat_92151231(player):
    player.npcChat("Human, what you want?", "why you disturb me?")
    player.nextChat(92151232)

def chat_92151232(player):
    player.dialogueOption("Nothing much.", 92151233, "I'm looking for quests!", 92151234)
    
def chat_92151233(player):
    player.playerChat("Nothing much.")
    player.endChat()

def chat_92151234(player):
    player.playerChat("I'm looking for quests!")
    player.nextChat(92151235)

def chat_92151235(player):
    player.npcChat("Quest you say? Hmmm, come here, come here!.")
    player.nextChat(92151236)

def chat_92151236(player):
    player.playerChat("What would you like me to do?")
    player.nextChat(92151237)

def chat_92151237(player):
    player.npcChat("I have new shiny armour for friend, Grubfoot.", "took whole of 5th age for me to make!")
    player.nextChat(92151238)

def chat_92151238(player):
    player.playerChat("So you want me to give them to him??", "Why can't you do it?")
    player.nextChat(92151239)

def chat_92151239(player):
    player.npcChat("Yes stupid human! if I leave here, me die!")
    player.nextChat(92161230)

def chat_92161230(player):
    player.playerChat("Why? Where does he live?")
    player.nextChat(92161231)

def chat_92161231(player):
    player.npcChat("He lives in Lumbridge, you humans kill Goblin", "like it's some sort of game!")
    player.nextChat(92161232)

def chat_92161232(player):
    player.dialogueOption("Fine, I'll deliver the armour.", 92161233, "Sorry, that's too far for me.", 92161234)

def chat_92161233(player):
    player.playerChat("Fine, I'll deliver the armour.")
    player.nextChat(92161237)

def chat_92161234(player):
    player.playerChat("Sorry, that's too far for me.")
    player.nextChat(92161235)

def chat_92161235(player):
    player.boxMessage("He looks outraged, but lets out a sigh.")
    player.nextChat(92161236)

def chat_92161236(player):
    player.npcChat("You human only think for self.", "never about other people.")
    player.endChat()

def chat_92161237(player):
    player.npcChat("Thank you human, he in big city of Lumbridge.")
    player.nextChat(92161238)

def chat_92161238(player):
    player.playerChat("Okay, I'll try and find him!")
    player.nextChat(92161239)

def chat_92161239(player):
    if player.hasInventorySpace(1):
        player.addItem(goblin_mail)
        player.getQuest(9).setStage(1)
        player.refreshQuestTab()
        player.npcChat("Wait stupid human, you forgot precious armour!")
        player.nextChat(92171230)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for the armour.")

def chat_92171230(player):
    player.playerChat("Erm, thanks... I guess.")
    player.endChat()
    
#Stage 1 (General)
def chat_92051230(player):
    player.npcChat("Human have delivered the armour yet?")
    player.nextChat(92051231)

def chat_92051231(player):
    player.playerChat("Not yet.")
    player.endChat()

#Stage 2 (Grubfoot)
def chat_92201230(player):
    player.playerChat("Hey Grubfoot!")
    player.nextChat(92201231)

def chat_92201231(player):
    player.npcChat("What you want?")
    player.nextChat(92201232)

def chat_92201232(player):
    player.playerChat("I have a present from General Wartface for you.")
    player.nextChat(92201233)

def chat_92201233(player):
    player.npcChat("What present?!")
    player.nextChat(92201234)

def chat_92201234(player):
    player.boxMessage("His face turns slightly greener.")
    player.nextChat(92201235)

def chat_92201235(player):
    player.playerChat("A nice set of armour for you, He said need it!")
    player.nextChat(92201236)

def chat_92201236(player):
    player.npcChat("I do, look at me, Human, I'm bare!")
    player.nextChat(92201237)

def chat_92201237(player):
    if player.hasItem(goblin_mail):
        player.deleteItem(goblin_mail)
        player.getQuest(9).setStage(2)
        player.refreshQuestTab()
        player.playerChat("Here you go then.")
        player.nextChat(92201238)
    else:
        player.playerChat("Whoops, I forgot to bring it. I'll be back soon.")
        player.endChat()

def chat_92201238(player):
    player.boxMessage("He definitely looks happier, General Wartface will be pleased.")
    player.endChat()

#Stage 3 (General)
def chat_92351230(player):
    player.npcChat("Human, have you given him armour yet?")
    player.nextChat(92351231)

def chat_92351231(player):
    player.playerChat("Yes! He looks a lot better now.")
    player.nextChat(92351232)

def chat_92351232(player):
    player.npcChat("Thank you human, here, take this as thank you.")
    player.nextChat(92351233)

def chat_92351233(player):
    player.endChat()
    player.getQuest(9).setStage(3)
    player.refreshQuestTab()
    player.addPoints(10)
    player.addItem(10581, 1)
    player.getTask().addSkillXP(25000, player.getLevelId("agility"))
    reward = QuestReward("25,000 Agility XP", "10 OXP", "1 Quest Point", "The Keris")    
    player.completeQuest("Goblin Diplomacy", reward, 10581)
    
def chat_92451230(player):
    player.npcChat("Thank you, goblin forever in debt to you, Human")
    player.nextChat(92451231)

def chat_92451231(player):
    player.playerChat("No problem, you're welcome.")
    player.endChat()

def chat_92401230(player):
    player.npcChat("Thank you, goblin forever in debt to you, Human!")
    player.endChat()