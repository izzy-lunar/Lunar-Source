# Quest Name: Roving Elves II
# Quest Author: Aram Hami
# Date Created: 2/20/2015
# Quest Length: Extremely Long

#NPCs
Islwyn = 1680

#Items
crystals = 4211
reg_logs = 2
money = 995
turtles = 395
seed = 4205
w_bones = 6812


iswyn_spawn = World.addNonCombatNpc(Islwyn, 2180, 3187, 0, 1)

#Quest configuration

def configure_quest_32():
    quest_id = 32
    quest_name = 'Roving Elves II'
    quest_stages = 13
    World.addQuest(quest_id, quest_name, quest_stages)

#Quest button
def quest_button_32(player):
    quest_stage = player.getQuest(32).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Roving Elves II", "I can start this quest by speaking to @dre@Lord Iorwerth@bla@ in @dre@Elf Camp@bla@.", "You must have 80 agility, 93 slayer and 95 prayer", "to complete this quest.", "I also need to have finished @dre@Roving Elves I@bla@.")
    elif quest_stage == 1:
        player.boxMessage("I should speak to @dre@Islwyn@bla@ north of the Tyras camp.")
    elif quest_stage == 2:
        player.boxMessage("I should bring @dre@Islwyn@bla@ the @dre@5@blu@ elf crystals@bla@.")
    elif quest_stage == 3:
        player.boxMessage("I must speak to @dre@Arianwyn@bla@ located in @fre@Lleyta@bla@.", "I think it's about how we're going to win the war.")
    elif quest_stage == 4:
        player.boxMessage("I should speak to @dre@Islwyn@bla@ north of the Tyras camp.")
    elif quest_stage == 5:
        player.boxMessage("I must bring back @dre@Islwyn@blu@ 100 cannonballs@bla@.")
    elif quest_stage == 6:
        player.boxMessage("I must bring back @dre@Islwyn@blu@ 100,000 coins@bla@.")
    elif quest_stage == 7:
        player.boxMessage("I must bring back @dre@Islwyn@blu@ 25 un-noted wyvern bones@bla@.")
    elif quest_stage == 8:
        player.boxMessage("I must bring back @dre@Islwyn@blu@ 25 un-noted cooked sea turtles@bla@.")
    elif quest_stage == 9:
        player.boxMessage("I must tell @dre@Arianwyn@bla@ that the @dre@Elven Clan@bla@ has", "successfully defeated the @dre@Dark Lord@bla@.")
    elif quest_stage == 10:
        player.boxMessage("I must speak to @dre@Islwyn@bla@ to give him his seed.")
    elif quest_stage == 11:
        player.boxMessage("I must speak to @dre@Islwyn@bla@ again to claim my reward.")
    elif quest_stage == 12:
        player.boxMessage("I must inform the Elven guard of our progress!")
    elif quest_stage == 13:
        player.boxMessage("You have completed @dre@Roving Elves II@bla@.")

#Lord Iorwerth

def first_click_npc_1182(player):
    agility_level = player.getLevel("agility")
    slayer_level = player.getLevel("slayer")
    prayer_level = player.getLevel("prayer")
    quest_stage = player.getQuest(32).getStage()
    if quest_stage == 0 and agility_level > 79 and slayer_level > 92 and prayer_level > 94 and player.getQuest(28).getStage() == 16:
        player.startChat(800000000)
    else:
        player.sendMessage("He doesn't look like he wants to talk right now.")

#Islwyn
def first_click_npc_1680(player):
    quest_stage = player.getQuest(32).getStage()
    if quest_stage == 1:
        player.startChat(800000016)
    elif quest_stage == 2 and player.hasItem(crystals, 5):
        player.startChat(800000025)
    elif quest_stage == 4:
        player.startChat(800000040)
    elif quest_stage == 5 and player.hasItem(reg_logs, 100):
        player.startChat(800000042)
    elif quest_stage == 6 and player.hasItem(money, 100000):
        player.startChat(800000044)
    elif quest_stage == 7 and player.hasItem(w_bones, 28):
        player.startChat(800000046)
    elif quest_stage == 8 and player.hasItem(turtles, 28):
        player.startChat(800000048)
    elif quest_stage == 10 and player.hasItem(seed, 1):
        player.startChat(800000056)
    else:
        iswyn_spawn.forceChat("Hurry up " + str(player.playerName) + "!")
        player.endChat()

#Chat dialogues    
def chat_800000000(player):
    player.npcChat("In the name of the @dre@Dark Lord@bla@ may @dre@Seren@bla@ fall", "to her feet.")
    player.nextChat(800000001)

def chat_800000001(player):
    player.npcChat("Her might will not prevail as we will win this Elven War.")
    player.nextChat(800000002)
    
def chat_800000002(player):
    player.npcChat("To those who try to make us fail shall they", "fear the wrath of the @dre@Dark Lord@bla@!")
    player.nextChat(800000003)
    
def chat_800000003(player):
    player.playerChat("Uhm, maybe I shouldn't be here...")
    player.nextChat(800000004)
    
def chat_800000004(player):
    player.boxMessage("You look around scared, wondering what to do.")
    player.nextChat(800000005)
    
def chat_800000005(player):
    player.playerChat("I don't know what's going on but I got to get out of here!")
    player.nextChat(800000006)

def chat_800000006(player):
    player.dialogueOption("Accept Quest", 800000007, "Decline Quest", 810000048)

def chat_800000007(player):
    player.getQuest(32).setStage(1)
    player.refreshQuestTab()
    player.boxMessage("The @dre@Lord@bla@ notices your presence nearby...")
    player.nextChat(800000008)
    
def chat_800000008(player):
    player.npcChat("A human! How sweet, what are you doing here?!")
    player.nextChat(800000009)

def chat_800000009(player):
    player.playerChat("I'm just, uh...walking around?")
    player.nextChat(800000010)
    
def chat_800000010(player):
    player.npcChat("I know what you're trying to do!", "You cannot spoil my plans with the @dre@Dark Lord@bla@.")
    player.nextChat(800000011)
    
def chat_800000011(player):
    player.playerChat("Plans? What pla -- oh, my...")
    player.nextChat(800000012)
    
def chat_800000012(player):
    player.boxMessage("You remember @dre@Sir Tiffy Cashien@bla@ stating an Elven War.", "You also realize that these 'plans' mark the beginning of the Elven War.")
    player.nextChat(800000013)
    
def chat_800000013(player):
    player.playerChat("You left @dre@Seren@bla@ for the @dre@Dark Lord@bla@. You're nothing but", "a betrayer in the eyes of the Elven clan.")
    player.nextChat(800000014)
    
def chat_800000014(player):
    player.npcChat("How do you know this? Well, it doesn't matter.", "You're nothing but a peasant.")
    player.nextChat(800000015)
    
def chat_800000015(player):
    player.playerChat("We'll see about that, traitor.", "I have to get a hold of @dre@Seren's follower@bla@ Islwyn, now!")
    player.endChat()

def chat_800000016(player):
    player.playerChat("Islwyn! I just saw @dre@Lord IorwerthZ@bla@. He and the @dre@Dark Lord@bla@", "are getting ready to begin a war.")
    player.nextChat(800000017)    
    
def chat_800000017(player):
    player.npcChat("I knew that the bloodshed would spread again one day...", "This is going to be an @dre@Elven War@bla@ we must win.")
    player.nextChat(800000018)
    
def chat_800000018(player):
    player.npcChat("Alright, I need your help adventurer. I need you to collect", "@blu@5 elf crystals@bla@. These crystals allow us to generate", "enough elf magic to help us win this war.")
    player.nextChat(800000019)

def chat_800000019(player):
    player.playerChat("How do I obtain such @blu@elf crystals@bla@?")
    player.nextChat(800000020)
    
def chat_800000020(player):
    player.npc("There are different ways you can acquire such crystals.", "They are worn by our elf warriors who protect the elf magic from others.")
    player.nextChat(800000021)
    
def chat_800000021(player):
    player.npcChat("Because we are Elven, we cannot practice violence against our own kind.", "A daring human like yourself, however, is a different story." )
    player.nextChat(800000022)
    
def chat_800000022(player):
    player.npcChat("You are also able to obtain them through other adventurers around the land", "of OwnXile. Some have tried to help us in past wars and have failed.", "Perhaps a few might still have some available to obtain through trading.")
    player.nextChat(800000023)
    
def chat_800000023(player):
    player.npcChat("You MUST be very careful. These crystals possess magic", "even sometimes beyond our own control.")
    player.nextChat(800000024)
    
def chat_800000024(player):
    player.getQuest(32).setStage(2)
    player.refreshQuestTab()
    player.playerChat("You can count on me.", "Right, @dre@Elf Warriors@bla@ and @dre@players@bla@.")
    player.endChat()
    
def chat_800000025(player):
    player.npcChat("Have you gotten the @blu@5 crystals@bla@ yet?")
    player.nextChat(800000026)
    
def chat_800000026(player):
    player.playerChat("Yes, I have!", "Here they are.")
    player.nextChat(800000027)
    
def chat_800000027(player):
    if player.hasItem(crystals, 5):
        player.deleteItem(crystals, 5)
        player.boxMessage("You hand over the @blu@Elf crystals@bla@.")
        player.getQuest(32).setStage(3)
        player.refreshQuestTab()
        player.nextChat(800000028)
    else:
        player.playerChat("Actually, I don't have them. I'll return when I do.")
        player.endChat()
    
def chat_800000028(player):
    player.npcChat("Fantastic.")
    player.nextChat(800000029)
   
def chat_800000029(player):
    player.npcChat("I need you to speak to @dre@Arianwyn@bla@. You can find him in @dre@Lleyta@bla@.")
    player.endChat()

def chat_800000030(player):
    player.npcChat("Ah! The adventurer I was looking for.")
    player.nextChat(800000031)
    
def chat_800000031(player):
    player.playerChat("It's nice to see you again Arianwyn,", "I'm here to help with the war effort.")
    player.nextChat(800000032)
    
def chat_800000032(player):
    player.npcChat("Excellent! We need all the assistance we can get.")
    player.nextChat(800000033)

def chat_800000033(player):
    player.playerChat("Right, got it.", "What can I do to help the elves?")
    player.nextChat(800000034)
    
def chat_800000034(player):
    player.npcChat("Our troops are dying quickly on the frontline, it appears", "that the Dark Lord has invaded the city of Priffdinas!")
    player.nextChat(800000035)

def chat_800000035(player):
    player.npcChat("We're losing troops quickly on the frontline, we need", "more resources as soon as possible!")
    player.nextChat(800000036)
    
def chat_800000036(player):
    player.getQuest(32).setStage(4)
    player.refreshQuestTab()
    player.npcChat("Please notify Iorwerth immediateley!")
    player.nextChat(800000037)
    
def chat_800000037(player):
    player.boxMessage("The dark lord has marked you as a target.")
    player.gfx100(1003)
    player.nextChat(800000038)
    
def chat_800000038(player):
    player.npcChat("Shit, if Prifddinas falls then Lleyta will be next!", "Get over to the Tyras camp!")
    player.sendMessage("The war has now begun, elven lands are no longer safe.")
    player.nextChat(700000039)
    
def chat_800000039(player):
    player.playerChat("I'll speak to @dre@Iorwerth@bla@ immediately!")
    player.endChat()
    
def chat_800000040(player):
    player.npcChat("We need more ammunition for the Catapult!")
    player.nextChat(800000041)
    
def chat_800000041(player):
    player.getQuest(32).setStage(5)
    player.refreshQuestTab()
    player.npcChat("Fetch me 100 cannonballs from the dwarves!")
    player.sendMessage("The elven energy from the crystals is waining, lowering their powers.")
    player.sendMessage("The city of Prifddinas is struggling to hold out.")
    player.endChat()
    
def chat_800000042(player):
    if player.hasItem(reg_logs, 100):
        player.deleteItem(reg_logs, 100)
        player.playerChat("I have the cannonballs!")
        player.nextChat(800000043)
        player.gfx100(1006)
    else:
        player.playerChat("I'll be back with those cannonballs.")
        player.endChat()

def chat_800000043(player):
    player.getQuest(32).setStage(6)
    player.refreshQuestTab()
    player.npcChat("Thanks, we need 100,000 coins to purchase some supplies.")
    player.sendMessage("It's been a while, the elves seem to lose three of five magic elf crystals.")
    player.sendMessage("It's not looking so well for the elven clan.")
    player.endChat()
    
def chat_800000044(player):
    if player.hasItem(money, 100000):
        player.deleteItem(money, 100000)
        player.playerChat("Here's the money!")
        player.nextChat(800000045)
        player.gfx100(1006)
    else:
        player.npcChat("I'll be back with that @grd@100k@bla@.")
        player.endChat()
    
def chat_800000045(player):
    player.getQuest(32).setStage(7)
    player.refreshQuestTab()
    player.npcChat("Thanks, we need 20 wyvern bones to give to the", "gods for prayer bonuses. That should strengthen our walls.")
    player.sendMessage("The elven clan regains some energy and has is fighting hard for Priffdinas!")
    player.endChat()
    
def chat_800000046(player):
    if player.hasItem(w_bones, 20):
        player.deleteItem(w_bones, 20)
        player.playerChat("Here are the bones you wanted!")
        player.nextChat(800000047)
        player.gfx100(1006)
    else:
        player.npcChat("I'll be back with those @dre@20 wyvern bones@bla@.")
        player.endChat()

def chat_800000047(player):
    player.getQuest(32).setStage(8)
    player.refreshQuestTab()
    player.npcChat("Thanks, we need 25 un-noted sea turtles for our elven troops.", "They're in need of more energy.")
    player.sendMessage("The Elven clan is very weak and needs food to restore their energy and health.")
    player.endChat()
    
def chat_800000048(player):
    if player.hasItem(turtles, 25):
        player.deleteItem(turtles, 25)
        player.playerChat("Here is the food you needed!")
        player.nextChat(800000049)
        player.gfx100(1006)
    else:
        player.npcChat("I'll be back with those @dre@25 cooked sea turtles@bla@.")
        player.endChat()
    
def chat_800000049(player):
    player.getQuest(32).setStage(9)
    player.refreshQuestTab()
    player.npcChat("Thanks!")
    player.nextChat(800000050)
    
def chat_800000050(player):
    player.boxMessage("@dre@Lord Iorwerth@bla@ and @dre@The Dark Lord@bla@ have retreated.")
    player.nextChat(800000051)
    
def chat_800000051(player):
    player.boxMessage("You feel a gust of Elven magic energy around your pixelated body...")
    player.nextChat(800000052)
    
def chat_800000052(player):
    player.npcChat("That was incredible! Thank you very much.", "Please tell @dre@Arianwyn@bla@ the news!")
    player.endChat()
        
def chat_800000053(player):
    player.playerChat("We've won the battle, I think we're safe for now!")
    player.nextChat(800000054)
	
def chat_800000054(player):
    player.npcChat("This is incredible news!", "Please, take this to @dre@Islwyn@bla@. It's crucial that", "he has this particular item.")
    player.nextChat(800000055)
	
def chat_800000055(player):
    if player.hasInventorySpace(1):
        player.addItem(seed)
        player.playerChat("Sounds good to me.")
        player.getQuest(32).setStage(10)
        player.refreshQuestTab()
        player.endChat()
    else:
        player.sendMessage("You need an empty inventory space to continue.")
        player.endChat()
		
def chat_800000056(player):
    player.playerChat("I think this is for you!")
    player.nextChat(800000057)
	
def chat_800000057(player):
    if player.hasItem(seed, 1):
        player.deleteItem(seed, 1)
        player.boxMessage("You hand over the @dre@seed@bla@.")
        player.getQuest(32).setStage(11)
        player.refreshQuestTab()
        player.nextChat(800000058)
    else:
        player.npcChat("You must bring me the @dre@seed@bla@.")
        player.endChat()
		
def chat_800000058(player):
    player.npcChat("The battle is won but the war goes on,")
    player.nextChat(800000059)

def chat_800000059(player):
    player.npcChat("The Prifddinas guardsmen are very pleased,", "I'm sure they will reward you kindly.")
    player.getQuest(32).setStage(12)
    player.endChat()

def chat_800000061(player):
    player.playerChat("I bring excellent news, the battle has been won!")
    player.nextChat(800000062)
	
def chat_800000062(player):
    player.npcChat("Interesting, we elves can soon return to our home city.")
    player.nextChat(800000063)
	
def chat_800000063(player):
    player.npcChat("I shall spread the message of your good work.", "Welcome to the Elven clan " + str(player.playerName) + "!")
    player.nextChat(800000060)
	
def chat_800000060(player):
    if player.hasInventorySpace(2):
        player.getQuest(32).setStage(13)
        player.endChat()
        player.addItem(11716)
        player.addItem(4447)
        player.getFunction().addSkillXP(250000, player.playerAgility)
        player.addPoints(500)
        player.qp += 2
        reward = QuestReward("Zamorakian Spear", "500 OXP", "250k Agility Experience", "Antique Lamp", "3 Quest Points")
        player.completeQuest("Roving Elves II", reward, 11716)  
    else:
        player.boxMessage("You must have 2 empty inventory spaces to continue.")
        player.endChat()
