white = 20
black = 21
blue = 22
red = 23

lever = 34
door = 39

DefaultGroundItem(21, 1, 2610, 9639, 0)#black cog
DefaultGroundItem(23, 1, 2583, 9613, 0)#red cog
DefaultGroundItem(20, 1, 2564, 9661, 0)#white cog
DefaultGroundItem(22, 1, 2576, 9631, 0)#blue cog

def configure_quest_39():
    quest_id = 39
    quest_name = 'Clock Tower'
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(223, 2568, 3248, 0, 1)

def fix_tower(player):
    if player.hasItem(20) and player.hasItem(21) and player.hasItem(22) and player.hasItem(23):
        player.sendMessage("You place all the cogs on in their correct positions...")
        player.getTask().delayMessage(".... you hear some creaking noices as the cogs rattle around ...", 2)
        player.getTask().delayMessage(".... a strange humming noices starts taking place ...", 4)
        player.getTask().delayMessage(".... the clock begins to tick!", 6)
        player.getTask().delayMessage("The tower is fixed, you should notify Brother Kojo.", 8)
        player.deleteItem(20)
        player.deleteItem(21)
        player.deleteItem(22)
        player.deleteItem(23)
        player.getQuest(39).setStage(2)
        player.startAnimation(827)
    else:
        player.boxMessage("You need all the cogs to do this.")

def use_item_23_on_object_29(player):
    fix_tower(player)
def use_item_23_on_object_25(player):
    fix_tower(player)
def use_item_21_on_object_26(player):
    fix_tower(player)
def use_item_21_on_object_30(player):
    fix_tower(player)
def use_item_22_on_object_28(player):
    fix_tower(player)

def quest_button_39(player):
    quest_stage = player.getQuest(39).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Clock Tower", "I can start this quest by talking to @dre@Brother Koho@bla@ who is.", "located in the house south west of @dre@Ardougne Zoo@bla@.", "", "There are no requirements for this quest.")
    elif quest_stage == 1:
        player.boxMessage("Brother Kojo has asked me to fix the tower. I should head under his house and obtain", "the various cogs and place them in their correct places.")
    elif quest_stage == 2:
        player.boxMessage("The tower is fixed, I should let Kojo know!")
    elif quest_stage == 3:
        player.boxMessage("I have completed @dre@Clock Tower@bla@.")
        
def first_click_npc_223(player):
    quest_stage = player.getQuest(39).getStage()
    if quest_stage == 0:
        player.startChat(36434340)
    elif quest_stage == 1:
        player.startChat(3094496)
    elif quest_stage == 2:
        player.startChat(943405614)
    elif quest_stage == 3:
        player.startChat(943405614)
        
def chat_943405617(player):
    player.addItem(995, 3000000)
    player.getQuest(39).setStage(3)
    player.refreshQuestTab()
    player.getFunction().addSkillXP(42000, player.playerCrafting)
    player.getFunction().addSkillXP(57000, player.playerThieving)
    player.endChat()
    reward = QuestReward("1 Quest Point", "2 Million Coins", "42,000 Crafting Exp", "57,000 Thieving Exp")
    player.completeQuest("Clock Tower", reward, 22)