##################################
###     Author: Eisenhower     ###
###     Date:   5.11.2013      ###
##################################

#Quest configuration

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem

def configure_quest_22():
    quest_id = 22
    quest_name = 'Birthday Party'
    quest_stages = 7
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(3921, 3036, 3344, 0, 1)

red_berries = 1951
red_dye = 1763
purp_sweets = 10476

#Quest button
def quest_button_22(player):
    quest_stage = player.getQuest(22).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Birthday Party","I can start this quest by talking to", "@dre@Gypsy Aris@bla@ near the Varrock fountain.", "You must have completed @dre@Sweet Tooth@bla@ to do this quest.", "")
    elif quest_stage == 1:
        player.boxMessage("I should find @dre@Gypsy Aris's@bla@ friend Halla in Falador.")
    elif quest_stage == 2:
        player.boxMessage("I should obtain the remaining ingredients.")
    elif quest_stage == 3:
        player.boxMessage("I should ask @dre@Caroline@bla@ how many sweets she wants.")
    elif quest_stage == 4:
        player.boxMessage("I should tell @dre@Gypsy Aris@bla@ that Caroline wants 5 packs of sweets.")
    elif quest_stage == 5:
        player.boxMessage("I should deliver the sweets to @dre@Caroline@bla@ for her party.")
    elif quest_stage == 6:
        player.boxMessage("I should tell @dre@Gypsy Aris@bla@ that Caroline has the sweets.")
    elif quest_stage == 7:
        player.boxMessage("I have completed the @dre@Birthday Party@bla@ quest.")

# Red dye shop
red_dye_shop = Shop("Halla's Supplies", 55)
red_dye_shop.addItem(ShopItem(1763, 10))        
        
#Red sweets
def click_item_4562(player):
    player.playerChat("These are for Caroline! I better not eat them.")
    player.endChat()
    
#Gypsy Aris
def handle_gypsy_party(player):
    quest_stage = player.getQuest(22).getStage()
    if quest_stage == 0:
        player.startChat(1360164388)
    elif quest_stage == 1:
        player.startChat(1360164484)
    elif quest_stage == 2:
        player.startChat(1360164442)
    elif quest_stage == 3:
        player.startChat(1360164486)
    elif quest_stage == 4:
        player.startChat(1360164458)
    elif quest_stage == 5:
        player.startChat(1360164488)
    elif quest_stage == 6:
        player.startChat(1360164478)
    else:
        player.startChat(1360164482)
        
#Caroline
def handle_caroline_party(player):
    quest_stage = player.getQuest(22).getStage()
    if quest_stage == 3:
        player.startChat(1360164452)
    elif quest_stage == 5:
        player.startChat(1360164471)
    elif quest_stage == 6:
        player.startChat(1360164490)
    elif quest_stage == 7:
        player.startChat(1360164490)                
    else:
        player.playerChat("I better not disturb Caroline...")
        player.endChat()
              
#Halla
def first_click_npc_3921(player):
    quest_stage = player.getQuest(22).getStage()
    if quest_stage == 1:
        player.startChat(1360164424)      
    else:
        player.startChat(1360164421)   
        
def second_click_npc_3921(player):
    quest_stage = player.getQuest(22).getStage()
    if quest_stage == 0:
        player.startChat(1360164420)    
    elif quest_stage == 1:
        player.startChat(1360164420)                       
    else:
        player.getShop().openShop(55)  
                   
def chat_1360164388(player):
    player.playerChat("Hi Gypsy Aris, how are doing?")
    player.nextChat(1360164389)

def chat_1360164389(player):
    player.npcChat("I'm great thank you.")
    player.nextChat(1360164390)

def chat_1360164390(player):
    player.playerChat("How's Caroline? Is she feeling better?")
    player.nextChat(1360164391)

def chat_1360164391(player):
    player.npcChat("Yes! Thanks for asking.", "She loved the sweets you delivered for her.", "She recently asked me if she could have more!")
    player.nextChat(1360164392)

def chat_1360164392(player):
    player.playerChat("More?! Corr.. it's impossible to please her!")
    player.nextChat(1360164393)

def chat_1360164393(player):
    player.npcChat("It's her birthday party soon and she wants", "to share them with all her friends.")
    player.nextChat(1360164394)

def chat_1360164394(player):
    player.playerChat("Can't you just go and get her some?")
    player.nextChat(1360164395)

def chat_1360164395(player):
    player.npcChat("Pfft. I wish it was that easy.")
    player.nextChat(1360164396)

def chat_1360164396(player):
    player.playerChat("How hard can it be to get some sweets?")
    player.nextChat(1360164397)

def chat_1360164397(player):
    player.boxMessage("Gypsy Aris looks at you with great disgust!")
    player.nextChat(1360164398)

def chat_1360164398(player):
    player.npcChat("Some sweets... they aren't just standard sweets.", "They are special sweets with a special recipie.")
    player.nextChat(1360164399)

def chat_1360164399(player):
    player.playerChat("Well how did you get them last time?")
    player.nextChat(1360164400)

def chat_1360164400(player):
    player.npcChat("I made them! ")
    player.nextChat(1360164401)

def chat_1360164401(player):
    player.playerChat("How the hell do you make sweets?!")
    player.nextChat(1360164402)

def chat_1360164402(player):
    player.npcChat("It's a lot easier than you'd think.", "You just need the correct ingredients.")
    player.nextChat(1360164403)

def chat_1360164403(player):
    player.playerChat("Okay, so once you've got the ingredients", "what do you do then?")
    player.nextChat(1360164404)

def chat_1360164404(player):
    player.npcChat("Well, I know of a special method. ")
    player.nextChat(1360164405)

def chat_1360164405(player):
    player.npcChat("Would you be interested in helping?")
    player.nextChat(1360164406)

def chat_1360164406(player):
    player.dialogueOption("No! She can get her own silly sweets.", 1360164, "Sure, I'd like to help.", 1360165)
    
def chat_1360164(player):
    player.playerChat("No! She can get her own silly sweets.")
    player.nextChat(1360166)

def chat_1360165(player):
    player.playerChat("Sure, I'd like to help.")
    player.getQuest(22).setStage(1)
    player.refreshQuestTab()
    player.nextChat(1360164409)

def chat_1360166(player):
    player.npcChat("Fine then!")
    player.endChat()
    
def chat_1360164409(player):
    player.npcChat("Fantastic!")
    player.nextChat(1360164410)

def chat_1360164410(player):
    player.playerChat("So what ingredients do I need to get?")
    player.nextChat(1360164411)

def chat_1360164411(player):
    player.npcChat("You need 5 redberries, 2 red dye",  "and 10 purple sweets.")
    player.nextChat(1360164412)

def chat_1360164412(player):
    player.playerChat("Okay, where do I get these ingredients?")
    player.nextChat(1360164413)

def chat_1360164413(player):
    player.npcChat("Well...")
    player.nextChat(1360164414)

def chat_1360164414(player):
    player.boxMessage("Gypsy Aris laughs to herself.")
    player.nextChat(1360164415)

def chat_1360164415(player):
    player.npcChat("If I knew, I wouldn't be asking you, would I?")
    player.nextChat(1360164416)

def chat_1360164416(player):
    player.npcChat("Try talking to my good friend Halla.")
    player.nextChat(1360164417)

def chat_1360164417(player):
    player.playerChat("Where can I find them?")
    player.nextChat(1360164418)

def chat_1360164418(player):
    player.npcChat("She lives in the north east Falador houses.")
    player.nextChat(1360164419)

def chat_1360164419(player):
    player.playerChat("I'll see what I can do.")
    player.endChat()

## Quest stage 0 ##
def chat_1360164420(player):
    player.boxMessage("Halla doesn't seem interested in trading with you.")
    player.endChat()

def chat_1360164421(player):
    player.playerChat("Nice house you have here!")
    player.nextChat(1360164422)

def chat_1360164422(player):
    player.npcChat("Thank you.")
    player.endChat()

## Quest stage 1 ##
def chat_1360164423(player):
    player.boxMessage("Halla doesn't seem to trade with strangers.")
    player.endChat()

def chat_1360164424(player):
    player.playerChat("Hi Halla, are you friends with Gypsy Aris?")
    player.nextChat(1360164425)

def chat_1360164425(player):
    player.npcChat("I am... why who are you and what do you want?")
    player.nextChat(1360164426)

def chat_1360164426(player):
    player.playerChat("I'm " + str(player.playerName) + ".", "I'm a friend of Gypsy Aris and she's sent me", "to talk with you.")
    player.nextChat(1360164427)

def chat_1360164427(player):
    player.playerChat("She said you may be able to help provide", "the ingredients for the special red sweets.")
    player.nextChat(1360164428)

def chat_1360164428(player):
    player.npcChat("Oh those beautiful sweets!")
    player.nextChat(1360164429)

def chat_1360164429(player):
    player.playerChat("I don't see what's so special about them...")
    player.nextChat(1360164430)

def chat_1360164430(player):
    player.npcChat("Well you clearly haven't tried one before.")
    player.nextChat(1360164431)

def chat_1360164431(player):
    player.playerChat("Anyway, I need 5 redberries, 2 red dye", "and 10 purple sweets.")
    player.nextChat(1360164432)

def chat_1360164432(player):
    player.playerChat("Where can I get these ingredients from?")
    player.nextChat(1360164433)

def chat_1360164433(player):
    player.npcChat("You will need to find the redberries near a hedge.", "I happen to have some red dye which I'm willing to sell.")
    player.nextChat(1360164434)

def chat_1360164434(player):
    player.playerChat("What about the purple sweets?")
    player.nextChat(1360164435)

def chat_1360164435(player):
    player.npcChat("Well I know that Aris had some, she", "usually gives them away.")
    player.nextChat(1360164436)

def chat_1360164436(player):
    player.playerChat("Okay, so where can I find the redberries?")
    player.nextChat(1360164437)

def chat_1360164437(player):
    player.npcChat("There are normally found north of here", "on the way to Taverly near the gate!")
    player.nextChat(1360164438)

def chat_1360164438(player):
    player.playerChat("Okay great, what about the dye then", "can I have some?")
    player.nextChat(1360164439)

def chat_1360164439(player):
    player.npcChat("Well it's not cheap, you'll have to buy it.")
    player.nextChat(1360164440)

def chat_1360164440(player):
    player.playerChat("Okay then...")
    player.getQuest(22).setStage(2)
    player.nextChat(1360164441)

def chat_1360164441(player):
	player.getShop().openShop(55)
    
## Stage 2 ##
def chat_1360164442(player):
    player.npcChat("Do you have the ingredients?")
    player.nextChat(1360164443)

def chat_1360164443(player):
    if player.hasItem(red_berries, 5) and player.hasItem(red_dye, 2) and player.hasItem(purp_sweets, 10):
        player.deleteItem(red_berries, 5)
        player.deleteItem(red_dye, 2)
        player.deleteItem(purp_sweets, 10)    
        player.getQuest(22).setStage(3)        
        player.boxMessage("You hand over the ingredients to Gypsy Aris.")
        player.nextChat(1360164445)
    else:
        player.playerChat("Woops, I forgot to bring them all. I'll be back soon.")
        player.endChat()        
        
def chat_1360164445(player):
    player.npcChat("Okay, you have everything here.")
    player.nextChat(1360164446)

def chat_1360164446(player):
    player.playerChat("So what happens now?")
    player.nextChat(1360164447)

def chat_1360164447(player):
    player.npcChat("Well I need to know how many to make.")
    player.nextChat(1360164448)

def chat_1360164448(player):
    player.npcChat("Please go to Caroline and ask her how many", "she needs for the party!")
    player.nextChat(1360164449)

def chat_1360164449(player):
    player.playerChat("Fine!")
    player.nextChat(1360164450)

def chat_1360164450(player):
    player.npcChat("In the meantime, I'll make as many", "as I possibly can!")
    player.nextChat(1360164451)

def chat_1360164451(player):
    player.playerChat("Okay I'll ask Caroline.")
    player.endChat()
    
## Stage 3 ##
def chat_1360164452(player):
    player.playerChat("Hi Caroline, how are you feeling?")
    player.nextChat(1360164453)

def chat_1360164453(player):
    player.npcChat("I'm a lot better thank you.")
    player.nextChat(1360164454)

def chat_1360164454(player):
    player.playerChat("How many sweets would you like", "me to provide for your birthday party?")
    player.nextChat(1360164455)

def chat_1360164455(player):
    player.npcChat("That's a kind offer!", "5 packs would be enough please!")
    player.getQuest(22).setStage(4)    
    player.nextChat(1360164456)

def chat_1360164456(player):
    player.playerChat("I'll be sure to tell Gypsy Aris.")
    player.nextChat(1360164457)

def chat_1360164457(player):
    player.npcChat("I hope to see you soon!")
    player.endChat()

## Stage 4 ##
def chat_1360164458(player):
    player.playerChat("Caroline said she would like 5 packs of sweets!")
    player.nextChat(1360164459)

def chat_1360164459(player):
    player.npcChat("Woah that's a lot of sweets.", "It's a good job you collected enough ingredients.", "I've made just about enough!")
    player.nextChat(1360164460)

def chat_1360164460(player):
    player.playerChat("Great, now you can give them to her!")
    player.nextChat(1360164461)

def chat_1360164461(player):
    player.npcChat("Well...")
    player.nextChat(1360164462)

def chat_1360164462(player):
    player.playerChat("You want me to go there again don't you...")
    player.nextChat(1360164463)

def chat_1360164463(player):
    player.npcChat("Yes please!")
    player.nextChat(1360164464)

def chat_1360164464(player):
    player.playerChat("I'm not your little delivery person! ")
    player.nextChat(1360164465)

def chat_1360164465(player):
    player.npcChat("She'll be very happy!")
    player.nextChat(1360164466)

def chat_1360164466(player):
    player.playerChat("Fine... I suppose.")
    player.nextChat(1360164467)

def chat_1360164467(player):
    player.npcChat("Great! Here's the sweets.")
    player.nextChat(1360164468)

def chat_1360164468(player):
    if player.hasInventorySpace(5):
        player.addItem(red_sweets, 5)
        player.boxMessage("Gypsy Aris hands you 5 packs of special sweets.")
        player.getQuest(22).setStage(5)        
        player.nextChat(1360164469)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for these sweets.")
        player.endChat()
        
def chat_1360164469(player):
    player.playerChat("I'll get them to Caroline.")
    player.nextChat(1360164470)

def chat_1360164470(player):
    player.npcChat("Good! See you soon.")
    player.endChat()

## Stage 5 ##
def chat_1360164471(player):
    player.playerChat("Caroline! I have the sweets", "for your birthday party!")
    player.nextChat(1360164472)

def chat_1360164472(player):
    player.npcChat("Really? All 5 packs?!")
    player.nextChat(1360164473)

def chat_1360164473(player):
    if player.hasItem(red_sweets, 5):
        player.deleteItem(red_sweets, 5)
        player.playerChat("Yes! Here you go...")    
        player.getQuest(22).setStage(6)   
        player.nextChat(1360164474)    
    else:
        player.playerChat("Woops, I forgot to bring them. I'll be back soon.")
        player.endChat()

def chat_1360164474(player):
    player.boxMessage("You hand Caroline the sweets.")
    player.nextChat(1360164475)

def chat_1360164475(player):
    player.npcChat("Yay!!! Just what I wanted.", "This is going to be a great party.")
    player.nextChat(1360164476)

def chat_1360164476(player):
    player.playerChat("I hope you have a good time.")
    player.nextChat(1360164477)

def chat_1360164477(player):
    player.npcChat("Thanks again!")
    player.endChat()

## Stage 6 ##
def chat_1360164478(player):
    player.playerChat("I delivered the sweets to her!", "Again...")
    player.nextChat(1360164479)

def chat_1360164479(player):
    player.npcChat("Good job! She must have been pleased.")
    player.nextChat(1360164480)

def chat_1360164480(player):
    player.playerChat("Yes, she was very excited.")
    player.nextChat(1360164481)

def chat_1360164481(player):
    player.npcChat("Thank you!")
    player.nextChat(1360164495)
	
def chat_1360164495(player):
    player.endChat()
    player.getQuest(22).setStage(7)
    player.addCash(4000000)
    player.addItem(10476, 200)
    player.addPoints(100)
    reward = QuestReward("4,000,000 coins", "100 OXP", "1 Quest Point", "200 Purple Sweets")
    player.completeQuest("Sweet Party", reward, 10476)

## Stage 7 ##
def chat_1360164482(player):
    player.npcChat("Thanks for helping Caroline out with her party!")
    player.nextChat(1360164483)

def chat_1360164483(player):
    player.playerChat("It's a pleasure... I guess.")
    player.endChat()
    
## Other Dialogues ##

def chat_1360164484(player):
    player.npcChat("Have you spoken with Halla yet?")
    player.nextChat(1360164485)

def chat_1360164485(player):
    player.playerChat("No, I better talk to her soon!")
    player.endChat()

def chat_1360164486(player):
    player.npcChat("Have you asked Caroline how many sweets she wants?")
    player.nextChat(1360164487)

def chat_1360164487(player):
    player.playerChat("No, I better ask her soon!")
    player.endChat()

def chat_1360164488(player):
    player.npcChat("Have you given the sweets to Caroline yet?")
    player.nextChat(1360164489)

def chat_1360164489(player):
    player.playerChat("No, I better give them to her soon!")
    player.endChat()
    
def chat_1360164490(player):
    player.npcChat("Thanks for delivering the sweets!")
    player.nextChat(1360164491)

def chat_1360164491(player):
    player.playerChat("You're welcome!")
    player.endChat()