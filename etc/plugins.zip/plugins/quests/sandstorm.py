#Author Hawk
#Quest Length = Short

#NPCs
wander_id = 2005
dwarf_id = 1842

#Items
secret_map = 3104

#Quest configuration
def configure_quest_24():
    quest_id = 24
    quest_name = "Sandstorm"
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(wander_id, 3315, 2849, 0, 1)
    World.addNonCombatNpc(dwarf_id, 3488, 3091, 0, 1)

#Quest button
def quest_button_24(player):
    quest_stage = player.getQuest(24).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("@blu@Sandstorm@bla@", "I can start this quest by talking to", "@dre@The Wanderer@bla@ north of sophenom town", "","")
    elif quest_stage == 1:
        player.boxMessage("I should find the engineer, Khorvak.")
    elif quest_stage == 2:
        player.boxMessage("I should tell the Wanderer that Khorvak has the map.")
    elif quest_stage == 3:
        player.boxMessage("I have completed @dre@Sandstorm@bla@.")
        
#wat
def click_item_6794(player):
    player.playerChat("wat.")
    player.endChat()
    
#Wanderer
def first_click_npc_2005(player):
    quest_stage = player.getQuest(24).getStage()
    if quest_stage == 0:
        player.startChat(55151240)
    elif quest_stage == 1:
        player.startChat(55051240)
    elif quest_stage == 2:
        player.startChat(55351240)
    elif quest_stage == 3:
        player.startChat(55451240)
    else:
        player.playerChat("I better not disturb her.")
        player.endChat()
#Khorvak
def first_click_npc_1842(player):
    quest_stage = player.getQuest(24).getStage()
    if quest_stage == 0:
        player.playerChat("I better not disturb him")
        player.endChat()
    elif quest_stage == 1:
        player.startChat(55201240)
    elif quest_stage == 2:
        player.startChat(55401240)
    elif quest_stage == 3:
        player.startChat(55401240)
    else:
        player.playerChat("I better not disturb him")
        player.endChat()
        
#Stage 0
def chat_55151240(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(55151241)

def chat_55151241(player):
    player.npcChat("Hello there! what can I help you with?")
    player.nextChat(55151242)

def chat_55151242(player):
    player.dialogueOption("Nothing much.", 55151243, "I'm looking for quests!", 55151244)
    
def chat_55151243(player):
    player.playerChat("Nothing much.")
    player.endChat()

def chat_55151244(player):
    player.playerChat("I'm looking for quests!")
    player.nextChat(55151245)

def chat_55151245(player):
    player.npcChat("A quest you say? I may have a job for you")
    player.nextChat(55151246)

def chat_55151246(player):
    player.playerChat("What would you like me to do?")
    player.nextChat(55151247)

def chat_55151247(player):
    player.npcChat("I have a secret map for an ally.", "It will help him with his Quest.")
    player.nextChat(55151248)

def chat_55151248(player):
    player.playerChat("So you want me to give them to him??", "Why can't you do it?")
    player.nextChat(55151249)

def chat_55151249(player):
    player.npcChat("I'm busy fighting the war against the evil sand-people.")
    player.nextChat(55161240)

def chat_55161240(player):
    player.playerChat("Not the sandpeople!, where is your ally right now?")
    player.nextChat(55161241)

def chat_55161241(player):
    player.npcChat("In the ruined city of Uzer!")
    player.nextChat(55161242)

def chat_55161242(player):
    player.dialogueOption("Fine, I'll deliver the map.", 55161243, "Sorry, that's too far for me.", 55161244)

def chat_55161243(player):
    player.playerChat("Fine, I'll deliver the map.")
    player.nextChat(55161247)

def chat_55161244(player):
    player.playerChat("Sorry, that's too far for me.")
    player.nextChat(55161245)

def chat_55161245(player):
    player.boxMessage("The Wanderer lets out a sigh.")
    player.nextChat(55161246)

def chat_55161246(player):
    player.npcChat("Don't worry about it.")
    player.endChat()

def chat_55161247(player):
    player.npcChat("Thank you so much, you won't regret this!")
    player.nextChat(55161248)

def chat_55161248(player):
    player.playerChat("Okay, I'll try and find him!")
    player.nextChat(55161249)

def chat_55161249(player):
    if player.hasInventorySpace(1):
        player.addItem(secret_map)
        player.getQuest(24).setStage(1)
        player.refreshQuestTab()
        player.npcChat("Wait, you forgot the Map!")
        player.nextChat(55171240)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for the map.")

def chat_55171240(player):
    player.playerChat("Phew, that was close.")
    player.endChat()
    
#Stage 1 (General)
def chat_55051240(player):
    player.npcChat("Have you delivered the map yet?")
    player.nextChat(55051241)

def chat_55051241(player):
    player.playerChat("Not yet!")
    player.endChat()

#Stage 2
def chat_55201240(player):
    player.playerChat("Are you Khorvak?")
    player.nextChat(55201241)

def chat_55201241(player):
    player.npcChat("*hic* What do you want?")
    player.nextChat(55201242)

def chat_55201242(player):
    player.playerChat("I have a map sent by your ally")
    player.nextChat(55201243)

def chat_55201243(player):
    player.npcChat("What map?!")
    player.nextChat(55201244)

def chat_55201244(player):
    player.boxMessage("He looks you up and down.")
    player.nextChat(55201245)

def chat_55201245(player):
    player.playerChat("A secret map, he said you needed","it for a 'mission'")
    player.nextChat(55201246)

def chat_55201246(player):
    player.npcChat("Ah yes, thank you, I'm sure you won't regret this...")
    player.nextChat(55201247)

def chat_55201247(player):
    if player.hasItem(secret_map):
        player.deleteItem(secret_map)
        player.getQuest(24).setStage(2)
        player.refreshQuestTab()
        player.playerChat("Here you go then.")
        player.nextChat(55201248)
    else:
        player.playerChat("Whoops, I forgot to bring it. I'll be back soon.")
        player.endChat()

def chat_55201248(player):
    player.boxMessage("He looks determined, the Wanderer will be pleased.")
    player.endChat()

#Stage 3
def chat_55351240(player):
    player.npcChat("Have you given him the map yet?")
    player.nextChat(55351241)

def chat_55351241(player):
    player.playerChat("Yes! He said to say thank you.")
    player.nextChat(55351242)

def chat_55351242(player):
    player.npcChat("Thank you, as a reward, you may learn the maps destination","and you may wear the mask of my people.","Take care, adventurer!")
    player.nextChat(55351243)

def chat_55351243(player):
    player.endChat()
    player.getQuest(24).setStage(3)
    player.addItem(7003, 1)
    player.refreshQuestTab()
    player.addCash(5000000)
    player.addPoints(100)
    reward = QuestReward("5,000,000 coins", "100 OXP", "1 Quest Point", "Camel Mask")
    player.completeQuest("Sandstorm", reward, 7003)

def chat_55451240(player):
    player.npcChat("Thank you for you help!")
    player.nextChat(55451241)

def chat_55451241(player):
    player.playerChat("No problem, you're welcome.")
    player.endChat()

def chat_55401240(player):
    player.npcChat("Thank you for the help!")
    player.endChat()