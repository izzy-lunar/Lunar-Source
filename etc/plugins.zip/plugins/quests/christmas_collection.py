#Items
present1 = 6542
present2 = 11918
present3 = 2522
present4 = 7759
present5 = 10508

def configure_quest_30():
    quest_id = 30
    quest_name = 'Christmas Collection'
    quest_stages = 7
    World.addQuest(quest_id, quest_name, quest_stages)
    #World.addNonCombatNpc(1552, 3085, 3498, 0, 1)

#Quest button
def quest_button_30(player):
    quest_stage = player.getQuest(30).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Christmas Collection", "I need to speak to @dre@Santa@bla@ who is in Edgeville near",
		"the big christmas tree.", "", "This quest can only be completed during Christmas.")
    elif quest_stage == 1:
        player.boxMessage("@dre@Santa@bla@ has asked me to search OwnXile for the missing presents")

    elif quest_stage == 2:
        player.boxMessage("Hand @dre@Santa@bla@ the second present.")

    elif quest_stage == 3:
        player.boxMessage("Hand @dre@Santa@bla@ the third present.")

    elif quest_stage == 4:
        player.boxMessage("Hand @dre@Santa@bla@ the fourth present.")

    elif quest_stage == 5:
        player.boxMessage("Hand @dre@Santa@bla@ the fifth present.")

    elif quest_stage == 6:
        player.boxMessage("Speak to @dre@Santa@bla@ again for your reward!")

    elif quest_stage == 7:
        player.boxMessage("@grd@Christmas @red@Collection@bla@ Event Complete.")

def first_click_npc_1552(player):
    quest_stage = player.getQuest(30).getStage()
    if quest_stage == 0:
        player.startChat(1267587159)
    elif quest_stage == 1:
        player.startChat(1267587172)
    elif quest_stage == 2:
        player.startChat(1267587175)
    elif quest_stage == 3:
        player.startChat(1267587176)
    elif quest_stage == 4:
        player.startChat(1267587177)
    elif quest_stage == 5:
        player.startChat(1267587178)
    elif quest_stage == 6:
        player.startChat(1267587179)
    elif quest_stage == 7:
        player.startChat(1267587180)
	
def chat_1267587159(player):
    player.playerChat("Hey Santa, all ready for Christmas?")
    player.nextChat(1267587160)

def chat_1267587160(player):
    player.npcChat("NO and you bothering me isn't helping matters!")
    player.nextChat(1267587161)

def chat_1267587161(player):
    player.playerChat("Sorry Santa, perhaps I can help out?")
    player.nextChat(1267587162)

def chat_1267587162(player):
    player.npcChat("Yes I SUPPOSE you can, I'm going to need all", "the help I can get! Things are not looking good!")
    player.nextChat(1267587163)

def chat_1267587163(player):
    player.playerChat("What's the problem??!")
    player.nextChat(1267587164)

def chat_1267587164(player):
    player.npcChat("As I flew my sled over the lands over OwnXile I", "dropped some important gifts. I've tried looking around", " to see where they might be but have had no luck!")
    player.nextChat(1267587165)

def chat_1267587165(player):
    player.playerChat("Right, where should I start looking?")
    player.nextChat(1267587166)

def chat_1267587166(player):
    player.npcChat("I really don't know, you'll have to use your own initiative.")
    if player.getQuest(30).getStage() == 0:
        player.nextChat(1267587167)
    else:
        player.npcChat("Actually here, hints: the undead forest, bandits,", "tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587167(player):
    player.playerChat("Well that's just great!")
    player.nextChat(1267587168)

def chat_1267587168(player):
    player.npcChat("There are five presents I need to locate.", "Good luck " + str(player.playerName) + "!")
    player.nextChat(1267587169)

def chat_1267587169(player):
    player.playerChat("I guess it's down to me to save Christmas.")
    player.getQuest(30).setStage(1)
    player.refreshQuestTab()
    player.nextChat(1267587170)

def chat_1267587170(player):
    player.npcChat("Actually here, hints: the undead forest, bandits,", "tower, creatures, and icy mountains.")
    player.nextChat(1267587171)

def chat_1267587171(player):
    player.playerChat("Wow liar, you asshole. Thanks anyways.")
    player.endChat()

def chat_1267587172(player):
    player.playerChat("I've got all the presents!")
    player.nextChat(1267587173)

def chat_1267587173(player):
    player.npcChat("Really? Let's see them!")
    player.nextChat(1267587174)

def chat_1267587174(player):
    if player.hasItem(present1, 1):
        player.deleteItem(present1, 1)
        player.getQuest(30).setStage(2)
        player.refreshQuestTab()
        player.boxMessage("You hand @dre@Santa@bla@ the first present.")
        player.nextChat(1267587175)
    else:
        player.boxMessage("Go find the first present, you don't have it.", "The undead forest, bandits, tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587175(player):
    if player.hasItem(present2, 1):
        player.deleteItem(present2, 1)
        player.getQuest(30).setStage(3)
        player.refreshQuestTab()
        player.boxMessage("You hand @dre@Santa@bla@ the second present.")
        player.nextChat(1267587176)
    else:
        player.boxMessage("Go find the second present, you don't have it.", "The undead forest, bandits, tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587176(player):
    if player.hasItem(present3, 1):
        player.deleteItem(present3, 1)
        player.getQuest(30).setStage(4)
        player.refreshQuestTab()
        player.boxMessage("You hand @dre@Santa@bla@ the third present.")
        player.nextChat(1267587177)
    else:
        player.boxMessage("Go find the third present, you don't have it.", "The undead forest, bandits, tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587177(player):
    if player.hasItem(present4, 1):
        player.deleteItem(present4, 1)
        player.getQuest(30).setStage(5)
        player.refreshQuestTab()
        player.boxMessage("You hand @dre@Santa@bla@ the fourth present.")
        player.nextChat(1267587178)
    else:
        player.boxMessage("Go find the fourth present, you don't have it yet.", "The undead forest, bandits, tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587178(player):
    if player.hasItem(present5, 1):
        player.deleteItem(present5, 1)
        player.getQuest(30).setStage(6)
        player.refreshQuestTab()
        player.boxMessage("You hand @dre@Santa@bla@ the fifth present.", "Make sure you have 3 inventory spaces before continuing.")
        player.nextChat(1267587179)
    else:
        player.boxMessage("Go find the fifth present, you don't have it yet.", "The undead forest, bandits, tower, creatures, and icy mountains.")
        player.endChat()

def chat_1267587179(player):
    player.endChat()
    player.getQuest(30).setStage(7)
    player.refreshQuestTab()
    player.addItem(10507)
    player.addItem(6858)
    player.addItem(6859)
    reward = QuestReward("Reindeer Hat", "Jester Hat", "Jester Scarf")
    player.completeQuest("Christmas Collection", reward, 10507)

def chat_1267587180(player):
    player.npcChat("@grd@Ho-Ho-Ho!@red@ Merry Christmas!")
    player.endChat()