# Quest Name: Vampire Slayer
# Quest Authors: Cam
# Date Created: 9/14/13
# Quest Length: Easy
# Quest Difficulty: Easy

morgan = 755
harlow = 756
vampire = 757

def configure_quest_15():
    quest_id = 15
    quest_name = "Vampire Slayer"
    quest_stages = 4
    World.addNonCombatNpc(morgan, 3099, 3268, 0, 1)
    World.addNonCombatNpc(harlow, 3222, 3398, 0, 1)
    World.addCombatNpc(vampire, 3078, 9774, 0, 1, 100, 12, 50, 50)
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_15(player):
    quest_stage = player.getQuest(15).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Vampire Slayer", "I can start this quest by speaking to @dre@Morgan@bla@ at his house", "in Draynor. This quest has no requirements however you are", "required to defeat a level 34 enemy.", "")
    elif quest_stage == 1:
        player.boxMessage("I need to visit the Blue Moon Inn located in Varrock", "and speak to Dr Harlow about the vampire problem in Draynor.")
    elif quest_stage == 2:
        player.boxMessage("I need to obtain valuable information from Dr Harlow, perhaps", "buying him a beer will get him to talk")
    elif quest_stage == 3:
        player.boxMessage("I must now defeat the Vampire who lives under @dre@Draynor Manor@bla@.")
    elif quest_stage == 4:
        player.boxMessage("I have completed the @dre@Vampire Slayer@bla@ quest.")
    
def first_click_npc_755(player): #Morgan
    quest_stage = player.getQuest(15).getStage()
    if quest_stage == 0:
        player.startChat(120500)
    else:
        player.npcChat("I hope we don't see that vampire around here again.")

def kill_npc_757(player):
    quest_stage = player.getQuest(15).getStage()
    if quest_stage == 3:
        player.getQuest(15).setStage(4)
        player.getFunction().addSkillXP(100000, player.playerAttack)
        player.addItem(10586, 2)
        reward = QuestReward("100,000 Attack XP", "2 Quest Points")
        player.completeQuest("Vampire Slayer", reward, 1549)
        player.qp += 1 # extra +1 qp
    
def first_click_npc_756(player): #Harlow
    quest_stage = player.getQuest(15).getStage()
    if quest_stage == 1:
        player.startChat(120509)
    elif quest_stage == 2:
        player.startChat(120516)
    else:
        player.playerChat("Dr Harlow looks very drunk, I better leave him alone.")

def chat_120500(player):
    player.npcChat("Please please help us bold adventurer!")
    player.nextChat(120501)    
    
def chat_120501(player):
    player.playerChat("What's the problem?")
    player.nextChat(120502)

def chat_120502(player):
    player.npcChat("Our little villiage has been dreadfully ravaged by an evil", "vampire! He lives in the basement of the manor to the", "north, we need someone to get rid of him once and for all!")
    player.nextChat(120503)    
    
def chat_120503(player):
    player.dialogueOption("No, vampires are scary!", 120504, "Ok, I'm up for an adventure.", 120505)
    
def chat_120504(player):
    player.playerChat("No, vampires are scary!")
    player.endChat()
    
def chat_120505(player):
    player.npcChat("I think first you should seek help. I have a friend who", "is a retired vampire hunter, his name is Dr. Harlow. He", "may be able to give you some tips. He can normally be found", "in the Blue Moon Inn in Varrock, he a bit of")
    player.nextChat(120507)

def chat_120507(player):
    player.npcChat("an old soak these days. Mention his old friend Morgan,", "I'm sure he wouldn't want me killed by a vampire.")
    player.nextChat(120508)    
    
def chat_120508(player):
    player.playerChat("I'll look him up then.")
    player.getQuest(15).setStage(1)
    player.refreshQuestTab()
    player.endChat()

def chat_120509(player):
    player.npcChat("Buy me a drrink pleassh...")
    player.nextChat(120510)

def chat_120510(player):
    player.playerChat("Morgan needs your help!")
    player.nextChat(120511)

def chat_120511(player):
    player.npcChat("Morgan you shhay..?")
    player.nextChat(120512)    

def chat_120512(player):
    player.playerChat("His village is being terrorised by a vampire! He told me", "to ask you about how I can stop it.")
    player.nextChat(120513)

def chat_120513(player):
    player.npcChat("Buy me a beer... then I'll teach you what you need to", "know...")
    player.nextChat(120514)    

def chat_120514(player):
    player.playerChat("But this is your friend Morgan we're talking about!")
    player.nextChat(120515)

def chat_120515(player):
    player.npcChat("Buy ush a drink anyway...")
    player.getQuest(15).setStage(2)
    player.endChat()

def chat_120516(player):
    player.npcChat("Got me beer?")
    if player.hasItem(1917):
        player.nextChat(120518)
    else:
        player.nextChat(120517)

def chat_120517(player):
    player.playerChat("No, hold on.")
    player.endChat()

def chat_120518(player):
    player.playerChat("Here you go.")
    player.nextChat(120519)

def chat_120519(player):
    player.boxMessage("You give a beer to Dr Harlow.")
    player.deleteItem(1917)
    player.nextChat(120520)

def chat_120520(player):
    player.npcChat("Cheerah matey...")
    player.nextChat(120521)    

def chat_120521(player):
    player.playerChat("So tell me how to kill vampires then.")
    player.nextChat(120522)

def chat_120522(player):
    player.npcChat("Yesh Yesh vampires, I was very good at", "killing em once...")
    player.nextChat(120523)

def chat_120523(player):
    player.boxMessage("Dr Hawlow appears to sober up slightly.")
    player.nextChat(120524)

def chat_120524(player):
    player.npcChat("Well you're gonna need a stake, otherwise he'll just", "regenerate. Yes, you must have a stake to finish it off..0.", "I just happen to have one with me.")
    player.nextChat(120525)

def chat_120525(player):
    player.boxMessage("Dr Hawlow hands you a stake.")
    player.addItem(1549)
    player.getQuest(15).setStage(3)
    player.nextChat(120526)
    
def chat_120526(player):
    player.npcChat("You'll need a hammer as well, to drive it in properly,", "your everyday general store hammer will do. One last", "thing... It's wise to carry garlic with you, vampires are", "somewhat weakened if they can smell garlic.")
    player.nextChat(120527)

def chat_120527(player):
    player.npcChat("always liked garlic, you should try his house. But", "remember, a vampire is still a dangerous foe!")
    player.nextChat(120528)

def chat_120528(player):
    player.playerChat("Thank you very much!")
    player.endChat()