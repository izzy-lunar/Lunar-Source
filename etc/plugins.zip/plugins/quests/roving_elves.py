# Quest Name: Roving Elves I
# Quest Author: Aram Hami
# Date Created: 10/18/14
# Quest Length: Very Long
#ADD QUEST REQS

#NPCs
sir_tiffy_cashien = 2290
fairy_aeryka = 6072
eluned = 2376
arianwyn = 1202

#Items
scruffy_note = 1508
chest = 11158
task_list = 11203
logs = 1514
ore = 452

#Quest configuration


def configure_quest_28():
    quest_id = 28
    quest_name = 'Roving Elves'
    quest_stages = 16
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(fairy_aeryka, 2449, 4464, 0, 1)
    World.addNonCombatNpc(arianwyn, 2352, 3171, 0, 1)
    eluned_talk = World.addNonCombatNpc(eluned, 2558, 3446, 0, 1)

#Quest button
def quest_button_28(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Roving Elves", "Start this quest by speaking to @dre@Sir Tiffy Cashien@bla@ in @dre@Falador Park@bla@.", "You must have 70 agility, 75 woodcutting, 85 mining and 80 slayer", "to complete this quest.", "You must also be a member of the legends guild.")
    elif quest_stage == 1:
        player.boxMessage("I should speak to @dre@Fairy Aeryka@bla@ in Zanaris.")
    elif quest_stage == 2:
        player.boxMessage("I must return to the @dre@Sir Tiffy Cashien@bla@ in @dre@Falador Park@bla@.")
    elif quest_stage == 3:
        player.boxMessage("I must return to @dre@Fairy Aeryka@bla@ in Zanaris.", "Perhaps she will trust me now.")
    elif quest_stage == 4:
        player.boxMessage("The chest is located northwest of the @dre@fishing guild@bla@.")
    elif quest_stage == 5:
        player.boxMessage("You must answer some questions by @dre@Eluned@bla@.")
    elif quest_stage == 6:
        player.boxMessage("I must return to @dre@Fairy Aeryka@bla@ in Zanaris.")
    elif quest_stage == 7:
        player.boxMessage("I must return to the @dre@Sir Tiffy Cashien@bla@ in Falador Park.")
    elif quest_stage == 8:
        player.boxMessage("Speak to @dre@Sir Tiffy Cashien@bla@ again.")
    elif quest_stage == 9:
        player.boxMessage("Complete the @dre@to-do list@bla@ in order and speak to @dre@Arianwyn@bla@.")
    elif quest_stage == 10:
        player.boxMessage("I have defeated the @dre@King Black Dragon@bla@ from the list.")
    elif quest_stage == 11:
        player.boxMessage("I have killed the @dre@Chaos Elemental@bla@ from the list.")
    elif quest_stage == 12:
        player.boxMessage("I have killed the @dre@Callisto@bla@ from the list.")
    elif quest_stage == 13:
        player.boxMessage("I have killed the @dre@Callisto@bla@ from the list.", "I should speak to @dre@Arianwyn@bla@.")
    elif quest_stage == 14:
        player.boxMessage("I must acquire:", "@dre@1000 magic logs@bla@ and @dre@500 runite ore@bla@.")
    elif quest_stage == 15:
        player.boxMessage("I must speak to @dre@Arianwyn@bla@ for my reward!")
    elif quest_stage == 16:
        player.boxMessage("I have completed @dre@Roving Elves I@bla@.")

#Sir Tiffy Cashien
def first_click_npc_2290(player):
    agility_level = player.getLevel("agility")
    woodcutting_level = player.getLevel("woodcutting")
    mining_level = player.getLevel("mining")
    slayer_level = player.getLevel("slayer")
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 0 and agility_level > 69 and woodcutting_level > 74 and mining_level > 84 and slayer_level > 79 and player.getQuest(23).getStage() == 7:
        player.startChat(700000000)
    elif quest_stage == 2:
        player.startChat(700000015)
    elif quest_stage == 7 and player.hasItem(scruffy_note, 1):
        player.startChat(700000049)
    elif quest_stage == 8:
        player.startChat(700000051)
    else:
        player.sendMessage("You do not have the necessary requirements to start this quest.")

#Fairy Aeryka
def first_click_npc_6072(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 1:
        player.startChat(700000010)
    elif quest_stage == 3:
        player.startChat(700000019)
    elif quest_stage == 6 and player.hasItem(chest, 1):
        player.startChat(700000038)
    else:
        player.boxMessage("That fairy doesn't want to be disturbed.")
        player.endChat()

#Eluned
def first_click_npc_2376(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 4:
        player.startChat(700000025)
    elif quest_stage == 5:
        player.startChat(700000029)
    elif quest_stage == 10:
        player.startChat(210069)
    else:
        player.sendMessage("Eluned is too busy to talk.")
        player.endChat()
    
def fix_glitch(player):
    player.startChat(800000037)
    player.getQuest(28).setStage(16)
    player.refreshQuestTab()

#Arianwyn
def first_click_npc_1202(player):
    quest_stage = player.getQuest(28).getStage()
    quest_stage2 = player.getQuest(32).getStage()
    if quest_stage2 == 4 and quest_stage == 7:
        fix_glitch(player)
    elif quest_stage2 == 3:
        player.startChat(800000030)
    elif quest_stage2 == 9:
        player.startChat(800000053)
    elif quest_stage == 13:
        player.startChat(700000058)
    elif quest_stage == 14 and player.hasItem(logs, 1000) and player.hasItem(ore, 500):
        player.startChat(700000069)
    elif quest_stage == 14:
        player.boxMessage("I need to bring Arianwyn 1000 magic logs and 500 runite ores.")
        player.endChat()
    elif quest_stage == 15:
        player.startChat(700000071)
    elif quest_stage == 16:
        player.startChat(700000083)
    else:
        player.boxMessage("You cannot help the @dre@Elves@bla@ right now.")
        player.endChat()
        
def chat_700000083(player):
    player.npcChat("I can teleport you to another camp if you like?")
    player.nextChat(700000084)

def chat_700000084(player):
    player.dialogueOption("Tyras Camp", 700000085, "Elf Camp", 700000086, "No thanks", 700000048)
    
def chat_700000085(player):
    player.getTask().teleport(2190, 3145, 0)
    
def chat_700000086(player):
    player.getTask().teleport(2197, 3252, 0)

#A scruffy note
def click_item_1508(player):
    player.boxMessage("The note is in fairy language.", "It may be related to their kingdom.")
        
#Chest
def click_item_11158(player):
    player.boxMessage("Roving Elves I", "The magic surrounding the chest prevents you", "from opening it.")

#Task List
def click_item_11203(player):
    player.getTask().startInfo("Slay the following in order:", "King Black Dragon", "Chaos Elemental", "Callisto", "The Inadequacy")
        
#Chat dialogues    
def chat_700000000(player):
    player.playerChat("Hi there, what are you doing?")
    player.nextChat(700000001)

def chat_700000001(player):
    player.npcChat("Listening to the many whispers around me.", "Can you hear them?")
    player.nextChat(700000002)
    
def chat_700000002(player):
    player.boxMessage("You try to listen carefully.", "You hear nothing but the butterflies that are near.")
    player.nextChat(700000003)
    
def chat_700000003(player):
    player.playerChat("I think you hear them in your head.", "Are you ok, sir?")
    player.nextChat(700000004)
    
def chat_700000004(player):
    player.npcChat("Ha-ha! You can't help me.", "My information is too valuable.")
    player.nextChat(700000005)
    
def chat_700000005(player):
    player.playerChat("I never said anything about helping you.", "What are you hiding?")
    player.nextChat(700000006)

def chat_700000006(player):
    player.dialogueOption("Accept Quest", 700000007, "Decline Quest", 710000048)

def chat_700000007(player):
    player.getQuest(28).setStage(1)
    player.refreshQuestTab()
    player.npcChat("If you want to help, bring me back my note.", "Speak to @dre@Fairy Aeryka@bla@.")
    player.nextChat(700000008)
    
def chat_700000008(player):
    player.npcChat("She will hand you a note that I need.", "Tell her that I sent you.")
    player.nextChat(700000009)

def chat_700000009(player):
    player.playerChat("Uh, okay will do.")
    player.endChat()
    
def chat_700000010(player):
    player.npcChat("Lete ti keh-noah.", "Isti-nei-ma.")
    player.nextChat(700000011)
    
def chat_700000011(player):
    player.playerChat("What?")
    player.nextChat(700000013)
    
def chat_700000013(player):
    player.npcChat("La-kei-lea!")
    player.nextChat(700000014)
    
def chat_700000014(player):
    player.getQuest(28).setStage(2)
    player.boxMessage("You are confused and decide to return to @dre@Sir Tiffy Cashien@bla@.")
    player.endChat()
    
def chat_700000015(player):
    player.playerChat("I couldn't get your note.", "What is 'La-kei-lea'?")
    player.nextChat(700000016)
    
def chat_700000016(player):
    player.npcChat("She doesn't trust you in her presence.", "Here, the language of the fairies.", "It will aid you to communicate.")
    player.nextChat(700000017)

def chat_700000017(player):
    player.getQuest(28).setStage(3)
    player.refreshQuestTab()
    player.boxMessage("You feel a wave of magic around your soul.")
    player.nextChat(700000018)    
    
def chat_700000018(player):
    player.npcChat("Get me my note.")
    player.endChat()
    
def chat_700000019(player):
    player.npcChat("Halt!", "La-kei-lea.")
    player.nextChat(700000020)

def chat_700000020(player):
    player.playerChat("Yasti kono lea.", "Eysta si @dre@Sir Tiffy Cashien@bla@ asa.")
    player.nextChat(700000021)
    
def chat_700000021(player):
    player.boxMessage("You tell her that she can trust you and", "that Sir Tiffy Cashien sent you.")
    player.nextChat(700000022)
    
def chat_700000022(player):
    player.npcChat("Hm.", "I cannot trust you with such valuable information.", "You must gain my trust." )
    player.nextChat(700000023)
    
def chat_700000023(player):
    player.getQuest(28).setStage(4)
    player.refreshQuestTab()
    player.npcChat("Please obtain an item for me.", "@dre@Cyrus's chest@bla@, yes, I think that is it.")
    player.nextChat(700000024)
    
def chat_700000024(player):
    player.npcChat("It is located near @dre@Glarial's Tombstone@bla@.")
    player.endChat()
    
def chat_700000025(player):
    player.npcChat("Hello, who are you?")
    player.nextChat(700000026)
    
def chat_700000026(player):
    player.playerChat("@dre@Fairy Aeryka@bla@ sent me to get @dre@Cyrisus's chest@bla@.")
    player.nextChat(700000027)
    
def chat_700000027(player):
    player.npcChat("Why would she ever trust you with such sensitive", "information?")
    player.nextChat(700000028)
    
def chat_700000028(player):
    player.boxMessage("She looks you up and down.")
    player.nextChat(700000029)
    
def chat_700000029(player):
    player.getQuest(28).setStage(5)
    player.refreshQuestTab()
    player.npcChat("You're going to have to answer some questions first.", "Obviously one that is sent can answer these questions",  "correctly. Make one inventory space now.")
    player.nextChat(700000031)
   
def chat_700000030(player):
    player.npcChat("Better luck next time!")
    player.endChat()

def chat_700000031(player):
    player.npcChat("Who is my companion?")
    player.nextChat(700000032)
    
def chat_700000032(player):
    player.dialogueOption("Arianwyn", 700000030, "Islwyn", 700000033, "Isafdar", 700000030, "Arandar", 700000030) 
    
def chat_700000033(player):
    player.npcChat("What is the name of the @dre@Elven Village@bla@?")
    player.nextChat(700000034)

def chat_700000034(player):
    player.dialogueOption("Lletya", 700000035, "Tirannwn", 700000030, "Iorwerth", 700000030, "Prifddinas", 700000030)
    
def chat_700000035(player):
    player.npcChat("Who was the main commander in the @dre@Elven Civil War@bla@?")
    player.nextChat(700000036)

def chat_700000036(player):
    player.dialogueOption("Arianwyn", 700000030, "General Hining", 700000030, "King Tyras", 700000030, "Lord Iorwerth", 700000037)
    
def chat_700000037(player):
    player.getQuest(28).setStage(6)
    player.refreshQuestTab()
    player.addItem(chest)
    player.boxMessage("The Elf reluctantly hands you the chest,", "she looks pretty annoyed about it.")
    player.endChat()
    
def chat_700000038(player):
    player.npcChat("Have you got @dre@Cyrisus's chest?")
    player.nextChat(700000039)
    
def chat_700000039(player):
    player.playerChat("Yes, I do, here you go.")
    player.nextChat(700000040)
    
def chat_700000040(player):
    player.getQuest(28).setStage(7)
    player.refreshQuestTab()
    if player.hasItem(chest, 1):
        player.deleteItem(chest, 1)
        player.boxMessage("You hand over @dre@Cyrisus's chest@bla@.")
        player.nextChat(700000041)
    else:
        player.npcChat("You must bring me @dre@Cyrisus's chest@bla@.")
        player.endChat()
    
def chat_700000041(player):
    player.npcChat("Thank you very much. Your kindness has helped", "us in our endeavours to improve our kingdom", "and the elves'.")
    player.nextChat(700000042)
    
def chat_700000042(player):
    player.playerChat("What's wrong with the elves?")
    player.nextChat(700000043)
    
def chat_700000043(player):
    if player.hasInventorySpace(1):
        player.addItem(scruffy_note)
        player.npcChat("@dre@Lord Iorwerth@bla@ betrayed the rest of the @dre@elven clans@bla@.", "Take this note back to @dre@Sir Tiffy Cashien@bla@.", "He will tell you what to do.")
        player.nextChat(700000044)
    
def chat_700000044(player):
    player.playerChat("Thank you.", "Don't worry, you can count on me!")
    player.nextChat(700000045)
    
def chat_700000045(player):
    player.npcChat("Would you like me to teleport you to @dre@Sir Tiffy@bla@?")
    player.nextChat(700000046)
    
def chat_700000046(player):
    player.dialogueOption("Teleport me", 700000047, "No thanks", 700000048)
    
def chat_700000047(player):
    player.getTask().teleport(3003, 3383, 0)

def chat_700000048(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def chat_700000049(player):
    player.npcChat("Have you gotten the note yet?")
    player.nextChat(700000050)
    
def chat_700000050(player):
    player.getQuest(28).setStage(8)
    player.refreshQuestTab()
    if player.hasItem(scruffy_note, 1):
        player.deleteItem(scruffy_note, 1)
        player.playerChat("Yeah I have, here it is.", "Now, what about those elves?")
        player.nextChat(700000051)
    else:
        player.npcChat("You must have an empty inventory space.")
        player.endChat()
    
def chat_700000051(player):
    player.npcChat("The leader of the Elves, @dre@Lord Iorwerth@bla@, betrayed the rest", "of the @dre@elven clans@bla@ which caused a civil war.")
    player.nextChat(700000052)
    
def chat_700000052(player):
    player.npcChat("@dre@Lord Iorwerth@bla@ abandoned @blu@Seren@bla@, God of the", "Elves and is now worshipping the @dre@Dark Lord@bla@.")
    player.nextChat(700000053)
    
def chat_700000053(player):
    player.npcChat("The war is tearing the kingdom of @dre@Tirannwn@bla@ apart.", "Including the newly constructed city, @dre@Lletya@bla@.", str(player.playerName) + " please help us stop this war.")
    player.nextChat(700000054)
        
def chat_700000054(player):
    player.npcChat("It will be a series of tasks.", "Each task is known as a 'ritual' and after each task magic", "will help the war and eventually take down @dre@Iorwerth@bla@.")
    player.nextChat(700000055)

def chat_700000055(player):
    player.playerChat("What do I need to do? I'm in!")
    player.nextChat(700000057)

def chat_700000056(player):
    player.npcChat("Get to work with the tasks on the list,", "when completed speak to @dre@Arianwyn@bla@ in Lleyta.")
    player.endChat()

def chat_700000057(player):
    player.getQuest(28).setStage(9)
    player.refreshQuestTab()
    if player.hasInventorySpace(2):
        player.addItem(task_list)
        player.addItem(task_list)
        player.boxMessage("You are handed a @dre@to-do list@bla@.", "Keep one in your bank in case you die.")
        player.nextChat(700000056)
    else:
        player.npcChat("You must have two empty inventory spaces.")
        player.endChat()
    
def kill_npc_50(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 9:
        player.getQuest(28).setStage(10)
        player.boxMessage("You slay the monster, better check the todo list for the next task.")
        
def kill_npc_3200(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 10:
        player.getQuest(28).setStage(11)
        player.boxMessage("You slay the monster, better check the todo list for the next task.")
        
def kill_npc_2552(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 11:
        player.getQuest(28).setStage(12)
        player.boxMessage("You slay the monster, better check the todo list for the next task.")
        
def kill_npc_5902(player):
    quest_stage = player.getQuest(28).getStage()
    if quest_stage == 12:
        player.getQuest(28).setStage(13)
        player.boxMessage("You slay the final monster, time to speak to @dre@Arianwyn@bla@.")

def command_skiprov(player):
    player.getQuest(28).setStage(13)
def chat_700000058(player):
    player.npcChat("I've been expecting you, " + str(player.playerName) + "!")
    player.nextChat(700000059)
    
def chat_700000059(player):
    player.playerChat("I've completed the @dre@to-do list@bla@.")
    player.nextChat(700000060)
    
def chat_700000060(player):
    if player.hasItem(task_list, 1):
        player.deleteItem(task_list, 1)
        player.boxMessage("@dre@Arianwyn@bla@ checks your progress...")
        player.nextChat(700000061)
    else:
        player.boxMessage("You must be carrying the @dre@To-do list@bla@.")
        player.endChat()
   
def chat_700000061(player):
    player.getQuest(28).setStage(14)
    player.refreshQuestTab()
    player.boxMessage("The elf magic seems to be restored.")
    player.nextChat(700000062)
    
def chat_700000062(player):
    player.npcChat("Thank you, adventurer! The elves are very grateful!", "The city of @dre@Lletya@bla@ seems to be restored once again.")
    player.nextChat(700000063)

def chat_700000063(player):
    player.playerChat("It was a piece of cake, ", "Would it be possible to have access to @dre@Lletya@bla@?")
    player.nextChat(700000064)

def chat_700000064(player):
    player.npcChat("Of course, however I do ask that you do us",  "one more favour.")
    player.nextChat(700000065)
    
def chat_700000065(player):
    player.playerChat("WHAT? ANOTHER FAVOUR?")
    player.nextChat(700000066)
    
def chat_700000066(player):
    player.npcChat("Can you please bring us some materials?", "Because of the war, we have lost many supplies.")
    player.nextChat(700000067)
    
def chat_700000067(player): 
    player.npcChat("We need around 1000 magic logs and 500 runite ore,", "this will help us rebuild our great city.")
    player.nextChat(700000068)

def chat_700000068(player):
    player.playerChat("Very well, I guess I can help.")
    player.endChat()

def chat_700000069(player):
    player.playerChat("I have your items.")
    player.nextChat(700000070)
    
def chat_700000070(player):
    if player.hasItem(logs, 1000) and player.hasItem(ore, 500):
        player.deleteItem(ore, 500)
        player.deleteItem(logs, 1000)
        player.getQuest(28).setStage(15)
        player.refreshQuestTab()
        player.boxMessage("You hand over the energy materials.")
        player.nextChat(700000071)
    else:
        player.boxMessage("You must be carrying the requested materials@bla@.")
        player.endChat()
    
def chat_700000071(player):
    player.npcChat("Thank you, but our fight is far from over.")
    player.nextChat(700000072)

def chat_700000072(player):
    player.playerChat("Well you can always count on my support.")
    player.nextChat(700000073)
    
def chat_700000073(player):
    player.npcChat("Please accept this reward to show our gratitude.")
    player.nextChat(700000074)
    
def chat_700000074(player):
    player.endChat()
    player.getQuest(28).setStage(16)
    player.addItem(4212)
    player.addItem(4447)
    player.addPoints(300)
    player.qp += 4
    reward = QuestReward("Access to Lletya", "Crystal Bow", "300 OXP", "Antique Lamp", "5 Quest Points")
    player.completeQuest("Roving Elves", reward, 1202)                         