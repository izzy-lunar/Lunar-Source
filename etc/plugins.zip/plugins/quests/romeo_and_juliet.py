# Quest Name: Romeo and Juliet
# Quest Authors: Cam
# Date Created: 9/13/13
# Quest Length: Medium

cadava_berry = 753

romeo_id = 639
juliet_id = 637
fatherlawrence_id = 640
rj_key = 709
apothecary = World.addNonCombatNpc(638, 3195, 3404, 0, 1)

def configure_quest_12():
    quest_id = 12
    quest_name = 'Romeo & Juliet'
    quest_stages = 9
    World.addNonCombatNpc(romeo_id, 3211, 3423, 0, 1)
    World.addNonCombatNpc(juliet_id, 3166, 3444, 0, 1)
    World.addNonCombatNpc(fatherlawrence_id, 3254, 3484, 0, 1)
    World.addQuest(quest_id, quest_name, quest_stages)
	
def quest_button_12(player):
    quest_stage = player.getQuest(12).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Romeo and Juliet", "I can start this quest by speaking to the @dre@Romeo@bla@ who", "is located south of the fountain area of Varrock.", " ","")
    elif quest_stage == 1:
        player.boxMessage("Romeo has asked me to find Juliet.")
    elif quest_stage == 2:
        player.boxMessage("Juliet has asked me to give a letter to Romeo.")
    elif quest_stage == 3:
        player.boxMessage("Romeo has asked me to speak to Father Lawrence,", "he works in the north east Varrock church.")
    elif quest_stage == 4:
        player.boxMessage("Father Lawrence told me to speak to Apothecary,", "he is in the potion shop in western Varrock.")
    elif quest_stage == 5:
        player.boxMessage("Apothecary asked me to fetch him some Cadava Berries", "to make the potion. I can find a Cadava bush near the", "mine that is south east of Varrock.")
    elif quest_stage == 6:
        player.boxMessage("I need to speak to Apothecary again.")
    elif quest_stage == 7:
        player.boxMessage("I need to deliver the potion to Juliet.")
    elif quest_stage == 8:
        player.boxMessage("I need to update Romeo on the current situation.")
    elif quest_stage == 9:
		player.boxMessage("I have completed @dre@Romeo & Juliet@bla@.")

def first_click_object_23625(player):
	player.getFunction().pickCadava()

#romeo	
def first_click_npc_639(player):
    quest_stage = player.getQuest(12).getStage()
    if quest_stage == 0:
        player.startChat(3555500)
    elif quest_stage == 1:
        player.npcChat("Please find Juliet, I miss her so much!")
    elif quest_stage == 2:
        player.startChat(3555509)
    elif quest_stage == 8:
        player.startChat(3555543)
    elif quest_stage == 9:
        player.npcChat("Thanks for helping again,", "Juliet and I will be moving to Falador soon.")
    else:
        player.sendMessage("Romeo looks very busy.")

#Juliet
def first_click_npc_637(player):
    quest_stage = player.getQuest(12).getStage()
    if quest_stage == 1:
        player.startChat(3555507)
    elif quest_stage == 7:
        player.startChat(3555541)
    elif quest_stage == 9:
        player.npcChat("Thanks for helping again,", "Romeo and I will be moving to Falador soon.")
    else:
        player.sendMessage("Juliet looks very sad, perhaps she's better left alone.")

def first_click_npc_640(player):
    quest_stage = player.getQuest(12).getStage()
    if quest_stage == 3:
        player.startChat(3555518)
    else:
        player.npcChat("Can't you see I'm busy?")

def first_click_npc_638(player):
    quest_stage = player.getQuest(12).getStage()
    if quest_stage == 4:
        player.startChat(3555529)
    elif quest_stage == 5 and player.hasItem(cadava_berry, 1):
        player.startChat(3555538)
    elif quest_stage == 5:
        player.startChat(3555550)
    elif quest_stage == 6:
        player.startChat(3555540)
    else:
        player.sendMessage("Doesn't look like Apothecary wants to talk.",)

def chat_3555500(player):
    player.playerChat("Hello? You look troubled")
    player.nextChat(3555501)
	
def chat_3555501(player):
    player.npcChat("Hmphmh, what? Yes I suppose you could say that.", "I can't find Juliet.")
    player.nextChat(3555502)
	
def chat_3555502(player):
    player.playerChat("Would you like some help finding her?")
    player.nextChat(3555503)
	
def chat_3555503(player):
    player.npcChat("Would you do that for me? I'd be ever so grateful!")
    player.nextChat(3555504)
	
def chat_3555504(player):
    player.playerChat("Not a problem, now, what does she look like?")
    player.nextChat(3555505)
	
def chat_3555505(player):
    player.npcChat("Er, blonde. A woman, um, our height, you get the jist.")
    player.nextChat(3555506)
	
def chat_3555506(player):
    player.getQuest(12).setStage(1)
    player.refreshQuestTab()
    player.playerChat("Oh okay, guess I'll get onto it.")
    player.endChat()

def chat_3555507(player):	
    player.playerChat("Juliet? Romeo is looking for you.")
    player.nextChat(3555508)
	
def chat_3555508(player):
    player.npcChat("Oh, has he?! Here, take this letter for him.")
    player.endChat()
    player.getQuest(12).setStage(2)
    player.addItem(755, 1)
    
def chat_3555509(player):
    player.playerChat("Romeo, I found Juliet and she gave me this letter!")
    player.deleteItem(755, 1)
    player.nextChat(3555510)
	
def chat_3555510(player):
    player.npcChat("Thank you! Listen here, it says..", "Romeo, I still love you and wish to be with you.", "However, my father has taken a strong dislike to you!")
    player.nextChat(4555511)
	
def chat_4555511(player):
    player.npcChat("He claims he will kill you if he sees you again", "We cannot be together, I am truly sorry, my love.", "However, we do have one hope. Father Lawrence.")
    player.nextChat(3555511)
	
def chat_3555511(player):
    player.playerChat("Well, I'm very sorry for you to be in this situation.")
    player.nextChat(3555512)
	
def chat_3555512(player):
    player.npcChat("This is disasterous!")
    player.nextChat(3555513)
	
def chat_3555513(player):
    player.playerChat("What is it about Father Lawrence?")
    player.nextChat(3555514)
	
def chat_3555514(player):
    player.npcChat("I don't know, maybe he can help. Can you find him for me?")
    player.nextChat(3555515)
	
def chat_3555515(player):
    player.playerChat("Sure, where is he?")
    player.nextChat(3555516)
	
def chat_3555516(player):
    player.npcChat("Father Lawrence. Hmm, I'm pretty sure he", "works in the north east Varrock church now.")
    player.nextChat(3555517)
	
def chat_3555517(player):
    player.playerChat("Great, I'll go speak to him then.")
    player.endChat()
    player.getQuest(12).setStage(3)
	
def chat_3555518(player):
    player.playerChat("Father Lawrence?")
    player.nextChat(3555519)
	
def chat_3555519(player):
    player.npcChat("Yes, would you like to confess?")
    player.nextChat(3555520)
	
def chat_3555520(player):
    player.playerChat("No, Father. I've come for Romeo. He needs help.")
    player.nextChat(3555521)
	
def chat_3555521(player):	
    player.npcChat("Well then, why didn't you say so! What can I do for him?")
    player.nextChat(3555522)
	
def chat_3555522(player):
    player.playerChat("Juliet needs an escape route from her dad,", "as he is threatening to kill Romeo!")
    player.nextChat(3555523)
	
def chat_3555523(player):
    player.npcChat("Hm, how about a potion to make her appear dead?")
    player.nextChat(3555524)
	
def chat_3555524(player):
    player.playerChat("A bit drastic, but what did you have in mind?")
    player.nextChat(3555525)
	
def chat_3555525(player):
    player.npcChat("Well if she's dead, then her", "father won't come looking for her..", "..and she can live happily with Romeo!")
    player.nextChat(3555526)
	
def chat_3555526(player):
    player.playerChat("I see! Well, yes, it could work.", "Where shall I get such a potion?")
    player.nextChat(3555527)
	
def chat_3555527(player):
    player.npcChat("Speak to Apothecary in his potion shop", "in the South West of Varrock.")
    player.nextChat(3555528)
	
def chat_3555528(player):
    player.playerChat("Okay. Great, thanks!")
    player.endChat()
    player.getQuest(12).setStage(4)
	
def chat_3555529(player):
    player.playerChat("Apothecary? I need your help.")
    player.nextChat(3555530)
	
def	chat_3555530(player):
    player.npcChat("Yes? What with?")
    player.nextChat(3555531)
	
def chat_3555531(player):
    player.playerChat("Father Lawrence said you could help me,","I need you to make me a potion to fake someones death.")
    player.nextChat(3555532)
	
def chat_3555532(player):
    player.npcChat("Oh that old fool, he knows not to tell people about our litte..", "..child kidnapping operation.")
    player.nextChat(3555533)
	
def chat_3555533(player):
    player.playerChat("Child kidnapping?!?!")
    player.nextChat(3555534)
	
def chat_3555534(player):
    player.npcChat("Oh erm, you didn't hear that.")
    player.nextChat(3555535)
	
def chat_3555535(player):
    player.playerChat("I didn't hear that, if you make me my potion.")
    player.nextChat(3555536)
	
def chat_3555536(player):
    player.npcChat("I'll make your potion if you get me some Cadava Berries,", "they can be picked from the bushes near", "the mine South East of Varrock.")
    player.nextChat(3555537)
	
def chat_3555537(player):
    player.playerChat("I'll get them for you.")
    player.getQuest(12).setStage(5)
    player.endChat()
	
def chat_3555538(player):
    player.playerChat("I have your berries!")
    player.nextChat(3555539)
	
def chat_3555539(player):
    player.npcChat("Great, hand them over and speak to me again in a moment!")
    player.endChat()
    player.deleteItem(cadava_berry)
    apothecary.startAnimation(1652)
    player.getQuest(12).setStage(6)
	
def chat_3555540(player):
    player.npcChat("Ah here you are, I have your potion for you,", "please take it to Juliet.")
    player.endChat()
    player.addItem(195, 1)
    player.getQuest(12).setStage(7)

def chat_3555541(player):
    player.playerChat("Here's the plan, I have a potion which you will drink", "you will appear dead, to which your father will not know", "the truth, thus he shall think you're dead and send your", "body to the morgue, where Romeo will meet you!")
    player.nextChat(3555542)
	
def chat_3555542(player):
    player.npcChat("Right, okay, pass it over then!")
    player.endChat()
    player.deleteItem(195, 1)
    player.getQuest(12).setStage(8)
	
def chat_3555543(player):
    player.playerChat("Romeo, so here's what's happening.", "I've given Juliet a potion which will kill her...")
    player.nextChat(3555544)

def chat_3555544(player):
    player.npcChat("You've done what!?")
    player.nextChat(3555545)

def chat_3555545(player):
    player.playerChat("It's okay, she's not really dead,", "it's to make her dad think she is.")
    player.nextChat(3555546)

def chat_3555546(player):
    player.npcChat("Oh right, great thinking. We can run away together now!")
    player.nextChat(3555547)
	
def chat_3555547(player):
    player.playerChat("I'm glad I could help.")
    player.nextChat(3555548)
	
def chat_3555548(player):
    player.npcChat("You have indeed, here take this reward!")
    player.nextChat(3555549)
	
def chat_3555550(player):
    player.npcChat("Have you got Cadava Berries yet?")
    player.nextChat(3555551)
	
def chat_3555551(player):
    player.playerChat("Not yet, I'm still looking.")
    player.endChat()
	
def chat_3555549(player):
    player.endChat()
    player.getQuest(12).setStage(9)
    player.getFunction().addSkillXP(500000, 15)
    reward = QuestReward("10 Mithril Seeds", "500,000 Herblore XP", "3 Quest Points")
    player.addItem(299, 10)
    player.qp += 2
    player.completeQuest("Romeo & Juliet", reward, 195)