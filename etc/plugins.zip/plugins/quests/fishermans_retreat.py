##################################
###       Author: eBolajake     ###
###        Date:20.1.2015      ###
##################################
 
def configure_quest_31():
    quest_id = 31
    quest_name = "Fishermans Retreat"
    quest_stages = 4
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(227, 3264, 3151, 0, 0)
   
def quest_button_31(player):
    quest_stage = player.getQuest(31).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("@blu@Fishermans Retreat@bla@", "I can start this quest by talking to", "@dre@Roachey@bla@ who is located at the Fishing Guild.", "", "")
    elif quest_stage == 1:
        player.boxMessage("Roachey has heard rumours of a fisherman who can", "make the ultimate fishing device. I should start looking for him.")
    elif quest_stage == 2:
        player.boxMessage("I should bring this @blu@Instruction Manual @bla@to @dre@Roachey.")
    elif quest_stage == 3:
        player.boxMessage("Roachey needs me to bring him a Harpoon and Big Fishing Net.")
    elif quest_stage == 4:
        player.boxMessage("I have completed @dre@Fishman's Retreat@bla@.")
         
def first_click_npc_592(player): #Roachey
    quest_stage = player.getQuest(31).getStage()
    if quest_stage == 0:
        player.startChat(754727313)
    elif quest_stage == 2:
        player.startChat(754727354)
    elif quest_stage == 3:
        player.startChat(754727367)
    else:
        player.playerChat("He looks pretty agitated, better leave him alone.")
        player.endChat() 

def first_click_item_5(player):
    player.playerChat("Roachy needs dis.")
	
def first_click_npc_227(player):#morris
    stage = player.getQuest(31).getStage()
    if stage == 1:
       player.startChat(754727331)
    else:
       player.sendMessage("Morris looks very busy.")
  
def chat_754727313(player):
    player.playerChat("Hello there!")
    player.nextChat(754727314)

def chat_754727314(player):
    player.npcChat("Nice day isn't it.")
    player.nextChat(754727315)

def chat_754727315(player):
    player.playerChat("Nothing like catching fish on a day like today.")
    player.nextChat(754727316)

def chat_754727316(player):
    player.npcChat("Ahh yes, the fish are plentiful!")
    player.nextChat(754727317)

def chat_754727317(player):
    player.boxMessage("Roachey looks into the sky")
    player.nextChat(754727318)

def chat_754727318(player):
    player.npcChat("It's just a shame it takes so long to catch fish!")
    player.nextChat(754727319)

def chat_754727319(player):
    player.playerChat("Yes if only there was a way to catch them quicker...")
    player.nextChat(754727320)

def chat_754727320(player):
    player.playerChat("Aww well as if that would ever happen!")
    player.nextChat(754727321)

def chat_754727321(player):
    player.boxMessage("*Awkward Silence*")
    player.nextChat(754727323)

def chat_754727323(player):
    player.playerChat("Hmm..")
    player.nextChat(754727324)

def chat_754727324(player):
    player.npcChat("What's you name young one?")
    player.nextChat(754727325)

def chat_754727325(player):
    player.playerChat(str(player.playerName) + "... why?")
    player.nextChat(754727326)

def chat_754727326(player):
    player.npcChat("Well " + str(player.playerName) + " I have heard rumours of a device", "that would allow you to catch fish quicker!")
    player.nextChat(754727327)

def chat_754727327(player):
    player.playerChat("Wow, that sounds impressive.")
    player.nextChat(754727328)

def chat_754727328(player):
    player.npcChat("Indeed, apparently it is owned by a man in a far away", "land where there ground is made of sand, a man named Morris.")
    player.nextChat(754727329)

def chat_754727329(player):
    player.npcChat("If you could find him and ask how he", "makes such a device I could make it!")
    player.getQuest(31).setStage(1)
    player.refreshQuestTab()
    player.nextChat(754727330)

def chat_754727330(player):
    player.playerChat("I will try my best to find him thank you.")
    player.endChat()


def chat_754727331(player):
    player.playerChat("Hello there.")
    player.nextChat(754727332)

def chat_754727332(player):
    player.npcChat("How may I be of help?")
    player.nextChat(754727333)

def chat_754727333(player):
    player.playerChat("By any chance you wouldn't be the one how could make", "such a device that would allow you to fish quicker?")
    player.nextChat(754727334)

def chat_754727334(player):
    player.npcChat("Nope sorry you have the wrong guy.")
    player.nextChat(754727335)

def chat_754727335(player):
    player.boxMessage("You are about to give up your search.")
    player.nextChat(754727336)

def chat_754727336(player):
    player.playerChat("Ok thanks for your help!")
    player.nextChat(754727337)

def chat_754727337(player):
    player.npcChat("Wait...")
    player.nextChat(754727338)

def chat_754727338(player):
    player.npcChat("Who told you of such device?")
    player.nextChat(754727339)

def chat_754727339(player):
    player.playerChat("A man named Roachey, at the fishing guild.")
    player.nextChat(754727340)

def chat_754727340(player):
    player.npcChat("Ahhh Roachey I have heard good things about this man.", "Excellent fisher he is supposed to be!")
    player.nextChat(754727341)

def chat_754727341(player):
    player.playerChat("That's nice I will be on my way now...")
    player.nextChat(754727343)

def chat_754727343(player):
    player.npcChat("Wait, I am the one you seek. I am the creator of such", "device I like to call it the @blu@ Barb-tail harpoon@bla@.")
    player.nextChat(754727344)

def chat_754727344(player):
    player.playerChat("Fantastic! You couldn't tell how to make", "it could you?")
    player.nextChat(754727345)

def chat_754727345(player):
    player.npcChat("I have it all wrote down in my instruction manual")
    player.nextChat(754727346)

def chat_754727346(player):
    player.playerChat("May I have a copy?")
    player.nextChat(754727347)

def chat_754727347(player):
    player.npcChat("Why yes of course young fisherman!")
    player.nextChat(754727348)

def chat_754727348(player):
    player.npcChat("For a price of course.")
    player.nextChat(754727349)

def chat_754727349(player):
    player.playerChat("How much are you looking for it?")
    player.nextChat(754727350)

def chat_754727350(player):
    player.npcChat("1 Million should cover it.")
    player.nextChat(754727351)

def chat_754727351(player):
    player.playerChat("Ok that sounds fair")
    if player.hasItem(995, 1000000):
        player.deleteItem(995, 1000000)
        player.nextChat(754727352)
    else:
        player.boxChat("You need to pay 1M.")
        player.endChat()

def chat_754727352(player):
    player.npcChat("Thank you very much here you go.")
    player.addItem(5)
    player.getQuest(31).setStage(2)
    player.refreshQuestTab()
    player.nextChat(754727353)
    
def chat_754727353(player):
    player.boxMessage("You should go give the Instruction Manuel to Roachey.")
    player.endChat()
    
    #Talking to Roachey 2nd time
    
    

def chat_754727354(player):
    player.npcChat("Did you find Morris?")
    player.nextChat(754727355)

def chat_754727355(player):
    player.playerChat("Yes, he give me this Instruction manual!")
    player.nextChat(754727356)

def chat_754727356(player):
    if player.hasItem(5):
        player.npcChat("Hand it over!")
        player.deleteItem(5)
        player.nextChat(754727357)
    else:
        player.boxMessage("I must give the Instruction manual to Roachey")
        player.endChat()

def chat_754727357(player):
    player.npcChat("Interesting... very interesting...")
    player.nextChat(754727358)

def chat_754727358(player):
    player.npcChat("There only is one problem!")
    player.nextChat(754727359)

def chat_754727359(player):
    player.playerChat("What is that?")
    player.nextChat(754727360)

def chat_754727360(player):
    player.npcChat("I need a few items to be able to make the Barb-tail harpoon.")
    player.nextChat(754727361)

def chat_754727361(player):
    player.playerChat("Right...")
    player.nextChat(754727362)

def chat_754727362(player):
    player.npcChat("Would you be able to fetch me these couple of items?")
    player.nextChat(754727363)

def chat_754727363(player):
    player.playerChat("It's times like this I question the very point", "of this silly existence in the land of OwnXile.")
    player.nextChat(754727364)

def chat_754727364(player):
    player.playerChat("What are these items?")
    player.nextChat(754727365)

def chat_754727365(player):
    player.npcChat("They shouldnt be that hard to come across", "I need a Harpoon and Big fishing net.")
    player.getQuest(31).setStage(3)
    player.refreshQuestTab()
    player.nextChat(754727366)

def chat_754727366(player):
    player.playerChat("Okay, I better go fetch them.")
    player.endChat()


#Giving items

def player_has_fish_stuff(player):
    return player.hasItem(311) and player.hasItem(305)

def chat_754727367(player):
    player.npcChat("Have you got the items I asked for?")
    player.nextChat(754727368)

def chat_754727368(player):
    if player_has_fish_stuff(player):
        player.playerChat("Yeah, here you go!")
        player.nextChat(754727369)
    else:
        player.playerChat("Still searching!")
        player.endChat()    

def chat_754727369(player):
    player.npcChat("Okay, hand them over.")
    player.nextChat(754727370)

def chat_754727370(player):
    player.boxMessage("You give Roachey the items.")
    player.deleteItem(311)
    player.deleteItem(305)
    player.nextChat(754727371)

def chat_754727371(player):
    player.npcChat("Excellcent, I shall now construct the barbtail harpoon!")
    player.nextChat(754727372)

def chat_754727372(player):
    player.boxMessage("Roachey does some strange things with the harpoon.")
    player.nextChat(754727373)

def chat_754727373(player):
    player.playerChat("Is it ready?")
    player.nextChat(754727374)

def chat_754727374(player):
    player.npcChat("Here you go and happy fishing!")
    player.nextChat(754727375)

def chat_754727375(player):
    player.addItem(10129)
    player.getFunction().addSkillXP(250000, player.playerFishing)
    player.getQuest(31).setStage(4)
    player.refreshQuestTab()
    reward = QuestReward("Ability to use Barbtail Harpoon", "Access to Roachey's shop","1 Quest Point")
    player.completeQuest("Fishermans Retreat", reward, 10129)
