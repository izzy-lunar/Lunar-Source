# Quest Name: Sewage Cleanup
# Quest Author: Parrot
# Date Created: 9/11/13
# Quest Length: Medium
import random

# NPCs - Here is a list of all the NPCs used in the quest.
hadley = 302

# Quest Configuration.
def configure_quest_11():
    quest_id = 11
    quest_name = 'Sewage Cleanup'
    quest_stages = 4
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(hadley, 3245, 9865, 0, 1)

# Kill Monsters
gd_monsters = [110,73,82,117,112]
gd_names = ["Fire Giant", "Zombie", "Lesser Demon", "Hill Giant", "Moss Giant"]
    
# Quest Button - Here is the configuration for the quest button.
def quest_button_11(player):
    quest_stage = player.getQuest(11).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Sewage Cleanup", "I can start this quest by talking to @dre@Hadley@bla@ in Varrock Sewers.", "You will need a Strength level of 50 to start this quest.", "", "")
    elif quest_stage == 1:
        if player.hasAttribute("monster_kills"):
            kills_required = 20 - player.getAttribute("monster_kills")
            player.boxMessage("I should explore the sewers and kill " + str(kills_required) + " @dre@" + gd_names[player.gdSlot] + "@bla@.")
        else:
            player.boxMessage("I should explore the sewers and kill 20 @dre@" + gd_names[player.gdSlot] + "@bla@.")
    elif quest_stage == 2:
        player.boxMessage("I've killed the monsters, I should go back to Hadley.")
    elif quest_stage == 3:
        player.boxMessage("I should return to Hadley once I've obtained","two diamonds and two silver bars.")
    elif quest_stage == 4:
        player.boxMessage("I have completed the @dre@Sewage Cleanup@bla@ quest.")        
		
def first_click_npc_302(player):
    quest_stage = player.getQuest(11).getStage()
    stage = player.getQuest(37).getStage()
    if stage == 2:
       player.startChat(672315139)
    elif quest_stage == 0:
        player.startChat(367000)
    elif quest_stage == 2:
        player.startChat(367023)
    elif quest_stage == 3:
        player.startChat(367037)    
    elif quest_stage == 4:
        player.startChat(367041)   		
    else: #Stage 1
        player.startChat(367021)
        
# Stage 0        
def chat_367000(player):
    player.playerChat("Hello there!")
    player.nextChat(367001)
    
def chat_367001(player):
    player.boxMessage("Hadley looks at you disapprovingly and mutters...")
    player.nextChat(367002)    
    
def chat_367002(player):
    player.npcChat("What do you want?")
    player.nextChat(367003)    
    
def chat_367003(player):
    player.playerChat("You look a little wound up. What's the problem?")
    player.nextChat(367004)
    
def chat_367004(player):
    player.npcChat("What isn't the problem?!")
    player.nextChat(367005)
    
def chat_367005(player):
    player.npcChat("I can't walk around these lands without being attacked.")
    player.nextChat(367006)

def chat_367006(player):
    player.playerChat("What do you mean?")
    player.nextChat(367007)
    
def chat_367007(player):
    player.npcChat("Every time I walk through the sewers I get bombarded", "with a group of monsters, it's ridiculous!")
    player.nextChat(367008)    
    
def chat_367008(player):
    player.playerChat("What do you expect? It's the sewers...")
    player.nextChat(367009)    
    
def chat_367009(player):
    player.npcChat("Yes but this has gone out of hand.", "I lost my wedding ring down there!")
    player.nextChat(367010)    

def chat_367010(player):
    player.dialogueOption("Is there anyway I can help?", 367011, "Oh well, sewers are always going to be full of monsters.", 367012)    

def chat_367011(player):
    player.playerChat("Is there anyway I can help?")
    player.nextChat(367014)    
    
def chat_367012(player):
    player.playerChat("Oh well, sewers are always going to be full of monsters.")
    player.nextChat(367013)        
    
def chat_367013(player):
    player.npcChat("Well they shouldn't be! Good day sir.")
    player.endChat()        
    
def chat_367014(player):
    strength_level = player.getLevel("strength")
    if strength_level < 50:
        player.npcChat("No, look at those skinny little arms of yours.", "How would you be able to kill those big monsters?!")
        player.nextChat(367015)
    else:
        player.npcChat("Well I suppose you could help actually.")
        player.nextChat(367016)    
    
def chat_367015(player):
    player.playerChat("Well, good luck with your problem.")
    player.endChat()

def chat_367016(player):
    player.gdSlot = Misc.random(4)
    player.npcChat("I'd like you to kill 20@dre@ " + gd_names[player.gdSlot] + " @bla@in the sewer.", "This will help reduce the number of these vicious monsters.")
    player.nextChat(367017)
    
def chat_367017(player):
    player.dialogueOption("Sure, I can do that.", 367018, "No thanks.", 367019)    

def chat_367018(player):
    player.playerChat("Sure, I can do that.")
    player.getQuest(11).setStage(1)
    player.refreshQuestTab()    
    player.nextChat(367020)
    
def chat_367019(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def chat_367020(player):
    player.npcChat("Excellent. Come back when you're done.")
    player.endChat()        

# Stage 1
def handle_monster_kill(player):
    if player.getAttribute("monster_kills") > 18:
        player.playerChat("It looks like I've killed 20@dre@ " + gd_names[player.gdSlot] + "@bla@.", "I better tell Hadley!")
        player.getQuest(11).setStage(2)
    else:
        player.addAttribute("monster_kills", player.getAttribute("monster_kills") + 1)

def chat_367021(player):
    player.npcChat("Have you killed 20@dre@ " + gd_names[player.gdSlot] + " @bla@yet?")    
    player.nextChat(367022)
    
def chat_367022(player):
    player.playerChat("Not yet!")
    player.endChat()        
        
# Stage 2        
def chat_367023(player):
    player.playerChat("I've killed the 20 " + gd_names[player.gdSlot] + " you asked me to kill!")
    player.nextChat(367024)    

def chat_367024(player):
    player.npcChat("Great job! Hopefully there's less of them now.")    
    player.nextChat(367025)
    
def chat_367025(player):
    player.npcChat("I still have a small problem though.")    
    player.nextChat(367026)    

def chat_367026(player):
    player.playerChat("What now?!")
    player.nextChat(367027)    

def chat_367027(player):
    player.npcChat("I lost my wedding ring the", "last time I went in the sewers.")    
    player.nextChat(367028)        
    
def chat_367028(player):
    player.playerChat("Let me guess...", "You want me to go and find it?")
    player.nextChat(367029)        
    
def chat_367029(player):
    player.boxMessage("Hadley laughs to himself a little.")
    player.nextChat(367030)

def chat_367030(player):
    player.npcChat("No, of course not.", "However, I do need a new ring and I was hoping you'd", " be able to gather the materials needed for a new one.")    
    player.nextChat(367031)            

def chat_367031(player):
    player.npcChat("My friend is a great craftsman, they will be able to make it.", "I just need the materials, they're hard to find.")    
    player.nextChat(367032)

def chat_367032(player):
    player.playerChat("What materials do you need?")
    player.nextChat(367033)    

def chat_367033(player):
    player.npcChat("I need 2 diamonds and 2 bars of silver.", "Can you get that?")    
    player.nextChat(367034)    
    
def chat_367034(player):
    player.dialogueOption("Sure, I can get those materials.", 367035, "I'm not so sure. I'll come back later.", 367036)        

def chat_367035(player):
    player.playerChat("Sure, I can get those materials.")
    player.getQuest(11).setStage(3)
    player.refreshQuestTab()	
    player.endChat()

def chat_367036(player):
    player.playerChat("I'm not so sure. I'll come back later.")
    player.endChat()    
 
# Stage 3      
def chat_367037(player):
    player.npcChat("Have you got the 2 diamonds and 2 bars of silver yet?") 
    player.nextChat(367038)

def chat_367038(player):
    if player.hasItem(2355, 2) & player.hasItem(1601, 2):
        player.deleteItem(2355, 2)
        player.deleteItem(1601, 2)		
        player.playerChat("Yes, here you go.")
        player.nextChat(367039)
    else:
        player.playerChat("Not yet. I'll come back later.")
        player.endChat()

def chat_367039(player):
    player.npcChat("Fantastic! Thanks a lot.") 
    player.nextChat(367040)

def chat_367040(player):
    player.getQuest(11).setStage(4)
    player.getFunction().addSkillXP(250000, 2)
    player.getFunction().addSkillXP(50000, 18)
    player.addItem(10586, 3)
    player.addPoints(50)    
    reward = QuestReward("250,000 Strength XP", "50,000 Slayer XP", "50 OXP", "3x Combat Lamp", "1 Quest Point")
    player.completeQuest("Sewage Cleanup", reward, 2355)
	
def chat_367041(player):
    player.npcChat("Thanks for your help brave warrior.") 
    player.nextChat(367042)

def chat_367042(player):
    player.playerChat("You're welcome buddy.")
    player.endChat()
	
def kill_npc_110(player):
    if gd_monsters[player.gdSlot] == 110 and player.getQuest(11).getStage() == 1:
        check_monster_kill(player)

def kill_npc_82(player):
    if gd_monsters[player.gdSlot] == 82 and player.getQuest(11).getStage() == 1:
        check_monster_kill(player)

def kill_npc_73(player):
    if gd_monsters[player.gdSlot] == 73 and player.getQuest(11).getStage() == 1:
        check_monster_kill(player)

def kill_npc_117(player):
    if gd_monsters[player.gdSlot] == 117 and player.getQuest(11).getStage() == 1:
        check_monster_kill(player)
	
def kill_npc_112(player):
    if gd_monsters[player.gdSlot] == 112 and player.getQuest(11).getStage() == 1:
        check_monster_kill(player)

def check_monster_kill(player):
    if player.hasAttribute("monster_kills") and player.getQuest(11).getStage() == 1:
        handle_monster_kill(player)
    else:
        player.addAttribute("monster_kills", 1)

def command_gdkills(player):
   player.addAttribute("monster_kills", 19)