# Quest Name: Cooks Assistant
# Quest Authors: Cam
# Date Created: 9/14/13
# Quest Length: Short

lumbridge_cook = 278
egg = 1944
bucket_of_milk = 1927
pot_of_flour = 1933

def configure_quest_13():
    quest_id = 13
    quest_name = "Cook's Assistant"
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(lumbridge_cook, 3210, 3216, 0, 1)
	
def quest_button_13(player):
    quest_stage = player.getQuest(13).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Cook's Assistant", "I can start this quest by speaking to the @dre@Cook@bla@ who", "is located in Lumbridge castle kitchen.", "","")
    elif quest_stage == 1:
        player.boxMessage("You need to bring the cook:","a bucket of milk, a pot of flour and an egg!")
    elif quest_stage == 2:
        player.boxMessage("I have completed the @dre@Cook's Assistant@bla@ quest.")

def first_click_npc_278(player):
    quest_stage = player.getQuest(13).getStage()
    if quest_stage == 0:
        player.startChat(3468202)
    elif quest_stage == 1 and player.hasItem(egg) and player.hasItem(pot_of_flour) and player.hasItem(bucket_of_milk):
        player.startChat(3468212)
    elif quest_stage == 1:
        player.startChat(3468209)
    elif quest_stage == 2:
        player.npcChat("Thanks for helping with the dukes birthday!")

def chat_3468202(player):
    player.playerChat("You look sad! What's wrong?")
    player.nextChat(3468203)
	
def chat_3468203(player):
    player.npcChat("Oh dear, oh dear, oh dear, I'm in a terrible, terrible mess!", "It's the Duke's birthday today, and I should", "be making him a lovely, big birthday", "cake using special ingredients...")
    player.nextChat(3468204)
	
def chat_3468204(player): 
    player.npcChat("...but I've forgotten to get the ingredients.", "I'll never get them in time now.", "He'll sack me! What ever will I do? I have four children"," and a goat to look after. Would you help me? Please?")
    player.nextChat(523010)

def chat_523010(player):
    player.dialogueOption("I'm always happy to help a cook in distress.", 3468205, "Sorry, I have troubles of my own.", 3468206)    

def chat_3468205(player):
    player.playerChat("I'm always happy to help a cook in distress.")
    player.getQuest(13).setStage(1)
    player.refreshQuestTab()
    player.nextChat(3468207)

def chat_3468206(player):
    player.playerChat("Sorry, I have troubles of my own.")
    player.nextChat(3468208)

def chat_3468207(player):
    player.npcChat("Thank Saradomin!")
    player.endChat()
	
def chat_3468208(player):
    player.npcChat("Oh, okay then...")
    player.endChat()

def chat_3468209(player):
    player.npcChat("How are you getting on with finding the ingredients?")
    player.nextChat(3468210)

def chat_3468210(player):
    player.playerChat("I haven't got all of them yet, I'm still looking.")
    player.nextChat(3468211)

def chat_3468211(player):
    player.npcChat("Please get the ingredients quickly. I'm running out of time!", "The Duke will throw me onto the street!")
    player.endChat()

def chat_3468212(player):
    player.playerChat("I've got the ingredients!")
    player.nextChat(3468213)

def chat_3468213(player):
    player.npcChat("You've got everything I need! I am saved!", "Thank you!")
    player.nextChat(3468214)

def chat_3468214(player):
    player.playerChat("So do I get to go to the Duke's party?")
    player.nextChat(3468215)

def chat_3468215(player):
    player.npcChat("I'm afraid not.", "Only the big cheeses get to Dine with the Duke.")
    player.nextChat(3468216)

def chat_3468216(player):
    player.playerChat(" Well, maybe one day I'll be important enough"," to sit at the Duke's table.")
    player.nextChat(3468217)

def chat_3468217(player):
    player.npcChat("Maybe, but I won't be holding my breath.")
    player.nextChat(3468218)
	
def chat_3468218(player):
    player.getQuest(13).setStage(2)
    player.deleteItem(egg)
    player.deleteItem(bucket_of_milk)
    player.deleteItem(pot_of_flour)
    player.getFunction().addSkillXP(50000, player.playerCooking)
    reward = QuestReward("1 Quest Point", "50,000 Cooking XP")
    player.completeQuest("Cook's Assistant", reward, 1891)

def first_click_object_8689(player):
    if player.hasItem(1925):
        player.deleteItem(1925)
        player.addItem(1927)
        player.startAnimation(2292)
        player.sendMessage("You fill the bucket with milk.")
    else:
        player.sendMessage("You need a bucket to milk a cow.")
		
def second_click_object_15507(player):
    pick_wheat(player)
	
def second_click_object_15508(player):
    pick_wheat(player)

def second_click_object_15506(player):
    pick_wheat(player)
	
def pick_wheat(player):
    if player.hasInventorySpace(1):
        player.startAnimation(827)
        player.sendMessage("You pick some wheat.")
        player.getFunction().addObject(-1, player.objectX, player.objectY, 0, 0, 10)
        player.addItem(1947)
    else:
        player.sendMessage("You don't have enough inventory space to pick wheat.")