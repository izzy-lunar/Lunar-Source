#Quest Name: Aggie's Concoction
#Quest Authors: Insignia
#Date Created: April 18, 2015
#Quest Length: Short
#Item 7409 (Magic Seceteurs) must be made non-tradeable, if not already, and have the proper bonus (10% herb harvest bonus)

#NPCs
Aggie_id= 922

def configure_quest_35():
    quest_id = 35
    quest_name = 'Aggies Concoction'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)

def quest_button_35(player):
    quest_stage = player.getQuest(35).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Aggies Concoction", "I can start this quest by talking to Aggie in Draynor.", "I need a Herblore level of 25 and a Farming level", "of 32 to start this quest.", "")
    elif quest_stage == 1:
        player.boxMessage("I should bring the items to Aggie.")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Aggies Concoction@bla@.")
       
def first_click_npc_922(player):
    quest_stage = player.getQuest(35).getStage()
    farming_level = player.getLevel("farming")
    herblore_level = player.getLevel("herblore")
    if quest_stage == 0 and farming_level > 31 and herblore_level > 24:
        player.startChat(848401)
    elif quest_stage == 0:        
        player.npcChat("You're not the person I'm looking for.")
        player.endChat()
    elif quest_stage == 1 and player.hasItem(258, 10) and player.hasItem(256, 10) and player.hasItem (254, 10) and player.hasItem(252, 10) and player.hasItem(250, 10):
        player.startChat(5555444)
    elif quest_stage == 1:
        player.startChat(848411)
    elif quest_stage == 2 and not player.hasItem(7409):    #If quest is completed and you have lost the secateurs, Aggie will give another. Not sure if proper way to check if there is none in the inventory
        player.addItem(7409, 1)       
    else:
        player.playerChat("POTIONS!!! POTIONS!!! POTIONS!!!")
        player.endChat()
     
#Introductory Conversation       
             
def chat_848401(player):
    player.npcChat("HAHAHAHA It is all coming together!!!")
    player.nextChat(848402)

def chat_848402(player):
    player.playerChat("Excuse me?")
    player.nextChat(848403)
   
def chat_848403(player):
    player.npcChat("WHO DARES ENTER MY LAIR!!! *cough* *cough*")
    player.nextChat(848404)

def chat_848404(player):
    player.playerChat("Your 'lair'?")
    player.nextChat(848405)
   
def chat_848405(player):
    player.npcChat("Yes my lair! This is where I make all my evil potions!")
    player.nextChat(848406)
   
def chat_848406(player):
    player.playerChat("Evil Potions?")
    player.nextChat(848407)
   
def chat_848407(player):
    player.npcChat("Yes! The most diabolical potions this world has ever seen!")
    player.nextChat(848408)
   
def chat_848408(player):
    player.npcChat("Want to help gather supplies?", "I shall pay you handsomely!")
    player.nextChat(848409)

def chat_848409(player):
    player.dialogueOption("Im in!", 848410, "No way!", 5554)
   
def chat_5554(player):
    player.endChat()

def chat_848410(player):
    player.npcChat("OK then! You will need the following:")
    player.nextChat(848411)

def chat_848411(player):
    player.npcChat("10 noted clean Ranarr weeds")
    player.nextChat(848412)
   
def chat_848412(player):
    player.npcChat("10 noted clean Harralandar weeds")
    player.nextChat(848413)
   
def chat_848413(player):
    player.npcChat("10 noted clean Tarromin weeds")
    player.nextChat(848414)
   
def chat_848414(player):
    player.npcChat("10 noted clean Marrentill weeds")
    player.nextChat(848415)
   
def chat_848415(player):
    player.npcChat("10 noted clean Guam weeds")
    player.nextChat(848416)
   
def chat_848416(player):
    player.dialogueOption("Got it!", 848417, "I didn't catch all of that", 848410)
   
def chat_848417(player):
    player.npcChat("OK. Meet me back here when you have everything", "Good luck!")
    player.endChat()                                                                                                                                                                                                                                                           
    player.getQuest(35).setStage(1)
    player.refreshQuestTab()
#Conversation if player has required materials (50 Clean of all herbs)

def chat_5555444(player):
    player.playerChat("I have your weeds!")
    player.nextChat(5556444)
   
def chat_5556444(player):
    player.npcChat("Great! I'll take those.")
    player.nextChat(5557444)
   
def chat_5557444(player):
    player.boxMessage("Aggie stores the herbs in her hat.")
    player.nextChat(5558444)
       
def chat_5558444(player):
    player.npcChat("I suppose you're due some kind of reward...")
    player.nextChat(5559444)
    
def chat_5559444(player):
    player.endChat()
    player.getQuest(35).setStage(2)
    player.addCash(10000000)                                         
    player.getFunction().addSkillXP(250000, player.playerFarming)   
    player.getFunction().addSkillXP(250000, player.playerHerblore)   
    player.deleteItem(258, 10)                                       
    player.deleteItem(256, 10)
    player.deleteItem(254, 10)
    player.deleteItem(252, 10)
    player.deleteItem(250, 10)                                     
    player.addItem(7409, 1)                                         
    player.addPoints(100)                                             
    reward = QuestReward("10,000,000 coins", "1 Quest Point", "250,000 Farming XP",  "250,000 Herblore XP", "100 OXP", "Magic Secateurs")
    player.completeQuest("Aggies Concoction", reward, 7409)