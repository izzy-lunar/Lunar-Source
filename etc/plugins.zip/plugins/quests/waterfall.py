##################################
###       Author: Boljake      ###
###        Date:25.1.2015      ###
##################################



Waterfall_Barrel = 2022

Waterfall_Door = 2010

Dead_Tree = 2020

River = 10283

Almera = 304

Hadley = 302

Golrie = 306

Glarials_pebble = 294

Glarials_amulet = 295

Glarials_urn = 296

Chalice_of_Eternity = 2014

Glarials_tomb = 1993

Glarials_tombstone = 1992

Log_Raft = 1987

Book_On_Baxtorian = 292

Waterfall_Bookcase = 1989



def configure_quest_37():
    quest_id = 37
    quest_name = 'Waterfall Quest' 
    quest_stages = 8 
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(304, 2521, 3497, 0, 1)
    World.addNonCombatNpc(302, 2515, 3430, 0, 1)
    World.addNonCombatNpc(306, 2530, 3155, 0, 1)
    
def quest_button_37(player):
    quest_stage = player.getQuest(37).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Waterfall Quest", "I can start this quest by talking to @dre@Almera@bla@ near the waterfall.", "", "You will need an @dre@31 Agility@bla@ to start this quest", "and you must have completed @dre@Sewers Cleanup@bla@.")
    elif quest_stage == 1:
        player.boxMessage("I should check out the raft out back.")
    elif quest_stage == 2:
        player.boxMessage("I should find @dre@Hadley")
    elif quest_stage == 3:
        player.boxMessage("I should find the book about the elf king, @blu@Baxxtorian")
    elif quest_stage == 4:
        player.boxMessage("The book tells me I should find a man named @blu@Golrie@bla@.")
    elif quest_stage == 5:
        player.boxMessage("I should locate the @blu@Glarial's Tombstone")
    elif quest_stage == 6:
        player.boxMessage("I should locate the @blu@Glarial's Tomb")
    elif quest_stage == 7:
        player.boxMessage("I should locate the @blu@Chalice Of Eternity")
    elif quest_stage == 8:
        player.boxMessage("I have completed @dre@Waterfall Quest@bla@.")

            
#1st click

def click_item_292(player):
    player.playerChat("Apparently I can find a gnome named", "Gorlie near the centre of a maze.")

def first_click_npc_304(player):
    agility_level = player.getLevel("agility")
    quest_stage = player.getQuest(37).getStage()
    if quest_stage == 0 and agility_level > 30:
        player.startChat(672315133) 
    else:
        player.playerChat("Nice day in this land of OwnXile")
        

def first_click_npc_306(player):#Golrie
    stage = player.getQuest(37).getStage()
    if stage == 4:
       player.startChat(1033748637)
    else:
       player.sendMessage("Golrie looks very busy.")

def first_click_object_1989(player):
    stage = player.getQuest(37).getStage()
    if stage == 3:
        player.boxMessage("You search the book self and you find a book!")
        player.getQuest(37).setStage(4)
        player.refreshQuestTab()
        player.addItem (292)

def first_click_object_1992(player):
    stage = player.getQuest(37).getStage()
    down_hole = Point(2555, 9845)
    player.move(down_hole)
    player.boxMessage("You climb into the dark hole!")
    if stage == 5:
        player.getQuest(37).setStage(6)
        player.refreshQuestTab()
        down_hole = Point(2555, 9845)
        player.move(down_hole)
    
def first_click_object_1993(player):
    stage = player.getQuest(37).getStage()
    if stage == 6:
        player.boxMessage("You steal an amulet from the tomb!")
        player.addItem(Glarials_amulet)
        player.getQuest(37).setStage(7)
        player.refreshQuestTab()
    
def first_click_object_2014(player):
    stage = player.getQuest(37).getStage()
    if stage == 6:
        player.boxMessage("@blu@A magical force sweeps the amulet from right under your nose!!")
        player.deleteItem(Glarials_amulet)
        player.nextChat(10333448643)
                
def first_click_object_1987(player):
    player.dialogueQuestion("Go down stream?", "Yes I am fearless!", 24732420, "I think I will stay here", 2198329)

def first_click_object_10283(player):
    player.dialogueQuestion("Swim across?", "Am ready!", 247232420, "I think I will stay here", 2198329)

def first_click_object_2020(player):
    player.dialogueOption("Climb down the tree", 22432420, "I think I will stay here", 2198329)

def first_click_object_2010(player):
    player.boxMessage("You squeeze through the door")
    through_door = Point(2606, 9891)
    player.move(through_door) #update if find real dung

def first_click_object_2022(player):
    player.boxMessage("O DEAR! You feel in the Barrel!")
    barrel_fall = Point(2527, 3413)
    player.move(barrel_fall)

def chat_22432420(player):
    player.playerChat("What am I doing with my life?!?!")
    idk_wat = Point(2511, 3463)
    player.move(idk_wat)
    player.endChat()
    
#river
def chat_247232420(player):
    player.playerChat("Am ready!")
    river_go = Point(2513, 3468)
    player.move(river_go)
    player.endChat()
    
#raft
def chat_24732420(player):
    player.playerChat("Yes I am fearless!")
    fearless = Point(2512, 3480)
    player.move(fearless)
    stage = player.getQuest(37).getStage()
    if stage == 1:
        player.getQuest(37).setStage(2)
        player.playerChat("I don't see anyone here, I should find @blu@Hadley@bla@.")
        player.refreshQuestTab()
        player.endChat()
    
def chat_2198329(player):
    player.playerChat("I think I will stay here")
    player.endChat()

#talking to Almera

def chat_672315133(player):
    player.playerChat("Hello")
    player.nextChat(672315134)

def chat_672315134(player):
    player.npcChat("Ah hello there. Nice to see an outsider for a change.", "Are you busy? I have a small problem.")
    player.nextChat(672315135)

def chat_672315135(player):
    player.dialogueQuestion("Select an Option", "No I'm in a rush!", 32434238, "How can I help?", 672315136)
    player.nextChat(672315136)
   
def chat_32434238(player):
    player.npcChat("That's a shame ok.")
    player.endChat()
    

def chat_672315136(player):
    player.npcChat("It's my son Hudon, he's always getting into trouble, the boys convinced there's", "hidden treasure in the river and I'm abit worried about his safety,", "the poor lad can't even swim.")
    player.nextChat(672315137)

def chat_672315137(player):
    player.playerChat("I could go and take a look for you if you like?")
    player.getQuest(37).setStage(1)
    player.refreshQuestTab()
    player.nextChat(672315138)
    

def chat_672315138(player):
    player.npcChat("Would you? You are kind. You can use the small raft", "out back if you wish, do be careful the current down", "stream is very strong")
    player.endChat()

#Talking to Hadley

def chat_672315139(player):
    player.playerChat("Hello again Hadley!")
    player.nextChat(672315140)

def chat_672315140(player):
    player.npcChat("Are you on holiday? If so you've come to the right place.", "I'm working as a tourist guide, anything you nedd to know just", "ask me we have some of the most unspoilt wildlife and scenery in OwnXile.")
    player.nextChat(672315141)

def chat_672315141(player):
    player.npcChat("People come from miles around to fish in the", "clear lakes or to wonder the beautiful hill sides.")
    player.nextChat(672315142)

def chat_672315142(player):
    player.playerChat("It is quite pretty")
    player.nextChat(672315143)

def chat_672315143(player):
    player.npcChat("Surely pretty is an understatement kind Sir.", "Beautiful amazing or possibly life-changing would be more", "suitable wording. Have you senn Baxxtorian waterfall?", "Named after the elf king who was buried beneath.")
    player.nextChat(672315144)

def chat_672315144(player):
    player.playerChat("Can you tell me what happend to the elf king?")
    player.nextChat(672315145)

def chat_672315145(player):
    player.npcChat("There are many myths about Baxxtorian. One popular story is this", "afterdefending his kingdom against the invading dark forces", "from the west Baxxtorian returned to find his wife", "Glarial had been captured by the")
    player.nextChat(672315146)

def chat_672315146(player):
    player.npcChat("enemy!")
    player.nextChat(672315147)

def chat_672315147(player):
    player.npcChat("This destroyed Baxxtorian, after years of searching he became a recluse.", "In the secret home he had made for Glarial under the waterfall", "he never came out and it is told that only Glarial could enter.")
    player.nextChat(672315148)

def chat_672315148(player):
    player.playerChat("What happend to him?")
    player.getQuest(37).setStage(3)
    player.refreshQuestTab()
    player.nextChat(672315149)

def chat_672315149(player):
    player.npcChat("Oh, I dont know. I believe we have some pages", "on him upstairs in our archives. If you wish to look", "at them please be careful, they'are all pretty delicate.")
    player.endChat()


#Talking to Golrie

  
def chat_1033748637(player):
    player.playerChat("Hello is your name Golrie?")
    player.nextChat(1033748638)

def chat_1033748638(player):
    player.npcChat("That's me. I've been stuck in here for weeks, those goblins", "are trying to steal my family's heirlooms.", "My grandad gave me all sorts of old junk.")
    player.nextChat(1033748639)

def chat_1033748639(player):
    player.playerChat("Do you mind if i have a look?")
    player.nextChat(1033748640)

def chat_1033748640(player):
    player.npcChat("No, of course not.")
    player.nextChat(1033748641)

def chat_1033748641(player):
    player.boxMessage("You take a look around.")
    player.nextChat(1033748642)

def chat_1033748642(player):
    player.playerChat("Could i take this old pebble?")
    player.getQuest(37).setStage(5)
    player.refreshQuestTab()
    player.nextChat(1033748643)

def chat_1033748643(player):
    player.npcChat("Oh that, yes have it, its just some", "old elven junk I believe.")
    player.endChat()

def first_click_object_2014(player):
    if player.getQuest(37).getStage() == 7:
        player.startChat(1040758432)
    else:
        player.sendMessage("wat")
    
def chat_1040758432(player):
    player.addItem(10586, 4)
    player.addItem(995, 5000000)
    player.getQuest(37).setStage(8)
    player.refreshQuestTab()
    water_room = Point(2539, player.getY())
    player.move(water_room)
    reward = QuestReward("1 Quest Point", "5 Million Coins", "3x Combat Lamp")
    player.completeQuest("Waterfall Quest", reward, 295)
 
