demon_id = 934
king_roald_id = 648
iron_bar_id = 2352
rune_bar_id = 2364
addy_bar_id = 2362
steel_bar_id = 2354
raw_pike_id = 350#u fucking wot who set this as 349
silverlight_id = 2402
burnt_bones_id = 528

def configure_quest_3():
    quest_id = 3
    quest_name = 'Demon Slayer'
    quest_stages = 5
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(king_roald_id, 3222, 3476, 0, 1)
    World.addCombatNpc(demon_id, 3228, 3368, 0, 1, 250, 40, 150, 150)
    
def quest_button_3(player):
    quest_stage = player.getQuest(3).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Demon Slayer", "I can start this quest by speaking to the @dre@King Roald@bla@ who", "is located in an eastern room of the", " castle in @dre@Varrock@bla@. I will need a Smithing level", "of 15 and a Fishing level of 20 before I can start.")
    elif quest_stage == 1:
        player.boxMessage("I must bring 10 Iron Bars to @dre@King Road@bla@.") 
    elif quest_stage == 2:
        player.boxMessage("I must bring 50 raw pike to @dre@King Roald@bla@.") 
    elif quest_stage == 3:
        player.boxMessage("When I'm ready to fight the demon, I have to talk to @dre@King Roald@bla@") 
    elif quest_stage == 4:
        player.boxMessage("I should bring the burnt bones to @dre@King Roald@bla@.") 
    elif quest_stage == 5:
        player.boxMessage("I have completed the @dre@Demon Slayer@bla@.")
        
def kill_npc_934(player):
    quest_stage = player.getQuest(3).getStage()
    if quest_stage == 3:
        player.getQuest(3).setStage(4)
        player.playerChat("I better take the Demons bones to King Roald.")	

def click_item_528(player):
    player.playerChat("I better take the bones to King Roald")	

def first_click_npc_648(player):
    smithing_level = player.getLevel("smithing")
    fishing_level = player.getLevel("fishing")
    quest_stage = player.getQuest(3).getStage()
    if quest_stage == 0 and fishing_level > 19 and smithing_level > 15:
        player.startChat(5008)
    elif quest_stage == 1 and player.hasItem(iron_bar_id, 10):
        player.startChat(5017)
    elif quest_stage == 1:
        player.npcChat("Why are you back already?", "Hurry up and get me the items!")
    elif quest_stage == 2 and player.hasItem(raw_pike_id, 50):
        player.startChat(5021)
    elif quest_stage == 2:
        player.npcChat("The dwarfs are hungry, please hurry up!")
    elif quest_stage == 3 and player.hasItem(silverlight_id):
        player.startChat(5035)
    elif quest_stage == 3:
        player.npcChat("You must bring the Silverlight, to slay the demon!")
    elif quest_stage == 4 and player.hasItem(burnt_bones_id):
        player.startChat(5028)
    elif quest_stage == 4:
        player.npcChat("If you have slayed the demon, you better bring some proof!")
    else:
        player.playerChat("I better not disturb the king.")
    
def chat_5008(player):
    player.npcChat("Hello young adventurer, what brings you here?")
    player.nextChat(5009)
    
def chat_5009(player):
    player.dialogueOption("I'm looking for an adventure.", 5010, "I don't know, bye.", 5011)

def chat_5010(player):
    player.playerChat("I want to become the biggest legend in OwnXile.", "Thus I'm looking for a great adventure!")
    player.nextChat(5012)
    
def chat_5011(player):
    player.playerChat("To be honest I'm not sure, bye!")
    player.endChat()
    
def chat_5012(player):
    player.npcChat("In that case you have come to the right place.", "I have a quest that only the bravest warrior can complete", "Are you still up for the challenge young adventurer?")
    player.nextChat(5013)
    
def chat_5013(player):
    player.dialogueQuestion("Accept Quest?", "Yes", 5014, "No", 5015)
    
def chat_5014(player):
    player.playerChat("Yes, of course.")
    player.nextChat(5016)
    
def chat_5015(player):
    player.playerChat("No thanks, it sounds too dangerous...")
    player.endChat()
    
def chat_5016(player):
    player.npcChat("A dangerous demon is terrorizing our great world", "To to slay this demon you must bring the Silverlight sword", "The Silverlight sword can only be made by my dwarfs.", "Bring me 10 rune bars, 20 addy bars and 100 steel bars")
    player.getQuest(3).setStage(1)
    player.refreshQuestTab()
    player.endChat()
    
def chat_5017(player):
    player.npcChat("Good. Hand me those items, we have little time!")
    player.deleteItem(iron_bar_id, 10)
    player.getQuest(3).setStage(2)
    player.refreshQuestTab()
    player.nextChat(5018)

def chat_5018(player):
    player.npcChat("The dwarfs are hungry,", "Please bring me 50 raw pike!")
    player.nextChat(5019)
    
def chat_5019(player):
    player.playerChat("50 raw pike!?")
    player.nextChat(5020)
    
def chat_5020(player):
    player.npcChat("The dwarfs eat a lot of raw food... Please hurry up!")
    player.endChat()
    
def chat_5021(player):
    player.playerChat("I have the 50 raw pike now.")
    player.nextChat(5022)
    
def chat_5022(player):
    player.npcChat("Good job! Here is your Silverlight sword.")
    player.addItem(silverlight_id)
    player.deleteItem(raw_pike_id, 50)
    player.getQuest(3).setStage(3)
    player.refreshQuestTab()
    player.nextChat(5023)
    
def chat_5023(player):
    player.npcChat("Come see me again when you are ready to fight the demon.")
    player.endChat()
    
def chat_5035(player):
    player.npcChat("Are you ready to fight the demon?")
    player.nextChat(5024)
    
def chat_5024(player):
    player.dialogueQuestion("Fight Demon?", "Bring it on!", 5025, "Not yet", 5026)

def chat_5025(player):
    player.playerChat("Bring it on!")
    player.nextChat(5027)
    
def chat_5026(player):
    player.playerChat("No, I'm not quite ready yet.")
    player.endChat()
    
def chat_5027(player):
    player.npcChat("As you wish young adventurer.")
    player.nextChat(5050)
	
def chat_5050(player):
    player.teleport(Position.DEMONS_ROOM)
    player.endChat()
    
def chat_5028(player):
    player.playerChat("Slaying the demon was a piece of cake.")
    player.nextChat(5029)
    
def chat_5029(player):
    player.npcChat("Wha.. What? I can't believe it!")
    player.nextChat(5030)
    
def chat_5030(player):
    player.playerChat("I brought you the demon's bones as a trophy.")
    player.nextChat(5031)
    
def chat_5031(player):
    player.npcChat("Thank you " + str(player.playerName) + "!", "You will never be forgotten!")
    player.nextChat(5032)
    
def chat_5032(player):
    player.playerChat("That's it? Don't I get a reward?")
    player.nextChat(5033)
    
def chat_5033(player):
    player.npcChat("Oh... I almost forgot!")
    player.nextChat(5034)
    
def chat_5034(player):
    player.endChat()
    player.getQuest(3).setStage(5)
    player.refreshQuestTab()
    player.deleteItem(burnt_bones_id, 1)
    player.addCash(5000000)
    player.getFunction().addSkillXP(50000, player.playerSmithing)
    player.getFunction().addSkillXP(50000, player.playerFishing)
    player.addItem(10586, 1)
    reward = QuestReward("5,000,000 coins", "50,000 XP in Smithing", "50,000 XP in Fishing", "1 Combat Lamp")
    player.completeQuest("Demon Slayer", reward, silverlight_id)