
#dungeon guard
def configure_quest_36():
    quest_id = 36
    quest_name = 'Bone Gatherer'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(5922, 2883, 9796, 0, 1)
	
def quest_button_36(player):
    quest_stage = player.getQuest(36).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Bone Gatherer", "I can start this quest by speaking to the ", "in Taverly dungeon. I should have completed the quest", "@dre@Leaders no Longer@bla@ before attempting this.", "")
    elif quest_stage == 1:
        player.boxMessage("I must bring the resources back to the guard.") 
    elif quest_stage == 2:
        player.boxMessage("I have completed the @dre@Bone Gatherer@bla@.")
	
def first_click_npc_5922(player):
    quest_stage = player.getQuest(36).getStage()
    if player.getQuest(27).getStage() == 2:
        if quest_stage == 0:
            player.startChat(1874903065)
        elif quest_stage == 1 and has_dungeon_guard_items(player) or has_dungeon_guard_items_noted(player):
            player.startChat(1001305094)
        elif quest_stage == 1:
            player.startChat(614811373)
        elif quest_stage == 2:
            player.npcChat("Thank you for your help.")
    else:
        player.sendMessage("You must have completed @dre@Leaders no Longer@bla@ to speak to him.")



def has_dungeon_guard_items(player):
    return player.hasItem(530, 5) and player.hasItem(532, 5) and player.hasItem(11783, 5) and player.hasItem(592, 5)
	
def has_dungeon_guard_items_noted(player):
    return player.hasItem(531, 5) and player.hasItem(533, 5) and player.hasItem(11783, 5) and player.hasItem(593, 5)
	
def delete_bones_dung(player):
    if has_dungeon_guard_items(player):
        player.deleteItem(530, 5)
        player.deleteItem(532, 5)
        player.deleteItem(11783, 5)
        player.deleteItem(592, 5)
    if has_dungeon_guard_items_noted(player):
        player.deleteItem(531, 5)
        player.deleteItem(533, 5)
        player.deleteItem(11783, 5)
        player.deleteItem(593, 5)

def chat_1874903065(player):
    player.playerChat("The combat instructor sent me to speak", "with you!")
    player.nextChat(1874903066)

def chat_1874903066(player):
    player.npcChat("Oh he did, did he?")
    player.nextChat(1874903067)

def chat_1874903067(player):
    player.npcChat("I assume you're fully trained to handle", "various monsters and demons then?")
    player.nextChat(1874903068)

def chat_1874903068(player):
    player.playerChat("I've had a fair bit of experience, yes!")
    player.nextChat(1874903069)

def chat_1874903069(player):
    player.npcChat("Then you can assist us in our battle here.")
    player.nextChat(1874903070)

def chat_1874903070(player):
    player.npcChat("I need you to gather the following resources:")
    player.nextChat(1874903071)

def chat_1874903071(player):
    player.npcChat("5 Bat Bones.")
    player.nextChat(1874903072)

def chat_1874903072(player):
    player.npcChat("5 Big Bones.")
    player.nextChat(1874903073)

def chat_1874903073(player):
    player.npcChat("5 Human Bones.")
    player.nextChat(1874903074)

def chat_1874903074(player):
    player.npcChat("5 Ashes.")
    player.nextChat(1874903075)

def chat_1874903075(player):
    player.playerChat("I'll go explore the dungeon and see what", "I can find then!")
    player.getQuest(36).setStage(1)
    player.refreshQuestTab()
    player.nextChat(1874903076)

def chat_1874903076(player):
    player.npcChat("Be careful out there!")
    player.endChat()

def chat_614811373(player):
    player.npcChat("Have you got those items yet?")
    player.nextChat(614811374)

def chat_614811374(player):
    player.playerChat("I'm still working on it!")
    player.endChat()
	
def chat_1001305094(player):
    player.playerChat("I got all the bones!")
    player.nextChat(1001305095)

def chat_1001305095(player):
    player.npcChat("Cheers dude!")
    player.nextChat(1001305096)

def chat_1001305096(player):
    player.addItem(10586, 2)
    player.addItem(995, 2000000)
    player.getFunction().addSkillXP(35000, player.playerPrayer)
    player.getQuest(36).setStage(2)
    player.refreshQuestTab()
    player.endChat()
    delete_bones_dung(player)
    reward = QuestReward("1 Quest Point", "2 Million Coins", "2x Combat Lamp", "35,000 Prayer XP")
    player.completeQuest("Bone Gatherer", reward, 530)