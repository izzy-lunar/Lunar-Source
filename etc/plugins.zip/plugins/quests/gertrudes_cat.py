
from com.ownxile.core import World

gertrude = World.addNonCombatNpc(780, 3152, 3414, 0, 1)
gertrudes_cat = World.addNonCombatNpc(759, 3306, 3512, 1, 1)
shilop = 781
wilough = 783

def configure_quest_16():
    quest_id = 16
    quest_name = "Gertrudes Cat"
    quest_stages = 4
    World.addNonCombatNpc(shilop, 3218, 3434, 0, 1)
    World.addNonCombatNpc(wilough, 3219, 3433, 0, 1)
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_16(player):
    quest_stage = player.getQuest(16).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Gertrude's Cat", "I can start this quest by speaking to @dre@Gertrude@bla@ who", "is lives in a house west of @dre@Varrock@bla@.", " ", " ")
    elif quest_stage == 1:
        player.boxMessage("I need to find Gertrudes kids, perhaps they'll know where", "I can find Fluffs.")
    elif quest_stage == 2:
        player.boxMessage("Shilop told me he last saw Fluffs in the Lumber mill,", "to the north west of Varrock.")
    elif quest_stage == 3:
        player.boxMessage("I found the cat! I should let Gertrude know.")
    elif quest_stage == 4:
        player.boxMessage("I have completed @dre@Gertrude's Cat@bla@.")

def first_click_npc_780(player):
    quest_stage = player.getQuest(16).getStage()
    if quest_stage == 0: 
        player.startChat(245850)
    elif quest_stage == 1 or quest_stage == 2:
        player.startChat(245862)
    elif quest_stage == 3:
        player.startChat(245886)
    elif quest_stage == 4:
        player.startChat(245896)
        
def first_click_npc_759(player):
    gertrudes_cat.forceChat("Hisss!")
    player.sendMessage("Doesn't seem like the Cat wants to be picked up.")
    
def second_click_npc_759(player):
    gertrudes_cat.forceChat("Hisss!")
    player.sendMessage("Doesn't seem like the Cat wants to be stroked.")

def third_click_npc_759(player):
    player.startChat(245885)
    
def use_item_1573_on_327(player):
    season_sardine(player)
    
def use_item_327_on_1573(player):
    season_sardine(player)

def season_sardine(player):
    player.deleteItem(327)
    player.deleteItem(1573)
    player.addItem(1552)
    player.sendMessage("You season the sardine with some doodle leaves.")

def item_1552_on_npc_759(player):
    quest_stage = player.getQuest(16).getStage()
    if quest_stage == 2: 
        player.deleteItem(1552)
        player.getQuest(16).setStage(3)
        player.startAnimation(837)
        player.boxMessage("You feed Fluffs the sardine and she heads home.")
        player.endChat()

def first_click_npc_781(player):
    quest_stage = player.getQuest(16).getStage()
    if quest_stage == 1: 
        player.startChat(245864)
    else:
        player.playerChat("I probably shouldn't be talking to those kids.")

def first_click_object_2618(player):
    if player.getY() > 3492:
        player.getFunction().movePlayer(player.getX(), 3491, 0)
    else:
        player.getFunction().movePlayer(player.getX(), 3493, 0)

def chat_245850(player):
    player.playerChat("Hello, are you ok?")
    player.nextChat(245851)
    
def chat_245851(player):
    player.npcChat("Do I look ok? Those kids drive me crazy.")
    player.nextChat(245852)

def chat_245852(player):
    player.npcChat("I'm sorry. It's just that I've lost her.")
    player.nextChat(245853)

def chat_245853(player):
    player.playerChat("Lost who?")
    player.nextChat(245854)
    
def chat_245854(player):
    player.npcChat("Fluffs, poor Fluffs. She never hurt anyone.")
    player.nextChat(245855)

def chat_245855(player):
    player.playerChat("Who's Fluffs?")
    player.nextChat(245856)

def chat_245856(player):
    player.playerChat("My beloved feline friend Fluffs. She's been purring by", "my side side for almost a decade. Please could you go", "search for her while I look over the kids?")
    player.nextChat(345856)
    
def chat_345856(player):
    player.dialogueOption("Well, I suppose I could.", 245860, "Sorry, I'm too busy to play pet rescue.", 245857)

def chat_245857(player):
    player.playerChat("Sorry, I'm too busy to play pet rescue.", "Bitch.")
    player.endChat()
    
def chat_245860(player):
    player.playerChat("Well I suppose I could.")
    player.nextChat(245861)
    
def chat_245861(player):
    player.npcChat("Really? Thank you so much! I really have no idea", "where she could be!")
    player.nextChat(245862)

def chat_245862(player):
    player.npcChat("I think my sons, Shilop and Wilough, saw the her last.", "They'll be out in the market place.")
    player.nextChat(245863)
    if player.getQuest(16).getStage() == 0:
        player.getQuest(16).setStage(1)
        player.refreshQuestTab()

def chat_245863(player):
    player.playerChat("Alright then, I'll see what I can do.")
    player.endChat()
    
def chat_245864(player):
    player.playerChat("Hello there. I've been looking for you.")
    player.nextChat(245865)
    
def chat_245865(player):
    player.npcChat("I didn't mean to take it!")
    player.nextChat(245866)

def chat_245866(player):
    player.playerChat("What? I'm trying to help your mum find Fluffs.")
    player.nextChat(245867)

def chat_245867(player):
    player.npcChat("I might be able to help. Fluffs followed me to our secret", "play area and I haven't seen her since")
    player.nextChat(245868)
    
def chat_245868(player):
    player.playerChat("Where's the play area?")
    player.nextChat(245869)

def chat_245869(player):
    player.npcChat("If I told you that, it wouldn't be a secret.")
    player.nextChat(245870)

def chat_245870(player):
    player.playerChat("What will make you tell me?")
    player.nextChat(245871)

def chat_245871(player):
    player.npcChat("Well... now you ask, I am a bit short on cash.")
    player.nextChat(245872)

def chat_245872(player):
    player.playerChat("How much?")
    player.nextChat(245873)
    
def chat_245873(player):
    player.npcChat("10 coins.")
    player.nextChat(245874)
    
def chat_245874(player):
    player.lastClickedNpcId = 783
    player.npcChat("10 coins?!?!")
    player.nextChat(245875)
    
def chat_245875(player):
    player.npcChat("I'll handle this.")
    player.nextChat(245876)

def chat_245876(player):
    player.npcChat("100,000 coins should suffice.")
    player.nextChat(245877)
    
def chat_245877(player):
    player.playerChat("100,000 coins! Why should I pay you?")
    player.nextChat(245878)
    
def chat_245878(player):
    player.npcChat("You shouldn't, but we won't help you otherwise. We never", "liked that cat anyway, so what do you say?")
    player.nextChat(245879)
    
def chat_245879(player):
    player.dialogueOption("I'm not paying you a penny.", 245880, "Okay then, I'll pay.", 245881)
    
def chat_245884(player):
    player.playerChat("I'm not paying you a penny.")
    player.endChat()

def chat_245881(player):
    if player.hasItem(995, 100000):
        player.playerChat("Okay then I'll pay you the money.")
        player.nextChat(245882)
    else:
        player.playerChat("I would pay but I don't have any money.")
        player.endChat()

def chat_245882(player):
    player.playerChat("So where did you see Fluffs?")
    player.nextChat(245883)
    
def chat_245883(player):
    player.lastClickedNpcId = 781
    player.npcChat("We play at an abandoned lumber mill to the north east.", "Just beyond the Jolly Boar Inn. I saw Fluffs running", "around in there.")
    player.nextChat(245884)
    player.deleteItem(995, 100000)
    player.getQuest(16).setStage(2)
    
def chat_245884(player):
    player.playerChat("Great.")
    player.endChat()

def chat_245885(player):
    player.playerChat("I think she needs feeding.")
    player.endChat()

def chat_245886(player):
    player.playerChat("Hello Gertrude. I found Fluffs.")
    player.nextChat(245887)

def chat_245887(player):
    player.npcChat("You're back! Thank you! Thank you! Fluffs just came", "back! I think she was just upset as she couldn't find her,", "kitten")
    player.nextChat(245888)
    
def chat_245888(player):
    player.boxMessage("Gertrude gives you kiss.")
    player.nextChat(245889)

def chat_245889(player):
    player.npcChat("If you hadn't found her kitten it would have died out", "there!")
    player.nextChat(245890)

def chat_245890(player):
    player.npcChat("I don't know how to thank you. I have no real matierial", "possessions. I do have kittens! I can only really look", "after one.")
    player.nextChat(245891)

def chat_245891(player):
    player.playerChat("Well, if it needs a home.")
    player.nextChat(245892)
    
def chat_245892(player):
    player.npcChat("I would sell it to my cousin in West Ardougne. I hear", "there's a rat epidemic there. But it's too far.")
    player.nextChat(245893)

def chat_245893(player):
    player.npcChat("Here you go, look after her and thank you again!")
    player.nextChat(245894)

def chat_245894(player):
    player.boxMessage("Gertrude gives you a kitten.")
    player.nextChat(245895)

def chat_245895(player):
    gcat_id = 1555 + Misc.random(4)
    player.getQuest(16).setStage(4)
    player.addItem(gcat_id)
    reward = QuestReward("1 Quest Point", "A kitten!", "Raise cats.")
    player.completeQuest("Gertrude's Cat", reward, gcat_id)
    player.endChat()
    
def chat_245896(player):
    player.npcChat("Thanks for saving my cat!")
    player.nextChat(245897)

def chat_245897(player):
    player.playerChat("It was my pleasure.")
    player.endChat()