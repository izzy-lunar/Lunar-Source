def configure_quest_38():
    quest_id = 38
    quest_name = 'Imp Catcher'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(706, 3113, 3169, 0, 1)

def quest_button_38(player):
    quest_stage = player.getQuest(38).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Imp Catcher", "I can start this quest by talking to @dre@Wizard Mizmog@bla@ who is.", "near the Wizard tower south of Draynor.", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should slay those pesky imps and bring all four beads", "to the @dre@Wizard Migmog@bla@. He will be very pleased!")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Imp Catcher@bla@.")
        
def first_click_npc_706(player):
    quest_stage = player.getQuest(38).getStage()
    if quest_stage == 0:
        player.startChat(1452811767)
    elif quest_stage == 1 and player.hasItem(1470) and player.hasItem(1472) and player.hasItem(1474) and player.hasItem(1476):
        player.startChat(1452811777)
    elif quest_stage == 1:
        player.npcChat("Hurry up with those beads please.")
    else:
        player.sendMessage("Wizard Mizmog doesn't look like he wants to be disturbed.")

def chat_1452811767(player):
    player.playerChat("Give me a quest!")
    player.nextChat(1452811768)

def chat_1452811768(player):
    player.npcChat("Give me a quest what?")
    player.nextChat(1452811769)

def chat_1452811769(player):
    player.playerChat("Give me a quest please.")
    player.nextChat(1452811770)

def chat_1452811770(player):
    player.npcChat("Well seeing as you asked nicely... I could do with some", "help.")
    player.nextChat(1452811771)

def chat_1452811771(player):
    player.npcChat("The wizard Grayzag next door decided he didn't like", "me so he enlisted an army of hundreds of imps.")
    player.nextChat(1452811772)

def chat_1452811772(player):
    player.npcChat("These imps stole all sorts of my things. Most of these", "things I don't really care about, just eggs and balls of", "string and things.")
    player.nextChat(1452811773)

def chat_1452811773(player):
    player.npcChat("But they stole my four magical beads. There was a red", "one, a yellow one, a black one, and a white one.")
    player.nextChat(1452811774)

def chat_1452811774(player):
    player.npcChat("These imps are north of here near Draynor.", "Could you get my beads back for me?")
    player.nextChat(1452811775)

def chat_1452811775(player):
    player.dialogueQuestion("Collect Beads?", "Sure I'll help.", 1452811776, "I'm too busy", 58)
    player.nextChat(1452811776)

def chat_1452811776(player):
    player.npcChat("That's great, thank you.")
    player.getQuest(38).setStage(1)
    player.endChat()

def chat_1452811777(player):
    player.npcChat("So how are you doing finding my beads?")
    player.nextChat(1452811778)

def chat_1452811778(player):
    player.playerChat("I've got all four beads. It was hard work I can tell you.")
    player.nextChat(1452811779)

def chat_1452811779(player):
    player.npcChat("Give them here and I'll check that they really are MY", "beads, before I give you your reward. You'll like it, it's", "an amulet of glory.")
    player.nextChat(1452811780)

def chat_1452811780(player):
    player.boxMessage("You give four coloured beads to Wizard Mizgog.")
    player.nextChat(1452811781)
    
def chat_1452811781(player):
    player.addItem(10586, 3)
    player.addItem(995, 3000000)
    player.getFunction().addSkillXP(100000, player.playerMagic)
    player.getQuest(38).setStage(2)
    player.refreshQuestTab()
    player.endChat()
    player.deleteItem(1470)
    player.deleteItem(1472)
    player.deleteItem(1474)
    player.deleteItem(1476)
    reward = QuestReward("1 Quest Point", "3 Million Coins", "3x Combat Lamp", "100,000 Magic XP")
    player.completeQuest("Imp Catcher", reward, 1477)
