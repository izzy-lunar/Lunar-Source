#This Quest was created by Cam
#Quest Length = Long
#NPC 5421 needs a 100% drop of 11154; plus drops of good items to encourgae it as a killable boss; Tarn(NPC5421) needs its death anim fixed
#NPCs
mutant_id = 5421
alrena_id = 710

#Items
ruby_id = 1604
steel_bar_id = 2354
iron_bar_id = 2352
cosmic_id = 564
ring_id = 11014
dream_id = 11154

from com.ownxile.core import World
def configure_quest_29():
    quest_id = 29
    quest_name = 'Lucid Dreaming'
    quest_stages = 5
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(alrena_id, 2617, 3302, 0, 1)
    World.addCombatNpc(mutant_id, 3099, 5538, 0, 1, 550, 70, 450, 350)
	
	
    #World.addCombatNpc(1523, 3094, 5535, 0, 1, 150, 10, 200, 200)
    #World.addCombatNpc(1523, 3092, 5533, 0, 1, 150, 10, 200, 200)
    #World.addCombatNpc(1523, 3090, 5530, 0, 1, 150, 10, 200, 200)
    #World.addCombatNpc(mutant_id, 1826, 5151, 0, 1) #If more than one demon is to be added in the fight
    #World.addCombatNpc(mutant_id, 1826, 5151, 0, 1) #If more than one demon is to be added in the fight
    
def quest_button_29(player):
    quest_stage = player.getQuest(29).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Lucid Dreams", "I can start this quest by speaking to @dre@Alrena@bla@ who", "is located outside the church", "in @dre@Ardougne@bla@. I will need a Runecrafting level", "of 50 and a Smithing level of 50 before I can start.")
    elif quest_stage == 1:
        player.boxMessage("I must bring 10 cut rubys, 20 iron bars and", "20 steel bars to @dre@Alrena@bla@ who is outside Ardougne church.") 
    elif quest_stage == 2:
        player.boxMessage("I must bring the items to @dre@Alrena.") 
    elif quest_stage == 3:
        player.boxMessage("When I'm ready to fight @dre@Tarn@bla@, I have to talk to @dre@Alrena") 
    elif quest_stage == 4:
        player.boxMessage("I should bring the @dre@Dream Potion@bla@ to @dre@Alrena.") 
    elif quest_stage == 5:
        player.boxMessage("I have completed @dre@Lucid Dreams@bla@.")
        
def kill_npc_5421(player):
    quest_stage = player.getQuest(29).getStage()
    if quest_stage == 3:
        player.getQuest(29).setStage(4)
        player.playerChat("I should take that Potion back to Alrena.")

def second_click_item_11014(player):
    player.getTask().teleport(3096, 5525, 0)

def first_click_npc_710(player):
    smithing_level = player.getLevel("smithing")
    runecrafting_level = player.getLevel("runecrafting")
    quest_stage = player.getQuest(29).getStage()
    if quest_stage == 0 and runecrafting_level < 50:
        player.boxMessage("You need a Runecrafting level of 50 or higher to start this quest.")
    elif quest_stage == 0 and smithing_level < 50:
        player.boxMessage("You need a Smithing level of 50 or higher to start this quest.")  
    elif quest_stage == 0:
        player.startChat(45022348)
    elif quest_stage == 1 and player.hasItem(ruby_id, 10) and player.hasItem(iron_bar_id, 20) and player.hasItem(steel_bar_id, 20):
        player.startChat(45022317)
    elif quest_stage == 1:
        player.npcChat("Why are you back already?", "Hurry up and get me the items!")
    elif quest_stage == 2 and player.hasItem(cosmic_id, 500):
        player.startChat(45022351)
    elif quest_stage == 2:
        player.npcChat("I need those cosmic runes, please hurry.")
    elif quest_stage == 3 and player.hasItem(ring_id):
        player.startChat(494912350)
    elif quest_stage == 3:
        player.npcChat("You must bring the ring, to slay Tarn!")
    elif quest_stage == 4 and player.hasItem(dream_id):
        player.startChat(45022358)
    elif quest_stage == 4:
        player.npcChat("If you have killed Tarn, you better bring some proof!")
    else:
        player.sendMessage("She looks half asleep, probably not worth disturbing.")
    
def chat_45022348(player):
    player.npcChat("What on OwnXile are you doing here?")
    player.nextChat(45022349)
    
def chat_45022349(player):
    player.dialogueOption("I'm looking for an adventure.", 45022310, "I don't know, bye.", 45022311)

def chat_45022310(player):
    player.playerChat("I'm looking for an adventure!")
    player.nextChat(45022312)
    
def chat_45022311(player):
    player.playerChat("To be honest I'm not sure, bye!")
    player.endChat()
    
def chat_45022312(player):
    player.npcChat("In that case you have come to the right place.", "But before we begin you have to trust me", "Are you still up for the challenge, adventurer?")
    player.nextChat(45022313)
    
def chat_45022313(player):
    player.dialogueOption("Yes", 45022314, "No", 45022315)
    
def chat_45022314(player):
    player.playerChat("Yes, of course!")
    player.nextChat(40412316)
    
def chat_45022315(player):
    player.playerChat("No thanks, you seem crazy.")
    player.endChat()
    
def chat_40412316(player):
	player.npcChat("An evil being is cursing my dreams this beings name is Tarn", "we must craft the ring of dreams so we may finally rest!")
	player.nextChat(45022316)
	
def chat_45022316(player):
    player.npcChat("Fortunately I can create this ring,", "bring me 10 cut rubys, 20 iron bars and 20 steel bars.")
    player.getQuest(29).setStage(1)
    player.refreshQuestTab()
    player.endChat()
    
def chat_45022317(player):
    player.npcChat("Hand over the items, we don't have much time!")
    player.nextChat(45022318)
    player.deleteItem(ruby_id, 10)
    player.deleteItem(iron_bar_id, 20)
    player.deleteItem(steel_bar_id, 20)
    player.getQuest(29).setStage(2)

def chat_45022318(player):
    player.npcChat("I need some runes to enchant the ring, Please bring me", "500 cosmic runes.")
    player.nextChat(45022319)
    
def chat_45022319(player):
    player.playerChat("500 cosmic runes!?")
    player.nextChat(45022350)
    
def chat_45022350(player):
    player.npcChat("You have no idea how powerful Tarn has", "become, it's the only way")
    player.endChat()
    
def chat_45022351(player):
    player.playerChat("I have the 500 cosmic runes.")
    player.nextChat(45022352)
    
def chat_45022352(player):
    player.npcChat("Good job! Here is the ring.")
    player.deleteItem(cosmic_id, 500)
    player.addItem(ring_id)
    player.getQuest(29).setStage(3)
    player.nextChat(45022353)
    
def chat_45022353(player):
    player.npcChat("Come see me again when you are ready", "to fight the nightmare that is Tarn.")
    player.endChat()
    
def chat_494912350(player):
    player.npcChat("Are you ready to fight Tarn?")
    player.nextChat(45022354)
    
def chat_45022354(player):
    player.dialogueOption("Yes", 45022355, "No", 45022356)

def chat_45022355(player):
    player.playerChat("Yes, take me to Tarn!")
    player.nextChat(45022357)
    
def chat_45022356(player):
    player.playerChat("No, I'm not quite ready yet.")
    player.endChat()
    
def chat_45022357(player):
    player.npcChat("As you wish young adventurer.")
    player.nextChat(58153500)
	
def chat_58153500(player):
    player.getTask().teleport(3103, 5532, 0)
    player.endChat()
    
def chat_45022358(player):
    player.playerChat("Slaying Tarn was a challenge.")
    player.nextChat(45022359)
    
def chat_45022359(player):
    player.npcChat("Wha.. what? I can't believe it!")
    player.nextChat(450223500)
    
def chat_450223500(player):
    player.playerChat("I brought you a potion that may let you rest.")
    player.nextChat(450223501)
    
def chat_450223501(player):
    player.npcChat("Thank you " + str(player.playerName) + ",", "you will never be forgotten!")
    player.nextChat(450223502)
    
def chat_450223502(player):
    player.playerChat("That's it? Don't I get a reward?")
    player.nextChat(450223503)
    
def chat_450223503(player):
    player.npcChat("I'm so tired I almost forgot!")
    player.nextChat(450223504)

def chat_450223504(player):
    player.endChat()
    player.getQuest(29).setStage(5)
    player.refreshQuestTab()
    player.deleteItem(dream_id, 1)
    player.addCash(5000000)
    player.addPoints(250)
    player.getFunction().addSkillXP(200000, 20)
    player.getFunction().addSkillXP(250000, 13)
    reward = QuestReward("5,000,000 coins", "200,000 Runecrafting XP", "250,000 Smithing XP", "250 OXP", "1 Quest Point")
    player.completeQuest("Lucid Dreams", reward, 11014)