def configure_quest_33():
    quest_id = 33
    quest_name = 'Keys to the City'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_33(player):
    quest_stage = player.getQuest(33).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Keys to the City", "You can start this quest by speaking to the @dre@Elven Guard@bla@ outside", "of the @dre@Elven City of Prifddinas@bla@. You must have completed @dre@Roving Elves II@bla@ to start", "this quest.", " ")
    elif quest_stage == 1:
        player.boxMessage("The Elven city guard has asked me to find his keys.")    
    elif quest_stage == 2:
        player.boxMessage("You have completed @dre@Keys to the City@bla@.")
		
def chat_650444442(player):
    player.playerChat("Isn't it lovely now your city is safe again?")
    player.nextChat(650444443)

def chat_650444443(player):
    player.npcChat("Hmmm, yes I suppose you could say that.")
    player.nextChat(650444444)

def chat_650444444(player):
    player.playerChat("You seem uncertain?")
    player.nextChat(650444445)

def chat_650444445(player):
    player.npcChat("No it's just... well... I had a bit of a mishap.")
    player.nextChat(650444446)

def chat_650444446(player):
    player.npcChat("I took a week off work to do some traveling, thought", "I would head up north you see, to visit where I'd been", "while I was a young kid.")
    player.nextChat(650444447)

def chat_650444447(player):
    player.npcChat("Anyway, I ended up coming into contact with the", "notorious Lunar clan. ")
    player.nextChat(650444448)

def chat_650444448(player):
    player.npcChat("Strange bunch... I don't remember what happened really.")
    player.nextChat(650444449)

def chat_650444449(player):
    player.npcChat("All I know is, I lost my keys.")
    player.nextChat(650444450)

def chat_650444450(player):
    player.playerChat("What are the keys for...?")
    player.nextChat(650444451)

def chat_650444451(player):
    player.npcChat("For the city of Prifddinas of course!")
    player.nextChat(650444452)

def chat_650444452(player):
    player.playerChat("Oh damn, that's a big deal.")
    player.nextChat(650444453)

def chat_650444453(player):
    player.npcChat("Could you help me look?")
    player.nextChat(650444454)

def chat_650444454(player):
    player.playerChat("I suppose I could ask around.")
    player.getQuest(33).setStage(1)
    player.refreshQuestTab()
    player.endChat()
	
	
def chat_650444455(player):
    player.npcChat("Do you have my keys yet?")
    player.nextChat(650444456)

def chat_650444456(player):
    player.playerChat("I'm afraid I haven't come across them yet.")
    player.endChat()
	
def chat_650444457(player):
    player.playerChat("Are these your keys?")
    player.nextChat(650444458)

def chat_650444458(player):
    player.npcChat("YES! OH MY GOSH THANK YOU!")
    player.nextChat(650444459)

def chat_650444459(player):
    player.npcChat("Here! Take this Ectophial.")
    player.nextChat(650444460)	

def chat_650444460(player):
    player.deleteItem(11042)
    player.getQuest(33).setStage(2)
    player.endChat()
    player.addItem(4251)
    player.addPoints(50)
    player.addItem(4447)
    reward = QuestReward("Ectophial", "50 OXP", "Antique Lamp", "1 Quest Point")
    player.completeQuest("Keys to the City", reward, 11716)