from com.ownxile.core import World

World.addNonCombatNpc(5200, 3099, 3369, 0, 1)
World.addNonCombatNpc(5198, 3094, 3361, 0, 1)
World.addNonCombatNpc(1701, 3627, 3526, 0, 1)
#World.addNonCombatNpc(5202, 3618, 3529, 0, 1)
#World.addNonCombatNpc(1695, 3462, 3558, 0, 1)

#undead chickens
World.addCombatNpc(1692, 3631, 3530, 0, 1, 5, 2, 5, 5)
World.addCombatNpc(1692, 3628, 3530, 0, 1, 5, 2, 5, 5)
World.addCombatNpc(1692, 3624, 3529, 0, 1, 5, 2, 5, 5)
World.addCombatNpc(1692, 3632, 3525, 0, 1, 5, 2, 5, 5)

def item_10486_on_npc_1692(p):
    p.deleteItem(10486)
    p.addItem(10487)
    p.startAnimation(827)
    p.boxMessage("You put an undead chicken in your sack.")

def configure_quest_17():
    quest_id = 17
    quest_name = "Animal Magnetism"
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)

def quest_button_17(p):
    quest_stage = p.getQuest(17).getStage()
    if quest_stage == 0:
        p.getFunction().startInfo("Animal Magnetism", "I can start this quest by speaking to @dre@Ava@bla@ who", "currently resides in @dre@Draynor Manor@bla@.", "","")
    elif quest_stage == 1 or quest_stage == 2 and not p.hasItem(10487):
        p.boxMessage("I need to bring Ava an undead chicken.")
    elif quest_stage == 2:
        p.boxMessage("I've got the undead chicken, I should bring it to Ava.")
    elif quest_stage == 3:
        p.boxMessage("I have completed @dre@Animal Magnetism@bla@.")

def first_click_npc_1701(p):
    quest_stage = p.getQuest(17).getStage()
    if quest_stage == 1:
        p.startChat(2100024)
    else:
        p.sendMessage("Hajedy looks very busy at the moment.")

def first_click_npc_5198(p):
    quest_stage = p.getQuest(17).getStage()
    if quest_stage == 0:
        p.startChat(2100000)
    elif quest_stage == 1 or quest_stage == 2 and not p.hasItem(10487):
        p.npcChat("Hurry up getting me that undead chicken!")
    elif quest_stage == 2:
        p.startChat(2100030)
    elif quest_stage == 3:
        p.startChat(169100)
        
def second_click_npc_5198(p):
    quest_stage = p.getQuest(17).getStage()
    if quest_stage == 3:
        p.startChat(169110)
    else:
        p.npcChat("I don't have anything to sell you.")

def chat_2100000(p):
    p.npcChat("Hello there and welcome to my humble abode. It's sadly", "rather more humble than I'd like, to be honest, although", "perhaps you can help with that?")
    p.nextChat(2100001)
    
def chat_2100001(p):
    p.dialogueOption("I would be happy to make your home a better place.", 2100015, "I'm not much into interior design to tell the truth.", 2100010, "What's a nice girl like you doing in a place like this?", 2100002)

def chat_2100002(p):
    p.playerChat("What's a nice girl like you doing in a place like this?")
    p.nextChat(2100003)
    
def chat_2100003(p):
    p.npcChat("That's kind of you to say, I used to live in Varrock", "but I sold my house to my sister Gertrude. I've been too", "busy working on a new form of magnetic", "technology for archers to find a new home!")
    p.nextChat(2100004)
    
def chat_2100004(p):
    p.playerChat("Can I live with you? I'm homeless.")
    p.nextChat(2100005)

def chat_2100005(p):
    p.npcChat("Well I suppose there is room in my bed.")
    p.nextChat(2100006)

def chat_2100006(p):
    p.playerChat("On second thoughts, I'll pass.")
    p.nextChat(2100007)

def chat_2100007(p):
    p.npcChat("Awww, we could have had so much fun!")
    p.nextChat(2100008)
    
def chat_2100008(p):
    p.dialogueOption("I would be happy to make your home a better place.", 2100015, "I'm not much into interior design to tell the truth.", 2100010)
    
def chat_2100010(p):
    p.playerChat("I'm not much into interior design to tell the truth.")
    p.nextChat(2100011)

def chat_2100011(p):
    p.npcChat("Then you aren't the kind of person I'm looking for.")
    p.endChat()

def chat_2100015(p):
    p.playerChat("I would be happy to make your home a better place.")
    p.nextChat(2100016)

def chat_2100016(p):
    p.npcChat("Yay, I didn't even have to talk about a reward; you're", "more gullible than most adventurers, that's for sure.")
    p.nextChat(2100017)
    
def chat_2100017(p):
    p.npcChat("Don't worry, though; I just need you to help fix this", "vile old bed for me. Then I'll find suitable reward for", "you.")
    p.nextChat(2100018)

def chat_2100018(p):
    p.playerChat("Great, will I be able to take a nap in it?")
    p.nextChat(2100019)
    
def chat_2100019(p):
    p.npcChat("Don't be silly; everyone knows that true warriors don't", "ever sleep... or perform many other bodily functions, for", "that matter. I'll come up with something, though.")
    p.nextChat(2100020)
    
def chat_2100020(p):
    p.playerChat("I'm not convinced by just a vague something; can you", "be a slight bit more inspiring in your offer?")
    p.nextChat(2100021)
    
def chat_2100021(p):
    p.npcChat("What I need is simple: an undead chicken.", "You should be able to pick some up at the farm", "near Port Phasmatys.")
    p.nextChat(2100022)

def chat_2100022(p):
    p.npcChat("I'll use one for my bed, then see what I can make", "from the other in the way of a reward. I have some", "ideas involving infinite feathers.")
    p.getQuest(17).setStage(1)
    p.refreshQuestTab()
    p.nextChat(2100023)

def chat_2100023(p):
    p.playerChat("Very well then, I'll see what I can do.")
    p.endChat()
    
def chat_2100024(p):
    p.playerChat("I'm here about a quest.")
    p.nextChat(2100025)

def chat_2100025(p):
    p.playerChat("I'm after one of your, er, unhealthier poultry. Could", "you help me?")
    p.nextChat(2100026)
    
def chat_2100026(p):
    p.npcChat("You need those useless, undead chickens? How odd you", "adventurers are.")
    p.nextChat(2100027)

def chat_2100027(p):
    p.npcChat("I suppose I don't mind you taking one of them,", "you'll need one of these though...")
    p.nextChat(2100028)

def chat_2100028(p):
    p.boxMessage("Hajedy gives you an empty sack.")
    p.addItem(10486)
    p.getQuest(17).setStage(2)
    p.refreshQuestTab()
    p.nextChat(2100029)
        
def chat_2100029(p):
    p.playerChat("Thanks for being so helpful.")
    p.endChat()
    
def chat_2100030(p):
    p.npcChat("Have you got me that undead chicken then?")
    p.nextChat(2100031)

def chat_2100031(p):
    p.playerChat("I sure have, it wasn't much of a challenge.")
    p.nextChat(2100032)
    
def chat_2100032(p):
    p.npcChat("Oh, so you want me to issue a trickier challenge?")
    p.nextChat(2100033)
    
def chat_2100033(p):
    p.playerChat("Ah... erm, no. On second thoughts I'll", "take my reward now thank you.")
    p.nextChat(2100034)
    
def chat_2100034(p):
    p.npcChat("That's what I thought.")
    p.nextChat(2100035)

def chat_2100035(p):
    p.getQuest(17).setStage(3)
    p.refreshQuestTab()
    p.deleteItem(10487)
    p.addItem(10499)
    p.addItem(995, 2500000)
    p.getFunction().addSkillXP(100000, 4)
    reward = QuestReward("1 Quest Point", "Ava's device", "100,000 Ranging experience", "2,500,000 coins")
    p.completeQuest("Animal Magnetism", reward, 10499)