def configure_quest_27():
    quest_id = 27
    quest_name = 'Leaders no Longer'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_27(player):
    quest_stage = player.getQuest(27).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Leaders no Longer", "Speak to the @dre@Combat Instructor@bla@ in the training cave to", "start this quest. You must have completed @dre@Huntsman at Heart"," and have a minimum combat level of 50.", " ")
    elif quest_stage == 1:
        player.boxMessage("I must defeat @dre@Melzar@bla@ and @dre@Salarin@bla@.", "The instructor suggested I visit the @dre@Tradesman@bla@ in @dre@Edgeville", "to obtain better equipment.")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Leaders no Longer@bla@.")
        
def chat_1294369618(player):
    player.npcChat("I'm afraid you will need a combat level", "of at least 50 for this next task.")
    player.nextChat(1294369619)

def chat_1294369619(player):
    player.playerChat("That's horsesh*t.")
    player.nextChat(1294369620)

def chat_1294369620(player):
    player.npcChat("Quit complaining and get training.")
    player.endChat()

def chat_1294369621(player):
    player.npcChat("It would appear you are ready.")
    player.nextChat(1294369622)

def chat_1294369622(player):
    player.npcChat("Two evil wizards have been cursing this", "wretched dungeon for years. @dre@Melvar the Mad@bla@ the leader of", "the dark wizards and his accomplice @dre@Salarin", "@dre@the Twisted.")
    player.nextChat(1294369623)

def chat_1294369623(player):
    player.playerChat("And I suppose you want me to assasinate them?")
    player.nextChat(1294369624)

def chat_1294369624(player):
    player.npcChat("Yes that would be nice.")
    player.nextChat(1294369625)

def chat_1294369625(player):
    player.playerChat("I suppose more killing can't hurt...")
    player.getQuest(27).setStage(1)
    player.refreshQuestTab()
    player.nextChat(1294369626)

def chat_1294369626(player):
    player.playerChat("Do you have any tips for killing the wizards?")
    player.nextChat(1294369627)

def chat_1294369627(player):
    player.npcChat("Well your equipment is pretty basic, perhaps you could", "purchase some better weapons and armour.")
    player.nextChat(1294369628)

def chat_1294369628(player):
    player.npcChat("The town crier can teleport you to the main", "city of Edgeville and back here. There's a guy", "called the @dre@Tradesman@bla@ who sells vast amounts of equipment.")
    player.nextChat(1294369629)

def chat_1294369629(player):
    player.playerChat("Thanks buddy, I'll give it a shot.")
    player.nextChat(1294369631)

def chat_1294369630(player):
    player.npcChat("Good luck " + str(player.playerName) + "!")
    player.endChat()

def chat_1294369631(player):
    player.npcChat("One more thing, I'll need proof you've killed them", "so bring me something of they may posses.")
    player.nextChat(1294369630)

def chat_1294369633(player):
    player.npcChat("Very good, you've advanced into a fine warrior", "since I met you. Now hand over that evidence.")
    player.nextChat(1294369634)

def chat_1294369634(player):
    player.boxMessage("You give the instructor the dirty robes.")
    player.nextChat(1294369635)

def chat_1294369635(player):
    player.npcChat("I'm afraid there is little more for me to teach you.")
    player.nextChat(1294369636)

def chat_1294369636(player):
    player.npcChat("If you wish to advance further, recommend heading", "over to Taverly dungeon. The captain and his guards", "always need some extra hands on board.")
    player.nextChat(1294369637)

def chat_1294369637(player):
    player.playerChat("I'll bear that in mind.")
    if player.getQuest(27).getStage() == 1:
        player.nextChat(1294369638)
    else:
        player.endChat()

def chat_1294369638(player):
    player.npcChat("Have fun out there then " + str(player.playerName) + "!")
    player.nextChat(1294369639)
    
def chat_1294369639(player):#complete quest
    player.getQuest(27).setStage(2)
    player.addPoints(50)
    player.deleteItem(1033, 1)
    player.deleteItem(1035, 1)
    player.deleteItem(546, 1)
    player.deleteItem(548, 1)
    player.addItem(995, 1000000)
    player.addItem(10586, 2)
    reward = QuestReward( "1,000,000 coins and 50 ox points,", "two combat experience lamps", "and 1 quest point.", "")
    player.completeQuest("Leaders no Longer", reward, 1035)

