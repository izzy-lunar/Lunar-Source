easter_bunny = 1835
rabbit_spawn = World.addNonCombatNpc(easter_bunny, 2467, 5327, 0, 1)
World.addCombatNpc(1192, 2455, 5345, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5345, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2461, 5345, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2463, 5345, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2465, 5345, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2465, 5342, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2463, 5340, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2460, 5337, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5334, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5331, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5329, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5326, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5324, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5321, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2458, 5318, 0, 1, 5, 1, 50,2)
World.addCombatNpc(1192, 2455, 5318, 0, 1, 5, 1, 50,2)

def configure_quest_34():
    quest_id = 34
    quest_name = 'Easter Hunting'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
	
#down a rabbit hole
def first_click_object_23117(player):
    if player.getQuest(34).getStage() == 0:
        player.lastClickedNpcId = 1835
        player.startChat(1737055736)
        player.turnPlayerTo(rabbit_spawn.getX(), rabbit_spawn.getY())
        rabbit_spawn.turnNpc(player.getX(), player.getY())
    else:
        player.getFunction().movePlayerCutscene(2480, 5332, 0)
        
def quest_button_34(player):
    quest_stage = player.getQuest(34).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Easter Hunting", "I can start this quest by speaking to the @dre@Easter bunny@bla@ who", "is east of Edgeville bank.", "", "This quest can only be completed during Easter.")
    elif quest_stage == 1:
        player.boxMessage("I must take 100 pieces of chocolate to the Easter bunny.")

    elif quest_stage == 2:
        player.boxMessage("You have completed @dre@Easter Egg Hunt@bla@.")

def first_click_npc_1835(player):
    quest_stage = player.getQuest(34).getStage()
    if quest_stage == 0:
        player.startChat(1737055736)
    elif quest_stage == 1 and not player.hasItem(11025, 100):
        player.startChat(1737055746)
    elif quest_stage == 1:
        player.startChat(460248856)
    elif quest_stage == 2:
        player.startChat(460248863)

def chat_1737055736(player):
    player.npcChat("Hey there " + str(player.playerName) + "!")
    player.nextChat(1737055737)

def chat_1737055737(player):
    player.playerChat("What's going on?")
    player.nextChat(1737055738)

def chat_1737055738(player):
    player.npcChat("I'm just visiting here for easter, unfortunately I seem to", "have misplaced some of my eggs.")
    player.nextChat(1737055739)

def chat_1737055739(player):
    player.dialogueOption("Perhaps I could help?", 1737055740, "What a stupid bunny you are!", 1737055750)
    player.nextChat(1737055740)

def chat_1737055740(player):
    player.playerChat("I could help you I suppose.")
    player.nextChat(1737055741)

def chat_1737055741(player):
    player.npcChat("That would be nice, I need you to collect", "some special pieces of chocolate.")
    player.nextChat(1737055742)

def chat_1737055742(player):
    player.npcChat("The kebbits down that hole should", "give you some.")
    player.nextChat(1737055743)

def chat_1737055743(player):
    player.npcChat("They might be a little bit umm...")
    player.nextChat(1737055744)

def chat_1737055744(player):
    player.npcChat("...resistant, however that shouldn't be a problem", "for a brave warrior like you!")
    player.nextChat(1737055745)
    player.getQuest(34).setStage(1)
    player.refreshQuestTab()

def chat_1737055745(player):
    player.playerChat("You're so charming! I wish you were around more often.")
    player.endChat()

def chat_1737055746(player):
    player.npcChat("Have you got the pieces of chocolate?")
    player.nextChat(1737055747)

def chat_1737055747(player):
    player.playerChat("Not yet I'm still working on it.")
    player.endChat()
	
def chat_1737055750(player):
    player.playerChat("Stupid bunny I'm too busy for you.")
    player.nextChat(1737055751)

def chat_1737055751(player):
    player.npcChat("You don't look busy to me!")
    player.nextChat(1737055752)

def chat_1737055752(player):
    player.playerChat("Mind your business you big eared freak.")
    player.endChat()
	
def chat_460248856(player):
    player.playerChat("I've got those chocolates you wanted...")
    player.nextChat(460248857)

def chat_460248857(player):
    player.npcChat("Ah perfect, I shall put these to good use!")
    player.nextChat(460248858)

def chat_460248858(player):
    player.playerChat("Any chance of a reward?")
    player.nextChat(460248859)

def chat_460248859(player):
    player.npcChat("I'm not made of money!")
    player.nextChat(460248860)

def chat_460248860(player):
    player.npcChat("I do have some magic rings though!")
    player.nextChat(460248861)

def chat_460248861(player):
    player.npcChat("Thanks for helping out.")
    player.nextChat(460248862)

def chat_460248862(player):
    player.deleteItem(11025, 100)
    player.getQuest(34).setStage(2)
    player.endChat()
    player.addItem(7927)
    player.addPoints(50)
    reward = QuestReward("50 OXP", "Easter Ring", " ")
    player.completeQuest("Bunny Bashing", reward, 7927)

def chat_460248863(player):
    player.playerChat("Are you STILL here?")
    player.nextChat(460248864)

def chat_460248864(player):
    player.playerChat("It's no longer easter you know!")
    player.nextChat(460248865)

def chat_460248865(player):
    player.npcChat("Mind your own business kid.")
    player.nextChat(460248866)

def chat_460248866(player):
    player.npcChat("I'll slap you down.")
    player.endChat()