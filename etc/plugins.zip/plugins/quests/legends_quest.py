                                                                #Author: Aram
#Quest Created: 9/29/14
#Quest Length: Short
#Quest Requirements: Animal Magnetism (17), Dragon Slayer (2), Horror from the Deep (20), Lost City (14), Saving Souls (6)

#NPCs
legend_guard = 398
azzaranda = 1971
black_demon = 83##idk
sir_gawain = 250

#Items
golden_key = 2944
logs = 1514

def configure_quest_23():
    quest_id = 23
    quest_name = 'Legends Quest'
    quest_stages = 7
    World.addNonCombatNpc(398, 2727, 3349, 0, 0)
    World.addNonCombatNpc(1971, 3085, 9932, 0, 1)
    World.addQuest(quest_id, quest_name, quest_stages)


def first_click_object_2392(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        handle_guild_door(player)
    else:
        player.boxMessage("You need to be have completed Legends quest to enter this guild.")

def first_click_object_2391(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        handle_guild_door(player)
    else:
        player.sendMessage("You need to be have completed Legends quest to enter this guild.")

def first_click_object_2971(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        handle_dungeon_door(player)
    else:
        player.boxMessage("Only members of the legends guild may pass through here.")

def handle_guild_door(player):
    if player.getAbsY() > 3349:
        player.getFunction().movePlayer(player.getAbsX(), 3349, 0)
    else:
        player.getFunction().movePlayer(player.getAbsX(), 3350, 0)
        
def handle_dungeon_door(player):
    if player.getAbsY() > 4690:
        player.getFunction().movePlayer(player.getAbsX(), 4690, 0)
    else:
        player.getFunction().movePlayer(player.getAbsX(), 4691, 0)

        
#Quest button
def quest_button_23(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Legend's Quest", "I can start this quest by talking to the @dre@Legend's Guard@bla@ at the", "Legend's guild.", "I must have completed the following quests: @dre@Animal Magnetism@bla@,", " @dre@Dragon Slayer@bla@, @dre@Horror from the Deep@bla@, @dre@Lost City@bla@, and @dre@Saving souls@bla@.")
    elif quest_stage == 1:
        player.boxMessage("I should speak to the @dre@Sir Gawain@bla@ in Camelot.", "Maybe he can help me find the key.")
    elif quest_stage == 2:
        player.boxMessage("I know the key is somewhere in the Edgeville Dungeon.", "I must speak to Azzanadra.")
    elif quest_stage == 3:
        player.boxMessage("I must defeat the Black Demon.")
    elif quest_stage == 4:
        player.boxMessage("I must go back to the Legends Guard and return this key to him.")
    elif quest_stage == 5:
        player.boxMessage("I must go bring back 100 noted magic logs to the Guard.")
    elif quest_stage == 6:
        player.boxMessage("Speak to the Guard to complete this quest.")
    elif quest_stage == 7:
        player.boxMessage("I have completed the @dre@Legends' Quest@bla@.")
                       
#Black Demon Kill
def kill_npc_84(player):
    if player.hasAttribute("bdemon_kills"):
        handle_bdemon_kills(player)
    else:
        player.addAttribute("bdemon_kills", 1)
        
def handle_bdemon_kills(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 3 and player.getAttribute("bdemon_kills") < 5:
        player.addAttribute("bdemon_kills", 0)
        player.sendMessage("You have received a golden key.")
        player.addItem(golden_key)
        player.getQuest(23).setStage(4)
    else:
        player.addAttribute("bdemon_kills", player.getAttribute("bdemon_kills") + 1)

#Legends Guard
def first_click_npc_398(player):
    total_level = player.getTotalLevel()
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 0 and total_level < 1000 and player.getQuest(17).getStage() == 3 and player.getQuest(2).getStage() == 23 and player.getQuest(20).getStage() == 2 and player.getQuest(14).getStage() == 4 and player.getQuest(6).getStage() == 10:
        player.boxMessage("You need to have a total level of 1000 or higher", "and 5 quest requirements to start", "the @dre@Legend's Quest@bla@.", "You must also be able to chop down magic trees.")
    elif quest_stage == 0:
        player.startChat(650000000)
    elif quest_stage == 4 and player.hasItem(golden_key, 1):
        player.startChat(650000020)
    elif quest_stage == 5:
        player.startChat(650000023)
    elif quest_stage == 6:
        player.startChat(650000025)
    else:
        player.npcChat("Welcome to the Legend's Guild!")
        player.endChat()
        
#Sir Gawain
def first_click_npc_240(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 1:
        player.startChat(650000010)
    else:
        player.npcChat("I heard there was a rumour in town that", "a new city and elf series quests are coming soon.")
        player.endChat()
        
#Azzaranda
def first_click_npc_1971(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 2:
        player.startChat(650000014)
    else:
        player.npcChat("Fear me!")
        player.endChat()
        
#Chat dialogues    
def chat_650000000(player):
    player.npcChat("Yes Sir, how can I help you?")
    player.nextChat(650000001)

def chat_650000001(player):
    player.playerChat("What is this place?")
    player.nextChat(650000002)

def chat_650000002(player):
    player.npcChat("This is the Legends Guild sir!")
    player.nextChat(650000003)

def chat_650000003(player):
    player.npcChat("Legendary OwnXile citizens are invited to complete a quest in", "order to become members of the guild.")
    player.nextChat(650000004)

def chat_650000004(player):
    player.playerChat("Am I eligible for this quest?")
    player.nextChat(650000005)

def chat_650000005(player):
    player.boxMessage("The guard gets out a scroll of paper and starts looking through it.")
    player.nextChat(650000006)
    
def chat_650000006(player):
    player.getQuest(23).setStage(1)
    player.refreshQuestTab()
    player.boxMessage("You suddenly feel as if your mind is being read.")
    player.nextChat(650000007)
    
def chat_650000007(player):
    player.npcChat("You are required to collect a certain item for us")
    player.nextChat(650000008)
    
def chat_650000008(player):
    player.boxMessage("The guard shows you a picture of a Golden Key.", "Collect this key and bring it back to the Guard.")
    player.nextChat(650000009)
    
def chat_650000009(player):
    player.npcChat("Begin by speaking to Sir Gawain in Seers Village.")
    player.endChat()
    
def chat_650000010(player):
    player.npcChat("Hello!")
    player.nextChat(650000011)
    
def chat_650000011(player):
    player.playerChat("Hello, do you know of a Golden Key?")
    player.nextChat(650000012)
    
def chat_650000012(player):
    player.getQuest(23).setStage(2)
    player.refreshQuestTab()
    player.npcChat("Yes, last time I heard one of my past adventurers", "died with it in the Edgeville Dungeon.")
    player.nextChat(650000013)
    
def chat_650000013(player):
    player.npcChat("I'll have to check it out, thanks!")
    player.endChat()
    
def chat_650000014(player):
    player.npcChat("What do you want.")
    player.nextChat(650000015)
    
def chat_650000015(player):
    player.playerChat("I need to know where to find the Golden Key.")
    player.nextChat(650000016)
    
def chat_650000016(player):
    player.npcChat("If you wish to find the Golden Key you must", "be willing to be fearless.")
    player.nextChat(650000017)
    
def chat_650000017(player):
    player.playerChat("What do I have to do?")
    player.nextChat(650000018)
    
def chat_650000018(player):
    player.getQuest(23).setStage(3)
    player.refreshQuestTab()
    player.playerChat("The first test is to defeat that Black Demon over there.")
    player.nextChat(650000019)
    
def chat_650000019(player):
    player.playerChat("Piece of cake!")
    player.endChat()
    
def chat_650000020(player):
    if player.hasItem(golden_key):
        player.deleteItem(golden_key, 1)
        player.getQuest(23).setStage(5)
        player.refreshQuestTab()
        player.npcChat("I see you have gotten the Golden Key.")
        player.nextChat(650000021)

def chat_650000021(player):
    player.npcChat("One last thing, the guild is short on magic logs.", "Please bring us 100 noted logs.")
    player.nextChat(650000022)
    
def chat_650000022(player):
    player.playerChat("Now I feel as if I'm running errands...")
    player.endChat() 
  
def chat_650000023(player):
    player.npcChat("Do you have the logs?")
    player.nextChat(650000025) 
    
def chat_650000025(player):
    if player.hasItem(logs, 100):
        player.deleteItem(logs, 100)
        player.boxMessage("You hand over the noted logs.")
        player.getQuest(23).setStage(6)
        player.refreshQuestTab()
        player.nextChat(650000025)
    else:
        player.playerChat("I think I know what you want. I'll be back.")
        player.endChat()
        
def chat_650000025(player):
    player.npcChat("Thank you and welcome to the guild.")
    player.nextChat(650000026) 
    
def chat_650000026(player):
    player.endChat()
    player.getQuest(23).setStage(7)
    player.refreshQuestTab()
    player.addCash(2000000)
    player.addPoints(100)
    player.addItem(1052)
    player.qp += 2
    reward = QuestReward("20,000,000 coins", "200 OXP", "3 Quest Points")
    player.completeQuest("Legends' Quest", reward, 1052)
                            
def command_legcheat(p):
    p.getQuest(23).setStage(1)                            
                            
                            