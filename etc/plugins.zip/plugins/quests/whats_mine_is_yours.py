#Author Hawk
#Quest Length = Short

#NPCs
doric_id = 284
thurgo_id = 604

#Items
golden_hammer = 2949

#Quest configuration
def configure_quest_8():
    quest_id = 8
    quest_name = "What's Mine is Yours"
    quest_stages = 3
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(doric_id, 2952, 3451, 0, 1)
    World.addNonCombatNpc(thurgo_id, 3000, 3144, 0, 1)

#Quest button
def quest_button_8(player):
    quest_stage = player.getQuest(8).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("What's Mine is Yours", "I can start this quest by talking to", "@dre@Doric@bla@ at the Goblin village.", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should find Doric's grandfather, Thurgo.")
    elif quest_stage == 2:
        player.boxMessage("I should tell Doric that Thurgo has the hammer.")
    elif quest_stage == 3:
        player.boxMessage("I have completed @dre@What's Mine is Yours@bla@.")
        
#Pie book
def click_item_7162(player):
    player.playerChat("I'm not even sure why I'm reading this, I hate pie.")
    player.endChat()
    
#Doric
def first_click_npc_284(player):
    quest_stage = player.getQuest(8).getStage()
    if quest_stage == 0:
        player.startChat(92151240)
    elif quest_stage == 1:
        player.startChat(92051240)
    elif quest_stage == 2:
        player.startChat(92351240)
    elif quest_stage == 3:
        player.startChat(92451240)
    else:
        player.playerChat("I better not disturb the Dwarf")
        player.endChat()
#Thurgo
def first_click_npc_604(player):
    quest_stage = player.getQuest(8).getStage()
    if quest_stage == 0:
        player.playerChat("He looks defenceless")
        player.endChat()
    elif quest_stage == 1:
        player.startChat(92201240)
    elif quest_stage == 2:
        player.startChat(92401240)
    elif quest_stage == 3:
        player.startChat(92401240)
    else:
        player.playerChat("I better not disturb the Goblin")
        player.endChat()
        
#Stage 0
def chat_92151240(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(92151241)

def chat_92151241(player):
    player.npcChat("Hello there! what can I help you with?")
    player.nextChat(92151242)

def chat_92151242(player):
    player.dialogueOption("Nothing much.", 92151243, "I'm looking for quests!", 92151244)
    
def chat_92151243(player):
    player.playerChat("Nothing much.")
    player.endChat()

def chat_92151244(player):
    player.playerChat("I'm looking for quests!")
    player.nextChat(92151245)

def chat_92151245(player):
    player.npcChat("A quest you say? I may have a job for you")
    player.nextChat(92151246)

def chat_92151246(player):
    player.playerChat("What would you like me to do?")
    player.nextChat(92151247)

def chat_92151247(player):
    player.npcChat("I have a special Hammer for my Grandfather.", "It will help him with his 'project'...!")
    player.nextChat(92151248)

def chat_92151248(player):
    player.playerChat("So you want me to give them to him??", "Why can't you do it?")
    player.nextChat(92151249)

def chat_92151249(player):
    player.npcChat("If you could! I'm making a new shield for a customer")
    player.nextChat(92161240)

def chat_92161240(player):
    player.playerChat("Ah well, where does he live?")
    player.nextChat(92161241)

def chat_92161241(player):
    player.npcChat("He lives just south west of Port Sarim")
    player.nextChat(92161242)

def chat_92161242(player):
    player.dialogueOption("Fine, I'll deliver the hammer.", 92161243, "Sorry, that's too far for me.", 92161244)

def chat_92161243(player):
    player.playerChat("Fine, I'll deliver the hammer.")
    player.nextChat(92161247)

def chat_92161244(player):
    player.playerChat("Sorry, that's too far for me.")
    player.nextChat(92161245)

def chat_92161245(player):
    player.boxMessage("Doric lets out a sigh.")
    player.nextChat(92161246)

def chat_92161246(player):
    player.npcChat("Don't worry about it.")
    player.endChat()

def chat_92161247(player):
    player.npcChat("Thank you so much, you won't regret this!")
    player.nextChat(92161248)

def chat_92161248(player):
    player.playerChat("Okay, I'll try and find him!")
    player.nextChat(92161249)

def chat_92161249(player):
    if player.hasInventorySpace(1):
        player.addItem(golden_hammer)
        player.getQuest(8).setStage(1)
        player.refreshQuestTab()
        player.npcChat("Wait, you forgot the Hammer!")
        player.nextChat(92171240)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for the armour.")

def chat_92171240(player):
    player.playerChat("Phew, that was close.")
    player.endChat()
    
#Stage 1 (General)
def chat_92051240(player):
    player.npcChat("Have you delivered the hammer yet?")
    player.nextChat(92051241)

def chat_92051241(player):
    player.playerChat("Not yet!")
    player.endChat()

#Stage 2
def chat_92201240(player):
    player.playerChat("Are you Thurgo?")
    player.nextChat(92201241)

def chat_92201241(player):
    player.npcChat("What do you want?")
    player.nextChat(92201242)

def chat_92201242(player):
    player.playerChat("I have a present from your Grandson for you.")
    player.nextChat(92201243)

def chat_92201243(player):
    player.npcChat("What present?!")
    player.nextChat(92201244)

def chat_92201244(player):
    player.boxMessage("His old face gleams with joy.")
    player.nextChat(92201245)

def chat_92201245(player):
    player.playerChat("A golden hammer for you, he said you needed","it for a 'project'")
    player.nextChat(92201246)

def chat_92201246(player):
    player.npcChat("Ah yes, thank you I'm sure you won't regret this...")
    player.nextChat(92201247)

def chat_92201247(player):
    if player.hasItem(golden_hammer):
        player.deleteItem(golden_hammer)
        player.getQuest(8).setStage(2)
        player.refreshQuestTab()
        player.playerChat("Here you go then.")
        player.nextChat(92201248)
    else:
        player.playerChat("Whoops, I forgot to bring it. I'll be back soon.")
        player.endChat()

def chat_92201248(player):
    player.boxMessage("He definitely looks happier, Doric will be pleased.")
    player.endChat()

#Stage 3
def chat_92351240(player):
    player.npcChat("Have you given him the hammer yet?")
    player.nextChat(92351241)

def chat_92351241(player):
    player.playerChat("Yes! He said to thank you.")
    player.nextChat(92351242)

def chat_92351242(player):
    player.npcChat("Thank you, here, take this as thank you","It's an old dwarf artefact","Take care of it!")
    player.nextChat(92351243)

def chat_92351243(player):
    player.endChat()
    player.getQuest(8).setStage(3)
    player.refreshQuestTab()
    player.addCash(1500000)
    player.addPoints(20)
    player.addItem(4567, 1)
    reward = QuestReward("1500,000 coins", "20 OXP", "1 Quest Point", "A Golden Helmet")
    player.completeQuest("What's Mine is Yours", reward, 4567)

def chat_92451240(player):
    player.npcChat("Thank you for you help!")
    player.nextChat(92451241)

def chat_92451241(player):
    player.playerChat("No problem, you're welcome.")
    player.endChat()

def chat_92401240(player):
    player.npcChat("Thank you for the help!")
    player.endChat()