
def configure_quest_0():
    quest_id = 0
    quest_name = 'Barbaric Troubles'
    quest_stages = 2
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_0(player):
    quest_stage = player.getQuest(0).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Barbaric Troubles", "Speak to the @dre@Combat Instructor@bla@ in the @dre@Training@bla@ dungeon", "to start this quest."," ", " ")
    elif quest_stage == 1:
        player.boxMessage("I must slay @dre@5 Barbarians@bla@ and collect the coconuts.")
    elif quest_stage == 2:
        player.boxMessage("I have completed @dre@Barbaric Troubles@bla@.")
