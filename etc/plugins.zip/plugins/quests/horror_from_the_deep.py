# Quest Name: Horror from the Deep
# Quest Authors: Rob, Aram, Cam.
# Date Created: 15/4/2014
# Quest Length: Short
# Quest Difficulty: Hard

from com.ownxile.core import World
def configure_quest_20():
    quest_id = 20
    quest_name = "Horror from the Deep"
    quest_stages = 2
    World.addNonCombatNpc(1336, 2506, 3634, 0, 1)
    World.addNonCombatNpc(1335, 2519, 10009, 0, 0)
    World.addNonCombatNpc(1334, 2510, 3642, 1, 1)
    World.addQuest(quest_id, quest_name, quest_stages)
 
def command_resethorror(player):
    player.getQuest(20).setStage(0)

def quest_button_20(player):
    quest_stage = player.getQuest(20).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("Horror from the Deep", "I can start this quest by speaking to @dre@Larrissa@bla@ who", "is located outside the lighthouse west of Relleka.", " ", " ")
    elif quest_stage == 1:
        player.boxMessage("Larissa has asked me to find her boyfriend Jossik.")
    elif quest_stage == 2:
        player.boxMessage("I have completed the @dre@Horror from the Deep@bla@ quest.")


def first_click_object_4577(player):
    quest_stage = player.getQuest(20).getStage()
    if quest_stage == 0:
	    player.sendMessage("The door is locked.")
    else:
	    enter_lighthouse(player)

def enter_lighthouse(player):
    if player.getY() > 3635:
        player.getTask().movePlayer(2509, 3635, 0)
    else:
        player.getTask().movePlayer(2509, 3636, 0)
        
def first_click_object_4615(player):
    if player.getX() > 2597:
        player.getTask().movePlayer(2596, 3608, 0)
    else:
        player.getTask().movePlayer(2598, 3608, 0)
        
def first_click_object_4616(player):
    if player.getX() > 2597:
        player.getTask().movePlayer(2596, 3608, 0)
    else:
        player.getTask().movePlayer(2598, 3608, 0)

def first_click_object_4383(player):
    Ladder.climb(player, 2519, 9995, 1)
    
def first_click_object_4412(player):
    Ladder.climb(player, 2510, 3644, 0)
    
def first_click_object_4485(player):
    if player.getQuest(20).getStage() == 2:
        Ladder.climb(player, 2515, 4632, 0)
    else:
        Ladder.climb(player, 2515, 10008, 0)

def first_click_object_4413(player):
    Ladder.climb(player, 2515, 10005, 1)
        
def first_click_object_4544(player):
    player.getTask().showInterface(10116)
    
def first_click_object_4543(player):
    player.getTask().showInterface(10116)

def first_click_object_4546(player):
    if player.getY() > 10002:
        player.getTask().movePlayer(2513, 10002, 1)
    else:
        player.getTask().movePlayer(2513, 10003, 1)

def first_click_object_4545(player):
    if player.getY() > 10002:
        player.getTask().movePlayer(2516, 10002, 1)
    else:
        player.getTask().movePlayer(2516, 10003, 1)

def first_click_npc_1336(player):
    quest_stage = player.getQuest(20).getStage()
    if quest_stage == 0: 
        player.startChat(1161508324)
    elif quest_stage == 2:
        player.startChat(1248009291)
    else:
        player.sendMessage("Doesn't look like Larrissa wants to chat.")

def first_click_npc_1335(player):
    quest_stage = player.getQuest(20).getStage()
    if quest_stage == 1: 
        player.startChat(572582264)
    
def chat_1161508324(player):
    player.playerChat("Hello there.")
    player.nextChat(1161508325)

def chat_1161508325(player):
    player.npcChat("Oh, thank Armadyl!! I am in such a worry...")
    player.nextChat(1161508326)

def chat_1161508326(player):
    player.playerChat("How can I help?")
    player.nextChat(1161508327)

def chat_1161508327(player):
    player.npcChat("Oh... it is terrible... horrible... My boyfriend lives here", "in this lighthouse, but I haven't seen him the last few", "days! I think something terrible has happened!")
    player.nextChat(1161508328)

def chat_1161508328(player):
    player.npcChat("Look, you can see for yourself that the light has gone", "out and the front door is locked up tight! He would", "NEVER do that!")
    player.nextChat(1161508329)

def chat_1161508329(player):
    player.npcChat("With the light off this coastline is terribly dangerous to", "ships! And to lock the front door so that nobody can", "turn the light back on?")
    player.nextChat(1161508330)

def chat_1161508330(player):
    player.playerChat("Maybe he went on holiday or something? Must be", "pretty boring living in a lighthouse.")
    player.nextChat(1161508331)

def chat_1161508331(player):
    player.npcChat("That is terribly irresponsible! He is far too thoughtful", "for that! He would never leave it unattended! He would", "also never leave without telling me!")
    player.nextChat(1161508332)

def chat_1161508332(player):
    player.npcChat("Please, I know something terrible has happened to him...", "I can sense it! Please... please help me adventurer!")
    player.nextChat(1161508333)

def chat_1161508333(player):
    player.playerChat("But how can I help?")
    player.nextChat(1161508334)

def chat_1161508334(player):
    player.npcChat("Well, we have to do something to get the lighthouse", "working again, I will be eternally grateful!")
    player.nextChat(1161508337)

def chat_1161508337(player):
    player.playerChat("Okay, I'll help.")
    player.nextChat(1161508338)

def chat_1161508338(player):
    player.npcChat("OH THANK YOU SO MUCH! I know my darling", "would never have left with the lighthouse lights off and ", "without even telling me where he's gone!")
    player.nextChat(1161508339)

def chat_1161508339(player):
    player.playerChat("I'll see what I can do.")
    player.nextChat(1161508340)

def chat_1161508340(player):
    player.npcChat("Thank you so much!")
    player.getQuest(20).setStage(1)
    player.refreshQuestTab()
    player.endChat()
    
def chat_610812046(player):
    player.npcChat("Have you found my husband?")
    player.nextChat(610812047)

def chat_610812047(player):
    player.playerChat("No not yet, I'll keep looking.")
    player.nextChat(610812048)

def chat_610812048(player):
    player.playerChat("I found him under the lighthouse, he had been injured", "by some dagannoths but I managed to fight them", "off. He's safely upstairs now.")
    player.nextChat(610812049)

def chat_610812049(player):
    player.npcChat("My dear Jossik! I am so happy, thank", "you ever so much.")
    player.nextChat(610812050)

def chat_610812050(player):
    player.playerChat("No problem.")
    player.getQuest(20).setStage(1)
    player.refreshQuestTab()
    player.endChat()
    
def chat_572582264(player):
    player.npcChat("*cough*", "Please... please help me...", "I think my leg is broken and those creatures will be",  "back any minute now!")
    player.nextChat(572582265)

def chat_572582265(player):
    player.playerChat("I guess you're Jossik then...", "What creatures are you talking about?")
    player.nextChat(572582266)

def chat_572582266(player):
    player.npcChat("I... I do not know.", "I have never seen their like before!")
    player.nextChat(572582267)

def chat_572582267(player):
    player.npcChat("I was searching for information about my uncle Silas,", "who vanished mysteriously from this lighthouse many", "months ago. I found the secret of that strange wall, and", "discovered that I could use it as a door, but when I")
    player.nextChat(572582268)

def chat_572582268(player):
    player.npcChat("came down here I was attacked by...")
    player.nextChat(572582269)

def chat_572582269(player):
    player.npcChat("Well, I do not know what they are, but they are very", "strong! They hurt me badly enough to trap me here,", "and I have been fearing for my life ever since!")
    player.nextChat(572582270)

def chat_572582270(player):
    player.playerChat("Don't worry, I'm here now.", "Larrissa was worried about you and asked for help.")
    player.nextChat(572582271)

def chat_572582271(player):
    player.playerChat("I'll go back upstairs and let her know that I've found", "you and that you're still alive, and then we can work", "out some way of getting you out of here, okay?")
    player.nextChat(572582272)

def chat_572582272(player):
    player.npcChat("NO! No, you can't leave me now!", "Look! They're coming again! Do something!")
    World.getNpcHandler().spawnNpc(player, 1351, 2511, 10020, player.absZ, 0, 120, 20, 150, 150, True, True)
    player.endChat()
    
def chat_1248009291(player):
    player.npcChat("Thank you so much for saving Jossik!")
    player.nextChat(1248009292)

def chat_1248009292(player):
    player.playerChat("Oh, it was nothing.")
    player.nextChat(1248009293)

def chat_1248009293(player):
    player.npcChat("If you're looking for some kind of reward", "Jossik has some cheap books for sale.")
    player.nextChat(1248009294)

def chat_1248009294(player):
    player.playerChat("Books? Err yeah great. Thanks.")
    player.endChat()

def kill_npc_1356(player):
    player.getQuest(20).setStage(2)
    player.getTask().movePlayer(2516, 9997, 1)
    reward = QuestReward("3 Quest Points", "112,342 XP in each of", "Ranged, Magic & Strength")
    player.getTask().addSkillXP(112342, player.getLevelId("strength"))
    player.getTask().addSkillXP(112342, player.getLevelId("ranged"))
    player.getTask().addSkillXP(112342, player.getLevelId("magic"))
    player.qp += 2 # an extra 2 quest points plus the 1 default
    player.completeQuest("Horror from the Deep", reward, 3849)