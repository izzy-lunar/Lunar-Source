
def configure_quest_14():
    quest_id = 14
    quest_name = "Lost City"
    quest_stages = 4
    World.addNonCombatNpc(649, 3150, 3207, 0, 1) #archer
    World.addNonCombatNpc(650, 3149, 3206, 0, 1) #warrior
    World.addNonCombatNpc(651, 3153, 3205, 0, 1) #monk
    World.addNonCombatNpc(652, 3154, 3202, 0, 1) #wizard
    World.addNonCombatNpc(654, 3131, 3209, 0, 1) #leprechaun
    World.addQuest(quest_id, quest_name, quest_stages)
    
def quest_button_14(player):
    quest_stage = player.getQuest(14).getStage()
    if quest_stage == 0: 
        player.getFunction().startInfo("Lost City", "I can start this quest by speaking the Adventurers in", "the Swamp just south of Lumbridge. To complete this quest I need", "Level 31 Crafting and Level 36 Woodcutting and to be able", "to defeat a level 101 spirit.")
    elif quest_stage == 1:
        player.boxMessage("I need to find the leprechaun, it must know more", "about how I can find Zanaris.")
    elif quest_stage == 2:
        player.boxMessage("I need to chop a Dramen tree to obtain a staff", "made from Dramenwood, the Leprechaun said I could find such wood", "in a cave on the island of Entrana.")
    elif quest_stage == 3: 
        player.boxMessage("I must use the Dramenwood staff obtained from Entrana", "to enter the city of Zanaris via the shed in", "lumbridge swamp.")
    elif quest_stage == 4:
        player.boxMessage("I have completed the @dre@Lost City@bla@ quest.")

def first_click_npc_654(player):
    player.startChat(352061)
def first_click_npc_649(player):
    player.startChat(352034)
def first_click_npc_650(player):
    player.startChat(352034)
def first_click_npc_651(player):
    player.startChat(352034)
def first_click_npc_652(player):
    player.startChat(352034)

def kill_npc_655(player):
    quest_stage = player.getQuest(14).getStage()
    if quest_stage == 2:
        player.getQuest(14).setStage(3)
    
def first_click_object_1292(player):
    if player.hasAttribute("treespirit"):
        player.playerChat("I don't think I can chop this tree, I'll", "have to find some other way to obtain Dramenwood.")
        player.endChat()
    else:
        World.getNpcHandler().spawnNpc(player, 655, 2858, 9733, player.absZ, 0, 120, 25, 170, 170, True, True)
        player.addAttribute("treespirit", 1)
        player.boxMessage("A spirit escapes from the tree.")

def chat_352034(player):
    player.npcChat("Hello there traveller.")
    player.nextChat(352035)
    
def chat_352035(player):
    player.dialogueOption("What are you camped out here for?", 352042, "Do you know any good adventures I can go on?", 352038)
    
def chat_352038(player):
    player.playerChat("Do you know any good adventures I can go on?")
    player.nextChat(352039)
    
def chat_352039(player):
    player.npcChat("Well we're on an adventure right now. Mind you, this", "is OUR adventure and we don't want to share it - find", "your own!")
    player.nextChat(352040)

def chat_352040(player):
    quest_stage = player.getQuest(14).getStage()
    requirement = player.getLevel("crafting") > 30 and player.getLevel("woodcutting") > 35
    if player.lastClickedNpcId == 650 and requirement and quest_stage == 0:
        player.dialogueOption("Please tell me.", 352041, "I don't think you've found a good adventure at all!", 352045)
    else:
        player.playerChat("Oh, okay then.")
        player.endChat()

def chat_352041(player):
    player.playerChat("Please tell me.")
    player.nextChat(352042)
    
def chat_352042(player):
    player.npcChat("You aren't getting any information out of me!")
    player.endChat()

def chat_352045(player):
    player.playerChat("I don't think you've found a good adventure at all!")
    player.nextChat(352046)

def chat_352046(player):
    player.npcChat("Hah! Adventurers of our calibre don't just hang around", "in forests for fun, whelp!")
    player.nextChat(352047)

def chat_352047(player):
    player.playerChat("Oh really?")
    player.nextChat(352048)
    
def chat_352048(player):
    player.playerChat("What are you camped here for?")
    player.nextChat(352049)
    
def chat_352049(player):
    player.npcChat("We're looking for Zanaris...GAH! I mean we're not", "here for any particular reason at all.")
    player.nextChat(352050)

def chat_352050(player):
    player.playerChat("Who's Zanaris?")
    player.nextChat(352051)
    
def chat_352051(player):
    player.npcChat("Ahahaha! Zanaris isn't a person! It's a magical hidden", "city filled with treasures and rich... uh, nothing. It's", "nothing.")
    player.nextChat(352052)
    
def chat_352052(player):
    player.playerChat("If it's hidden, how are you planning to find it?")
    player.nextChat(352053)

def chat_352053(player):
    player.npcChat("Well, we don't want to tell anyone else about that,", "because we don't want anyone else sharing in all that", "glory and treasure.")
    player.nextChat(352054)
    
def chat_352054(player):
    player.playerChat("Well it looks to me like YOU don't know EITHER", "seeing as you're all just sat around here.")
    player.nextChat(352055)
    
def chat_352055(player):
    player.npcChat("Of course we know!", "We just haven't found which tree", "the stupid leprechaun's hiding in yet!")
    player.nextChat(352056)
    
def chat_352056(player):
    player.npcChat("GAH! I didn't mean to tell you that! Look, just forget I", "said anything in okay?")
    player.nextChat(352057)
    
def chat_352057(player):
    player.playerChat("So a leprechaun knows where Zanaris is eh?")
    player.nextChat(352058)

def chat_352058(player):
    player.npcChat("Ye.. uh, no. No, not at all. And even if he did - which", "he doesn't - he DEFINITELY ISN'T hiding in some", "trees around here. Nope, definitely. Honestly.")
    player.nextChat(352059)
    player.getQuest(14).setStage(1)
    player.refreshQuestTab()

def chat_352059(player):
    player.playerChat("Thanks for the help!")
    player.nextChat(352060)

def chat_352060(player):
    player.npcChat("Help? What help? I didn't help! Please don't say I did,", "I'll get in trouble!")
    player.endChat()
    
def chat_352061(player):
    player.npcChat("Ay yer big elephant! Yer've caught me, to be sure!", "What would an elephant like yer be wanting wid o'l", "Shamus then?")
    player.nextChat(352062)

def chat_352062(player):
    quest_stage = player.getQuest(14).getStage()
    if quest_stage == 1: 
        player.playerChat("I want to find Zanaris.")
        player.nextChat(352063)
    else:
        player.playerChat("Nothing you little green bellend.")
        player.endChat()

def chat_352063(player):
    player.npcChat("Zanaris is it now? Well well well... Yer'll be needing to", "be going to that funny little out there in the", "swamp, so you will.")
    player.nextChat(352064)
    
def chat_352064(player):
    player.playerChat("...but... I thought... Zanaris was a city...?")
    player.nextChat(352065)
    
def chat_352065(player):
    player.npcChat("Aye that it is!")
    player.nextChat(352066)
    
def chat_352066(player):
    player.playerChat("I've been in that shed, I didn't see a city.")
    player.nextChat(352067)

def chat_352067(player):
    player.npcChat("Oh, was I fergetting to say? Yer need to be carrying a", "Dramenwood staff to be getting there! Otherwise Yer'll", "just be ending up in the shed.")
    player.nextChat(352068)
    
def chat_352068(player):
    player.npcChat("Dramenwood staffs are crafted from branches of the", "Dramen tree, so they are. I hear there's a Dramen", "tree over on the island of Entrana in a cave")
    player.nextChat(352069)
    
def chat_352069(player):
    player.npcChat("or some such. There would probably be a good place", "for an elephant like yer to be starting looking I reckon.")
    player.nextChat(352070)

def chat_352070(player):
    player.npcChat("The monks are running a ship from Port Sarim to", " Etrana, I hear too. Now leave me alone yer elephant!")
    player.getQuest(14).setStage(2)
    player.endChat()
    
def chat_352080(player):
    player.getQuest(14).setStage(4)
    reward = QuestReward("3 Quest Points", "Access to Zanaris")
    player.completeQuest("Lost City", reward, 772)
    player.qp += 2