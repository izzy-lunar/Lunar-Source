# Quest Name: Monkey Madness
# Quest Authors: OwnXile
# Date Created: 9/14/13
# Quest Length: Medium
# Quest Difficulty: Hard

king_narnode_shareen = 670
karam = 1420
lundo = 1419
lumo = 1413

def configure_quest_19():
    quest_id = 19
    quest_name = "Monkey Madness"
    quest_stages = 6
    World.addNonCombatNpc(king_narnode_shareen, 2465, 3496, 0, 1)
    World.addNonCombatNpc(lumo, 2764, 2705, 0, 1)
    World.addNonCombatNpc(karam, 2781, 2799, 0, 1)
    World.addNonCombatNpc(lundo, 2804, 9146, 0, 1)
    World.addQuest(quest_id, quest_name, quest_stages)

def quest_button_19(player):
    stage = player.getQuest(19).getStage()
    if stage == 0:
        player.getFunction().startInfo("Monkey Madness", "I can start this quest by speaking to the @dre@King narnode shareen@bla@", "is located at the ground level of the gnome stronghold.", "", "")
    elif stage == 1:
        player.boxMessage("King narnode shareen told me to find his spy", "on Ape Atol. I'll need to take use the glider to get", "there then get inside the city somehow.")
    elif stage == 2:
        player.boxMessage("Lumo has informed me that Lundo can make me", "enchanted equipment to disguise myself.")
    elif stage == 3:
        player.boxMessage("Lundo has provided me with a Monkey Greegree", "which I can use to sneak into Ape Atol and find", "the kings spy.")
    elif stage == 4:
        player.boxMessage("Karam told me to enter the trapdoor in the", "building to the south of Ape Atol.")
    elif stage == 5:
        player.boxMessage("The Jungle demon has been defeated and the", "gnomish race has been saved. I should probably let the", "king know.")
    elif stage == 6:
        player.boxMessage("I have completed the @dre@Monkey Madness @bla@quest.")

def first_click_npc_670(player):#king
    stage = player.getQuest(19).getStage()
    if stage == 0:
        player.startChat(1781662388)
    elif stage == 5:
        player.startChat(22433224)
    else:
        player.sendMessage("The king looks very busy.")

def first_click_npc_1420(player):#karam
    stage = player.getQuest(19).getStage()
    if stage == 3:
        player.startChat(1057961997)
    else:
        player.sendMessage("Looks like he wants to remain hidden.")
    
def first_click_npc_1413(player):#lumo
    stage = player.getQuest(19).getStage()
    if stage == 1:
        player.startChat(172080016)
    else:
        player.sendMessage("Doesn't look like he wants to talk right now.")

def first_click_npc_1419(player):#lundo
    player.startChat(1756093858)

def chat_1781662388(player):
    player.npcChat("Hey there young adventurer.")
    player.nextChat(1781662389)

def chat_1781662389(player):
    player.playerChat("Hi little guy, so you're a king?")
    player.nextChat(1781662390)

def chat_1781662390(player):
    player.npcChat("I am not little! I am King Narnode Shareen and ", "this is my stronghold.")
    player.nextChat(1781662391)

def chat_1781662391(player):
    player.playerChat("Do you have any quests?")
    player.nextChat(1781662392)

def chat_1781662392(player):
    player.npcChat("Well as a matter of fact I do, ", "one of my spies has managed to lose", "contact with us on ape atol. Perhaps you could", "find out what's happened to him? ")
    player.nextChat(1781662393)

def chat_1781662393(player):
    player.playerChat("What's ape atol?")
    player.nextChat(1781662394)

def chat_1781662394(player):
    player.npcChat("Ape atol is where all the stinking apes live! We gnomes", "have a history of poor relations with them. They don't take kindly", "to newcomers.")
    player.nextChat(1781662395)

def chat_1781662395(player):
    player.playerChat("I'm sure they'll love me though!")
    player.nextChat(1781662396)

def chat_1781662396(player):
    player.npcChat("If there's one thing an Ape hates more than a Gnome,", "it's a human.")
    player.nextChat(1781662397)

def chat_1781662397(player):
    player.playerChat("Pfff, I'm not scared of stupid monkeys!")
    player.nextChat(1781662398)

def chat_1781662398(player):
    player.npcChat("Good.")
    player.nextChat(1781662399)

def chat_1781662399(player):
    player.npcChat("My spies name is Karam, if you find him tell him he", "needs to report back to us immediately.")
    player.nextChat(1781662400)

def chat_1781662400(player):
    player.npcChat("You'll need to take the gnome glider over to the island", "and if you get caught....well....", "good luck.")
    player.getQuest(19).setStage(1)
    player.refreshQuestTab()
    player.nextChat(1781662401)

def chat_1781662401(player):
    player.playerChat("Um, thanks.")
    player.endChat()
    
def chat_172080016(player):
    player.playerChat("Hello there, have you seen a gnome, ", "named Karam?")
    player.nextChat(172080017)

def chat_172080017(player):
    player.npcChat("Who's asking?")
    player.nextChat(172080018)

def chat_172080018(player):
    player.playerChat("My name is " + str(player.playerName) + ", I was sent by King", "narnode shareen.")
    player.nextChat(172080019)

def chat_172080019(player):
    player.npcChat("King Narnode eh.. yeah I've seen him.")
    player.nextChat(172080020)

def chat_172080020(player):
    player.npcChat("He passed through here a few weeks ago, said", "he was heading up to the city of the apes.")
    player.nextChat(172080021)

def chat_172080021(player):
    player.playerChat("Brilliant, I'll head there right away then!")
    player.nextChat(172080022)

def chat_172080022(player):
    player.npcChat("Hahaha - very funny.")
    player.nextChat(172080023)

def chat_172080023(player):
    player.npcChat("A human in Ape atol!")
    player.nextChat(172080024)

def chat_172080024(player):
    player.npcChat("Ha ha ha")
    player.nextChat(172080025)

def chat_172080025(player):
    player.playerChat("What's so funny about that?")
    player.nextChat(172080026)

def chat_172080026(player):
    player.npcChat("You don't know what they do to humans?")
    player.nextChat(172080027)

def chat_172080027(player):
    player.npcChat("Let's just say you're better off disguising yourself.")
    player.nextChat(172080028)

def chat_172080028(player):
    player.playerChat("What? As an monkey?!")
    player.nextChat(172080029)

def chat_172080029(player):
    player.npcChat("Precisely.")
    player.nextChat(172080030)

def chat_172080030(player):
    player.playerChat("And how do you suggest I manage that?")
    player.nextChat(172080031)

def chat_172080031(player):
    player.npcChat("I know a guy handy little gnome, goes by", "the name Lumdo. You can find him in the dungeon over there.")
    player.nextChat(172080032)

def chat_172080032(player):
    player.npcChat("He's a specialist in enchanted equipment. The kind", "that can transform your physical appearance.")
    player.nextChat(172080033)

def chat_172080033(player):
    player.playerChat("Sounds amazing, I can't wait to meet him.")
    player.getQuest(19).setStage(2)
    player.nextChat(172080034)

def chat_172080034(player):
    player.npcChat("Be careful though, it won't be easy surviving down in the dungeon,", "all sorts of undead creatures live down there.")
    player.nextChat(172080035)

def chat_172080035(player):
    player.playerChat("Don't worry, I've handled quite a few undeads in my time.", "Thank you for your assistant, I'll see you later.")
    player.endChat()

def chat_1756093858(player):
    player.playerChat("Lundo?")
    player.nextChat(1756093859)

def chat_1756093859(player):
    player.npcChat("That's my name, don't wear it out.")
    player.nextChat(1756093860)

def chat_1756093860(player):
    player.playerChat("I was told you were a specialist in", "enchanted equipment!")
    player.nextChat(1756093861)

def chat_1756093861(player):
    player.npcChat("Yes I am.")
    player.nextChat(1756093862)

def chat_1756093862(player):
    player.npcChat("What are you looking for?")
    player.nextChat(1756093863)

def chat_1756093863(player):
    player.playerChat("I wish to take on the physical appearance of a monkey!")
    player.nextChat(1756093864)

def chat_1756093864(player):
    player.npcChat("Ah, you're not the first. I have a couple of greegrees that", "will do just that.")
    player.nextChat(1756093865)

def chat_1756093865(player):
    player.npcChat("They don't come cheap mind.")
    player.nextChat(1756093866)

def chat_1756093866(player):
    player.playerChat("How much for your cheapest greegree?")
    player.nextChat(1756093867)

def chat_1756093867(player):
    player.npcChat("I'd say around 500,000 coins should cover", "my production costs.")
    player.nextChat(1756093868)

def chat_1756093868(player):
    if player.hasItem(995, 500000):
        player.playerChat("Sounds reasonable, thanks!")
        player.deleteItem(995, 500000)
        player.nextChat(1756093869)
    else:
        player.playerChat("Ah I didn't bring enough money with me.")
        player.endChat()

def chat_1756093869(player):
    player.npcChat("A pleasure doing business with you, have fun", "being an ape. Don't let the real apes catch", "you though! Ha ha ha.")
    
    stage = player.getQuest(19).getStage()
    if stage == 2:
        player.getQuest(19).setStage(3)
    if not player.hasItem(4024):
        player.addItem(4024)
    player.endChat()

def chat_1057961997(player):
    player.playerChat("Hello? Is anybody there?")
    player.nextChat(1057961998)

def chat_1057961998(player):
    player.npcChat("That depends on who is asking...")
    player.nextChat(1057961999)

def chat_1057961999(player):
    player.playerChat("I am in service of King Narnode Shareen. I have", "been sent here to retrieve information from the ", "gnome spy mission.")
    player.nextChat(1057962000)

def chat_1057962000(player):
    player.npcChat("At last! I've been stuck here for weeks.")
    player.nextChat(1057962001)

def chat_1057962001(player):
    player.npcChat("The monkeys are preparing the launch an attack on ", "the gnome stronghold!")
    player.nextChat(1057962002)

def chat_1057962002(player):
    player.playerChat("Really...? I find that hard to believe....")
    player.nextChat(1057962003)

def chat_1057962003(player):
    player.npcChat("I know it's difficult but they have a secret weapon! There ", "isn't much time. You must help me stop them.")
    player.nextChat(1057962004)

def chat_1057962004(player):
    player.playerChat("Me? I'm really only a messenger...")
    player.nextChat(1057962005)

def chat_1057962005(player):
    player.npcChat("You must be tough if you were sent by the King! ", "Please I need your help.")
    player.nextChat(1057962006)

def chat_1057962006(player):
    player.playerChat("Well, I suppose I could offer you some assistance.", "How though?")
    player.nextChat(1057962007)

def chat_1057962007(player):
    player.npcChat("The trapdoor in the building to the south of the city!", "I'll meet you down there.")
    player.getQuest(19).setStage(4)
    player.nextChat(1057962008)

def chat_1057962008(player):
    player.playerChat("Very well.")
    player.endChat()
    
def command_ttt(player):
    player.startChat(1635409878)

def chat_1635409878(player):
    player.lastClickedNpcId = 1420
    player.cannotCloseWindows = True
    player.playerChat("Wait... so what are we doing here?")
    player.nextChat(1635409879)

def chat_1635409879(player):
    player.npcChat("The demon...!!!!")
    player.nextChat(1635409880)

def chat_1635409880(player):
    player.npcChat("He must be stopped, the gnomish race depends on you!")
    player.nextChat(1635409881)

def chat_1635409881(player):
    player.playerChat("A demon? you lied to me!")
    player.nextChat(1635409882)

def chat_1635409882(player):
    player.npcChat("I didn't lie.. I just didn't tell you the whole truth.", "Look there isn't time, just kill it!")
    player.nextChat(1635409883)
    World.getNpcHandler().spawnNpc(player, 1472, 2651, 4573, 1, 0, 220, 35, 370, 370, True, True)

def chat_1635409883(player):
    player.playerChat("I'll kill you too!")
    player.cannotCloseWindows = False
    player.endChat()

def kill_npc_1472(player):
    stage = player.getQuest(19).getStage()
    if stage == 4:
        player.getQuest(19).setStage(5)
        player.playerChat("I better update the King on what's happened.")

def chat_22433224(player):
    player.npcChat("Ah there you are! Karam told me all", "about what you did! You saved us all.")
    player.nextChat(22433225)

def chat_22433225(player):
    player.playerChat("Oh, it was nothing.")
    player.nextChat(22433226)

def chat_22433226(player):
    player.playerChat("Not the first time I've slayed a demon and it", "won't be the last.")
    player.nextChat(22433227)

def chat_22433227(player):
    player.npcChat("Bravo! The entire gnome kingdom owes you greatly,", "please accept this gift as a reward.")
    player.nextChat(22433228)

def chat_22433228(player):
    player.endChat()
    player.getQuest(19).setStage(6)
    player.addItem(10586, 3)
    reward = QuestReward("Ability to equip Dragon Scimitars", "Access to Ape Atol", "1 Quest Point", "3x Combat Lamp")
    player.completeQuest("Monkey Madness", reward, 4587)