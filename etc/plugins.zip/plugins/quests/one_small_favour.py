# Quest Name: One Small Favor
# Quest Authors: Ferret, Parrot
# Date Created: 19/8/13
# Quest Length: Long

#NPCs
peer_the_seer_id = 1288
bartender_id = 731
bartender_2_id = 733
sir_vyvin_id = 605
sawmill_operator_id = 4250
captain_shanks_id = 518

#Items
shiny_key_item = 85
secret_way_map_item = 3104
knight_key_item = 85
recipe_item = 6546
yew_logs_item = 1516
note_item = 4597


#Quest configuration
def configure_quest_7():
    quest_id = 7
    quest_name = 'One Small Favour'
    quest_stages = 15
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(4250, 3302, 3492, 0, 0)
    World.addNonCombatNpc(518, 2674, 3273, 0, 1)
    World.addNonCombatNpc(1288, 2711, 3478, 0, 1)
    World.addNonCombatNpc(731, 3226, 3400, 0, 0)
    World.addNonCombatNpc(733, 2954, 3371, 0, 1)
    World.addNonCombatNpc(605, 2957, 3337, 0, 1)
    World.addNonCombatNpc(456, 3244, 3205, 0, 1)
    World.addCombatNpc(3349, 2972, 3345, 0, 1, 37, 11, 16, 30)
    World.addCombatNpc(3349, 2975, 3343, 0, 1, 37, 11, 16, 30)
    World.addCombatNpc(3349, 2977, 3341, 0, 1, 37, 11, 16, 30)

#Quest button
def quest_button_7(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 0:
        player.getFunction().startInfo("One Small Favour", "I can start this quest by talking to", "@dre@Peer the Seer@bla@ in Camelot.", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should speak to the @dre@Bartender@bla@ in Varrock.", "Maybe he can help me find the map.")
    elif quest_stage == 2:
        player.boxMessage("I should speak to the @dre@Bartender@bla@ in Falador.")
    elif quest_stage == 3:
        player.boxMessage("I have to get some key that is in posession of the White Knights.")
    elif quest_stage == 4:
        player.boxMessage("I think this is what the @dre@Bartender@bla@ in Falador wanted.")
    elif quest_stage == 5:
        player.boxMessage("The White Knights stole the recipe.", "I'm going to have to get it back somehow.")
    elif quest_stage == 6:
        player.boxMessage("I need to give 200 noted yew logs to the @dre@Sawmill Operator@bla@.", "He's located northeast of Varrock.")
    elif quest_stage == 7:
        player.boxMessage("I need to speak to @dre@Father Aereck@bla@.", "He can give the Sawmill's son a blessing.")
    elif quest_stage == 8:
        player.boxMessage("I should return to the @dre@Sawmill Operator@bla@ to tell him the news.")
    elif quest_stage == 9:
        player.boxMessage("I should return to @dre@Sir Vyvin@bla@ with these notes.")
    elif quest_stage == 10:
        player.boxMessage("I should return to the @dre@Bartender@bla@ in Falador with this recipe.")
    elif quest_stage == 11:
        player.boxMessage("I should return to the @dre@Bartender@bla@ in Varrock with this recipe.")
    elif quest_stage == 12:
        player.boxMessage("I need to talk to @dre@Captain Shanks@bla@. He has the secret map.")
    elif quest_stage == 13:
        player.boxMessage("I should return to @dre@Peer the Seer@bla@ with this secret map.")
    elif quest_stage == 14:
        player.boxMessage("I should talk to @dre@Peer the Seer@bla@ to claim my reward.")
    elif quest_stage == 15:
        player.boxMessage("I have completed the @dre@One Small Favour@bla@ quest.")

#Peer the Seer
def first_click_npc_1288(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 0:
        player.startChat(210000)
    elif quest_stage == 13:
        player.startChat(210093)
    elif quest_stage == 14:
        player.startChat(210095)
    elif quest_stage == 15:
        player.startChat(210102)
    else:
        player.npcChat("The future of OwnXile is looking good!")

#Bartender 1
def first_click_npc_731(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 1:
        player.startChat(210014)
    elif quest_stage == 11:
        player.startChat(210073)
    else:
        player.startChat(533900)

def chat_533900(player):
    player.npcChat("Would you like to try some of the finest ale?")
    player.nextChat(533901)
    
def chat_533901(player):
    player.dialogueOption("Yes please!", 533902, "No thanks.", 533903)
    
def chat_533903(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def chat_533902(player):
    player.playerChat("Yes please!")
    player.nextChat(533904)
    
def chat_533904(player):
    player.endChat()
    player.getShop().openShop(455)    

#Bartender 2    
def first_click_npc_733(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 2:
        player.startChat(210021)
    elif quest_stage == 4:
        player.startChat(210030)
    elif quest_stage == 10:
        player.startChat(210069)
    else:
        player.npcChat("My bar is currently closed.", "There's too many drunks here.")
        player.endChat()
        
#White Knight Killing    
def kill_npc_3349(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 3:
        player.getQuest(7).setStage(4)
        player.addItem(knight_key_item)
        player.boxMessage("You recieved a key.")

#Sir Vyvin
def first_click_npc_605(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 5:
        player.startChat(210038)
    elif quest_stage == 9:
        player.startChat(210065)
    else:
        player.npcChat("Welcome to the White Knights Castle.")
        player.endChat()

#Sawmill Operator
def first_click_npc_4250(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 6 and player.hasItem(yew_logs_item, 200):
        player.startChat(210047)
    elif quest_stage == 6:
        player.startChat(210055)
    elif quest_stage == 8:
        player.startChat(210061)
    else:
        player.playerChat("I better not disturb him right now. He seems busy.")
        player.endChat()
        
def second_click_npc_605(player):
    player.boxMessage("Nothing interesting happens.")
    
def third_click_npc_605(player):
    player.boxMessage("The Shop is no longer open.")

#Father Aereck
def first_click_npc_456(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 7:
        player.startChat(210056)
    else:
        player.npcChat("Hello there, " + str(player.playerName) + " ! ")
        player.endChat()
        
#Captin Shanks
def first_click_npc_518(player):
    quest_stage = player.getQuest(7).getStage()
    if quest_stage == 12:
        player.startChat(210081)

#Recipe
def click_item_6546(player):
    player.boxMessage("There's spilled beer on the recipe.", "You can't make out what it says.")
        
#Note
def click_item_4597(player):
    player.boxMessage("One Small Favour", " " + str(player.playerName) + " has brought me 200 noted yew logs.", "Sincerely, The Sawmill Operator.")
        
#Chat dialogues    
def chat_210000(player):
    player.npcChat("Hello adventurer, what can I do for you?")
    player.nextChat(210001)

def chat_210001(player):
    player.dialogueOption("Nothing, just passing by.", 210002, "I'm looking for a quest!", 210004)
    player.nextChat(210000)
    
def chat_210002(player):
    player.playerChat("Nothing, just passing by.")
    player.nextChat(210003)
    
def chat_210003(player):
    player.npcChat("Okay.")
    player.endChat()
    
def chat_210004(player):
    player.playerChat("I'm looking for a quest!")
    player.nextChat(210005)
    
def chat_210004(player):
    player.npcChat("I suppose I do need one small favour.", "Can you help me?")
    player.nextChat(210005)

def chat_210005(player):
    player.dialogueOption("Accept Quest", 210006, "Decline Quest", 210003)
    player.nextChat(210006)

def chat_210006(player):
    player.getQuest(7).setStage(1)
    player.refreshQuestTab()
    player.playerChat("I'll gladly help you. What can I do for you?")
    player.nextChat(210007)
    
def chat_210007(player):
    player.npcChat("I'm in dire need of a map. There's a legend that", "claims that riches beyond belief will be granted if"," the treasure is found!")
    player.nextChat(210008)

def chat_210008(player):
    player.playerChat("How do I get this map?")
    player.nextChat(210009)
    
def chat_210009(player):
    player.npcChat("I'm not quite sure, perhaps you can talk to my friend in Varrock.", "He's the bartender.")
    player.nextChat(210010)
    
def chat_210010(player):
    player.playerChat("I'll ask him.")
    player.nextChat(210011)
    
def chat_210011(player):
    player.npcChat("Thank you, adventurer. Say, what's you're name?")
    player.nextChat(210012)
    
def chat_210012(player):
    player.playerChat("I'm " + str(player.playerName) + ".")
    player.nextChat(210013)
    
def chat_210013(player):
    player.npcChat("Thank you, " + str(player.playerName) + ". ")
    player.endChat()
    
def chat_210014(player):
    player.dialogueOption("Hey, I was sent by Peer the Seer to talk to you about some map?", 810015, "Can I buy a beer please?", 533900)

def chat_810015(player):
    player.playerChat("Hey, I was sent by Peer the Seer to talk to you", "about some map?")
    player.nextChat(210015)    
    
def chat_210015(player):
    player.npcChat("That old man is always after something!", "I assume he's asked for you help?")
    player.nextChat(210016)
    
def chat_210016(player):
    player.playerChat("That's correct.", "Do you know where I can get it?")
    player.nextChat(210017)

def chat_210017(player):
    player.npcChat("I used to know, however I know someone who may be able", "to help. I can give you his name and location", "if you do me one small favour?")
    player.nextChat(210018)
    
def chat_210018(player):
    player.playerChat("What can I do for you?")
    player.nextChat(210019)
    
def chat_210019(player):
    player.npcChat("My ales aren't as popular as they used to.", "The other Bartender in Falador has a recipe.", "Can you help me achieve it?" )
    player.nextChat(210020)
    
def chat_210020(player):
    player.getQuest(7).setStage(2)
    player.refreshQuestTab()
    player.playerChat("I'll see what I can do.")
    player.endChat()
    
def chat_210021(player):
    player.playerChat("Hello, I heard you had a recipe for a new brand of ales?")
    player.nextChat(210022)
    
def chat_210022(player):
    player.npcChat("If you think I'll give you the recipe so that", "the fool in Varrock can have my business then forget it!")
    player.nextChat(210023)
    
def chat_210023(player):
    player.playerChat("I'm sure we can negotiate something.", "What do you want in exchange for the recipe?")
    player.nextChat(210024)
    
def chat_210024(player):
    player.npcChat("Nothing! Now leave!")
    player.nextChat(210025)
    
def chat_210025(player):
    player.boxMessage("The Bartender suddenly seems to have a change of heart.")
    player.nextChat(210026)
    
def chat_210026(player):
    player.getQuest(7).setStage(3)
    player.refreshQuestTab()
    player.npcChat("Actually... if you can get me the one thing those", "White Knights desire the most, I'll give you the recipe.", "Those knights think they own me!")
    player.nextChat(210027)
    
def chat_210027(player):
    player.playerChat("What do they love the most?")
    player.nextChat(210028)
    
def chat_210028(player):
    player.npcChat("You figure it out. Now leave!")
    player.nextChat(210029)
    
def chat_210029(player):
    player.boxMessage("You overhear a conversation about a key in the knights' posession.")
    player.endChat()

def chat_210030(player):
    player.playerChat("I have what you want.", "Here's your key.")
    player.nextChat(210031)
    
def chat_210031(player):
    if player.hasItem(knight_key_item):
        player.deleteItem(knight_key_item)
        player.boxMessage("You hand over the shiny key.")
        player.nextChat(210032)
    else:
        player.playerChat("I think I know what you want. I'll be back.")
        player.endChat()

def chat_210032(player):
    player.getQuest(7).setStage(5)
    player.refreshQuestTab()
    player.npcChat("THOSE WHITE KNIGHTS! THEY CAN'T DO THIS TO ME!")
    player.nextChat(210033)
    
def chat_210033(player):
    player.playerChat("What happened?")
    player.nextChat(210034)
    
def chat_210034(player):
    player.npcChat("THE RECIPE! THEY STOLE MY RECIPE!")
    player.nextChat(210035)
    
def chat_210035(player):
    player.playerChat("I didn't do all of this for nothing!", "I'll get that recipe if it's the last thing I do!")
    player.nextChat(210036)
    
def chat_210036(player):
    player.npcChat("If you find the recipe return to me so I know it's safe.", "Only then you may keep it and give it to", "the Bartender in Varrock.")
    player.nextChat(210037)
    
def chat_210037(player):
    player.playerChat("Thank you.")
    player.endChat()
    
def chat_210038(player):
    player.npcChat("Welcome to the White Knights Castle!", "What can I do for you?")
    player.nextChat(210040)
    
def chat_210040(player):
    player.playerChat("There's rumours going around that you stole a recipe?")
    player.nextChat(210041)
    
def chat_210041(player):
    player.npcChat("Indeed we did, that Bartender sent one of his men to get hold", "of one of our precious keys we're in posession of.", "Can you believe that?")
    player.nextChat(210042)
    
def chat_210042(player):
    player.playerChat("Ha...Ha-ha...", "What can I do for you in exchange for that recipe?")
    player.nextChat(210043)
    
def chat_210043(player):
    player.npcChat("I wasn't going to give it away, but now that I think about it...", "Perhaps you can do me one small favour?")
    player.nextChat(210044)
    
def chat_210044(player):
    player.playerChat("Lay it on me!")
    player.nextChat(210045)
    
def chat_210045(player):
    player.getQuest(7).setStage(6)
    player.refreshQuestTab()
    player.npcChat("We're trying to expand our castle.", "We need about 200 noted yew logs.", "You can give them to the Sawmill Operator northeast of Varrock.")
    player.nextChat(210046)
    
def chat_210046(player):
    player.playerChat("I'll get those 200 noted yew logs to him.")
    player.endChat()
    
def chat_210047(player):
    player.playerChat("I was told by Sir Vyvin to bring you 200 yew logs?")
    player.nextChat(210048)
    
def chat_210048(player):
    player.npcChat("Ah yes, hand them over please.")
    player.nextChat(210049)
    
def chat_210049(player):
    if player.hasItem(yew_logs_item, 200):
        player.deleteItem(yew_logs_item, 200)
        player.getQuest(7).setStage(7)
        player.refreshQuestTab()
        player.boxMessage("You hand over the noted yew logs.")
        player.nextChat(210050)
        
def chat_210050(player):
    player.playerChat("Can I get a note to prove to Sir Vyvin that I have delivered", "the 200 yew logs?")
    player.nextChat(210051)

def chat_210051(player):
    player.npcChat("I can, if you do me one small favour.")
    player.nextChat(210052)

def chat_210052(player):
    player.playerChat("What do you need me to do?")
    player.nextChat(210053)

def chat_210053(player):
    player.npcChat("My son is sick. The Father in Lumbridge can give him a blessing.", "Can you please ask him to do this for me?")
    player.nextChat(210054)
    
def chat_210054(player):
    player.playerChat("Yes, I can.", "I hope your son gets better.")
    player.endChat()
    
def chat_210055(player):
    player.playerChat("It seems I don't have the logs.", "I'll return with all 200 noted yews.")
    player.endChat()
    
def chat_210056(player):
    player.playerChat("Hello there, I need your help.")
    player.nextChat(210057)
    
def chat_210057(player):
    player.npcChat("What do you need assistance with?")
    player.nextChat(210058)
    
def chat_210058(player):
    player.playerChat("The Sawmill's son is sick.", "He asked me if you can give him a blessing.")
    player.nextChat(210059)
    
def chat_210059(player):
    player.getQuest(7).setStage(8)
    player.refreshQuestTab()
    player.npcChat("Of course! I can't refuse someone in need!", "Tell him I will give him a blessing later tonight.")
    player.nextChat(210060)
    
def chat_210060(player):
    player.playerChat("Thank you, Father Aereck.")
    player.endChat()
    
def chat_210061(player):
    player.npcChat("Did you speak to Father Aereack?")
    player.nextChat(210062)
    
def chat_210062(player):
    player.playerChat("Yes. He said he'd give him a blessing later tonight.")
    player.nextChat(210063)

def chat_210063(player):
    if player.hasInventorySpace(1):
        player.addItem(note_item)
        player.getQuest(7).setStage(9)
        player.refreshQuestTab()
        player.npcChat("Thank you so much! Here's the note you wanted.", "You should probably return to Sir Vyvin.")
        player.nextChat(210064)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for this note.")

def chat_210064(player):
    player.playerChat("Thank you.")
    player.endChat()
    
def chat_210065(player):
    player.npcChat("Did you give the Sawmill Operator the yew logs?")
    player.nextChat(210066)
    
def chat_210066(player):
    player.playerChat("Yes, to prove that I did here are his notes.")
    player.nextChat(210067)

def chat_210067(player):
    if player.hasItem(note_item):
        player.deleteItem(note_item)
        player.getQuest(7).setStage(10)
        player.refreshQuestTab()
        player.boxMessage("You hand over the notes.")
        player.nextChat(210068)
    else:
        player.playerChat("I forgot the note. I'll be back.")
        player.endChat()
    
def chat_210068(player):
    if player.hasInventorySpace(1):
        player.addItem(recipe_item)
        player.npcChat("Splendid! Here is the recipe I promised you.")
        player.endChat()
    else:
        player.boxMessage("It looks like I don't have enough inventory space for this recipe.")
        player.endChat()
        
def chat_210069(player):
    player.playerChat("Here's your recipe!")
    player.nextChat(210070)

def chat_210070(player):
    if player.hasItem(recipe_item):
        player.getQuest(7).setStage(11)
        player.refreshQuestTab()
        player.boxMessage("You show the bartender the recipe.")
        player.nextChat(210071)
    else:
        player.playerChat("I forgot the recipe. I'll be back.")
        player.endChat()

def chat_210071(player):
    player.npcChat("Thank you so much!", "Please, share it with the Bartender in varrock.")
    player.nextChat(210072)
    
def chat_210072(player):
    player.playerChat("Thank you.")
    player.endChat()
    
def chat_210073(player):
    player.npcChat("Do you have the recipe for the new ales?")
    player.nextChat(210074)
 
def chat_210074(player):
    if player.hasItem(recipe_item):
        player.deleteItem(recipe_item)
        player.getQuest(7).setStage(12)
        player.refreshQuestTab()
        player.playerChat("Here you go!")
        player.nextChat(210075)
    else:
        player.playerChat("I forgot the recipe. I'll be back.")
        player.nextChat(810020)
        
def chat_810020(player):
    player.npcChat("Okay. Would you like to buy a beer whilst you're here?")
    player.nextChat(810021)
        
def chat_810021(player):
    player.dialogueOption("Yes please.", 810022, "No thanks.", 810023)    

def chat_810022(player):
    player.playerChat("Yes please.")
    player.nextChat(810024)
    
def chat_810023(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def chat_810024(player):
    player.endChat()
    player.getShop().openShop(455)
    
def chat_210075(player):
    player.npcChat("I can't believe it! Getting this must have been easy", "if he just gave it to you this quickly!")
    player.nextChat(210076)
    
def chat_210076(player):
    player.playerChat("Believe me, it wasn't easy...")
    player.nextChat(210077)
    
def chat_210077(player):
    player.npcChat("Thank you, anyways.", "To find the secret map, the guy you need to talk to", "is Captain Shanks.")
    player.nextChat(210078)
    
def chat_210078(player):
    player.playerChat("Where can I find him?")
    player.nextChat(210079)
    
def chat_210079(player):
    player.npcChat("He's located just southeast of Ardougne.")
    player.nextChat(210080)
    
def chat_210080(player):
    player.playerChat("Finally, thank you for your help.")
    player.endChat()
    
def chat_210081(player):
    player.playerChat("Hello, I'm looking for a secret map.", "Do you know where I can get it?")
    player.nextChat(210082)
    
def chat_210082(player):
    player.npcChat("Aye matey! It's the legendary " + str(player.playerName) + " !")
    player.nextChat(210083)
    
def chat_210083(player):
    player.playerChat("How did you know my name? That's besides the point...", "Do you know where I can find the secret map?")
    player.nextChat(210084)
    
def chat_210084(player):
    player.boxMessage("The Captain shows you the secret map.", "He quickly puts it away.")
    player.nextChat(210085)
    
def chat_210085(player):
    player.playerChat("Yes! What could I do for you in exchange", "for that map?")
    player.nextChat(210086)
    
def chat_210086(player):
    player.npcChat("I can't be bothered to find it anyways.", "Here, take it.")
    player.nextChat(210087)
    
def chat_210087(player):
    if player.hasInventorySpace(1):
        player.addItem(secret_way_map_item)
        player.getQuest(7).setStage(13)
        player.refreshQuestTab()
        player.boxMessage("The Captain gives you the secret map.", "You feel relieved you don't need to do another favour.")
        player.nextChat(210088)
    else:
        player.boxMessage("It looks like I don't have enough inventory space for this secret map.")
        player.endChat()
    
def chat_210088(player):
    player.playerChat("Thank you!")
    player.nextChat(210089)
    
def chat_210089(player):
    player.npcChat("If you find the treasure, use it wisely.")
    player.nextChat(210090)
    
def chat_210090(player):
    player.playerChat("Oh it's not for me, it's for Peer the Seer.")
    player.nextChat(210091)
    
def chat_210091(player):
    player.npcChat("I hope he doesn't die trying to find it.", "Ha-ha!")
    player.nextChat(210092)
    
def chat_210092(player):
    player.boxMessage("You're a bit confused, but decide to walk away.")
    player.endChat()
    
def chat_210093(player):
    player.playerChat("I have your map!")
    player.nextChat(210094)
    
def chat_210094(player):
    if player.hasItem(secret_way_map_item):
        player.deleteItem(secret_way_map_item)
        player.getQuest(7).setStage(14)
        player.refreshQuestTab()
        player.boxMessage("You hand the map to Peer the Seer.", "Peer the Seer inspects the map.", "Talk to him again.")
        player.endChat()
    else:
        player.playerChat("I forgot the map. I'll be back soon.")
        player.endChat()
    
def chat_210095(player):
    player.npcChat("The legend is true! The map does exist!")
    player.nextChat(210096)
    
def chat_210096(player):
    player.playerChat("Wait, wait...you weren't sure if the legend was true?", "What if I went through all this trouble", "and the map never existed?")
    player.nextChat(210097)
    
def chat_210097(player):
    player.npcChat("That's why it's called a legend, right? Ha-ha!")
    player.nextChat(210098)
    
def chat_210098(player):
    player.playerChat("...")
    player.nextChat(210100)
    
def chat_210100(player):
    player.npcChat("Oh, hush. Here's your reward.", "Thank you for your help!")
    player.nextChat(210101)
    
def chat_210101(player):
    player.endChat()
    player.getQuest(7).setStage(15)
    player.refreshQuestTab()
    player.addCash(5000000)
    player.addPoints(100)
    player.qp += 4
    reward = QuestReward("5,000,000 coins", "100 OXP", "5 Quest Points")
    player.completeQuest("One Small Favour", reward, 6546)
    
def chat_210102(player):
    player.npcChat("This treasure is soon to be mine!")
    player.nextChat(210103)
    
def chat_210103(player):
    player.playerChat("Can I see your plans?")
    player.nextChat(210104)
    
def chat_210104(player):
    player.npcChat("No! Get lost!", "If I need your help again you'll know about it.")
    player.nextChat(210105)
    
def chat_210105(player):
    player.npcChat("Ok, then.")
    player.endChat()