#Saving Souls
#Author Ferret
#Quest Length = Medium

#NPCs
troll_id = 1106
aeonisig_raispher_id = 4710
wounded_soldier_id = 1069
lost_soldier_id = 1063
sergeant_id = 1061
boy_id = 895
troll_general_id = 1115

#Items
big_bones = 532

#Quest configuration
def configure_quest_6():
    quest_id = 6
    quest_name = 'Saving Souls'
    quest_stages = 10
    World.addQuest(quest_id, quest_name, quest_stages)
    World.addNonCombatNpc(boy_id, 3080, 3256, 0, 1)
    World.addNonCombatNpc(aeonisig_raispher_id, 2896, 3528, 0, 1)
    World.addNonCombatNpc(wounded_soldier_id, 2872, 3583, 0, 0)
    World.addNonCombatNpc(lost_soldier_id, 2964, 3871, 0, 1)
    World.addNonCombatNpc(sergeant_id, 2886, 3540, 0, 1)
    World.addCombatNpc(troll_id, 2870, 3595, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2879, 3586, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2867, 3589, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2859, 3593, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2868, 3593, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2855, 3597, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_id, 2857, 3589, 0, 1, 100, 10, 100, 150)
    World.addCombatNpc(troll_general_id, 2860, 3592, 0, 1, 300, 30, 250, 250)

#Quest button
def quest_button_6(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 0:
       player.getFunction().startInfo("Saving Souls", "I can start this quest by talking to the @dre@Boy@bla@ in Draynor Market.", "", "", "")
    elif quest_stage == 1:
        player.boxMessage("I should speak to @dre@Aeonisig Raispher@bla@, located somewhere in Burthope.")
    elif quest_stage == 2:
        player.boxMessage("@dre@Aeonisig Raispher@bla@ told me the trolls are to the north.", "Better teach those ugly beasts a few lessons.")
    elif quest_stage == 3:
        player.boxMessage("The trolls will no longer hurt me.", "I should speak to the wounded soldier.")
    elif quest_stage == 4:
        player.boxMessage("I should speak to @dre@Aeonisig Raispher@bla@ so that he can call help.")
    elif quest_stage == 5:
        player.boxMessage("I need to find the recruit that is lost near an icy, dangerous area.")
    elif quest_stage == 6:
        player.boxMessage("I need to defeat the @dre@Troll General@bla@ and bring back some bones.")
    elif quest_stage == 7:
        player.boxMessage("The lost soldier is looking for some @dre@Troll Bones@bla@.")
    elif quest_stage == 8:
        player.boxMessage("I should speak to the @dre@Sergeant@bla@ in the tent.")
    elif quest_stage == 9:
        player.boxMessage("I should speak to @dre@Aeonisig Raispher@bla@.")
    elif quest_stage == 10:
        player.boxMessage("I have completed the @dre@Saving Souls@bla@ quest.")

#Boy    
def first_click_npc_895(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 0:
        player.startChat(200000)
    else:
        player.playerChat("The boy is distracted spreading the current news.")

#Aeonisig Raispher
def first_click_npc_4710(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 1:
        player.startChat(200013)
    elif quest_stage == 4:
        player.startChat(200025)
    elif quest_stage == 9:
        player.startChat(200055)
    elif quest_stage == 10:
        player.startChat(200061)
    else:
        player.playerChat("He's busy and has no time to speak.")
        player.endChat()

#Wounded Soldier    
def first_click_npc_1069(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 3:
        player.startChat(200023)
    else:
        player.playerChat("The soldier is in too much pain to speak.")
        player.endChat()

#Lost Soldier
def first_click_npc_1063(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 5:
        player.startChat(200031)
    elif quest_stage == 7:
        player.startChat(200041)
    else:
        player.boxMessage("You watch the lost soldier inspect the area.")
        player.endChat()

#Sergeant
def first_click_npc_1061(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 8:
        player.startChat(200046)
    else:
        player.boxMessage("The Sergeant looks very busy, I better not disturb him.")
        player.endChat()

#Troll Killing
def kill_npc_1106(player):
    if player.hasAttribute("troll_kills"):
        handle_troll_kill(player)
    else:
        player.addAttribute("troll_kills", 1)
        
def handle_troll_kill(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 2 and player.getAttribute("troll_kills") > 4:
        player.boxMessage("The trolls are scared and will leave you alone.")
        player.sendMessage("The trolls are scared and will leave you alone.")
        player.getQuest(6).setStage(3)
        player.refreshQuestTab()
    else:
        player.addAttribute("troll_kills", player.getAttribute("troll_kills") + 1)
    
#Troll General Killing
def kill_npc_1115(player):
    quest_stage = player.getQuest(6).getStage()
    if quest_stage == 6:
        player.getQuest(6).setStage(7)
        player.boxMessage("I should return to the lost soldier with these Troll bones.")

#Chat dialogues    
def chat_200000(player):
    player.npcChat("News, news! Get your news here!")
    player.nextChat(200001)
    
def chat_200001(player):
    player.playerChat("What's going on?")
    player.nextChat(200002)
    
def chat_200002(player):
    player.npcChat("There's a wounded soldier that needs saving", "but nobody is brave enough because of the trolls!")
    player.nextChat(200003)
    
def chat_200003(player):
    player.playerChat("Is there a reward if one saves this soldier?")
    player.nextChat(200004)

def chat_200004(player):
    player.npcChat("I heard there is a huge reward!", "Are you offering to help?")
    player.nextChat(200005)
    
def chat_200005(player):
    player.dialogueOption("Offer to help", 200006, "Decline to help", 200012)
    
def chat_200006(player):
    player.getQuest(6).setStage(1)
    player.refreshQuestTab()
    player.playerChat("Perhaps. Say if I want to help, who would I speak to?")
    player.nextChat(200007)
    
def chat_200012(player):
    player.playerChat("No, I'm just curious. Thank you, though.")
    player.endChat()

def chat_200007(player):
    player.boxMessage("The boy looks distracted by others passing by.")
    player.nextChat(200008)
    
def chat_200008(player):
    player.playerChat("Boy! Who can give me more information about this?")
    player.nextChat(200009)

def chat_200009(player):
    player.npcChat("I heard Aeonisig Raispher can tell you more about it.", "He's somewhere in the city of Burthope.")
    player.nextChat(200010)

def chat_200010(player):
    player.playerChat("Thank you.")
    player.endChat()
    
def chat_200013(player):
    player.playerChat("Are you Aeonisig Raispher?")
    player.nextChat(200014)

def chat_200014(player):
    player.npcChat("Yes, and I assume you're " + str(player.playerName) + "?")
    player.nextChat(200015)
    
def chat_200015(player):
    player.playerChat("How do you know who I am?")
    player.nextChat(200016)

def chat_200016(player):
    player.npcChat("It's all over the news. " + str(player.playerName) + " out to save", "the wounded soldier!", "And I assume you're here to talk to me about this quest?")
    player.nextChat(200017)
    
def chat_200017(player):
    player.playerChat("Indeed. What do I need to do to resue him?")
    player.nextChat(200018)
    
def chat_200018(player):
    player.getQuest(6).setStage(2)
    player.refreshQuestTab()
    player.npcChat("One of our soldiers are wounded, held hostage north of here", "by the trolls that surround the area.", "It's up to you to save him.")
    player.nextChat(200019)
    
def chat_200019(player):
    player.npcChat("Big rewards will be given!", "But be warned, this is a dangerous task.", "Nobody dares to go near the trolls!")
    player.nextChat(200020)
	
def chat_200020(player):
    player.npcChat("We're counting on you.")
    player.nextChat(200021)	
    
def chat_200021(player):
    player.playerChat("It's a good thing I've arrived!")
    player.nextChat(200022)
    
def chat_200022(player):
    player.npcChat("Fantastic! Good luck, adventurer!")
    player.endChat()
    
def chat_200023(player):
    player.npcChat("GET ME OUT OF HERE! GET ME OUT!")
    player.nextChat(200024)

def chat_200024(player):
    player.getQuest(6).setStage(4)
    player.refreshQuestTab()
    player.playerChat("The trolls aren't going to hurt you anymore.", "I'm going to tell Aeonisig Raispherhelp so", "that he can call help. Stay strong!")
    player.endChat()
    
def chat_200025(player):
    player.playerChat("I've scared the trolls and the wounded soldier needs help!")
    player.nextChat(200026)

def chat_200026(player):
    player.getQuest(6).setStage(5)
    player.refreshQuestTab()
    player.npcChat("Great news! Help will be on the way.", "However, there is one more thing...")
    player.nextChat(200027)
    
def chat_200027(player):
    player.playerChat("*sigh* Yes?")
    player.nextChat(200028)

def chat_200028(player):
    player.npcChat("One of our recruits lost his way near an icy area", "deep in the wilderness. Would you be so kind to ", "find him and give him directions?")
    player.nextChat(200029)
    
def chat_200029(player):
    player.playerChat("I'd be happy to help.")
    player.nextChat(200030)

def chat_200030(player):
    player.npcChat("Thank you! Your actions are greatly appreciated!")
    player.endChat()
    
def chat_200031(player):
    player.playerChat("Are you the recruit that's lost? Your superior sent me.")
    player.nextChat(200032)

def chat_200032(player):
    player.npcChat("At last! How do I get out of here?")
    player.nextChat(200033)
    
def chat_200033(player):
    player.playerChat("Walk all the way South and you'll exit the Wilderness.", "Try not to get lost again.")
    player.nextChat(200034)

def chat_200034(player):
    player.getQuest(6).setStage(6)
    player.npcChat("Thank you, adventurer!", "Say, you wouldn't mind helping me? It's a small task.")
    player.nextChat(200035)

def chat_200035(player):
    player.playerChat("What is it?")
    player.nextChat(200036)

def chat_200036(player):
    player.npcChat("Can you kill the Troll General for me and bring back", "its bones?")
    player.nextChat(200037)

def chat_200037(player):
    player.playerChat("Why?")
    player.nextChat(200038)

def chat_200038(player):
    player.npcChat("Perhaps my superior won't think of me as such a failure...")
    player.nextChat(200039)

def chat_200039(player):
    player.playerChat("Why do I have to be so nice...?")
    player.nextChat(200040)

def chat_200040(player):
    player.npcChat("Thank you!")
    player.endChat()

def chat_200041(player):
    player.playerChat("Here are the items you wanted.")
    player.nextChat(200042)

def chat_200042(player):
    if player.hasItem(532):
        player.deleteItem(532)
        player.getQuest(6).setStage(8)
        player.refreshQuestTab()
        player.boxMessage("You give the bones to the soldier.")
        player.nextChat(200043)
    else:
        player.boxMessage("You need to bring the soldier @dre@Big Bones@bla@.")
        player.endChat()
    
def chat_200043(player):
    player.npcChat("You truely are a hero. Thank you for everything.", "I'll be leaving shortly, please inform the seargent.")
    player.nextChat(200044)
    
def chat_200044(player):
    player.boxMessage("You watch the soldier take more notes of the area.")
    player.nextChat(200045)

def chat_200045(player):
    player.playerChat("Well errr, I'll see you around...")
    player.endChat()
    
def chat_200046(player):
    player.npcChat("Halt! Who goes there?")
    player.nextChat(200047)

def chat_200047(player):
    player.playerChat("Hello, my name is " + str(player.playerName) + ".")
    player.nextChat(200048)
    
def chat_200048(player):
    player.npcChat("Ah " + str(player.playerName) + "! Thank you for bringing our recruit back.", "He's not the brightest one around here you know.")
    player.nextChat(200049)

def chat_200049(player):
    player.playerChat("He may not be the brightest but he did kill the", "Troll General!")
    player.nextChat(200050)

def chat_200050(player):
    player.npcChat("HA! Those bones he gave me?", "I'm sure someone killed it for him.")
    player.nextChat(200051)

def chat_200051(player):
    player.playerChat("No sir, I saw him. He killed the mighty beast", "right before my eyes!")
    player.nextChat(200052)

def chat_200052(player):
    player.npcChat("I...I can't believe this! I CAN'T BELIEVE THIS!", "I'm quite impressed! Thank you for everything,")
    player.nextChat(200053)

def chat_200053(player):
    player.boxMessage("The recruit overhears your conversation and is overjoyed.")
    player.nextChat(200054)

def chat_200054(player):
    player.getQuest(6).setStage(9)
    player.refreshQuestTab()
    player.npcChat("Anyway, you should inform Aeonisig Raispher of", "the good news.")
    player.endChat()
    
def chat_200055(player):
    player.playerChat("I was told to speak to you.", "When can I get my reward?")
    player.nextChat(200056)
    
def chat_200056(player):
    player.npcChat("Be patient, please. I heard what you did!", "A great job, " + str(player.playerName) + "!")
    player.nextChat(200057)

def chat_200057(player):
    player.playerChat("Thank you, I try my best.")
    player.nextChat(200058)
    
def chat_200058(player):
    player.npcChat("For your help, I now grant you your reward.", "By the way, you're all over the news.")
    player.nextChat(200059)

def chat_200059(player):
    player.playerChat("Really? Fantastic!")
    player.nextChat(200060)
    
def chat_200060(player):
    player.endChat()
    player.getQuest(6).setStage(10)
    player.refreshQuestTab()
    player.addCash(25000000)
    player.addPoints(100)
    player.addItem(10586)
    reward = QuestReward("25,000,000 coins", "100 OXP","A combat lamp", "1 Quest Point")
    player.completeQuest("Saving Souls", reward, 532)

def chat_200061(player):
    player.npcChat("You're a brave adventurer, and a hero!")
    player.nextChat(200062)

def chat_200062(player):
    player.playerChat("You're too kind, thank you.")
    player.endChat()