from com.ownxile.core import World

equp_ex = World.addNonCombatNpc(4874, 3117, 3503, 0, 1)

def first_click_npc_4874(player):
    player.sendMessage("This minigame is currently unavailable.")
def second_click_npc_4874(player):
    player.sendMessage("This minigame is currently unavailable.")
def third_click_npc_4874(player):
    player.sendMessage("This minigame is currently unavailable.")