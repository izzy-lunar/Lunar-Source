                                                                                                                                                                                                                                                                World.addCombatNpc(2359, 2323, 3172, 0, 1, 120, 15, 120,120)#elf warrior guard
World.addCombatNpc(2360, 2330, 3171, 0, 1, 120, 15, 120,120)#elf warrior guard
World.addCombatNpc(2361, 2331, 3164, 0, 1, 120, 15, 120,120)#elf archer guard
World.addCombatNpc(2360, 2323, 3184, 0, 1, 120, 15, 120,120)#elf archer guard
World.addCombatNpc(2361, 2340, 3164, 0, 1, 120, 15, 120,120)#elf archer guard
World.addNonCombatNpc(2367, 2348, 3186, 0, 1)#Kelyn the citizen
World.addNonCombatNpc(2364, 2322, 3190, 0, 1)#Ysgawyn the citizen
World.addNonCombatNpc(2363, 2349, 3157, 0, 1)#Goreu the citizen
World.addNonCombatNpc(2365, 2346, 3176, 0, 1)#Arvel the citizen
World.addNonCombatNpc(2368, 2340, 3170, 0, 1)#Eoin the child
World.addNonCombatNpc(2369, 2334, 3172, 0, 1)#Iona the child
World.addNonCombatNpc(2352, 2337, 3183, 0, 1)#Eudav the general store
World.addNonCombatNpc(2353, 2326, 3177, 0, 1)#Orowens clothing store
World.addNonCombatNpc(2356, 2323, 3164, 0, 1)#Daladav ranging store
World.addNonCombatNpc(2357, 2340, 3157, 1, 1)#Gethins food store
World.addNonCombatNpc(157, 2341, 3172, 0, 1)#butterfly
World.addNonCombatNpc(156, 2335, 3174, 0, 1)#butterfly
World.addNonCombatNpc(155, 2346, 3169, 0, 1)#butterfly
World.addNonCombatNpc(157, 2343, 3178, 0, 1)#butterfly
World.addNonCombatNpc(154, 2346, 3180, 0, 1)#butterfly
World.addNonCombatNpc(155, 2324, 3184, 0, 1)#butterfly
World.addNonCombatNpc(156, 2320, 3191, 0, 1)#butterfly
World.addNonCombatNpc(157, 2325, 3189, 0, 1)#butterfly
World.addNonCombatNpc(153, 2329, 3163, 0, 1)#butterfly
World.addNonCombatNpc(157, 2341, 3172, 0, 1)#butterfly
World.addNonCombatNpc(2354, 2352, 3166, 0, 0)#Banker
World.addNonCombatNpc(2355, 2350, 3166, 0, 0)#Banker

#Kelyn

def first_click_npc_2367(player):
    player.startChat(1100000000)
    
def chat_1100000000(player):
    player.npcChat("In @blu@Seren the Elven God@bla@ we trust!")
    player.endChat()
	
#Ysgawyn

def first_click_npc_2364(player):
    player.startChat(1100000000)
    
#Goreu

def first_click_npc_2363(player):
    player.startChat(392629156)
	
def chat_392629156(player):
    player.playerChat("Hello there.", "Hmm...why are you so oddly familiar?")
    player.nextChat(392629157)

def chat_392629157(player):
    player.npcChat("Hello, Adventurer")
    player.nextChat(392629158)

def chat_392629158(player):
    player.npcChat("Would you like to purchase a gnome scarf?", "They are limited!", "Only @grd@100m@bla@!")
    player.nextChat(392629159)

def chat_392629159(player):
    player.dialogueOption("Sure.", 392629160, "I don't have the funds.", 392629162)
    player.nextChat(392629160)
    
def chat_392629160(player):
    if player.hasItem(995, 100000000):
        player.playerChat("Sounds reasonable, thanks!")
        player.deleteItem(995, 100000000)
        player.nextChat(392629161)
    else:
        player.playerChat("Ah I didn't bring enough money with me.", "Fuck me.")
        player.endChat()
        
def chat_392629161(player):
    player.npcChat("You purchase the gnome scarf for 100m")
    player.addItem(9470)
    player.endChat()
    
def chat_392629162(player):
    player.npcChat("Ha-ha, silly cosmetics.")
    player.endChat()
    
#Arvel


def first_click_npc_2365(player):
    player.startChat(1110000000)
    
def chat_1110000000(player):
    player.npcChat("Save your @dre@Keys to my Beamer@bla@.", "You'll need them in @grd@December@bla@.")
    player.endChat()

#Eoin

def first_click_npc_2368(player):
    player.startChat(1100000004)
    	
def chat_1100000004(player):
    player.npcChat("Would you like to teleport to the @dre@Elf Camp@bla@?")
    player.nextChat(1100000005)
	
def chat_1100000005(player):
    player.dialogueOption("Yes", 1100000006, "No", 1100000007)
    
def chat_1100000006(player):#elf camp
    player.getTask().movePlayer(2197, 3252, 0)
    
def chat_1100000007(player):#no elf camp
    player.playerChat("No.")
    player.endChat()
    
#Iona

def first_click_npc_2369(player):
    player.npcChat("Would you like to reset your defence?")
    player.nextChat(1100002200)
    
def chat_1100002200(player):
    player.dialogueQuestion("Reset?", "Yes reset my defence level to 1.", 1100002201, "No thanks.", 1100001103)

def chat_1100002201(player):
    if player.isWieldingItems():
        player.boxMessage("You must not be wielding any items to do this.")
        player.endChat()
    else:
        player.getFunction().resetLevel(1)
        player.boxMessage("You have reset your defence level to 1.")
        player.endChat()
    
#Eudav general 

def first_click_npc_2352(player):
    player.getShop().openShop(1)
    
def second_click_npc_2352(player):
    player.getShop().openShop(1)
    
#Orowens clothing store
def first_click_npc_2353(player):
    player.getShop().openShop(50)
  
def second_click_npc_2353(player):
    player.getShop().openShop(50)
    
#Daladav ranging store
    
def first_click_npc_2356(player):
    player.getShop().openShop(60)
  
def second_click_npc_2356(player):
    player.getShop().openShop(60)
    
#Gethins food store
    
def first_click_npc_2357(player): 
    player.startChat(1100000100)
	
def chat_1100000100(player):
    player.npcChat("Psst. Want to buy some sea turtles?", "I stole them from the @dre@elf fisherman@bla@", "They're 100k each and you can buy 100 at a time.")
    player.nextChat(1100000101)
 
def chat_1100000101(player):
    player.dialogueOption("Buy 100 sea turtles for 10m", 1100000102 , "No", 1100000103)
	
def chat_1100000102(player):
    if player.hasItem(995, 10000000):
        player.deleteItem(995, 10000000)
        player.addItem(398, 100)
    else:
        player.boxMessage("You do not have @grd@10M@bla@.")
        
def chat_1100000103(player):
    player.npcChat("Reported for robbing an npc.")
    player.endChat()
	
def second_click_npc_2357(player): 
    player.startChat(1100000100)
    
#Banker
def first_click_npc_2354(player): 
    player.startChat(1100001100)
    
def chat_1100001100(player):
    player.npcChat("Would you like to use the bank of @dre@Lletya@bla@?")
    player.nextChat(1100001101)
    
def chat_1100001101(player):
    player.dialogueOption("Yes", 1100001102 , "No", 1100001103)
    
def chat_1100001102(player):
    player.getFunction().openUpBank()
    
def chat_1100001103(player):
    player.playerChat("No thanks, elf.")
    player.endChat()
    
def second_click_npc_2354(player): 
    player.getFunction().openUpBank()
    
#Banker
def first_click_npc_2355(player): 
    player.startChat(1100001200)
    
def chat_1100001200(player):
    player.npcChat("Would you like to use the bank of @dre@Lletya@bla@?")
    player.nextChat(1100001201)
    
def chat_1100001201(player):
    player.dialogueOption("Yes", 1100001202 , "No", 1100001203)
    
def chat_1100001202(player):
    player.getFunction().openUpBank()
    
def chat_1100001203(player):
    player.playerChat("No thanks, elf.")
    player.endChat()
    
def second_click_npc_2355(player): 
    player.getFunction().openUpBank()
	
                            
                            
                            
                            
                            
                            
                            