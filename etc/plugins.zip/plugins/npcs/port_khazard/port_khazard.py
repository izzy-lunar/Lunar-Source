##################################
###       Author: Kennedy      ###
###       Date:12.11.2013      ###
##################################

World.addNonCombatNpc(522, 2657, 3153, 0, 4)
World.addNonCombatNpc(581, 2653, 3164, 0, 1)
World.addNonCombatNpc(463, 2667, 3162, 0, 1)
World.addNonCombatNpc(1799, 2678, 3151, 0, 1)
World.addNonCombatNpc(522, 2641, 3173, 0, 1)
World.addCombatNpc(1, 2632, 3173, 0, 1, 10, 2, 1,1)
World.addCombatNpc(3, 2635, 3163, 0, 1, 10, 2, 1,1)

def first_click_npc_463(player):
    player.startChat(1677965612)

def chat_1677965612(player):
    player.boxMessage("The Fishing Trawler minigame has been temporarly disabled.")
    player.endChat()

w_wep_shop = Shop("Tindel's Weapon Store", 8058)
w_wep_shop.addItem(ShopItem(1333, 1))
w_wep_shop.addItem(ShopItem(1319, 1))
w_wep_shop.addItem(ShopItem(1215, 1))
w_wep_shop.addItem(ShopItem(5698, 1))
w_wep_shop.addItem(ShopItem(4587, 1))
w_wep_shop.addItem(ShopItem(1305, 1))
w_wep_shop.addItem(ShopItem(1434, 1))

def first_click_npc_1799(player):
    player.startChat(180648813)

def second_click_npc_1799(player):
    player.getShop().openShop(8058)
    
def chat_180648813(player):
    player.npcChat("Hello there " + str(player.playerName) + ", would you like", "to purchase some fine weapons?")
    player.nextChat(180648814)

def chat_180648814(player):
    player.playerChat("Perhaps, show me what you have for sale.")
    player.nextChat(180648815)

def chat_180648815(player):
    player.getShop().openShop(8058)