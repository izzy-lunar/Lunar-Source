# Catherby fishing shop
# Harry = 576
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

#wat
World.addNonCombatNpc(576, 2835, 3446, 0, 1)
World.addNonCombatNpc(3021, 2859, 3434, 0, 1)

#Men
World.addCombatNpc(1, 2816, 3451, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 2825, 3451, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(3, 2807, 3453, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 2819, 3452, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(5, 2824, 3449, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(4, 2806, 3450, 0, 1, 10, 2, 1, 1)

CathyFishing_shop = Shop("Fishery", 338)
CathyFishing_shop.addItem(ShopItem(303, 10))
CathyFishing_shop.addItem(ShopItem(311, 10))
CathyFishing_shop.addItem(ShopItem(301, 10))
CathyFishing_shop.addItem(ShopItem(309, 10))
CathyFishing_shop.addItem(ShopItem(307, 10))
CathyFishing_shop.addItem(ShopItem(305, 10))
CathyFishing_shop.addItem(ShopItem(313, 100000))
CathyFishing_shop.addItem(ShopItem(314, 100000))

def second_click_npc_576(player):
    player.getShop().openShop(338)
    
def first_click_npc_576(player):
    player.startChat(278915)
    
def chat_278915(player):
    player.npcChat("Welcome to my fishery,", "Would you like to buy anything?")
    player.nextChat(278916)
    
def chat_278916(player):
    player.dialogueOption("Sure, I'll have a look.", 278917, "No thanks.", 278918)
    
def chat_278917(player):
    player.getShop().openShop(338)
    
def chat_278918(player):
    player.playerChat("No thanks.")
    player.endChat()