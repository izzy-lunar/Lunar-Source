# NPC Config Script
# Candle Maker - 562
# Author Badger and Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

Candle = Shop("Candle shop", 976)
 
Candle.addItem(ShopItem(32, 50))
Candle.addItem(ShopItem(33, 50))

World.addNonCombatNpc(562, 2800, 3439, 0, 1)

def second_click_npc_562(player):
	player.getShop().openShop(976)
	
def first_click_npc_562(player):
	player.startChat(830000)
	
def chat_830000(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(830001)
	
def chat_830001(player):
	player.npcChat("Hey, " + str(player.playerName) + ", would you like to buy any candles?")
	player.nextChat(830002)
	
def chat_830002(player):
	player.dialogueOption("Sure.", 830003, "No thank you.", 830004)
	
def chat_830003(player):
	player.getShop().openShop(976)
	
def chat_830004(player):
	player.playerChat("No thank you.")
	player.nextChat(830005)
	
def chat_830005(player):
	player.npcChat("Looks like I'll be seeing you around, goodbye.")
	player.endChat()	
