# Author Parrot
from com.ownxile.core import World
from com.ownxile.rs2.world.transport import KaramjaCart

#Pierre
World.addNonCombatNpc(807, 2804, 3422, 0, 2)

def first_click_object_69(player):
    player.lastClickedNpcId = 807
    player.startChat(2013003)
    
def first_click_npc_807(player):
    player.startChat(2013000)

def chat_2013000(player):
    player.npcChat("Ahoy matey! Do you want to go to Port Phasmatys?")
    player.nextChat(2013001)    
    
def chat_2013001(player):
    player.dialogueOption("Yes please, lets go!", 2013002, "No thank you.", 2013013, "Tell me a little about yourself.", 2013014)

def chat_2013013(player):
    player.playerChat("No thank you.")
    player.endChat()        
    
def chat_2013002(player):
    player.playerChat("Yes please, lets go!")
    player.nextChat(2013003)
    
def chat_2013003(player):
    player.npcChat("Woah! Slow down there matey.", "You ain't getting on my ship for nothing.")
    player.nextChat(2013004)    
    
def chat_2013004(player):
    player.playerChat("What do you want then?")
    player.nextChat(2013005)    
    
def chat_2013005(player):
    player.npcChat("A bottle of rum!")
    player.nextChat(2013006)      
    
def chat_2013006(player):
    player.playerChat("Sorry, I won't be able to get you that.", "How about some money?")
    player.nextChat(2013007)      
    
def chat_2013007(player):
    player.npcChat("Okay then, 5,000 coins matey!")
    player.nextChat(2013008)      
    
def chat_2013008(player):
    player.dialogueOption("Pay 5,000 coins", 2013009, "Leave", 2013011)    
    
def chat_2013009(player):
    if player.hasItem(995, 5000):
        player.deleteItem(995, 5000)
        player.playerChat("Here you go.")
        player.nextChat(2013012)       
    else:    
        player.playerChat("Sorry, I don't have 5,000 coins on me at the moment.")
        player.nextChat(2013010)    
        
def chat_2013010(player):
    player.npcChat("Argh, maybe come back later!")
    player.endChat()            
    
def chat_2013011(player):
    player.playerChat("Nevermind.")
    player.endChat()    

def chat_2013012(player):
    player.endChat()
    KaramjaCart.travel(player, 3709, 3496)
    
def chat_2013014(player):
    player.playerChat("Tell me a little about yourself.")
    player.nextChat(2013015)       

def chat_2013015(player):
    player.npcChat("Aye, I love my boat, that's about it.")
    player.nextChat(2013016)  

def chat_2013016(player):
    player.playerChat("Sounds interesting...")
    player.endChat()