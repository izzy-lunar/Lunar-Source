# Catherby / Seers Village NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Men & Women
World.addCombatNpc(1, 2713, 3471, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2701, 3471, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2712, 3493, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(4, 2707, 3492, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2764, 3507, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2758, 3515, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2751, 3507, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2818, 3440, 0, 1, 10, 2, 2, 2)

# Rats
World.addCombatNpc(47, 2752, 3486, 0, 0, 1, 1, 1, 1)
World.addCombatNpc(47, 2764, 3486, 0, 0, 1, 1, 1, 1)

# General store
World.addNonCombatNpc(522, 2803, 3430, 0, 1)

# Bank
World.addNonCombatNpc(494, 2721, 3495, 0, 0)
World.addNonCombatNpc(494, 2722, 3495, 0, 0)
World.addNonCombatNpc(494, 2724, 3495, 0, 0)
World.addNonCombatNpc(494, 2727, 3495, 0, 0)
World.addNonCombatNpc(494, 2728, 3495, 0, 0)
World.addNonCombatNpc(494, 2729, 3495, 0, 0)
World.addNonCombatNpc(494, 2807, 3443, 0, 0)
World.addNonCombatNpc(494, 2809, 3443, 0, 0)
World.addNonCombatNpc(494, 2810, 3443, 0, 0)
World.addNonCombatNpc(494, 2811, 3443, 0, 0)

# Bees
World.addNonCombatNpc(411, 2757, 3445, 0, 0)
World.addNonCombatNpc(411, 2760, 3441, 0, 0)
World.addNonCombatNpc(411, 2764, 3446, 0, 0)

# Lowe
World.addNonCombatNpc(550, 2825, 3444, 0, 1)

#Fishing spots
World.addNonCombatNpc(312, 2836, 3431, 0, 0)
World.addNonCombatNpc(313, 2836, 3431, 0, 0)
World.addNonCombatNpc(312, 2838, 3431, 0, 0)
World.addNonCombatNpc(309, 2844, 3429, 0, 0)
World.addNonCombatNpc(312, 2844, 3429, 0, 0)
World.addNonCombatNpc(316, 2853, 3423, 0, 0)
World.addNonCombatNpc(312, 2853, 3423, 0, 0)
World.addNonCombatNpc(309, 2860, 3426, 0, 0)