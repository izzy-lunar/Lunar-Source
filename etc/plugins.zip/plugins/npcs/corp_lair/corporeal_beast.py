from com.ownxile.core import World

World.addCombatNpc(5422, 2915, 3612, 0, 1, 2000, 80, 750, 400)