# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addCombatNpc(1087, 2925, 3535, 0, 1, 10, 2, 1, 1)

def first_click_npc_1087(player):
	player.startChat(249995160)