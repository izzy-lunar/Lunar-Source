# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

World.addNonCombatNpc(1080, 2902, 3564, 1, 1)

def first_click_npc_1080(player):
    player.startChat(332000)

def chat_332000(player):
    player.npcChat("What are you doing up here?!")
    player.nextChat(332001)      
    
def chat_332001(player):
    player.dialogueOption("I'm exploring!", 332002, "I was looking for you.", 332003, "Nevermind.", 332006)
    
def chat_332002(player):
    player.playerChat("I'm exploring!")
    player.nextChat(332004)    
    
def chat_332003(player):
    player.playerChat("I was looking for you.")
    player.nextChat(332007)
    
# Option 1: "I'm exploring!"

def chat_332004(player):
    player.npcChat("Can you explore somewhere else?", "It's private up here.")
    player.nextChat(332005)

def chat_332005(player):
    player.playerChat("Okay...")
    player.nextChat(332001)      

# Option 2: "I was looking for you."

def chat_332007(player):
    player.npcChat("How can I help you?")
    player.nextChat(332008)

def chat_332008(player):
    player.dialogueOption("What is this place?", 332009, "Have you got any tasks for me?", 332012, "Nevermind.", 332006)    
    
# Option 3 & 6: "Nevermind."

def chat_332006(player):
    player.playerChat("Nevermind.")
    player.endChat()         

# Option 4: "What is this place?"

def chat_332009(player):
    player.playerChat("What is this place?")
    player.nextChat(332010)
    
def chat_332010(player):
    player.npcChat("This the Burthorpe castle. It's private up here.", "I'd appreciate it if you were to leave.")
    player.nextChat(332011) 

def chat_332011(player):
    player.playerChat("Okay then...")
    player.nextChat(332008)   

# Option 4: "Have you got any tasks for me?"

def chat_332012(player):
    player.playerChat("Have you got any tasks for me?")
    player.nextChat(332013)    

def chat_332013(player):
    player.npcChat("Not at the moment. If you come back another time,", "then I may have some tasks for you.")
    player.nextChat(332014)   

def chat_332014(player):
    player.playerChat("Okay, thanks!")
    player.nextChat(332008)     