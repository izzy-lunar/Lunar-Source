# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

World.addNonCombatNpc(1079, 2906, 3537, 0, 2)

def first_click_npc_1079(player):
    player.startChat(332040)
    
def second_click_npc_1079(player):
    player.getShop().openShop(455)    

def chat_332040(player):
    player.npcChat("Hi there, how can I help you?")
    player.nextChat(332041)      
    
def chat_332041(player):
    player.dialogueOption("What drinks do you serve?", 332042, "Nevermind.", 332006)
    
def chat_332042(player):
    player.playerChat("What drinks do you serve?")
    player.nextChat(332043)    
    
# Option 1: "What drinks do you serve?"

def chat_332043(player):
    player.npcChat("I can offer a large variety! Take a look...")
    player.nextChat(332044)

def chat_332044(player):
    player.endChat()
    player.getShop().openShop(455)