# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addCombatNpc(1073, 2900, 3549, 0, 0, 10, 2, 1, 1)
World.addCombatNpc(1073, 2897, 3549, 0, 0, 10, 2, 1, 1)

World.addCombatNpc(1073, 2902, 3569, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2905, 3567, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2903, 3558, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2905, 3557, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2892, 3559, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2894, 3558, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2894, 3570, 1, 1, 10, 2, 1, 1)
World.addCombatNpc(1073, 2892, 3568, 1, 1, 10, 2, 1, 1)

def first_click_npc_1073(player):
	player.startChat(249995180)
	
def chat_249995180(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(249995181)
	
def chat_249995181(player):
	player.npcChat("Hi " + str(player.playerName) + ",","I hope you're not getting in to any trouble!")
	player.endChat()