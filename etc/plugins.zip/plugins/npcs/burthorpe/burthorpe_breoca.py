# Author Cam
from com.ownxile.core import World

World.addCombatNpc(1084, 2914, 3547, 0, 1, 10, 2, 1, 1)

def first_click_npc_1084(player):
	player.startChat(249995160)