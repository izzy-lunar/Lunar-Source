# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

World.addNonCombatNpc(796, 2903, 3510, 0, 4)

def first_click_npc_796(player):
    player.startChat(332050)

def chat_332050(player):
    player.boxMessage("Achietties looks busy...")
    player.nextChat(332051)      
    
def chat_332051(player):
    player.dialogueOption("Disturb Achietties", 332052, "Leave", 332053)
    
def chat_332052(player):
    player.playerChat("Hopefully she won't mind.")
    player.nextChat(332054)    
    
def chat_332053(player):
    player.playerChat("I better not disturb Achietties...")
    player.endChat()
    
# Option 1: "I'm exploring!"

def chat_332054(player):
    player.playerChat("Hey, Achietties! Can I come in please?")
    player.nextChat(332055)

def chat_332055(player):
    player.npcChat("No! This is a private area.")
    player.nextChat(332056)   
    
def chat_332056(player):
    player.playerChat("Please?")
    player.nextChat(332057)    
    
def chat_332057(player):
    player.npcChat("You are only permitted to enter if you're a member!")
    player.nextChat(332058)  

def chat_332058(player):
    player.playerChat("How do I become a member?")
    player.nextChat(332059)     
    
def chat_332059(player):
    player.npcChat("I don't have the time to explain it right now.")
    player.nextChat(332060)    

def chat_332060(player):
    player.playerChat("Okay, goodbye.")
    player.endChat()     