# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1090, 2931, 3567, 0, 1)

def first_click_npc_1090(player):
	player.startChat(249995160)