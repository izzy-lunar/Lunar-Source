# Author Cam
from com.ownxile.core import World

World.addCombatNpc(1072, 2893, 3557, 0, 1, 10, 2, 1, 1)

def first_click_npc_1072(player):
	player.startChat(249995150)
	
def chat_249995150(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(249995151)
	
def chat_249995151(player):
	player.npcChat("Hi " + str(player.playerName) + ", I hope you have a pleasant day.")
	player.endChat()