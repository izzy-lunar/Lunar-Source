# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

World.addNonCombatNpc(1086, 2919, 3559, 0, 1)

def first_click_npc_1086(player):
    player.startChat(332070)

def chat_332070(player):
    player.npcChat("What are you doing in my house?!")
    player.nextChat(332071)      
    
def chat_332071(player):
    player.dialogueOption("I'm exploring!", 332072, "I've come to rob you!", 332073, "Nevermind.", 332006)
    
def chat_332072(player):
    player.playerChat("I'm exploring!")
    player.nextChat(332074)    
    
def chat_332073(player):
    player.playerChat("I've come to rob you!")
    player.nextChat(332077)
    
# Option 1: "I'm exploring!"

def chat_332074(player):
    player.npcChat("Can you explore somewhere else?", "My house is private.")
    player.nextChat(332075)

def chat_332075(player):
    player.playerChat("Okay...")
    player.nextChat(332071)      

# Option 2: "I've come to rob you!"

def chat_332077(player):
    player.npcChat("Ahhh!")
    player.nextChat(332071)