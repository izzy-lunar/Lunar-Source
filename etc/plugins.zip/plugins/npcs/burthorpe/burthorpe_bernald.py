# Author Cam
from com.ownxile.core import World

World.addNonCombatNpc(2580, 2918, 3535, 0, 1)

def first_click_npc_2580(player):
	player.startChat(249995390)
	
def chat_249995390(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(249995391)
	
def chat_249995391(player):
	player.npcChat("Not now " + str(player.playerName) + ", my Grapevine is Diseased!")
	player.endChat()