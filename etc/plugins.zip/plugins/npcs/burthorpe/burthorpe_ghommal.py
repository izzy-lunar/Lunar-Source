# Author Parrot
from com.ownxile.core import World

World.addNonCombatNpc(4285, 2879, 3545, 0, 4)

def first_click_npc_4285(player):
    player.startChat(332030)

def chat_332030(player):
    player.npcChat("Hi, how can I help you?")
    player.nextChat(332031)

def chat_332031(player):
    player.dialogueOption("I'm exploring!", 332032, "Am I worthy of being a Warriors Guild member?", 332033, "Nevermind.", 332006)

def chat_332032(player):
    player.playerChat("I'm exploring!")
    player.nextChat(332031)

def chat_332033(player):
    player.playerChat("Am I worthy of being a Warriors Guild member?")
    player.nextChat(332034)

def chat_332034(player):
    strength_level = player.getLevel("strength")
    if strength_level < 70:
        player.startChat(33203544)
    else:
        player.startChat(33203545)

def chat_332035(player):
    player.playerChat("Oh, okay.")
    player.endChat()

def chat_33203544(player):
    player.npcChat("No, you are too weak!")
    player.nextChat(332035)

def chat_33203545(player):
    player.npcChat("Yes you are worthy! However, we aren't currently", "accepting new members, perhaps come back another time.")
    player.nextChat(332035)