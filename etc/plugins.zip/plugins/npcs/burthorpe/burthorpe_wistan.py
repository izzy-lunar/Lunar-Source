# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1083, 2930, 3546, 0, 1)

def second_click_npc_1083(player):
	player.getShop().openShop(92)
	
def first_click_npc_1083(player):
	player.getShop().openShop(92)