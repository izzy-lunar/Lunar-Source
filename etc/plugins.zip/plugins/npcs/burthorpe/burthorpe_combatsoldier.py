# Author Cam
from com.ownxile.core import World

World.addCombatNpc(1065, 2889, 3530, 0, 1, 40, 5, 7, 7)
World.addCombatNpc(1065, 2886, 3536, 0, 1, 40, 5, 7, 7)
World.addCombatNpc(1065, 2882, 3539, 0, 1, 40, 5, 7, 7)
World.addCombatNpc(1065, 2903, 3542, 0, 1, 40, 5, 7, 7)
World.addCombatNpc(1065, 2905, 3539, 0, 1, 40, 5, 7, 7)
World.addCombatNpc(1065, 2901, 3527, 0, 1, 40, 5, 7, 7)

def first_click_npc_1065(player):
	player.startChat(249995190)
	
def chat_249995190(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(249995191)
	
def chat_249995191(player):
	player.npcChat("Semper Fidelis!")
	player.endChat()