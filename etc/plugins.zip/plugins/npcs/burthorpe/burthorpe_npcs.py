# Author Parrot
from com.ownxile.core import World
import random
# npc id, x, y, height, stationary, hp, maxhit, attack, defence

#Sergeant
sergeant_speak = World.addNonCombatNpc(1062, 2893, 3540, 0, 0)

World.addNonCombatNpc(70, 2931, 3536, 0, 3)

#Back Line
World.addNonCombatNpc(1064, 2895, 3536, 0, 4)
World.addNonCombatNpc(1064, 2894, 3536, 0, 4)
World.addNonCombatNpc(1064, 2893, 3536, 0, 4)
World.addNonCombatNpc(1064, 2892, 3536, 0, 4)
World.addNonCombatNpc(1064, 2891, 3536, 0, 4)

#Middle Line
World.addNonCombatNpc(1064, 2895, 3537, 0, 4)
World.addNonCombatNpc(1064, 2894, 3537, 0, 4)
World.addNonCombatNpc(1064, 2893, 3537, 0, 4)
World.addNonCombatNpc(1064, 2892, 3537, 0, 4)
World.addNonCombatNpc(1064, 2891, 3537, 0, 4)

#Front Line
World.addNonCombatNpc(1064, 2895, 3538, 0, 4)
World.addNonCombatNpc(1064, 2894, 3538, 0, 4)
World.addNonCombatNpc(1064, 2893, 3538, 0, 4)
World.addNonCombatNpc(1064, 2892, 3538, 0, 4)
World.addNonCombatNpc(1064, 2891, 3538, 0, 4)

#Around fire
soldier1_speak = World.addNonCombatNpc(1066, 2894, 3532, 0, 2)
soldier2_speak = World.addNonCombatNpc(1067, 2893, 3533, 0, 0)

lt = ["Can't you see I'm training?", "I'm busy, go away!", "I can't talk right now.", "Go away! I'm training."]
sa = random.choice([0,1,2,3])

def first_click_npc_1064(player): 
    player.startChat(332020)

def chat_332020(player):
    player.npcChat(lt[sa])
    player.endChat()
    
def first_click_npc_1062(player): 
    sergeant_speak.forceChat("I have soliders to train, go away!")    
    
def first_click_npc_1066(player): 
    soldier1_speak.forceChat("Isn't this fire lovely and warm?!")    
    
def first_click_npc_1067(player): 
    soldier2_speak.forceChat("Isn't this relaxing?!")    