# Author Cam
from com.ownxile.core import World

World.addCombatNpc(1085, 2929, 3559, 0, 1, 10, 2, 1, 1)

def first_click_npc_1085(player):
	player.startChat(249995160)