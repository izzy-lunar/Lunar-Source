# Author Cam
from com.ownxile.core import World

World.addNonCombatNpc(1082, 2920, 3574, 0, 1)

def first_click_npc_1082(player):
    player.startChat(5870060)
    
def chat_5870060(player):
    player.playerChat("Hello there!")
    player.nextChat(5870061)    
    
def chat_5870061(player):
    player.npcChat("Hello there, how can I help you?")
    player.nextChat(5870062)

def chat_5870062(player):
    player.dialogueOption("Can I use your anvil?", 587006399, "Do you have a hammer can I can buy?", 5870064)    

def chat_587006399(player):
    player.playerChat("Can I use your anvil?")
    player.nextChat(5870063) 
    
def chat_5870063(player):
    player.npcChat("Sure thing!")
    player.endChat()
    
def chat_5870064(player):
    player.playerChat("Do you have a hammer can I can buy?")
    player.nextChat(5870065)    
    
def chat_5870065(player):
    player.npcChat("Not really.")
    player.nextChat(5870066)    

def chat_5870066(player):
    player.dialogueOption("Oh okay.", 5870067, "Please! I'll pay 10,000 coins.", 5870068)        

def chat_5870067(player):
    player.playerChat("Oh okay.")
    player.endChat()    
    
def chat_5870068(player):
    player.playerChat("Please! I'll pay 10,000 coins.")
    player.nextChat(5870069)        
    
def chat_5870069(player):
    player.npcChat("10,000 coins you say? Alright then.")
    player.nextChat(5870070)    
    
def chat_5870070(player):
    player.playerChat("Thanks!")
    player.nextChat(5870071)    

def chat_5870071(player):
    if player.hasItem(995, 10000):
        player.npcChat("Here you go.")
        player.deleteItem(995, 10000)
        player.addItem(2347, 1)
        player.endChat()
    else:    
        player.playerChat("Oh wait, Sorry, I don't have 10,000 coins right now.")
        player.endChat()
    