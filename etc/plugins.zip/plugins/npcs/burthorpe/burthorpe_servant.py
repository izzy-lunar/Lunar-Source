# Author Cam
from com.ownxile.core import World

World.addCombatNpc(1081, 2899, 3563, 0, 1, 10, 2, 1, 1)

def first_click_npc_1081(player):
	player.startChat(249995160)
	
def chat_249995160(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(249995161)
	
def chat_249995161(player):
	player.npcChat("Hi " + str(player.playerName) + ", I hope you're having a nice day.")
	player.endChat()