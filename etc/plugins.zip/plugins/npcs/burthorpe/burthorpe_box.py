# Author Parrot
from com.ownxile.core import World

def handle_random_box(player, a, b, c, d, e):     
    boxcontain = random.choice([a,b,c,d,e])
    if Misc.random(5) == 5:
        player.addItem(boxcontain)
        player.boxMessage("You search the box and find something!")
    else:
        player.boxMessage("You search the box but find nothing.")

def first_click_object_3685(player):
    handle_random_box(player, 1957, 946, 1925, 1733, 1931)
    
def first_click_object_3686(player):
    handle_random_box(player, 1957, 946, 1925, 1733, 1931) 

def first_click_object_3687(player):
    handle_random_box(player, 1957, 946, 1925, 1733, 1931)    