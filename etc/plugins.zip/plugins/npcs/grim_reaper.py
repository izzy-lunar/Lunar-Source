World.addNonCombatNpc(5383, 3210, 3437, 0, 1)

def first_click_npc_6390(player):
    player.startChat(150861807)

def chat_150861807(player):
    player.npcChat("Happy halloween " + str(player.playerName) + "...")
    player.nextChat(150861808)

def chat_150861808(player):
    player.npcChat("...mwuahahahaha!")
    player.nextChat(150861809)

def chat_150861809(player):
    player.playerChat("What's so funny?")
    player.nextChat(150861810)

def chat_150861810(player):
    player.npcChat("Oh I'm just in a good mood, Halloween is", "the only time of year I get to speak to people.")
    player.nextChat(150861811)

def chat_150861811(player):
    player.playerChat("That's sad, it must be a lonely life being a reaper.")
    player.nextChat(150861812)

def chat_150861812(player):
    player.npcChat("You have no idea.")
    player.nextChat(150861813)

def chat_150861813(player):
    player.playerChat("Don't you have some kind of event to offer?")
    player.nextChat(150861814)

def chat_150861814(player):
    player.npcChat("Yeah, it's due to be released on the @dre@25th of October@bla@.")
    player.nextChat(150861815)

def chat_150861815(player):
    player.playerChat("Okay, great!")
    player.endChat()
