#mith dragons
World.addCombatNpc(5363, 2403, 4680, 0, 1, 250, 25, 150,250)
World.addCombatNpc(5363, 2411, 4677, 0, 1, 250, 25, 150,250)
World.addCombatNpc(5363, 2415, 4683, 0, 1, 250, 25, 150,250)
World.addCombatNpc(5363, 2423, 4681, 0, 1, 250, 25, 150,250)

#wyverns
World.addCombatNpc(3068, 2381, 4692, 0, 1, 150, 18, 350,350)
World.addCombatNpc(3068, 2389, 4690, 0, 1, 150, 18, 350,350)
World.addCombatNpc(3068, 2397, 4678, 0, 1, 150, 18, 350,350)
World.addCombatNpc(3068, 2384, 4680, 0, 1, 150, 18, 350,350)

#tormented
World.addCombatNpc(2349, 2422, 4707, 0, 1, 400, 40, 450,450)
World.addCombatNpc(2349, 2413, 4711, 0, 1, 400, 40, 450,450)
World.addCombatNpc(2349, 2405, 4721, 0, 1, 400, 40, 450,450)
World.addCombatNpc(2349, 2384, 4721, 0, 1, 400, 40, 450,450)
World.addCombatNpc(2349, 2417, 4725, 0, 1, 400, 40, 450,450)
