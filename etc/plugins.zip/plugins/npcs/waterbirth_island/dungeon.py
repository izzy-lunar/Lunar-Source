#rock lobsters

World.addCombatNpc(2885, 1900, 4408, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1905, 4408, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1905, 4404, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1900, 4400, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1894, 4399, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1888, 4390, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1883, 4385, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1923, 4365, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1930, 4360, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1939, 4356, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1946, 4357, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1951, 4359, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1956, 4366, 0, 1, 250, 17, 170,170)

#giant rock crabs
World.addCombatNpc(2885, 1883, 4369, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1884, 4363, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1890, 4362, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1893, 4368, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1898, 4371, 0, 1, 250, 17, 170,170)
World.addCombatNpc(2885, 1901, 4363, 0, 1, 250, 17, 170,170)

