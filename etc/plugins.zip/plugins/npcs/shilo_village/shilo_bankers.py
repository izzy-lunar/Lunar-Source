World.addNonCombatNpc(497, 2850, 2954, 0, 1)
World.addNonCombatNpc(496, 2854, 2955, 0, 1)
World.addNonCombatNpc(499, 2852, 2953, 0, 1)

