from com.ownxile.rs2.world.transport import KaramjaCart

World.addNonCombatNpc(511, 2834, 2955, 0, 1)

def second_click_npc_511(player):
	if player.hasItem(995, 1000):
		player.deleteItem(995, 1000)
		player.sendMessage("You pay a fare of 1000 coins to travel to Brimhaven.")
		KaramjaCart.travel(player, 2779, 3216)
	else:
		player.boxMessage("You need 1000 coins to travel to Brimhaven.")
		