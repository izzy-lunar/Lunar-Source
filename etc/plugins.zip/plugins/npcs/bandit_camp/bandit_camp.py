#Bandit Camp
#Created by Nixon

#NPC's
bandit_id = 1926
kebab_shop = 1865
bartender = 731

# npc id, x, y, height, stationary, hp, maxhit, attack, defence
World.addNonCombatNpc(kebab_shop, 3176, 2987, 0, 1)
World.addNonCombatNpc(bartender, 3159, 2983, 0, 1)
World.addCombatNpc(bandit_id, 3159, 2987, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3162, 2987, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3162, 2983, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3163, 2981, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3161, 2979, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3164, 2977, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3171, 2980, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3179, 2979, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3172, 2975, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3173, 2972, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3175, 2973, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3186, 2986, 0, 1, 150, 50, 50, 100)
World.addCombatNpc(bandit_id, 3185, 2983, 0, 1, 150, 50, 50, 100)

#Kebab Shop
def first_click_npc_1865(player):
	player.startChat(72915)

def chat_72915(player):
	player.npcChat("Welcome to my kebab house,", "Would you like anything to eat?")
	player.nextChat(72916)

def chat_72916(player):
	player.dialogueOption("Sure, I'll have a look at the menu.", 72917, "No thanks.", 72918)

def chat_72917(player):
	player.getShop().openShop(177)

def chat_72918(player):
	player.playerChat("No thanks.")
	player.endChat()
	
def first_click_npc_1926(player):
	player.startChat(997300435)

def chat_997300435(player):
	player.npcChat("Fight me and fear the power", "of Zaros!")
	player.endChat()