# Ardougne City NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Guards
World.addCombatNpc(23, 3307, 3205, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2636, 3339, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2613, 3345, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2578, 3299, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2580, 3298, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2584, 3298, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2582, 3306, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2587, 3302, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2587, 3291, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2583, 3286, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2571, 3285, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2572, 3298, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2629, 3297, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2643, 3306, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(23, 2689, 3305, 0, 1, 15, 5, 7, 7)

# Guard dogs
World.addCombatNpc(99, 2632, 3313, 0, 1, 25, 8, 25, 25)
World.addCombatNpc(99, 2639, 3313, 0, 1, 25, 5, 25, 25)

# Heros
World.addCombatNpc(21, 2656, 3307, 0, 1, 40, 12, 40, 40)
World.addCombatNpc(21, 2656, 3307, 0, 1, 40, 12, 40, 40)

# Paladin
World.addCombatNpc(20, 2666, 3300, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(20, 2607, 3313, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(20, 2613, 3340, 0, 1, 35, 10, 35, 35)

# Monkeys
World.addCombatNpc(132, 2604, 3277, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2602, 3276, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2600, 3275, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2600, 3278, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2602, 3280, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2602, 3280, 0, 1, 5, 1, 2, 1)
World.addCombatNpc(132, 2604, 3282, 0, 1, 5, 1, 2, 1)

# gwd bosses
World.addNonCombatNpc(4001, 2594, 3268, 0, 1)
World.addNonCombatNpc(4005, 2596, 3269, 0, 1)
World.addNonCombatNpc(4006, 2595, 3272, 0, 1)
World.addNonCombatNpc(4007, 2591, 3270, 0, 1)

# dagannoths
World.addNonCombatNpc(4008, 2609, 3268, 0, 1)
World.addNonCombatNpc(4009, 2607, 3270, 0, 1)
World.addNonCombatNpc(4010, 2601, 3270, 0, 1)

# Wolves
World.addCombatNpc(95, 2628, 3276, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2632, 3275, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2635, 3276, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2634, 3281, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2629, 3283, 0, 1, 35, 10, 35, 35)

# main bosses
World.addNonCombatNpc(4000, 2623, 3272, 0, 1)
World.addNonCombatNpc(4002, 2622, 3278, 0, 1)
World.addNonCombatNpc(4004, 2616, 3284, 0, 1)
World.addNonCombatNpc(4017, 2621, 3283, 0, 1)

# Unicorns
World.addCombatNpc(89, 2636, 3268, 0, 1, 8, 4, 3, 5)
World.addCombatNpc(89, 2635, 3266, 0, 1, 8, 4, 3, 5)
World.addCombatNpc(89, 2631, 3266, 0, 1, 8, 4, 3, 5)
World.addCombatNpc(89, 2628, 3266, 0, 1, 8, 4, 3, 5)

# Bears
World.addCombatNpc(105, 2618, 3218, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(105, 2700, 3330, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(105, 2710, 3338, 0, 1, 15, 5, 7, 7)

# Ducks
World.addCombatNpc(46, 2615, 3275, 0, 1, 1, 1, 1, 1)
World.addCombatNpc(46, 2611, 3274, 0, 1, 1, 1, 1, 1)

# Chaos Druids
World.addCombatNpc(181, 2563, 3358, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(181, 2564, 3355, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(181, 2561, 3355, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(181, 2567, 3356, 0, 1, 15, 5, 7, 7)

# Mourners
World.addCombatNpc(347, 2561, 3305, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(347, 2559, 3303, 0, 1, 15, 5, 7, 7)


# Men
World.addCombatNpc(1, 2669, 3318, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2672, 3317, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2674, 3301, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2667, 3292, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2658, 3291, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 3650, 3302, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2662, 3320, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2676, 3282, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2643, 3269, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2636, 3294, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2645, 3337, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2616, 3317, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2611, 3309, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2566, 3273, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 2584, 3335, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 2594, 3323, 0, 1, 10, 2, 2, 2)

# Women
World.addCombatNpc(4, 2666, 3291, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(5, 2647, 3298, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 2649, 3313, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 2655, 3321, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(4, 2659, 3273, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(5, 2639, 3292, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(5, 2648, 3337, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 2616, 3324, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 2621, 3291, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(4, 2571, 3268, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(4, 2565, 3321, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 2572, 3334, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(5, 2566, 3333, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(25, 2587, 3318, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(25, 2592, 3319, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(25, 2592, 3322, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(25, 2587, 3324, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(25, 2586, 3326, 0, 1, 10, 2, 2, 2)

# General store
World.addNonCombatNpc(522, 2614, 3293, 0, 1)
World.addNonCombatNpc(523, 2613, 3292, 0, 1)

# Banks
World.addNonCombatNpc(494, 2619, 3330, 0, 0)
World.addNonCombatNpc(494, 2618, 3330, 0, 0)
World.addNonCombatNpc(494, 2615, 3330, 0, 0)
World.addNonCombatNpc(494, 2657, 3286, 0, 0)
World.addNonCombatNpc(494, 2657, 3283, 0, 0)

#doctor orbon
World.addNonCombatNpc(290, 2617, 3308, 0, 1)

#Mourner
def first_click_npc_347(player):
	player.startChat(95000)
	
def chat_95000(player):
	player.npcChat("What are you doing here?!")
	player.endChat()
