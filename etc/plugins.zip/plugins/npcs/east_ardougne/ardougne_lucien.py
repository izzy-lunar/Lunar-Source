# Ardougne Lucien
# Lucien - 273
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(273, 2574, 3321, 0, 1)

def first_click_npc_273(player):
	player.startChat(745680)
	
def chat_745680(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745681)
	
def chat_745681(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745682)

def chat_745682(player):
	player.dialogueOption("Nothing much.", 745683, "I'm looking for quests!", 745684)
	
def chat_745683(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745684(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745685)
	
def chat_745685(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745686)	
	
def chat_745686(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()