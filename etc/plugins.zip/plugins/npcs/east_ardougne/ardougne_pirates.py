# Author Parrot
from com.ownxile.core import World

World.addCombatNpc(182, 2668, 3270, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(182, 2670, 3267, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(182, 2673, 3270, 0, 1, 15, 5, 7, 7)

#Pirate 182
def first_click_npc_182(player):
	player.startChat(94000)
	
def chat_94000(player):
	player.npcChat("Ahoy matey!")
	player.endChat()