# Ardougne Apprentice
# Apprentice - 3235
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(3235, 2600, 3312, 0, 1)

def first_click_npc_3335(player):
	player.startChat(745630)
	
def chat_745630(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745631)
	
def chat_745631(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745632)

def chat_745632(player):
	player.dialogueOption("Nothing much.", 745633, "I'm looking for quests!", 745634)
	
def chat_745633(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745634(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745635)
	
def chat_745635(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745636)	
	
def chat_745636(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()