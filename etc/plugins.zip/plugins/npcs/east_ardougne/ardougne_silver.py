# Ardougne Silver Stall
# Silver Merchant = 569
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(569, 2658, 3316, 0, 0)

ArdySilver_shop = Shop("Silver Stall", 376)
ArdySilver_shop.addItem(ShopItem(442, 250))
ArdySilver_shop.addItem(ShopItem(2355, 50))
ArdySilver_shop.addItem(ShopItem(1718, 50))
ArdySilver_shop.addItem(ShopItem(1724, 50))

def second_click_npc_569(player):
	player.getShop().openShop(376)

def first_click_npc_569(player):
    player.startChat(178925)
	
def chat_178925(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(178926)
       
def chat_178926(player):
    player.dialogueOption("Sure, I'll have a look.", 178927, "No thanks.", 178928)
       
def chat_178927(player):
    player.getShop().openShop(376)
       
def chat_178928(player):
    player.playerChat("No thanks.")
    player.endChat()