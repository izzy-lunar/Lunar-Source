# Ardougne Spice Stall
# Spice Merchant = 572
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(572, 2659, 3296, 0, 0)

ArdySpice_shop = Shop("Spice Stall", 380)
ArdySpice_shop.addItem(ShopItem(2007, 50))
ArdySpice_shop.addItem(ShopItem(2169, 50))
ArdySpice_shop.addItem(ShopItem(1550, 50))

def second_click_npc_572(player):
	player.getShop().openShop(380)

def first_click_npc_572(player):
    player.startChat(178985)
	
def chat_178985(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(178986)
       
def chat_178986(player):
    player.dialogueOption("Sure, I'll have a look.", 178987, "No thanks.", 178988)
       
def chat_178987(player):
    player.getShop().openShop(380)
       
def chat_178988(player):
    player.playerChat("No thanks.")
    player.endChat()