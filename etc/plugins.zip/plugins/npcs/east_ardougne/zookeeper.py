#npc 28

from com.ownxile.rs2.npcs import KillLog
from com.ownxile.rs2.npcs import PetHandler

World.addNonCombatNpc(28, 2609, 3278, 0, 1)

def first_click_npc_28(player):
    player.startChat(1919582700)
	
def insure_pet(player):
    index = KillLog.getBossPetIndex(player.summonId)
    if not player.hasItem(995, 50000000):
        player.boxMessage("You need 50 million coins to insure this pet.")
    else:
        player.deleteItem(995, 50000000)
        player.unlockedPets[index] = 1
        player.boxMessage("You insure the pet, you are now able to summon it", "at the zoo free of charge.")

def handle_pet_select(player, bossId):
    index = KillLog.getNpcArrayIndex(bossId)
    if not player.hasItem(995, 5000000) and player.unlockedPets[index] != 1:
        player.boxMessage("You need 5 million coins to summon this pet.")
        return
    kills_required = KillLog.getKillsForPet(index)
    pet_npc_id = KillLog.getPet(index)
    if player.loggedKills[index] > kills_required - 1:
        if PetHandler.summonPet(player, pet_npc_id):
            if player.unlockedPets[index] == 0:
                player.deleteItem(995, 5000000)
            player.boxMessage("You summon the pet.")
        else:
            player.boxMessage("You already have a pet.")
    else:
        player.boxMessage("You do not have the required number of kills.")

def chat_1919582690(player):
    handle_pet_select(player, 6260)
def chat_1919582691(player):
    handle_pet_select(player, 50)
def chat_1919582692(player):
    handle_pet_select(player, 2745)
def chat_1919582693(player):
    handle_pet_select(player, 1158)
def chat_1919582694(player):
    handle_pet_select(player, 2552)
def chat_1919582695(player):
    handle_pet_select(player, 3340)
def chat_1919582696(player):
    handle_pet_select(player, 1615)
def chat_1919582697(player):
    handle_pet_select(player, 5902)
	
	
def chat_1919582681(player):
    handle_pet_select(player, 6222)
def chat_1919582682(player):
    handle_pet_select(player, 3200)
def chat_1919582683(player):
    handle_pet_select(player, 3068)
def chat_1919582684(player):
    handle_pet_select(player, 2783)
	
def chat_1919582671(player):
    handle_pet_select(player, 6247)
def chat_1919582672(player):
    handle_pet_select(player, 5666)
def chat_1919582673(player):
    handle_pet_select(player, 3847)
def chat_1919582674(player):
    handle_pet_select(player, 5363)
	
def chat_1919582661(player):
    handle_pet_select(player, 2881)
def chat_1919582662(player):
    handle_pet_select(player, 2882)
def chat_1919582663(player):
    handle_pet_select(player, 2883)
def chat_1919582664(player):
    handle_pet_select(player, 5247)

def handle_pet_insurance(player, bossId):
    player.boxMessage("unavailable lel")

def chat_1919582698(player):
    player.dialogueOption("Baby Graardor - 500 kills", 1919582690, "Prince Black Dragon - 400 kills", 1919582691, "Baby Jad - 200 kills", 1919582692, "Kalphite Princess - 300 kills", 1919582693, "@blu@More", 1919582699)
	
def chat_1919582699(player):
    player.dialogueOption("Baby Callisto - 200 kills", 1919582694, "Baby Mole - 200 kills", 1919582695, "Baby Abyssal Demon - 2000 kills", 1919582696, "Baby Inadaquecy - 200 kills", 1919582697, "@blu@More", 1919582680)
	
def chat_1919582680(player):
    player.dialogueOption("Kree Arra - 500 kills", 1919582681, "Chaos Elemental - 200 kills", 1919582682, "Baby Wyvern - 1000 kills", 1919582683, "Baby Dark Beast - 1000 kills", 1919582684, "@blu@More", 1919582670)

def chat_1919582670(player):
    player.dialogueOption("Commander Zilyana - 500 kills", 1919582671, "Babychest - 300 kills", 1919582672, "Baby Seatroll - 300 kills", 1919582673, "Baby Mithril Dragon - 1000 kills", 1919582674, "@blu@More", 1919582660)
	
def chat_1919582660(player):
    player.dialogueOption("Dagannoth Supreme - 500 kills", 1919582661, "Dagannoth Prime - 500 kills", 1919582662, "Dagannoth Rex - 500 kills", 1919582663, "Penance Queen - 100 kills", 1919582664, "@blu@More", 1919582698)
	
def chat_1919582700(player):
    player.npcChat("Welcome to Ardougne Zoo, the official zoo", "of OwnXile. How may I help you?")
    player.nextChat(1919582701)
	
def chat_1919582701(player):
    player.dialogueOption("Enquire about pets", 1919582702, "Summon pet", 1919582698, "Check boss kills", 1919582717, "Query pet insurance", 1919582705, "Wish a happy birthday!", 1919582713)

def chat_1919582702(player):
    player.playerChat("What are the pets in the cages?")
    player.nextChat(1919582703)

def chat_1919582703(player):
    player.npcChat("Our reincarnated boss pets require you to have slayed", "that boss a number times. You'll also need to pay", "a fee of 5 million gold to summon it.")
    player.nextChat(1919582704)

def chat_1919582704(player):
    player.npcChat("If you die with your pet it will run away.", "Pet insurance is available though!")
    player.nextChat(1919582698)

def chat_1919582705(player):
    index = KillLog.getBossPetIndex(player.summonId)
    if player.unlockedPets[index] == 1:
        player.boxMessage("You have already insured this pet.")
    else:
        player.playerChat("Can I purchase pet insurance?")
        player.lastClickedNpcId = 28
        player.nextChat(1919582706)

def chat_1919582706(player):
    player.npcChat("It costs a fee of 50 million coins to insure this pet.")
    player.nextChat(1919582707)

def chat_1919582707(player):
    player.npcChat("This means the pet will be free to collect from", "the zoo if you ever lose it.")
    player.nextChat(1919582708)

def chat_1919582708(player):
    player.npcChat("Would you like to purchase pet insurance?")
    player.nextChat(1919582709)

def chat_1919582709(player):
    player.dialogueQuestion("Insure pet?", "Yes", 1919582710, "No", 58)
	
def chat_1919582710(player):
    insure_pet(player)

def chat_1919582713(player):
    player.playerChat("Happy birthday Mr Zookeeper!")
    player.nextChat(1919582714)

def chat_1919582714(player):
    player.npcChat("It's not my birthday.")
    player.nextChat(1919582715)

def chat_1919582715(player):
    player.playerChat("Too bad, I got you a present!")
    player.nextChat(1919582716)

def chat_1919582716(player):
    player.npcChat("I don't give a monkeys.")
    player.nextChat(1919582701)
def chat_1919582717(player):
    KillLog.killInterface(player)
    player.endChat()
