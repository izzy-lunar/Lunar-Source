# Vanessa
# Vanessa = 2305
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(2305, 2589, 3327, 0, 1)

Vanessa_shop = Shop("Vanessa's Pottery", 389)
Vanessa_shop.addItem(ShopItem(5350, 100))
Vanessa_shop.addItem(ShopItem(5350, 100))
Vanessa_shop.addItem(ShopItem(6036, 100))

def second_click_npc_2305(player):
	player.getShop().openShop(389)

def first_click_npc_2305(player):
    player.startChat(179915)
	
def chat_179915(player):
    player.npcChat("Welcome to my pottery,", "Would you like to buy anything?")
    player.nextChat(179916)
       
def chat_179916(player):
    player.dialogueOption("Sure, I'll have a look.", 179917, "No thanks.", 179918)
       
def chat_179917(player):
    player.getShop().openShop(389)
       
def chat_179918(player):
    player.playerChat("No thanks.")
    player.endChat()