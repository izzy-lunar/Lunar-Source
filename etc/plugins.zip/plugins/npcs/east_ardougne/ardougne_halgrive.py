# Ardougne Halgrive
# Halgrive - 289
# Author Cam

World.addNonCombatNpc(289, 2616, 3299, 0, 1)

def first_click_npc_289(player):
	player.startChat(745620)
	
def chat_745620(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745621)
	
def chat_745621(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745622)

def chat_745622(player):
	player.dialogueOption("Nothing much.", 745623, "I'm looking for quests!", 745624)
	
def chat_745623(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745624(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745625)
	
def chat_745625(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745626)	
	
def chat_745626(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()