# Ardy sailor
# Sailor = 1385
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1385, 2683, 3275, 0, 1)

def first_click_npc_1385(player):
    player.startChat(989000)
    
def chat_989000(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(989001)
    
def chat_989001(player):
    player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
    player.nextChat(989002)

def chat_989002(player):
    player.dialogueOption("Nothing much.", 989003, "I'm looking for quests!", 989004)
    
def chat_989003(player):
    player.playerChat("Nothing much.")
    player.endChat()
    
def chat_989004(player):
    player.playerChat("I'm looking for quests!")
    player.nextChat(989005)
    
def chat_989005(player):
    player.npcChat("Well actually, I may need your help you see,","I'm a little busy right now could you", "come back later on?")
    player.nextChat(989006)    
    
def chat_989006(player):
    player.playerChat("Okay sure.")
    player.endChat()