# Ardougne King
# King - 364
# Author Cam

World.addNonCombatNpc(364, 2577, 3293, 0, 1)

def first_click_npc_364(player):
	player.startChat(745670)
	
def chat_745670(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745671)
	
def chat_745671(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745672)

def chat_745672(player):
	player.dialogueOption("Nothing much.", 745673, "I'm looking for quests!", 745674)
	
def chat_745673(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745674(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745675)
	
def chat_745675(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745676)	
	
def chat_745676(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()