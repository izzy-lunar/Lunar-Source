# Ardougne Fur Stall
# Fur Merchant = 1316
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1316, 2663, 3295, 0, 0)
World.addNonCombatNpc(1316, 2804, 10071, 0, 1)

ArdyFur_shop = Shop("Fur Stall", 379)
ArdyFur_shop.addItem(ShopItem(948, 0))
ArdyFur_shop.addItem(ShopItem(958, 0))

def second_click_npc_1316(player):
	player.getShop().openShop(379)

def first_click_npc_1316(player):
    player.startChat(178975)
	
def chat_178975(player):
    player.npcChat("Welcome to my stall.", "Would you like to buy anything?")
    player.nextChat(178976)
       
def chat_178976(player):
    player.dialogueOption("Sure, I'll have a look.", 178977, "No thanks.", 178978)
       
def chat_178977(player):
    player.getShop().openShop(379)
       
def chat_178978(player):
    player.playerChat("No thanks.")
    player.endChat()