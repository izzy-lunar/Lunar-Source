# Ardougne Lord
# Lord - 200
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(200, 2635, 3322, 0, 1)

def first_click_npc_200(player):
	player.startChat(745600)
	
def chat_745600(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745601)
	
def chat_745601(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745602)

def chat_745602(player):
	player.dialogueOption("Nothing much.", 745603, "I'm looking for quests!", 745604)
	
def chat_745603(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745604(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745605)
	
def chat_745605(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745606)	
	
def chat_745606(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()