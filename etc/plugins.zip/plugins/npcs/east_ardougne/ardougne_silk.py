# Ardougne Silk Stall
# Silk Merchant = 574
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(574, 2655, 3301, 0, 0)

ArdySilk_shop = Shop("Silk Stall", 377)
ArdySilk_shop.addItem(ShopItem(950, 1000))

def first_click_npc_574(player):
    player.startChat(178935)
	
def chat_178935(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(178936)
       
def chat_178936(player):
    player.dialogueOption("Sure, I'll have a look.", 178937, "No thanks.", 178938)
       
def chat_178937(player):
    player.getShop().openShop(377)
       
def chat_178938(player):
    player.playerChat("No thanks.")
    player.endChat()