# Ardougne Gem Stall
# Gem Merchant = 570
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(570, 2669, 3304, 0, 0)

ArdyGem_shop = Shop("Gem Stall", 378)
ArdyGem_shop.addItem(ShopItem(1607, 5))
ArdyGem_shop.addItem(ShopItem(1605, 5))
ArdyGem_shop.addItem(ShopItem(1603, 5))
ArdyGem_shop.addItem(ShopItem(1601, 5))

def second_click_npc_570(player):
	player.getShop().openShop(378)

def first_click_npc_570(player):
    player.startChat(178955)
	
def chat_178955(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(178956)
       
def chat_178956(player):
    player.dialogueOption("Sure, I'll have a look.", 178957, "No thanks.", 178958)
       
def chat_178957(player):
    player.getShop().openShop(378)
       
def chat_178958(player):
    player.playerChat("No thanks.")
    player.endChat()