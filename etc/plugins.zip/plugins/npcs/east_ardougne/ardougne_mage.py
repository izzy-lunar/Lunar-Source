# Ardougne Mage
# Mage - 946
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(946, 2682, 3325, 0, 1)

def first_click_npc_946(player):
	player.startChat(745650)
	
def chat_745650(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(745651)
	
def chat_745651(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(745652)

def chat_745652(player):
	player.dialogueOption("Nothing much.", 745653, "I'm looking for quests!", 745654)
	
def chat_745653(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_745654(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(745655)
	
def chat_745655(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(745656)	
	
def chat_745656(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()