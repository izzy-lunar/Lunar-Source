# Ardougne Bakery
# Baker = 571
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(571, 2654, 3311, 0, 0)

ArdyBaker_shop = Shop("Bakery Stall", 375)
ArdyBaker_shop.addItem(ShopItem(2309, 10))
ArdyBaker_shop.addItem(ShopItem(1891, 10))
ArdyBaker_shop.addItem(ShopItem(1897, 10))
ArdyBaker_shop.addItem(ShopItem(1973, 100))

def second_click_npc_571(player):
	player.getShop().openShop(375)

def first_click_npc_571(player):
    player.startChat(178915)
	
def first_click_npc_581(player):
    player.startChat(178915)
	
def chat_178915(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(178916)
       
def chat_178916(player):
    player.dialogueOption("Sure, I'll have a look.", 178917, "No thanks.", 178918)
       
def chat_178917(player):
    player.getShop().openShop(375)
       
def chat_178918(player):
    player.playerChat("No thanks.")
    player.endChat()