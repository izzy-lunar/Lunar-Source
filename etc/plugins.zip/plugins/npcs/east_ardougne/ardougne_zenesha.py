# Ardougne Zenesha
# Zenesha = 589
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(589, 2652, 3295, 0, 0)

Zenesha_shop = Shop("Zenesha's armour", 381)
Zenesha_shop.addItem(ShopItem(1117, 10))
Zenesha_shop.addItem(ShopItem(1115, 10))
Zenesha_shop.addItem(ShopItem(1119, 10))
Zenesha_shop.addItem(ShopItem(1125, 10))
Zenesha_shop.addItem(ShopItem(1121, 10))
Zenesha_shop.addItem(ShopItem(1123, 10))
Zenesha_shop.addItem(ShopItem(1127, 10))

def second_click_npc_589(player):
    player.getShop().openShop(381)

def first_click_npc_589(player):
    player.startChat(178995)
    
def chat_178995(player):
    player.npcChat("Welcome to my shop,", "Would you like to buy anything?")
    player.nextChat(178996)
       
def chat_178996(player):
    player.dialogueOption("Sure, I'll have a look.", 178997, "No thanks.", 178998)
       
def chat_178997(player):
    player.getShop().openShop(381)
       
def chat_178998(player):
    player.playerChat("No thanks.")
    player.endChat()