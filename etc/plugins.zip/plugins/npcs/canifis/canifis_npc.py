# Canifis NPC
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

#General Store
World.addNonCombatNpc(522, 3476, 3496, 0, 1)

#Banker
World.addNonCombatNpc(494, 3514, 3478, 0, 2)
World.addNonCombatNpc(494, 3514, 3479, 0, 2)
World.addNonCombatNpc(494, 3514, 3480, 0, 2)
World.addNonCombatNpc(494, 3514, 3481, 0, 2)
World.addNonCombatNpc(494, 3514, 3482, 0, 2)
World.addNonCombatNpc(494, 3514, 3483, 0, 2)

#Men
World.addCombatNpc(1, 3494, 3475, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 3500, 3472, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 3491, 3472, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(5, 3500, 3479, 0, 1, 10, 2, 1, 1)