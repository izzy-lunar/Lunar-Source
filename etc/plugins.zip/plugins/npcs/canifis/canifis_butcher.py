# Canifis Clothes
# Barker = 1038
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1038, 3508, 3497, 0, 1)

CBarker_shop = Shop("Rufus's Meat Emporium", 589)
CBarker_shop.addItem(ShopItem(522, 5))
CBarker_shop.addItem(ShopItem(523, 5))
CBarker_shop.addItem(ShopItem(524, 5))
CBarker_shop.addItem(ShopItem(525, 5))

def second_click_npc_1038(player):
    player.getShop().openShop(589)
    
def first_click_npc_1038(player):
    player.startChat(148915)
    
def chat_148915(player):
    player.npcChat("Welcome to my meat emporium,", "Would you like to buy anything?")
    player.nextChat(148916)
    
def chat_148916(player):
    player.dialogueOption("Sure, I'll have a look.", 148917, "No thanks.", 148918)
    
def chat_148917(player):
    player.getShop().openShop(589)
    
def chat_148918(player):
    player.playerChat("No thanks.")
    player.endChat()