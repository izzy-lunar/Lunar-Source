# Canifis Bar
# Keeper = 1042
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1042, 3494, 3469, 0, 1)

CanBar_shop = Shop("The Canifis Cup", 454)
CanBar_shop.addItem(ShopItem(1917, 1000))
	
def second_click_npc_1042(player):
	player.getShop().openShop(454)
	
def first_click_npc_1042(player):
	player.startChat(18170580)
	
def chat_18170580(player):
	player.playerChat("Hello there, what is this place?")
	player.nextChat(18170581)
	
def chat_18170581(player):
	player.npcChat("Welcome to The Canifis Cup! Would you like a drink?")
	player.nextChat(18170582)
	
def chat_18170582(player):
	player.dialogueOption("No thank you", 18170583, "Sure!", 18170584)
	
def chat_18170583(player):
	player.playerChat("No thank you.")
	player.endChat()
	
def chat_18170584(player):
	player.playerChat("Sure!")
	player.getShop().openShop(454)