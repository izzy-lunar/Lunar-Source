# Canifis Clothes
# Barker = 1039
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1039, 3500, 3504, 0, 1)

Barker_shop = Shop("Barker's Haberdashery", 3755)
Barker_shop.addItem(ShopItem(2894, 25))
Barker_shop.addItem(ShopItem(2904, 25))
Barker_shop.addItem(ShopItem(2914, 25))
Barker_shop.addItem(ShopItem(2924, 25))
Barker_shop.addItem(ShopItem(2934, 25))
Barker_shop.addItem(ShopItem(2902, 25))
Barker_shop.addItem(ShopItem(2912, 25))
Barker_shop.addItem(ShopItem(2922, 25))
Barker_shop.addItem(ShopItem(2932, 25))
Barker_shop.addItem(ShopItem(2942, 25))

def second_click_npc_1039(player):
    player.getShop().openShop(3755)
    
def first_click_npc_1039(player):
    player.startChat(81789165)
    
def chat_81789165(player):
    player.npcChat("Welcome to my clothing store,", "Would you like to buy anything?")
    player.nextChat(81789166)
    
def chat_81789166(player):
    player.dialogueOption("Sure, I'll have a look.", 81789167, "No thanks.", 81789168)
    
def chat_81789167(player):
    player.getShop().openShop(3755)
    
def chat_81789168(player):
    player.playerChat("No thanks.")
    player.endChat()