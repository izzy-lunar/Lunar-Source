# Sbott the Tanner - 1041
# Author Robbie

World.addNonCombatNpc(1041, 3490, 3500, 0, 1)

def first_click_npc_1041(player):
	player.startChat(54120)
	
def second_click_npc_1041(player):
    player.getTan().setupInterface()