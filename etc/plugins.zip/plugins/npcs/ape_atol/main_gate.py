def chat_1894957419(player):
    player.npcChat("No humans allowed, keep away or we'll shoot!")
    player.endChat()

def chat_1894957420(player):
    player.npcChat("Open the gate!", "A monkey wishes to pass.")
    player.nextChat(1894957421)

def chat_1894957421(player):
    player.getFunction().movePlayer(player.absX, player.absY + 2, 0)
    player.endChat()

def first_click_object_4788(player):
    player.lastClickedNpcId = 1441
    if player.getFunction().wearingGreegree():
        player.startChat(1894957420)
    else:
        player.startChat(1894957419)
		
def first_click_object_4787(player):
    player.lastClickedNpcId = 1441
    if player.getFunction().wearingGreegree():
        player.startChat(1894957420)
    else:
        player.startChat(1894957419)