# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(602, 2468, 3488, 2, 1)

gulluck = Shop("Gulluck and Sons", 44)
gulluck.addItem(ShopItem(1307, 15))
gulluck.addItem(ShopItem(1309, 15))
gulluck.addItem(ShopItem(1311, 10))
gulluck.addItem(ShopItem(1313, 10))
gulluck.addItem(ShopItem(1315, 10))
gulluck.addItem(ShopItem(1317, 7))
#Arrows
gulluck.addItem(ShopItem(687, 500))
gulluck.addItem(ShopItem(884, 300))
gulluck.addItem(ShopItem(888, 150))

def first_click_npc_602(player):
    player.startChat(1152090263)
    
def second_click_npc_602(player):
    player.getShop().openShop(44)
    
def chat_1152090262(player):
    player.npcChat("Hey there, would you like to take a look at", "my weaponary that I have for sale?")
    player.nextChat(1152090263)

def chat_1152090263(player):
    player.playerChat("Sure, show me what you have to offer.")
    player.nextChat(1152090264)

def chat_1152090264(player):
    player.getShop().openShop(44)
    player.endChat()