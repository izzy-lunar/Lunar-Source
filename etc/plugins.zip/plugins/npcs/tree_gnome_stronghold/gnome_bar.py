# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(849, 2482, 3487, 1, 0)
World.addNonCombatNpc(849, 2482, 3489, 1, 4)
World.addNonCombatNpc(1407, 2485, 3488, 1, 1)
World.addNonCombatNpc(848, 2480, 3488, 1, 1)

blurberry_bar = Shop("Blurberry's Bar", 27)
blurberry_bar.addItem(ShopItem(2028, 15))
blurberry_bar.addItem(ShopItem(2030, 15))
blurberry_bar.addItem(ShopItem(2032, 15))
blurberry_bar.addItem(ShopItem(2034, 15))
blurberry_bar.addItem(ShopItem(2036, 15))
blurberry_bar.addItem(ShopItem(2038, 15))
blurberry_bar.addItem(ShopItem(2040, 15))

def first_click_npc_849(player):
    player.startChat(228247465)

def first_click_npc_1407(player):
    player.startChat(702797330)    

def first_click_npc_848(player):
    player.startChat(975178900)  
    
def second_click_npc_849(player):
    player.getShop().openShop(27)
    
def chat_228247465(player):
    player.npcChat("Hi, would you like to have a look at what drinks we serve?")
    player.nextChat(228247466)

def chat_228247466(player):
    player.playerChat("Sure, show me what you have!")
    player.nextChat(228247467)

def chat_228247467(player):
    player.getShop().openShop(27)
    player.endChat()    
    
def chat_702797330(player):
    player.playerChat("Hi there, what are you doing here?")
    player.nextChat(702797331)

def chat_702797331(player):
    player.npcChat("This is where I'm from, outsider!", "What are you doing here?")
    player.nextChat(702797332)

def chat_702797332(player):
    player.playerChat("I'm exploring!")
    player.nextChat(702797333)

def chat_702797333(player):
    player.npcChat("Oh, excellent. ")
    player.endChat()  

def chat_975178900(player):
    player.npcChat("Hi there outsider!", "Fancy a drink at our lovely bar?")
    player.nextChat(975178901)

def chat_975178901(player):
    player.playerChat("What drinks are you serving?")
    player.nextChat(975178902)

def chat_975178902(player):
    player.npcChat("Take a look...")
    player.nextChat(975178903)    
    
def chat_975178903(player):
    player.getShop().openShop(27)    
    player.endChat()      