# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(601, 2482, 3510, 1, 1)

gnome_rometti = Shop("Rometti's Fine Fashions", 43)
gnome_rometti.addItem(ShopItem(656, 15)) #Pink Hat
gnome_rometti.addItem(ShopItem(658, 15)) #Green Hat
gnome_rometti.addItem(ShopItem(660, 15)) #Blue Hat
gnome_rometti.addItem(ShopItem(662, 15)) #Cream Hat
gnome_rometti.addItem(ShopItem(664, 15)) #Turquoise Hat
gnome_rometti.addItem(ShopItem(636, 15)) #Pink Top
gnome_rometti.addItem(ShopItem(638, 15)) #Green Top
gnome_rometti.addItem(ShopItem(640, 15)) #Blue Top
gnome_rometti.addItem(ShopItem(642, 15)) #Cream Top
gnome_rometti.addItem(ShopItem(644, 15)) #Turquoise Top
gnome_rometti.addItem(ShopItem(646, 15)) #Pink Robe
gnome_rometti.addItem(ShopItem(648, 15)) #Green Robe
gnome_rometti.addItem(ShopItem(650, 15)) #Blue Robe
gnome_rometti.addItem(ShopItem(652, 15)) #Cream Robe
gnome_rometti.addItem(ShopItem(654, 15)) #Turquoise Robe
gnome_rometti.addItem(ShopItem(626, 15)) #Pink Boots
gnome_rometti.addItem(ShopItem(628, 15)) #Green Boots
gnome_rometti.addItem(ShopItem(630, 15)) #Blue Boots
gnome_rometti.addItem(ShopItem(632, 15)) #Cream Boots
gnome_rometti.addItem(ShopItem(634, 15)) #Turquoise Boots

def first_click_npc_601(player):
    player.startChat(132230391)
    
def second_click_npc_601(player):
    player.getShop().openShop(43)
    
def chat_132230391(player):
    player.npcChat("Would you like to see how to dress properly?")
    player.nextChat(132230392)

def chat_132230392(player):
    player.playerChat("Sure... I guess.")
    player.nextChat(132230393)

def chat_132230393(player):
    player.npcChat("Here, take a look at my fine clothing. ")
    player.nextChat(132230394)

def chat_132230394(player):
    player.getShop().openShop(43)
    player.endChat()