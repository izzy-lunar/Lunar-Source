# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(603, 2491, 3502, 1, 1)

gnome_funch = Shop("Funch's Fine Drinks", 42)
gnome_funch.addItem(ShopItem(2021, 15)) #Brandy
gnome_funch.addItem(ShopItem(2019, 15)) #Gin
gnome_funch.addItem(ShopItem(2015, 15)) #Vodka
gnome_funch.addItem(ShopItem(2017, 15)) #Whisky

def first_click_npc_603(player):
    player.startChat(1583114877)
    
def second_click_npc_603(player):
    player.getShop().openShop(42)
    
def chat_1583114877(player):
    player.npcChat("Hello outsider! Can I tempt you with some of my drinks?")
    player.nextChat(1583114878)

def chat_1583114878(player):
    player.playerChat("What are you serving?")
    player.nextChat(1583114879)

def chat_1583114879(player):
    player.npcChat("Take a look!","I'm sure you'll like what I have to offer.")
    player.nextChat(1583114880)

def chat_1583114880(player):
    player.getShop().openShop(42)
    player.endChat()