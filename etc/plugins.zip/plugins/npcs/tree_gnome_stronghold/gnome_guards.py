# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Guards
World.addCombatNpc(163, 2463, 3378, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2462, 3375, 0, 1, 15, 5, 10, 7)

# Inside
World.addCombatNpc(163, 2460, 3385, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2462, 3387, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2461, 3389, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2464, 3391, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2458, 3392, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2459, 3402, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2462, 3405, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2459, 3408, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2442, 3479, 0, 1, 15, 5, 10, 7)

# Floor 1
World.addCombatNpc(163, 2444, 3462, 1, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2438, 3465, 1, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2478, 3462, 1, 1, 15, 5, 10, 7)

# Unmounted Terrorbird
World.addCombatNpc(138, 2462, 3368, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2466, 3363, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2468, 3481, 0, 1, 15, 6, 10, 10)

# Grand tree
World.addCombatNpc(163, 2485, 3485, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2484, 3493, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2472, 3502, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2476, 3460, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2470, 3458, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2466, 3460, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2463, 3459, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2458, 3457, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2466, 3463, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2432, 3514, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2433, 3510, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2426, 3495, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(163, 2421, 3496, 0, 1, 15, 5, 10, 7)

World.addCombatNpc(1752, 2464, 3452, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2469, 3449, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2477, 3448, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2467, 3469, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2465, 3467, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2465, 3475, 0, 1, 20, 7, 15, 10)

# In pen
World.addCombatNpc(138, 2375, 3439, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2379, 3438, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2378, 3435, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2381, 3431, 0, 1, 15, 6, 10, 10)
World.addCombatNpc(138, 2378, 3429, 0, 1, 15, 6, 10, 10)

# Mounted Terrorbird
World.addCombatNpc(1752, 2461, 3398, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2460, 3395, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2461, 3398, 0, 1, 20, 7, 15, 10)

World.addCombatNpc(1752, 2443, 3509, 0, 1, 20, 7, 15, 10)
World.addCombatNpc(1752, 2441, 3513, 0, 1, 20, 7, 15, 10)

# Cute things
World.addNonCombatNpc(4614, 2468, 3392, 0, 1)
World.addNonCombatNpc(4614, 2454, 3392, 0, 1)
World.addNonCombatNpc(4614, 2437, 3475, 0, 1)
World.addNonCombatNpc(4614, 2475, 3481, 0, 1)
World.addNonCombatNpc(4614, 2458, 3503, 0, 1)