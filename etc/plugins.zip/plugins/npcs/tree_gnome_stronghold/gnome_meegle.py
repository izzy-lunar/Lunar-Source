# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

#Nearby butterfly
World.addNonCombatNpc(153, 2395, 3433, 0, 1)
World.addNonCombatNpc(153, 2402, 3442, 0, 1)
World.addNonCombatNpc(153, 2406, 3435, 0, 1)
World.addNonCombatNpc(153, 2385, 3428, 0, 1)
World.addNonCombatNpc(153, 2388, 3427, 0, 1)

World.addNonCombatNpc(4597, 2382, 3427, 0, 1)

def first_click_npc_4597(player):
    player.startChat(70910411)

def chat_1353712510(player):
    player.playerChat("So what do you do?")
    player.nextChat(1353712511)

def chat_1353712511(player):
    player.npcChat("I breed Terrorbirds.")
    player.nextChat(1353712512)

def chat_1353712512(player):
    player.playerChat("Why are they called Terrorbirds?")
    player.nextChat(1353712513)

def chat_1353712513(player):
    player.npcChat("Well, they're supposed to look terrifying but I think", "they are rather cure.")
    player.nextChat(1353712514)

def chat_1353712514(player):
    player.playerChat("I'm sure they are cute, unless they are biting your", "arm off.")
    player.nextChat(1353712515)

def chat_1353712515(player):
    player.npcChat("Oh, they'd never do that - unless I tell them to, of course.")
    player.nextChat(1353712516)

def chat_1353712516(player):
    player.playerChat("I'd better stay on your good side then.")
    player.endChat()