# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Butterfly
World.addNonCombatNpc(153, 2423, 3459, 0, 1)
World.addNonCombatNpc(153, 2430, 3468, 0, 1)
World.addNonCombatNpc(153, 2441, 3460, 0, 1)
World.addNonCombatNpc(153, 2454, 3451, 0, 1)
World.addNonCombatNpc(153, 2460, 3441, 0, 1)
World.addNonCombatNpc(153, 2487, 3449, 0, 1)
World.addNonCombatNpc(153, 2483, 3467, 0, 1)
World.addNonCombatNpc(153, 2461, 3507, 0, 1)
World.addNonCombatNpc(153, 2436, 3514, 0, 1)

# Children
World.addCombatNpc(159, 2408, 3437, 1, 1, 2, 1, 1, 1)
World.addCombatNpc(160, 2424, 3440, 1, 1, 2, 1, 1, 1)
World.addCombatNpc(159, 2425, 3425, 1, 1, 2, 1, 1, 1)
World.addCombatNpc(160, 2488, 3450, 1, 1, 2, 1, 1, 1)
World.addCombatNpc(159, 2490, 3447, 1, 1, 2, 1, 1, 1)

def first_click_npc_159(player):
    player.startChat(505395210)
    
def first_click_npc_160(player):
    player.startChat(1462768812)

def chat_505395210(player):
    player.playerChat("What are you doing on your own?!")
    player.nextChat(505395211)

def chat_505395211(player):
    player.npcChat("I'm exploring!")
    player.nextChat(505395212)

def chat_505395212(player):
    player.playerChat("Right, okay...")
    player.endChat()

def chat_1462768812(player):
    player.playerChat("Hi!")
    player.nextChat(1462768813)

def chat_1462768813(player):
    player.npcChat("Ew what do you want you creepy man?!")
    player.nextChat(1462768814)

def chat_1462768814(player):
    player.playerChat("Nothing...")
    player.endChat()