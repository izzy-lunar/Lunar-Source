# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(600, 2449, 3501, 1, 1)

gnome_hudo = Shop("Grand Tree Groceries", 41)
gnome_hudo.addItem(ShopItem(2120, 15)) #Lime
gnome_hudo.addItem(ShopItem(1965, 15)) #Cabbage
gnome_hudo.addItem(ShopItem(1933, 15)) #Pot of flour
gnome_hudo.addItem(ShopItem(2169, 15)) #Gnome spice
gnome_hudo.addItem(ShopItem(2130, 15)) #Pot of cream
gnome_hudo.addItem(ShopItem(2114, 15)) #Pineapple
gnome_hudo.addItem(ShopItem(2108, 15)) #Orange
gnome_hudo.addItem(ShopItem(2102, 15)) #Lemon
gnome_hudo.addItem(ShopItem(1985, 15)) #Cheese
gnome_hudo.addItem(ShopItem(1982, 15)) #Pot of flour
gnome_hudo.addItem(ShopItem(1973, 15)) #Chocolate 
gnome_hudo.addItem(ShopItem(1957, 15)) #Onion
gnome_hudo.addItem(ShopItem(1952, 15)) #Potato

def first_click_npc_600(player):
    player.startChat(810824455)
    
def second_click_npc_600(player):
    player.getShop().openShop(41)
    
def chat_810824455(player):
    player.npcChat("Hi there, would you like to take a look at what I'm selling?")
    player.nextChat(810824456)

def chat_810824456(player):
    player.playerChat("Sure, show me what you have to offer!")
    player.nextChat(810824457)

def chat_810824457(player):
    player.getShop().openShop(41)
    player.endChat()