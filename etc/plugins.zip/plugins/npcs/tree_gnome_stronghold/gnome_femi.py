# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

World.addNonCombatNpc(676, 2461, 3379, 0, 1)

def first_click_npc_676(player):
    player.startChat(70910411)

def chat_70910411(player):
    player.playerChat("Hi there!")
    player.nextChat(70910412)

def chat_70910412(player):
    player.npcChat("Not now!")
    player.nextChat(70910413)

def chat_70910413(player):
    player.playerChat("What's wrong?")
    player.nextChat(70910414)

def chat_70910414(player):
    player.npcChat("What isn't wrong?! It's a disaster!")
    player.nextChat(70910415)

def chat_70910415(player):
    player.playerChat("Perhaps I should leave you alone...")
    player.endChat()

