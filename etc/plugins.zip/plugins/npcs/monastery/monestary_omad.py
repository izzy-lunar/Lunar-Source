#Author Kennedy

def chat_409341841(player):
    player.playerChat("Hello there. What's wrong?")
    player.nextChat(409341842)

def chat_409341842(player):
    player.npcChat("*yawn*... oh, hello... *yawn* I'm sorry! I'm just so tired!", "I haven't slept in a week!")
    player.nextChat(409341843)

def chat_409341843(player):
    player.dialogueOption("Why can't you sleep, what's wrong?", 1, "Sorry! I'm too busy to hear about your problems", 1)
    player.nextChat(409341844)

def chat_409341844(player):
    player.playerChat("Why can't you sleep, what's wrong?")
    player.nextChat(409341845)

def chat_409341845(player):
    player.npcChat("It's brother Androe's son! With his constant: Waaaaaah!", "Waaaaaaaah! Androe said it's natura, but it's so", "annoying!")
    player.nextChat(409341846)

def chat_409341846(player):
    player.playerChat("I suppose that's what kids do.")
    player.nextChat(409341847)

def chat_409341847(player):
    player.npcChat("He was fine, up until last week! Thieves broke in! They", "stole his favourite sleeping blanket!")
    player.nextChat(409341848)

def chat_409341848(player):
    player.npcChat("Now he won't rest until it's returned... ...and that", "means neither can I!")
    player.nextChat(409341849)

def chat_409341849(player):
    player.dialogueOption("Can I help at all?", 1, "I'm sorry to hear that! I hope you find his blanket.", 1)
    player.nextChat(409341850)

def chat_409341850(player):
    player.playerChat("Can I help at all?")
    player.nextChat(409341851)

def chat_409341851(player):
    player.npcChat("Please do. We won't be able to help you as we are", "peaceful men but we would be grateful for your help!")
    player.nextChat(409341852)

def chat_409341852(player):
    player.playerChat("Where are they?")
    player.getQuest(40).setStage(1)
    player.refreshQuestTab()
    player.nextChat(409341853)

def chat_409341853(player):
    player.npcChat("They hide in a secret cave in the forest. It's hidden", "under a ring of stones. Please, bring back the blanket!")
    player.endChat()

def chat_409341854(player):
    player.playerChat("I'm sorry to hear that! I hope you find his blanket.")
    player.endChat()

