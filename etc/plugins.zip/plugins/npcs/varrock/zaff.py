# NPC Config Script
# Zaff - 546
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

zaffs_superior_staves = Shop("Zaff's Superior Staves", 49)

zaffs_superior_staves.addItem(ShopItem(1381, 100))
zaffs_superior_staves.addItem(ShopItem(1383, 100))
zaffs_superior_staves.addItem(ShopItem(1385, 100))
zaffs_superior_staves.addItem(ShopItem(1387, 100))
zaffs_superior_staves.addItem(ShopItem(2415, 100))
zaffs_superior_staves.addItem(ShopItem(2416, 100))
zaffs_superior_staves.addItem(ShopItem(2417, 100))

World.addNonCombatNpc(546, 3203, 3435, 0, 1)

def first_click_npc_546(player): 
	player.startChat(9050)
	
def chat_9050(player):
	player.npcChat("Would you like to buy some staves?")
	player.nextChat(9051)
 
def chat_9051(player):
    player.dialogueOption("Yes, please!", 9052, "No, thank you.", 9053)
 
def chat_9052(player):
	player.getShop().openShop(49)
 
def chat_9053(player):
	player.playerChat("No, thank you.")
	player.endChat()
	
def second_click_npc_546(player): 
	player.getShop().openShop(49)

def third_click_npc_546(player):
	player.getShop().openShop(49)
