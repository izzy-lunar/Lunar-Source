# Brother Jered
# Brother Jered - 802
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(802, 3254, 3484, 0, 1)

def first_click_npc_802(player):
	player.startChat(65260)
	
def chat_65260(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(65261)
	
def chat_65261(player):
	player.npcChat("Hi " + str(player.playerName) + ", Welcome to the church of Saradomin!", "what can I help you with?")
	player.nextChat(65262)

def chat_65262(player):
	player.dialogueOption("Nothing much.", 65263, "I'm looking for quests!", 65264)
	
def chat_65263(player):
	player.playerChat("Nothing much, Jered.")
	player.endChat()
	
def chat_65264(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(65265)
	
def chat_65265(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(65266)	
	
def chat_65266(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()