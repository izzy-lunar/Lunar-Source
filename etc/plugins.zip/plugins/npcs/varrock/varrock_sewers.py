# Varrock Sewers Script
# Author Cam
from com.ownxile.core import World


#last 4 numbers = hp, maxhit, attack, defence

# Lesser Demons 
World.addCombatNpc(82, 3227, 9904, 0, 1, 70, 13, 80, 80)
World.addCombatNpc(82, 3223, 9906, 0, 1, 70, 13, 80, 80)
World.addCombatNpc(82, 3226, 9907, 0, 1, 70, 13, 80, 80)
World.addCombatNpc(82, 3229, 9905, 0, 1, 70, 13, 80, 80)
World.addCombatNpc(82, 3230, 9907, 0, 1, 70, 13, 80, 80)


#Zombies
World.addCombatNpc(73, 3235, 9867, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3240, 9866, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3252, 9869, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3225, 9874, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3221, 9861, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3244, 9879, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3244, 9892, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3240, 9915, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3269, 9915, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3197, 9888, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(73, 3201, 9890, 0, 1, 30, 4, 25, 20)


#Moss Giants
World.addCombatNpc(112, 3254, 9916, 0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3248, 9915, 0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3174, 9896, 0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3179, 9883, 0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3251, 9903, 0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3251, 9897,0, 1, 50, 8, 65, 25)
World.addCombatNpc(112, 3255, 9908, 0, 1, 50, 8, 65, 25)

#Fire Giants
World.addCombatNpc(110, 3280, 9905, 0, 1, 90, 13, 100, 80)
World.addCombatNpc(110, 3280, 9897, 0, 1, 90, 13, 100, 80)
World.addCombatNpc(110, 3281, 9889, 0, 1, 90, 13, 100, 80)
World.addCombatNpc(110, 3204, 9881, 0, 1, 90, 13, 100, 80)


#Black dragons
World.addCombatNpc(54, 3212, 9906, 0, 1, 150, 18, 150, 110)
World.addCombatNpc(54, 3206, 9906, 0, 1, 150, 18, 150, 110)
World.addCombatNpc(54, 3219, 9887, 0, 1, 150, 18, 150, 110)
