# Zamorak Mage
# Zamorak mage - 2258
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(2258, 3259, 3382, 0, 1)
World.addNonCombatNpc(553, 3252, 3404, 0, 1)

def first_click_npc_2258(player):
	player.startChat(554630)
	
def chat_554630(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(554631)
	
def chat_554631(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(554632)

def chat_554632(player):
	player.dialogueOption("Nothing much.", 554633, "I'm looking for quests!", 554634)
	
def chat_554633(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_554634(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(554635)
	
def chat_554635(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(554636)	
	
def chat_554636(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()