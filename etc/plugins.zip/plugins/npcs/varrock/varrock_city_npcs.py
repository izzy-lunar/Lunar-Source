# Varrock City NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# North guards
World.addCombatNpc(9, 3210, 3463, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3214, 3461, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3216, 3464, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3244, 3501, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3246, 3499, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3247, 3503, 0, 1, 30, 7, 10, 10)

# East guards
World.addCombatNpc(9, 3272, 3429, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3273, 3428, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3275, 3430, 0, 1, 30, 7, 10, 10)

# South guards
World.addCombatNpc(9, 3211, 3381, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3212, 3380, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3210, 3378, 0, 1, 30, 7, 10, 10)

# West guards specificed elsewhere

# Level 7 dark wizards
World.addCombatNpc(174, 3227, 3374, 0, 1, 15, 4, 6, 5)
World.addCombatNpc(174, 3230, 3372, 0, 1, 15, 4, 6, 5)
World.addCombatNpc(174, 3231, 3370, 0, 1, 15, 4, 6, 5)

# Level 20 dark wizards
World.addCombatNpc(172, 3223, 3369, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(172, 3226, 3361, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(172, 3219, 3372, 0, 1, 30, 7, 10, 10)

# Non combat
World.addNonCombatNpc(494, 3187, 3436, 0, 0)
World.addNonCombatNpc(494, 3187, 3438, 0, 0)
World.addNonCombatNpc(494, 3187, 3440, 0, 0)
World.addNonCombatNpc(494, 3187, 3442, 0, 0)
World.addNonCombatNpc(494, 3187, 3444, 0, 0)

#East bank
World.addNonCombatNpc(494, 3252, 3416, 0, 0)
World.addNonCombatNpc(494, 3252, 3418, 0, 0)
World.addNonCombatNpc(494, 3255, 3418, 0, 0)

#Men
World.addCombatNpc(1, 3253, 3461, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3256, 3462, 0, 1, 10, 2, 2, 2)