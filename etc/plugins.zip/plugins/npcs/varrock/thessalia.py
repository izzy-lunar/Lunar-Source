# NPC Config Script
# Thessalia - 548
# Author Robbie, Parrot & Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

thessalias_fine_clothes = Shop("Fine Clothes Store", 50)

thessalias_fine_clothes.addItem(ShopItem(1757, 50))
thessalias_fine_clothes.addItem(ShopItem(1005, 50))
thessalias_fine_clothes.addItem(ShopItem(1011, 100))
thessalias_fine_clothes.addItem(ShopItem(1013, 100))
thessalias_fine_clothes.addItem(ShopItem(1015, 100))
thessalias_fine_clothes.addItem(ShopItem(1007, 10))
thessalias_fine_clothes.addItem(ShopItem(950, 50))
thessalias_fine_clothes.addItem(ShopItem(1061, 25))
thessalias_fine_clothes.addItem(ShopItem(1059, 25))
thessalias_fine_clothes.addItem(ShopItem(1129, 25))

World.addNonCombatNpc(548, 3206, 3417, 0, 1)

def first_click_npc_548(player): 
	player.startChat(99200)
 
def chat_99200(player):
	player.npcChat("Would you like to buy some clothes?")
	player.nextChat(99201)
 
def chat_99201(player):
	player.dialogueOption("Perhaps, let me see what you're offering.", 99202, "No, thank you.", 99203)
 
def chat_99202(player):
	player.getShop().openShop(50)
 
def chat_99203(player):
	player.playerChat("No, thank you.")
	player.endChat()
 
def second_click_npc_548(player): 
	player.getShop().openShop(50)

def third_click_npc_548(player):
	player.getFunction().showInterface(3559)
	player.canChangeAppearance = True