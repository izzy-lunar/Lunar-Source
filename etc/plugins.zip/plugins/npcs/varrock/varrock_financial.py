# Financial agent - 4247
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(4247, 3239, 3476, 0, 1)

def first_click_npc_4247(player):
	player.startChat(32000)
	
def chat_32000(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(32001)
	
def chat_32001(player):
	player.npcChat("Hello " + str(player.playerName) + ", what brings you to the", "housing agency today?")
	player.nextChat(32002)

def chat_32002(player):
	player.dialogueOption("I'm just browsing around.", 32003, "I'm looking to purchase a house.", 32004)
	
def chat_32003(player):
	player.playerChat("I'm just browsing around.")
	player.endChat()
	
def chat_32004(player):
	player.playerChat("I'm looking to purchase a house.")
	player.nextChat(32005)
	
def chat_32005(player):
	player.npcChat("I'm sorry, we don't have any properties for sale", "perhaps come back another time.")
	player.nextChat(32006)	
	
def chat_32006(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()