# Varrock Curator Haig Halen
# Curator Haig Halen - 646
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(646, 3261, 3449, 0, 1)

def first_click_npc_646(player):
	player.startChat(32040)
	
def chat_32040(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + ", what is this place?")
	player.nextChat(32041)
	
def chat_32041(player):
	player.npcChat("Hello " + str(player.playerName) + " this is the Varrock museum of course, ", "what can I help you with?")
	player.nextChat(32042)

def chat_32042(player):
	player.dialogueOption("Oh, a Museum? Never mind then.", 32043, "I'm looking for a quest!", 32044)
	
def chat_32043(player):
	player.playerChat("Oh, a Museum? Never mind then.")
	player.endChat()
	
def chat_32044(player):
	player.playerChat("I'm looking for a quest!.")
	player.nextChat(32045)
	
def chat_32045(player):
	player.npcChat("Actually I may need your help sometime soon.", "Perhaps come back another time!")
	player.nextChat(32046)	
	
def chat_32046(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()