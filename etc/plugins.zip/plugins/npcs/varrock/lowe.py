# NPC Config Script
# Lowe - 550
# Author John and Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(550, 3232, 3424, 0, 1)

lowe_shop = Shop("Varrock Range Emporium", 60)

lowe_shop.addItem(ShopItem(1169, 10))
lowe_shop.addItem(ShopItem(1129, 10))
lowe_shop.addItem(ShopItem(1133, 10))
lowe_shop.addItem(ShopItem(1097, 10))

lowe_shop.addItem(ShopItem(6322, 10))
lowe_shop.addItem(ShopItem(6324, 10))
lowe_shop.addItem(ShopItem(6328, 10))

lowe_shop.addItem(ShopItem(1135, 10))
lowe_shop.addItem(ShopItem(1099, 10))
lowe_shop.addItem(ShopItem(1065, 10))

lowe_shop.addItem(ShopItem(2499, 10))
lowe_shop.addItem(ShopItem(2493, 10))
lowe_shop.addItem(ShopItem(2487, 10))

lowe_shop.addItem(ShopItem(2501, 10))
lowe_shop.addItem(ShopItem(2495, 10))
lowe_shop.addItem(ShopItem(2489, 10))

lowe_shop.addItem(ShopItem(2503, 10))
lowe_shop.addItem(ShopItem(2497, 10))
lowe_shop.addItem(ShopItem(2491, 10))


lowe_shop.addItem(ShopItem(841, 5))
lowe_shop.addItem(ShopItem(849, 5))
lowe_shop.addItem(ShopItem(853, 5))
lowe_shop.addItem(ShopItem(857, 5))

lowe_shop.addItem(ShopItem(861, 5))
lowe_shop.addItem(ShopItem(882, 5000))
lowe_shop.addItem(ShopItem(884, 5000))
lowe_shop.addItem(ShopItem(886, 5000))
lowe_shop.addItem(ShopItem(888, 5000))
lowe_shop.addItem(ShopItem(890, 5000))
lowe_shop.addItem(ShopItem(892, 5000))
lowe_shop.addItem(ShopItem(9142, 500))
lowe_shop.addItem(ShopItem(9143, 500))
lowe_shop.addItem(ShopItem(9144, 500))
 
def first_click_npc_550(player):
        player.startChat(11100)
def first_click_npc_5033(player):
        player.startChat(11100)
 
def second_click_npc_550(player):
        player.getShop().openShop(60)
def second_click_npc_5033(player):
        player.getShop().openShop(60)
 
def chat_11100(player):
        player.npcChat("Welcome to my ranging emporium.", "Do you want to see my wares?")
        player.nextChat(11101)
       
def chat_11101(player):
    player.dialogueOption("Yes please!", 11102, "No, I prefer to bash things close up.", 11103)
       
def chat_11102(player):
        player.getShop().openShop(60)
       
def chat_11103(player):
        player.playerChat("No, I prefer to bash things close up.")
        player.nextChat(11104)
       
def chat_11104(player):
        player.npcChat("Oh, well if you find someone who does want", " ranging supplies, please send them my way.")
        player.endChat()
