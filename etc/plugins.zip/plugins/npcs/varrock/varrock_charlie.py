# Charlie the tramp - 641
# Author Parrot & Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(641, 3208, 3392, 0, 0)

def first_click_npc_641(player):
	player.startChat(87710)
	
def chat_87710(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(87711)
	
def chat_87711(player):
	player.npcChat("Hi " + str(player.playerName) + ", can you spare some change?", "I'm starving!")
	player.nextChat(87712)

def chat_87712(player):
	player.dialogueOption("Here, have 10 gold coins.", 87713, "Sorry, I don't have anything spare.", 87714)
	
def chat_87713(player):
	if player.hasItem(995, 10):
		player.playerChat("Here, have 10 gold coins.")
		player.deleteItem(995, 10)
		player.nextChat(87716)
	else:	
		player.playerChat("Sorry, I don't have anything spare.")
		player.nextChat(87715)

def chat_87714(player):
	player.playerChat("Sorry, I don't have anything spare.")
	player.nextChat(87715)		

def chat_87715(player):
	player.npcChat("Don't worry about it, have a nice day.")
	player.endChat()
	
def chat_87716(player):
	player.npcChat("Thank you very much!")
	player.endChat()	