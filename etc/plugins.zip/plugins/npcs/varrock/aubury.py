#Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World
from com.ownxile.rs2.Point import Position

aubury_shop = Shop("Auburys Magic Shop", 52)
 
aubury_shop.addItem(ShopItem(554, 5000))
aubury_shop.addItem(ShopItem(555, 5000))
aubury_shop.addItem(ShopItem(556, 5000))
aubury_shop.addItem(ShopItem(557, 5000))
aubury_shop.addItem(ShopItem(558, 5000))
aubury_shop.addItem(ShopItem(559, 5000))
aubury_shop.addItem(ShopItem(560, 5000))
aubury_shop.addItem(ShopItem(562, 5000))
aubury_shop.addItem(ShopItem(563, 5000))
aubury_shop.addItem(ShopItem(564, 5000))
aubury_shop.addItem(ShopItem(565, 5000))
aubury_shop.addItem(ShopItem(566, 5000))
aubury_shop.addItem(ShopItem(9075, 5000))

aubury_spawn = World.addNonCombatNpc(553, 3253, 3401, 0, 1)

def chat_990359462(player):
    player.npcChat("Hello there, feel free to browse my shop.")
    player.nextChat(990359463)

def chat_990359463(player):
    player.playerChat("Okay then.")
    player.nextChat(990359464)
	
def first_click_npc_522(player):
	player.startChat(990359462)

def first_click_npc_553(player):
	player.startChat(10100)

def second_click_npc_553(player):
	player.getShop().openShop(52)

def third_click_npc_553(player):
	aubury_spawn.startAnimation(1818)
	aubury_spawn.gfx0(343)
	aubury_spawn.turnNpc(player.getX(), player.getY())
	aubury_spawn.forceChat("Senventior disthine molenko!")
	player.getTask().teleport(2911, 4832, 0)
	
def chat_10100(player):
	player.npcChat("Do you want to buy some runes?")
	player.nextChat(10101)

def chat_10101(player):
    player.dialogueOption("Yes please!", 10102, "Oh, it's a rune shop. No thank you, then.", 10103)
	
def chat_10102(player):
	player.getShop().openShop(52)
	
def chat_10103(player):
	player.playerChat("Oh, it's a rune shop. No thank you, then.")
	player.nextChat(10104)
	
def chat_10104(player):
	player.npcChat("Oh, well if you find someone who does want runes, please", "send them my way.")
	player.endChat()
	
	