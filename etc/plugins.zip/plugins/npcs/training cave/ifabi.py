
World.addNonCombatNpc(1436, 2780, 10077, 0, 1)#ifaba the monkey

def chat_1108453868(player):
    player.npcChat("Would you like to buy some food?")
    player.nextChat(1108453872)

def chat_1108453869(player):
    player.playerChat("Yes please monkey.")
    player.nextChat(1108453871)

def chat_1108453870(player):
    player.playerChat("From a stinking ape? I don't think so.")
    player.endChat()

def chat_1108453871(player):
    if player.getQuest(0).getStage() == 2:
        player.getTask().openShop(982)
        player.endChat()
    else:
        player.lastClickedNpcId = 944
        player.npcChat("Stay away from that dirty ape and come here!")
        player.turnPlayerTo(2776, 10072)
        player.endChat()
		

def chat_1108453872(player):
    player.dialogueOption("Yes", 1108453869, "No", 1108453870)
    
def first_click_npc_1436(player):
    player.startChat(1108453868)
    
def second_click_npc_1436(player):
    player.startChat(1108453871)

ifabas_food = Shop("Ifaba's Food", 982)
ifabas_food.addItem(ShopItem(2327, 100))
ifabas_food.addItem(ShopItem(6701, 100))