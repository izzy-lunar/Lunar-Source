
# Combat Instructor - 944
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(944, 2776, 10072, 0, 1)

def first_click_npc_944(player):
    quest_stage = player.getQuest(0).getStage()
    if quest_stage == 0: 
	  player.startChat(99400)
    else: 
	  player.startChat(99402)

	
def chat_99400(player):
	player.playerChat("Hey there, my name is " + str(player.playerName) + "!")
	player.nextChat(99401)
	
def chat_99401(player):
	player.npcChat("Hello there " + str(player.playerName) + ", what can I help such a young ", "adventurer like yourself with today?")
	player.nextChat(99402)

def chat_99402(player):
    quest_stage = player.getQuest(0).getStage()
    if quest_stage == 0: 
	    player.dialogueOption("How do I get to the mainland?", 1322037130, "I'm looking to become a great warrior!", 1322037132)
    elif quest_stage == 1 and player.hasItem(5976, 5): 
	    player.startChat(1570103201)
    elif quest_stage == 1:
	    player.startChat(1322037138)
    elif quest_stage == 2:#once quest is complete send q HaH
	    player.startChat(1321453391)
	
def chat_1322037130(player):
    player.playerChat("How can I get to the mainland?")
    player.nextChat(1322037131)

def chat_1322037131(player):
    player.npcChat("The town crier to the east should be capable of", "teleporting you there.")
    player.nextChat(99402)

def chat_1322037132(player):
    player.playerChat("I'm looking to beome a great warrior!")
    player.nextChat(1322037133)

def chat_1322037133(player):
    player.npcChat("Well you've come to the right place!")
    player.nextChat(1322037134)

def chat_1322037134(player):
    player.npcChat("I have a few tasks that should you choose to", "accept I could train you up to become a fine warrior", "like myself.")
    player.nextChat(1322037135)

def chat_1322037135(player):
    player.playerChat("Well I had imagined becoming a better warrior", "than the likes of you...")
    player.nextChat(1322037136)

def chat_1322037136(player):
    player.playerChat("... but I suppose that's a start.")
    player.nextChat(1322037137)

def chat_1322037137(player):
    player.npcChat("I'll pretend I didn't hear that!")
    player.nextChat(1322037138)

def chat_1322037138(player):
    player.npcChat("Those pesky @dre@Barbarians@bla@ to the south have been", "stealing @dre@Ifabas@bla@ precious coconuts. Could you please",  "slay them and bring back some of the stolen fruits?")
    player.nextChat(1322037139)

def chat_1322037139(player):
    player.npcChat("I'll be sure to reward you handsomely for", "your efforts!")
    player.nextChat(1322037140)

def chat_1322037140(player):
    player.playerChat("You've got yourself a deal, I'll be right on it!")
    player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(3250));
    player.getQuest(0).setStage(1)
    player.refreshQuestTab()
    player.endChat()
	
def chat_1570103201(player):
    player.playerChat("I've got some of those coconuts you wanted.")
    player.nextChat(1570103202)

def chat_1570103202(player):
    player.npcChat("Excellent work. You've exceeded my expectations!")
    player.nextChat(1570103203)

def chat_1570103203(player):
    player.playerChat("Ah, it was a piece of cake!")
    player.nextChat(1570103205)

def chat_1570103205(player):
    player.npcChat("Perhaps we can find more work for you, in the", "meantime here is your reward.")
    player.nextChat(1570103206)

def kill_npc_3250(player):
    if player.getQuest(0).getStage() == 1 and player.hasAttribute("barb_kills"):
        handle_barb_kill(player)
    else:
        player.addAttribute("barb_kills", 1)

def kill_npc_3246(player):
    if player.getQuest(0).getStage() == 1 and player.hasAttribute("barb_kills"):
        handle_barb_kill(player)
    else:
        player.addAttribute("barb_kills", 1)

def kill_npc_3261(player):
    if player.getQuest(0).getStage() == 1 and player.hasAttribute("barb_kills"):
        handle_barb_kill(player)
    else:
        player.addAttribute("barb_kills", 1)

def handle_barb_kill(player):
    if player.getAttribute("barb_kills") > 3:
        player.playerChat("I should take those 5 coconuts back to the", "combat instructor.")
        player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(944));
    else:
        player.addAttribute("barb_kills", player.getAttribute("barb_kills") + 1)
        player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(barb_ids[Misc.random(2)]));

barb_ids = [3246, 3250, 3261]
def chat_1570103206(player):#complete quest
    player.getQuest(0).setStage(2)
    player.addPoints(20)
    player.deleteItem(5976, 5)
    player.addItem(11037, 1)
    player.addItem(995, 200000)
    player.addItem(10586, 1)
    reward = QuestReward("Access to Ifabas food store,", "200,000 coins and 20 ox points,", "a combat experience lamp", "a brine sabre", "and 1 quest point.")
    player.completeQuest("Barbaric Troubles", reward, 11037)
