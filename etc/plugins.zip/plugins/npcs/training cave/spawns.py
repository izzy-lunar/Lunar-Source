World.addNonCombatNpc(5383, 2790, 10075, 0, 1)#odovacar
World.addNonCombatNpc(70, 2773, 10087, 0, 1)#turael
