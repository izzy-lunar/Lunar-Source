town_crier = World.addNonCombatNpc(945, 2785, 10071, 0, 1)

def first_click_npc_945(player):
    player.startChat(199283891)
def second_click_npc_945(player):
    player.startChat(199283890)

def chat_199283890(player):
    player.dialogueOption("Where am I?", 199283892, "How do I get to the home area?", 199283897, "Where can I get a slayer task?", 199283900, "Do you have anything for sale?", 217608)

def chat_199283891(player):
    player.npcChat("How can I help you " + str(player.playerName) + "?")
    player.nextChat(199283890)

def chat_199283892(player):
    player.playerChat("Where am I?")
    player.nextChat(199283893)

def chat_199283893(player):
    player.npcChat("This is the training cave, often newcomers to", "OwnXile like to use this place to prepare themselves", "for the real world exchanges of the outer world.")
    player.nextChat(199283894)

def chat_199283894(player):
    player.playerChat("What can I do here?")
    player.nextChat(199283895)

def chat_199283895(player):
    player.npcChat("There's a great deal of experience to be gained and loot",  "to be plundered. I believe the @dre@Combat Instructor@bla@ has a quest", "you may want to start to get yourself going.")
    player.nextChat(199283896)

def chat_199283896(player):
    player.npcChat("He often helps newcomers with financial support", "and gives them valuable experience in certain skills.")
    player.nextChat(199283890)

def chat_199283897(player):
    player.playerChat("How do I get to home?")
    player.nextChat(199283898)

def chat_199283898(player):
    player.npcChat("I can teleport you to the home area of Edgeville", "if you like.")
    player.nextChat(199283899)

def chat_199283899(player):
    player.dialogueOption("Teleport me to the home area.", 199283904, "I'm fine here thanks.", 58)

def chat_199283900(player):
    player.playerChat("Where can I get a slayer task?")
    player.nextChat(199283901)

def chat_199283901(player):
    player.npcChat("A man named @dre@Turael@bla@ north of here is offering various", "tasks that involve slaying some of the monsters and", "humanoids found in this very dungeon.")
    player.nextChat(199283902)
    
def chat_199283902(player):
    player.npcChat("You may wish to find one of the other slayer masters once", "you attain a higher level in the slayer skill as they",  "will offer greater rewards and experience.")
    player.nextChat(199283890)

def chat_199283904(player):
	town_crier.startAnimation(1818)
	town_crier.gfx0(343)
	town_crier.turnNpc(player.getX(), player.getY())
	player.getTask().teleport(3094, 3478, 0)
	player.endChat()