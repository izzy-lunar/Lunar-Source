# Party Room
# Knight - 5498
# Party Pete - 659
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World
from com.ownxile.rs2.world.games import PartyRoom

World.addNonCombatNpc(660, 2735, 3468, 0, 0)
World.addNonCombatNpc(660, 2736, 3468, 0, 0)
World.addNonCombatNpc(660, 2737, 3468, 0, 0)
World.addNonCombatNpc(660, 2738, 3468, 0, 0)
World.addNonCombatNpc(660, 2739, 3468, 0, 0)
World.addNonCombatNpc(660, 2740, 3468, 0, 0)
World.addNonCombatNpc(659, 2731, 3474, 0, 1)

def first_click_npc_660(player):
    if player.playerRights < 2:
        player.startChat(325660)
    
def chat_325660(player):
    player.npcChat("Party on!")
    player.endChat()

def first_click_npc_659(player):
    player.startChat(551450)
    
def chat_551450(player):
    player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
    player.nextChat(551451)
    
def chat_551451(player):
    player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
    player.nextChat(551452)

def chat_551452(player):
    player.dialogueOption("I want to make a party deposit", 551453, "I'm here to party!", 551454)
    
def chat_551453(player):
    player.playerChat("I want to make a party deposit.")
    player.nextChat(551456)
    
def chat_551456(player):
    player.npcChat("Sure!")
    player.nextChat(551457)
    
def chat_551456(player):
    player.endChat()
    #PartyRoom.open(player) needs patching for ironman mode and admin xfer

def chat_551454(player):
    player.playerChat("I'm here to party!")
    player.nextChat(551455)
    
def chat_551455(player):
    player.npcChat("Rock on!")
    player.nextChat(551457)

def chat_551457(player):
    player.dialogueQuestion("Release Balloons?", "Yes", 551458, "No", 0)

def chat_551458(player):
    #PartyRoom.dropAll()
    player.getFunction().closeAllWindows()