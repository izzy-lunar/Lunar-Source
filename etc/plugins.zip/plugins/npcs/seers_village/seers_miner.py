# Seers miner
# Miner - 5498
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(5498, 2698, 3506, 0, 1)

def first_click_npc_5498(player):
	player.startChat(325630)
	
def chat_325630(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(325631)
	
def chat_325631(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(325632)

def chat_325632(player):
	player.dialogueOption("Nothing much.", 325633, "I'm looking for quests!", 325634)
	
def chat_325633(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_325634(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(325635)
	
def chat_325635(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(325636)	
	
def chat_325636(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()