# Seers Bar
# Bartender = 1921
# Seer = 388
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1921, 2691, 3491, 0, 1)
World.addNonCombatNpc(388, 2695, 3495, 0, 1)
World.addNonCombatNpc(388, 2693, 3491, 0, 1)
World.addNonCombatNpc(388, 2696, 3497, 0, 1)

SeerBar_shop = Shop("Bar", 455)
SeerBar_shop.addItem(ShopItem(1917, 100))
SeerBar_shop.addItem(ShopItem(1993, 50))
SeerBar_shop.addItem(ShopItem(2015, 50))
SeerBar_shop.addItem(ShopItem(2017, 50))
SeerBar_shop.addItem(ShopItem(2019, 50))
SeerBar_shop.addItem(ShopItem(2021, 50))

def first_click_npc_388(player):
	player.startChat(181720)
	
def chat_181720(player):
	player.npcChat("Hey there, Adventurer.")
	player.endChat()
	
def second_click_npc_1921(player):
	player.getShop().openShop(455)
	
def first_click_npc_1921(player):
	player.startChat(181700)
	
def chat_181700(player):
	player.playerChat("Hello there, what is this place?")
	player.nextChat(181701)
	
def chat_181701(player):
	player.npcChat("Welcome to The Seers Beer! Would you like a drink?")
	player.nextChat(181702)
	
def chat_181702(player):
	player.dialogueOption("No thank you", 181703, "Sure!", 181704)
	
def chat_181703(player):
	player.playerChat("No thank you.")
	player.endChat()
	
def chat_181704(player):
	player.playerChat("Sure!")
	player.getShop().openShop(455)