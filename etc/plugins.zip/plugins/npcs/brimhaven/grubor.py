World.addNonCombatNpc(789, 2812, 3172, 0, 1)
