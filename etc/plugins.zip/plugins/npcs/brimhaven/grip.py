#sandy
World.addNonCombatNpc(792, 2774, 3191, 0, 1)