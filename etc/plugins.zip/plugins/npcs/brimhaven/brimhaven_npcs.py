#imps
World.addCombatNpc(709, 2804, 3157, 0, 0, 5, 2, 5, 5)

#thieves
World.addCombatNpc(9, 2815, 3159, 0, 0, 20, 4, 20, 20)

#pirates
World.addCombatNpc(9, 2803, 3162, 0, 0, 7, 50, 40, 40)

#sandy
World.addNonCombatNpc(3112, 2788, 3176, 0, 0)