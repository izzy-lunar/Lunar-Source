#sandy
World.addNonCombatNpc(788, 2776, 3185, 0, 1)