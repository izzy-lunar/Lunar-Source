World.addNonCombatNpc(794, 2796, 3192, 0, 1)
