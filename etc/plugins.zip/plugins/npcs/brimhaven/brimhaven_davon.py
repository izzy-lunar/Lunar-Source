World.addNonCombatNpc(588, 2803, 3152, 0, 0)
