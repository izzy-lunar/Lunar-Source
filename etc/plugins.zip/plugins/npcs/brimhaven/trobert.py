World.addNonCombatNpc(790, 2806, 3175, 0, 1)
