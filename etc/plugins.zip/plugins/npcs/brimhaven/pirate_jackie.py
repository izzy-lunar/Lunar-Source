World.addNonCombatNpc(1055, 2810, 3192, 0, 1)
