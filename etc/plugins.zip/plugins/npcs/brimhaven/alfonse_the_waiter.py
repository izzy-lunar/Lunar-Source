World.addNonCombatNpc(793, 2793, 3188, 0, 1)
