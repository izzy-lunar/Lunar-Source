from com.ownxile.rs2.world.transport import KaramjaCart

World.addNonCombatNpc(510, 2777, 3214, 0, 3)

def chat_504922695(player):
    player.npcChat("Hey there!")
    player.nextChat(504922696)

def chat_504922696(player):
    player.playerChat("Hi, what's your cart for?")
    player.nextChat(504922697)

def chat_504922697(player):
    player.npcChat("I use it to take customers down to", "the Shilo village")
    player.nextChat(504922698)

def chat_504922698(player):
    player.playerChat("Cool! Can I go?")
    player.nextChat(504922699)

def chat_504922699(player):
    player.npcChat("Sure thing.")
    player.nextChat(504922700)
	
def chat_504922700(player):
    travel_shilo(player)
    player.endChat()
	
def first_click_npc_510(player):
    startChat(504922695)
	
def second_click_npc_510(player):
    travel_shilo(player)

def travel_shilo(player):
	if player.hasItem(995, 1000):
		player.deleteItem(995, 1000)
		player.sendMessage("You pay a fare of 1000 coins to travel to Shilo village.")
		KaramjaCart.travel(player, 2834, 2952)		
	else:
		player.boxMessage("You need 1000 coins to travel to Shilo village.")