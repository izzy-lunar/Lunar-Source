World.addNonCombatNpc(846, 2791, 3182, 0, 1)
