# Yanille
# Author Cam
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Bankers
World.addNonCombatNpc(494, 2615, 3094, 0, 2)
World.addNonCombatNpc(494, 2615, 3092, 0, 2)
World.addNonCombatNpc(494, 2615, 3091, 0, 2)
#World.addObject(-1, 2961, 3389)

#Men
World.addCombatNpc(1, 2596, 3105, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 2570, 3081, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(3, 2550, 3079, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 2590, 3104, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(5, 2566, 3084, 0, 1, 10, 2, 1, 1)

#Soldier
World.addCombatNpc(35, 2546, 3092, 0, 1, 30, 4, 15, 15)
World.addCombatNpc(35, 2536, 3092, 0, 1, 30, 4, 15, 15)
World.addCombatNpc(35, 2551, 3084, 0, 1, 30, 4, 15, 15)
World.addCombatNpc(35, 2555, 3089, 0, 1, 30, 4, 15, 15)
World.addCombatNpc(35, 2535, 3091, 0, 1, 30, 4, 15, 15)
World.addCombatNpc(35, 2535, 3096, 0, 1, 30, 4, 15, 15)
