# Frank
# Bert - 3108
# Author Cam

World.addNonCombatNpc(3108, 2551, 3101, 0, 1)

# Test
# Author Cam
	
def click_item_10889(player):
	player.dialogueOption("Teleports", 21700711, "Equipment", 21700712, "Items", 21700713)
	
def chat_21700711(player):
	player.dialogueOption("Donator Island", 21700701, "Demonic Throne", 21700702, "Jail", 21700703)
	
def chat_21700701(player):
	player.getTask().teleport(3676, 2981, 0)
	
def chat_21700702(player):
	player.getTask().teleport(1994, 4489, 0)
	
def chat_21700703(player):
	player.getTask().teleport(2097, 4430, 0)
	
def chat_21700712(player):
	player.dialogueOption("Player Killing", 21700731, "Runes", 21700732, "Admin", 21700832)
	
def chat_21700731(player):
	player.addItem(4712)
	player.addItem(4714)
	player.addItem(6889)
	player.addItem(6914)
	player.addItem(10828)
	player.addItem(11724)
	player.addItem(11726)
	player.addItem(11732)
	player.addItem(7462)
	player.addItem(6570)
	player.addItem(4151)
	player.addItem(6585)
	player.addItem(6737)
	player.addItem(11283)
	player.addItem(11694)
	player.addItem(2436)
	player.addItem(2440)
	player.addItem(6685)
	player.addItem(3024, 3)
	
def chat_21700712(player):
	player.dialogueOption("Vengeance", 21700741, "Ice Barrage", 21700742)
	
def chat_21700742(player):
	player.addItem(565, 100000)
	player.addItem(555, 100000)
	player.addItem(560, 100000)
	
def chat_21700741(player):
	player.addItem(557, 100000)
	player.addItem(9075, 100000)
	player.addItem(560, 100000)

def chat_21700832(player):
	player.addItem(13896)
	player.addItem(13887)
	player.addItem(13893)
	player.addItem(13899)

def first_click_npc_3108(player):
	player.startChat(43745670)
	
def chat_43745670(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(43745671)
	
def chat_43745671(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with?")
	player.nextChat(43745672)

def chat_43745672(player):
	player.dialogueOption("Nothing much.", 43745673, "I'm looking for quests!", 43745674)
	
def chat_43745673(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_43745674(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(43745675)
	
def chat_43745675(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(43745676)	
	
def chat_43745676(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()