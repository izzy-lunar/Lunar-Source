
#Author Aram

blue = 52


red = 1589
chaos_druid = 181
ghost = 103
dust_devil = 6218
black_demon = 84
greater_demon = 83
skeleton = 93
fire = 110


#babyblues
World.addCombatNpc(blue, 3095, 9881, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3101, 9883, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3112, 9882, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3118, 9888, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3120, 9892, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3095, 9894, 0, 1, 60, 5, 90,90)
World.addCombatNpc(blue, 3097, 9909, 0, 1, 60, 5, 90,90)

#babyreds
World.addCombatNpc(red, 3109, 9909, 0, 1, 60, 5, 90,90)
World.addCombatNpc(red, 3123, 9909, 0, 1, 60, 5, 90,90)

#chaos_druids
World.addCombatNpc(chaos_druid, 3130, 9929, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3131, 9933, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3125, 9929, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3120, 9926, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3115, 9926, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3312, 9928, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3115, 9931, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3119, 9930, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3109, 9934, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3105, 9936, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3105, 9941, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3108, 9943, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3111, 9939, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(chaos_druid, 3111, 9935, 0, 1, 30, 5, 20, 20)

#ghosts
World.addCombatNpc(ghost, 3105, 9946, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(ghost, 3106, 9952, 0, 1, 30, 4, 25, 20)

#goraks
World.addCombatNpc(dust_devil, 3119, 9957, 0, 1, 120, 22, 150, 100)
World.addCombatNpc(dust_devil, 3119, 9951, 0, 1, 120, 22, 150, 100)
World.addCombatNpc(dust_devil, 3122, 9955, 0, 1, 120, 22, 150, 100)
World.addCombatNpc(dust_devil, 3128, 9949, 0, 1, 120, 22, 150, 100)
World.addCombatNpc(dust_devil, 3121, 9961, 0, 1, 120, 22, 150, 100)

World.addCombatNpc(5666, 3090, 9955, 0, 1, 600, 88, 500, 500)

#greater_demon
World.addCombatNpc(greater_demon, 3089, 9940, 0, 1, 60, 24, 150, 150)
World.addCombatNpc(greater_demon, 3086, 9935, 0, 1, 60, 24, 150, 150)

#skeleton
World.addCombatNpc(skeleton, 3140, 9908, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3144, 9900, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3146, 9888, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3151, 9875, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3142, 9869, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3137, 9871, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3138, 9878, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3141, 9876, 0, 1, 20, 8, 40, 30)
World.addCombatNpc(skeleton, 3124, 9877, 0, 1, 20, 8, 40, 30)

#fire demons
World.addCombatNpc(fire, 3119, 9843, 0, 1, 70, 30, 150, 150)
World.addCombatNpc(fire, 3109, 9841, 0, 1, 70, 30, 150, 150)
World.addCombatNpc(fire, 3114, 9835, 0, 1, 70, 30, 150, 150)
World.addCombatNpc(fire, 3105, 9829, 0, 1, 70, 30, 150, 150)

