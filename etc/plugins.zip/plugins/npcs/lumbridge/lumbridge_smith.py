# Lumbridge Furnace 
# Smith - 4904
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(4904, 3225, 3253, 0, 1)

def first_click_npc_4904(player):
	player.startChat(22740)
	
def chat_22740(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(22741)
	
def chat_22741(player):
	player.npcChat("Hi " + str(player.playerName) + ", I'm a little busy at the moment", "but what can I help you with?")
	player.nextChat(22742)

def chat_22742(player):
	player.dialogueOption("Nothing much.", 22743, "I'm looking for quests!", 22744)
	
def chat_22743(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_22744(player):
	player.playerChat("Can I help you with anything?")
	player.nextChat(22745)
	
def chat_22745(player):
	player.npcChat("Maybe if you come back a little later", "you may be of use.")
	player.nextChat(22746)	
	
def chat_22746(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()