# Lumbridge Farmer Brumty
# Author Parrot
from com.ownxile.core import World

brumty = World.addNonCombatNpc(291, 3226, 3290, 0, 1)

def first_click_npc_291(player): 
	brumty.forceChat("Get out of my house!")