# Lumbridge City NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

#Misc

World.addNonCombatNpc(2237, 3209, 3213, 0, 1)
World.addNonCombatNpc(2237, 3233, 3222, 0, 1)
World.addNonCombatNpc(0, 3222, 3223, 0, 1)
World.addCombatNpc(3, 3233, 3212, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(708, 3238, 3219, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3221, 3214, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 3236, 3201, 0, 1, 10, 2, 2, 2)

# Goblins
World.addCombatNpc(100, 3244, 3237, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3247, 3234, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3251, 3231, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3256, 3230, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3253, 3234, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3244, 3247, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3199, 3243, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3208, 3253, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3184, 3235, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3180, 3240, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3176, 3247, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(100, 3172, 3238, 0, 1, 7, 1, 1, 1)

# Giant Spiders
World.addCombatNpc(59, 3164, 3249, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3167, 3247, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3256, 3236, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3255, 3239, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3253, 3242, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3250, 3245, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3246, 3241, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3246, 3246, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3203, 3242, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3201, 3248, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3195, 3239, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3191, 3247, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3188, 3242, 0, 1, 7, 1, 1, 1)
World.addCombatNpc(59, 3188, 3251, 0, 1, 7, 1, 1, 1)

# Chicken
World.addCombatNpc(41, 3191, 3277, 0, 1, 3, 1, 1, 1)
World.addCombatNpc(41, 3189, 3278, 0, 1, 3, 1, 1, 1)
World.addCombatNpc(41, 3185, 3278, 0, 1, 3, 1, 1, 1)

# Rats
World.addCombatNpc(47, 3235, 3208, 0, 1, 2, 1, 1, 1)
World.addCombatNpc(47, 3218, 3208, 0, 1, 2, 1, 1, 1)
World.addCombatNpc(47, 3210, 3205, 0, 1, 2, 1, 1, 1)

# Men & Women
World.addCombatNpc(3, 3231, 3238, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(4, 3229, 3241, 0, 1, 10, 2, 2, 2)

# Giant rats
World.addCombatNpc(86, 3154, 3210, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3172, 3209, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3183, 3211, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3195, 3205, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3196, 3212, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3198, 3220, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3198, 3229, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3239, 3184, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3243, 3177, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3234, 3173, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3230, 3164, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3238, 3173, 0, 1, 7, 2, 1, 1)
World.addCombatNpc(86, 3162, 3210, 0, 1, 7, 2, 1, 1)

# General Store
World.addNonCombatNpc(522, 3209, 3245, 0, 1)
World.addNonCombatNpc(523, 3212, 3248, 0, 1)

# Sheep
World.addNonCombatNpc(43, 3210, 3260, 0, 1)
World.addNonCombatNpc(43, 3210, 3265, 0, 1)
World.addNonCombatNpc(43, 3209, 3271, 0, 1)
World.addNonCombatNpc(43, 3205, 3274, 0, 1)
World.addNonCombatNpc(43, 3204, 3267, 0, 1)
World.addNonCombatNpc(43, 3205, 3263, 0, 1)
World.addNonCombatNpc(43, 3203, 3259, 0, 1)
World.addNonCombatNpc(43, 3200, 3263, 0, 1)
World.addNonCombatNpc(43, 3200, 3269, 0, 1)
World.addNonCombatNpc(43, 3200, 3274, 0, 1)
World.addNonCombatNpc(43, 3196, 3272, 0, 1)
World.addNonCombatNpc(43, 3196, 3268, 0, 1)
World.addNonCombatNpc(43, 3195, 3262, 0, 1)

#Farmer
fromund = World.addNonCombatNpc(3917, 3258, 3310, 0, 1)

def first_click_npc_3917(player):
	fromund.forceChat("Don't step there, I just raked it!")