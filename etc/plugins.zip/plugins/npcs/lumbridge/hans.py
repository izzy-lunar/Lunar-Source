def chat_1771065956(player):
    player.npcChat("Hello. What are you doing here?")
    player.nextChat(1771065957)

def chat_1771065957(player):
    player.playerChat("I don't know. I'm lost. Where am I?")
    player.nextChat(1771065958)

def chat_1771065958(player):
    player.npcChat("You are in Lumbridge Castle.")
    player.endChat()