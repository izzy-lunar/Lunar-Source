# Lumbridge forest
# wilfred - 4906
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(4906, 3228, 3246, 0, 1)

def first_click_npc_4906(player):
	player.startChat(22750)
	
def chat_22750(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(22751)
	
def chat_22751(player):
	player.npcChat("Hi " + str(player.playerName) + ", I'm a little busy at the moment", "but what can I help you with?")
	player.nextChat(22752)

def chat_22752(player):
	player.dialogueOption("Nothing much.", 22753, "I'm looking for quests!", 22754)
	
def chat_22753(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_22754(player):
	player.playerChat("Can I help you with anything?")
	player.nextChat(22755)
	
def chat_22755(player):
	player.npcChat("Maybe if you come back a little later", "you may be of use")
	player.nextChat(22756)	
	
def chat_22756(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()