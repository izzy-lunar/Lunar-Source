sheer_animation = 894

def first_click_npc_43(player):
	dat_sheep = player.getFunction().getNpc()
	if dat_sheep.transformId == 42:
		player.sendMessage("This sheep has already been sheared.")
	else:
		player.startAnimation(sheer_animation)
		World.delayFunction("transform_sheep", player, 1)
		World.delayFunction("regrow_sheep", player, 50)

def transform_sheep(player):
	player.addItem(1737)
	player.sendMessage("You sheer the sheep and get some wool.")
	dat_sheep = player.getFunction().getNpc()
	dat_sheep.transform(42)
	dat_sheep.forceChat("Baa!")

def regrow_sheep(player):
	dat_sheep = player.getFunction().getNpc()
	dat_sheep.transform(43)
	dat_sheep.forceChat("Baa!")
