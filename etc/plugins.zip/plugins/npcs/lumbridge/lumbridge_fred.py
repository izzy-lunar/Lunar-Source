# Lumbridge Farmer Fred
# Author Parrot
from com.ownxile.core import World

fred = World.addNonCombatNpc(758, 3190, 3273, 0, 1)

def first_click_npc_758(player): 
	fred.forceChat("Damn kids stealing my chickens!")