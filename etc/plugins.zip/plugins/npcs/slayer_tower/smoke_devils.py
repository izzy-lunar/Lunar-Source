World.addCombatNpc(1625, 3416, 3547, 2, 1, 150, 10, 120,120)
World.addCombatNpc(1625, 3525, 3558, 2, 1, 150, 10, 120,120)
World.addCombatNpc(1625, 3430, 3559, 2, 1, 150, 10, 120,120)
World.addCombatNpc(1625, 3427, 3549, 2, 1, 150, 10, 120,120)
