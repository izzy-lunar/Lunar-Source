# Port Phasmatys npcs, doors
# Author Parrot
# npc id, x, y, height
from com.ownxile.core import World

# Bankers
World.addNonCombatNpc(1702, 3691, 3464, 0, 4)
World.addNonCombatNpc(1702, 3690, 3464, 0, 4)
World.addNonCombatNpc(1702, 3688, 3464, 0, 4)
World.addNonCombatNpc(1702, 3687, 3464, 0, 4)

# Ghost villagers
World.addNonCombatNpc(1697, 3673, 3469, 0, 1)
World.addNonCombatNpc(1697, 3675, 3502, 0, 1)
World.addNonCombatNpc(1697, 3696, 3464, 0, 1)
World.addNonCombatNpc(1697, 3662, 3503, 0, 1)

#tortured souls - outer city
World.addCombatNpc(1698, 3658, 3533, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1698, 3660, 3537, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1698, 3666, 3531, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1698, 3672, 3528, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1698, 3671, 3521, 0, 1, 50, 7, 50, 70)

ecto = 4278

def handle_west_barrier(player):     
    if player.getX() > 3652:
        player.getFunction().movePlayer(3652, player.getY(), 0)
        player.gfx100(867)
    else:
        player.getFunction().movePlayer(3653, player.getY(), 0)
        player.gfx100(867)
        
def handle_north_barrier(player):     
    if player.getY() > 3507:
        player.getFunction().movePlayer(player.getX(), 3507, 0)
        player.gfx100(867)
    else:
        player.getFunction().movePlayer(player.getX(), 3508, 0)
        player.gfx100(867)

def first_click_object_5259(player):
    player.startChat(2009900)

def third_click_object_5259(player):
    player.startChat(2009901)
    
def chat_2009900(player):
    if player.hasItem(ecto, 2):
        player.playerChat("It'll cost 2 Ecto-token's to pass this barrier!")
        player.nextChat(2009901)
    else:
        player.playerChat("I'll need 2 Ecto-token's before passing this barrier.")
        player.endChat()

def chat_2009901(player):
    player.dialogueOption("Pay 2 Ecto-token's to pass through the barrier", 2009903, "Leave it", 2009902)

def chat_2009902(player):
    player.endChat()    

def chat_2009903(player):
    if player.hasItem(ecto, 2):
        player.deleteItem(ecto, 2)    
        player.boxMessage("You pay 2 Ecto-token's to pass through the barrier.")
        if player.getY() > 3504:
            handle_north_barrier(player)
        else:
            handle_west_barrier(player)
    else:
        player.boxMessage("You need 2 Ecto-token's to pass through the barrier.")
        player.endChat()
        
def first_click_npc_1697(player):
    player.startChat(2009910)
    
def chat_2009910(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hello?! Can you hear me?")
        player.nextChat(2009913)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2009911(player):        
    player.playerChat("I don't have a clue what they just said.")
    player.nextChat(2009912)

def chat_2009912(player):     
    player.boxMessage("You'll need to wear an amulet of ghostspeak to interact with ghosts.")        
    player.endChat()
        
def chat_2009913(player):        
    player.playerChat("Yes, I can hear you. What's the problem?")
    player.nextChat(2009914)

def chat_2009914(player):
    player.npcChat("Oh my gosh! You can hear me?!")
    player.nextChat(2009915)       

def chat_2009915(player):       
    player.npcChat("What isn't the problem?! My beautiful home","was destroyed and now I'm a lonely ghost.")
    player.nextChat(2009916)   

def chat_2009916(player):        
    player.playerChat("What happened here?")
    player.nextChat(2009917)
        
def chat_2009917(player):       
    player.npcChat("A lot happened, young one.", "It makes me sad to think about it again...")
    player.nextChat(2009918)   
        
def chat_2009918(player):        
    player.playerChat("Perhaps I should leave you alone then.")
    player.endChat()        