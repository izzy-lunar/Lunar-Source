# Port Phasmatys Necrovarus
# Author Parrot
from com.ownxile.core import World

# Necrovarus
World.addNonCombatNpc(1684, 3660, 3497, 0, 1)

def first_click_npc_1684(player):
    player.startChat(2012000)
    
def chat_2012000(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hello?!")
        player.nextChat(2012001)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2012001(player):
    player.playerChat("Hi there.")
    player.nextChat(2012002)
    
def chat_2012002(player):
    player.npcChat("Woah, it's been a long time.")
    player.nextChat(2012003)
    
def chat_2012003(player):
    player.playerChat("What do you mean?")
    player.nextChat(2012004)    
    
def chat_2012004(player):
    player.npcChat("I haven't been able to talk to anyone in years.")
    player.nextChat(2012005)    
    
def chat_2012005(player):
    player.playerChat("What is this place?")
    player.nextChat(2012006)        
    
def chat_2012006(player):
    player.npcChat("This is the old stalls, it used to be very busy!")
    player.nextChat(2012007)        

def chat_2012007(player):
    player.npcChat("My stall used to be right here, those were the days...")
    player.nextChat(2012008)    
    
def chat_2012008(player):
    player.playerChat("What happened to it?", "Why isn't it very busy anymore?")
    player.nextChat(2012009)
    
def chat_2012009(player):
    player.npcChat("I don't really want to talk about it. It upsets me.")
    player.nextChat(2012010)

def chat_2012010(player):
    player.playerChat("Oh. Okay then.")
    player.endChat()        