# Port Phasmatys General Store
# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

# Shopkeeper
World.addNonCombatNpc(1699, 3659, 3477, 0, 1)

port_phasmatys_general = Shop("General Store", 92)
port_phasmatys_general.addItem(ShopItem(1925, 100))
port_phasmatys_general.addItem(ShopItem(1931, 100))
port_phasmatys_general.addItem(ShopItem(590, 75))
port_phasmatys_general.addItem(ShopItem(1755, 50))
port_phasmatys_general.addItem(ShopItem(2347, 50))
port_phasmatys_general.addItem(ShopItem(952, 50))
port_phasmatys_general.addItem(ShopItem(946, 50))

def first_click_npc_1699(player):
    player.startChat(2009960)

def second_click_npc_1699(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.getShop().openShop(92)
    else:
        player.playerChat("He doesn't seem interested in trading.")
        player.nextChat(2009912)
    
def chat_2009960(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hi, would you like to take a look at my supplies?")
        player.nextChat(2009961)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2009961(player):
    player.playerChat("Sure.")
    player.nextChat(2009962)

def chat_2009962(player):
    player.getShop().openShop(92)