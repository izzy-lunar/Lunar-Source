# Port Phasmatys Guard
# Author Parrot
from com.ownxile.core import World

# Guard
World.addNonCombatNpc(1706, 3661, 3507, 0, 0)
World.addNonCombatNpc(1706, 3652, 3484, 0, 2)

def first_click_npc_1706(player):
    player.startChat(2012040)
    
def chat_2012040(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Would you like to pass the barrier?")
        player.nextChat(2012044)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2012044(player):
    player.dialogueOption("Yes", 2012041, "No", 2012042)
    
def chat_2012041(player):
    player.playerChat("Yes please.")
    player.nextChat(2012043)
    
def chat_2012042(player):
    player.playerChat("No thank you.")
    player.endChat()    
    
def chat_2012043(player):
    player.npcChat("Okay, make sure you have 2 Ecto-token's before", "passing the barrier!")
    player.endChat()        