# Port Phasmatys Captain
# Author Parrot
from com.ownxile.core import World

# Captain
World.addNonCombatNpc(1704, 3703, 3487, 0, 2)

def first_click_npc_1704(player):
    player.startChat(2009990)
    
def chat_2009990(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hi, can I help you?")
        player.nextChat(2009991)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2009991(player):
    player.playerChat("Yes! Can I go on your boat?")
    player.nextChat(2009992)
    
def chat_2009992(player):
    player.npcChat("No sorry, not now.")
    player.nextChat(2009993)    
    
def chat_2009993(player):
    player.playerChat("Aw, okay then.")
    player.endChat()    