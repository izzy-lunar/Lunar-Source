# Port Phasmatys Inn keeper
# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

ghost_ale = Shop("Inn Keeper's Ale", 94)
ghost_ale.addItem(ShopItem(1905, 25))

# Inn Keeper (Barman)
World.addNonCombatNpc(1700, 3681, 3495, 0, 2)

def first_click_npc_1700(player):
    player.startChat(2009930)
    
def chat_2009930(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("How can I help you?")
        player.nextChat(2009931)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)

def chat_2009931(player):
    player.dialogueOption("Woah this place is really messy.", 2009932, "Have you got any beer for sale?", 2009937, "Have you got any place for me to stay?", 2009940)
    
def chat_2009932(player):
    player.playerChat("Woah this place is really messy.")
    player.nextChat(2009933)
    
def chat_2009933(player):
    player.npcChat("I know, it's really sad.")
    player.nextChat(2009934)    
    
def chat_2009934(player):
    player.playerChat("What happened here?!")
    player.nextChat(2009935)    
    
def chat_2009935(player):
    player.npcChat("I'd prefer not to talk about it.")
    player.nextChat(2009936)        
    
def chat_2009936(player):
    player.playerChat("Oh okay...")
    player.nextChat(2009931)
    
def chat_2009937(player):
    player.playerChat("Have you got any beer for sale?")
    player.nextChat(2009938)    
    
def chat_2009938(player):
    player.npcChat("I sure do, here's what I have to offer.")
    player.nextChat(2009939)    
    
def chat_2009939(player):
    player.getShop().openShop(94)
    player.endChat()        
    
def chat_2009940(player):
    player.playerChat("Have you got any place for me to stay?")
    player.nextChat(2009941)    
    
def chat_2009941(player):
    player.npcChat("No sorry, most of my building has been destroyed!")
    player.nextChat(2009942)        
    
def chat_2009942(player):
    player.playerChat("I'm sorry to hear it.")
    player.nextChat(2009931)    