# Port Phasmatys Velorina
# Author Parrot
from com.ownxile.core import World

# Velorina
World.addNonCombatNpc(1683, 3683, 3481, 0, 0)

def first_click_npc_1683(player):
    player.startChat(2009980)
    
def chat_2009980(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hello?!")
        player.nextChat(2009981)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2009981(player):
    player.playerChat("Hi there.")
    player.nextChat(2009982)
    
def chat_2009982(player):
    player.npcChat("Oh my gosh you can hear me?!", "It's been years since I last talked to someone.")
    player.nextChat(2009983)
    
def chat_2009983(player):
    player.playerChat("Yes I can! What's the problem?", "You seem a little unhappy...")
    player.nextChat(2009984)    
    
def chat_2009984(player):
    player.npcChat("Well I have no reason to be happy, look at me.")
    player.nextChat(2009985)    
    
def chat_2009985(player):
    player.playerChat("Is there anyway I can help you?")
    player.nextChat(2009986)        
    
def chat_2009986(player):
    player.npcChat("Maybe another time, I'm feeling a little", "emotional at the moment.")
    player.nextChat(2009987)        
    
def chat_2009987(player):
    player.playerChat("Okay, perhaps I'll come back another time.")
    player.endChat()        