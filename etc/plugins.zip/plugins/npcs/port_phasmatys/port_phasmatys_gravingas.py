# Port Phasmatys Gravingas
# Author Parrot
from com.ownxile.core import World

# Gravingas
World.addNonCombatNpc(1685, 3679, 3508, 0, 1)

def first_click_npc_1685(player):
    player.startChat(2012020)
    
def chat_2012020(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Hello?!")
        player.nextChat(2012021)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2012021(player):
    player.playerChat("Hello, how are you?")
    player.nextChat(2012022)
    
def chat_2012022(player):
    player.npcChat("I'm a little upset actually, thanks for asking.")
    player.nextChat(2012023)
    
def chat_2012023(player):
    player.playerChat("That's a shame. Is there anyway I can help?")
    player.nextChat(2012024)    
    
def chat_2012024(player):
    player.npcChat("Maybe if you come back later you could help me.")
    player.nextChat(2012025)    
    
def chat_2012025(player):
    player.playerChat("Okay!")
    player.endChat()