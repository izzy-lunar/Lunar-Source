# Author Parrot
from com.ownxile.core import World
from com.ownxile.rs2.world.transport import KaramjaCart

# Sailor
World.addNonCombatNpc(1703, 3709, 3497, 0, 2)

def first_click_npc_1703(player):
    player.startChat(2009970)
    
def first_click_object_11209(player):
    player.lastClickedNpcId = 1703
    player.startChat(2009970)    
    
def chat_2009970(player):
    if player.playerEquipment[player.playerAmulet] == 552:
        player.npcChat("Would you like to go to Catherby?")
        player.nextChat(2009971)
    else:
        player.npcChat("Wooo Woooo Wooooo!")
        player.nextChat(2009911)
        
def chat_2009971(player):
    player.dialogueOption("Yes please!", 2009973, "No thank you.", 2009972)
    
def chat_2009972(player):
    player.playerChat("No thank you.")
    player.endChat()      

def chat_2009973(player):
    player.playerChat("Yes please!")
    player.nextChat(2009974)    
    
def chat_2009974(player):
    player.npcChat("It'll cost 5,000 coins, is that okay?")
    player.nextChat(2009975)     
    
def chat_2009975(player):
    player.dialogueOption("Pay 5,000 coins", 2009977, "Leave", 2009976)    
    
def chat_2009976(player):
    player.playerChat("No thank you.")
    player.endChat() 

def chat_2009977(player):
    if player.hasItem(995, 5000):
        player.deleteItem(995, 5000)
        player.playerChat("Here you go.")
        player.nextChat(2009979)       
    else:    
        player.playerChat("Sorry, I don't have 5,000 coins on me at the moment.")
        player.nextChat(2009978)      
        
def chat_2009978(player):
    player.npcChat("Not to worry, see you later.")
    player.endChat() 

def chat_2009979(player):
    player.endChat()
    KaramjaCart.travel(player, 2804, 3421)