tutors = [705, 1861, 4707]

combat_tutor = 705
ranged_tutor = 1861
mage_tutor = 4707

extras = ["a sword and shield", "a bow and arrows", "some basic runes"]

short_names = ["Equipment", "Ammo", "Runes"]

def get_tutor_index(npc):
    for i in tutors:
        if tutors[i] == npc:
            return i
		
def get_short_name(npc):
    return short_names(get_tutor_index(npc))
def get_extra(npc):
    return extras(get_tutor_index(npc))

def handle_claim(player):
    npc_index = get_tutor_index(player.lastClickedNpcId)
    if npc_index == combat_tutor:
        handle_combat_claim(player)
    elif npc_index == ranged_tutor:
        handle_range_claim(player)
    elif npc_index == mage_tutor:
        handle_mage_claim(player)
		
def chat_395184986(player):
    player.npcChat("Hello, I am the " + str(World.getNpcHandler().getNpcName(player.lastClickedNpcId)) + "!")
    player.nextChat(395184987)

def chat_395184987(player):
    player.npcChat("I can provide you with " + str(get_extra(player.lastClickedNpcId)) + ".")
    player.nextChat(395184988)

def chat_395184988(player):
    player.dialogueQuestion("Accept " + str(get_short_name(player.lastClickedNpcId)), "Yes I would like some please.", 395184989, "No thanks", 58)
    player.nextChat(395184989)

def chat_395184989(player):
    player.playerChat("I'll take " + str(get_extra(player.lastClickedNpcId)) + "!")
    player.nextChat(395184990)

def chat_395184990(player):
    player.npcChat("Here you go.")
    player.nextChat(395184991)

def chat_395184991(player):
    handle_claim(player)
    player.endChat()

def first_click_npc_705(player):
    player.startChat(395184986)
def first_click_npc_1861(player):
    player.startChat(395184986)
def first_click_npc_4707(player):
    player.startChat(395184986)
