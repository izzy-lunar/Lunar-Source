# Hairdresser - 598
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

hairdresser_shop = Shop("Hairdresser's Hats", 95)

hairdresser_shop.addItem(ShopItem(6382, 100))
hairdresser_shop.addItem(ShopItem(656, 100))
hairdresser_shop.addItem(ShopItem(658, 100))
hairdresser_shop.addItem(ShopItem(660, 100))
hairdresser_shop.addItem(ShopItem(662, 100))
hairdresser_shop.addItem(ShopItem(664, 100))
hairdresser_shop.addItem(ShopItem(740, 100))
hairdresser_shop.addItem(ShopItem(2900, 100))
hairdresser_shop.addItem(ShopItem(2910, 100))
hairdresser_shop.addItem(ShopItem(2920, 100))
hairdresser_shop.addItem(ShopItem(2930, 100))
hairdresser_shop.addItem(ShopItem(2940, 100))
hairdresser_shop.addItem(ShopItem(2978, 100))
hairdresser_shop.addItem(ShopItem(2979, 100))
hairdresser_shop.addItem(ShopItem(2980, 100))
hairdresser_shop.addItem(ShopItem(2981, 100))
hairdresser_shop.addItem(ShopItem(2982, 100))
hairdresser_shop.addItem(ShopItem(2983, 100))
hairdresser_shop.addItem(ShopItem(2978, 100))

World.addNonCombatNpc(598, 2945, 3379, 0, 1)

def first_click_npc_598(player): 
	player.startChat(10250)
	
def chat_10250(player):
	player.npcChat("Hello! Would you like to purchase", "some hats?")
	player.nextChat(10251)
 
def chat_10251(player):
    player.dialogueOption("Let's have a look!", 10252, "No, thank you.", 10253)
 
def chat_10252(player):
	player.getShop().openShop(95)
 
def chat_10253(player):
	player.playerChat("No, thank you.")
	player.endChat()