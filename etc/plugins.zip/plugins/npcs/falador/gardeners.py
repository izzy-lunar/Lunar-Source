# NPC Config Script
# Gardener - 1217
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1217, 2996, 3381, 0, 1)
World.addNonCombatNpc(1217, 3007, 3372, 0, 1)
World.addNonCombatNpc(1217, 3015, 3386, 0, 1)
World.addNonCombatNpc(25, 2991, 3383, 0, 1)
World.addNonCombatNpc(153, 3003, 3378, 0, 1)
World.addNonCombatNpc(153, 2993, 3388, 0, 1)
World.addNonCombatNpc(153, 2985, 3384, 0, 1)
World.addNonCombatNpc(154, 3012, 3373, 0, 1)
World.addNonCombatNpc(155, 3016, 3383, 0, 1)
World.addNonCombatNpc(156, 3013, 3381, 0, 1)
World.addNonCombatNpc(1830, 3015, 3382, 0, 1)

def first_click_npc_1217(player):
	player.startChat(11000)
	
def chat_11000(player):
	player.npcChat("What a lovely day it is today!")
	player.nextChat(11001)
	
def chat_11001(player):
	player.playerChat("Yes, indeed it is!")
	player.endChat()

def first_click_npc_25(player):
	player.startChat(11500)
	
def chat_11500(player):
	player.npcChat("The view of the park is delightful.")
	player.nextChat(11501)
	
def chat_11501(player):
	player.playerChat("It's a beautiful sight.")
	player.endChat()