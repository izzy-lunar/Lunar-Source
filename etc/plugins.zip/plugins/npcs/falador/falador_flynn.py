#Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(580, 2950, 3387, 0, 0)

flynn_shop = Shop("Flynn's Jewels", 2574)
flynn_shop.addItem(ShopItem(1623, 5))
flynn_shop.addItem(ShopItem(1621, 5))
flynn_shop.addItem(ShopItem(1619, 5))
flynn_shop.addItem(ShopItem(1617, 5))

def first_click_npc_580(player):
    player.getShop().openShop(2574)

def second_click_npc_580(player):
    player.startChat(607705)
    
def chat_607705(player):
    player.npcChat("Welcome to my shop.", "Would you like to buy anything?")
    player.nextChat(607706)
    
def chat_607706(player):
    player.dialogueOption("Sure, I'll have a look.", 6077007, "No thanks.", 607708)
    
def chat_6077007(player):
    player.getShop().openShop(2574)
    
def chat_607708(player):
    player.playerChat("No thanks.")
    player.endChat()