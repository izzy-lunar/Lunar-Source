# Wayne = 581
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(581, 2972, 3369, 0, 1)

Wayne_shop = Shop("Wayne's Smithing Emporium", 93)

Wayne_shop.addItem(ShopItem(2347, 100))
Wayne_shop.addItem(ShopItem(1265, 10))
Wayne_shop.addItem(ShopItem(1267, 10))
Wayne_shop.addItem(ShopItem(1269, 10))
Wayne_shop.addItem(ShopItem(1273, 10))
Wayne_shop.addItem(ShopItem(1271, 10))
Wayne_shop.addItem(ShopItem(1275, 10))
Wayne_shop.addItem(ShopItem(436, 50))
Wayne_shop.addItem(ShopItem(438, 50))
Wayne_shop.addItem(ShopItem(453, 50))
Wayne_shop.addItem(ShopItem(2349, 25))
Wayne_shop.addItem(ShopItem(2351, 25))
Wayne_shop.addItem(ShopItem(2355, 25))
Wayne_shop.addItem(ShopItem(2357, 25))

def first_click_npc_581(player):
	player.startChat(78915)

def chat_78915(player):
	player.npcChat("Welcome to my shop.", "Would you like to buy anything?")
	player.nextChat(78916)

def chat_78916(player):
	player.dialogueOption("Sure, I'll have a look.", 78917, "No thanks.", 78918)

def chat_78917(player):
	player.getShop().openShop(93)

def chat_78918(player):
	player.playerChat("No thanks.")
	player.endChat()

def second_click_npc_581(player):
	player.getShop().openShop(93)