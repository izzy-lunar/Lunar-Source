# Falador dwarves
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Attackable
World.addCombatNpc(118, 3023, 3338, 0, 1, 15, 4, 5, 5)
World.addCombatNpc(118, 3021, 3341, 0, 1, 15, 4, 5, 5)
World.addCombatNpc(118, 3016, 3338, 0, 1, 15, 4, 5, 5)
World.addCombatNpc(121, 3019, 3333, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(121, 3011, 3336, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(121, 3012, 3341, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(121, 3016, 3346, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(121, 3022, 3345, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(121, 3027, 3340, 0, 1, 30, 7, 10, 10)

# Non attackable (Quest start)
World.addNonCombatNpc(232, 3024, 3344, 0, 0)
World.addNonCombatNpc(382, 3014, 3343, 0, 1)
World.addNonCombatNpc(382, 3017, 3335, 0, 1)

#Two dwarves
def first_click_npc_382(player):
	player.startChat(98000)
	
def chat_98000(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(98001)
	
def chat_98001(player):
	player.npcChat("What do you want?")
	player.nextChat(98002)	
	
def chat_98002(player):
	player.dialogueOption("Nothing.", 98003, "I'm looking for a quest!", 98004)	

def chat_98003(player):
	player.playerChat("Nothing.")
	player.endChat()

def chat_98004(player):
	player.playerChat("I'm looking for a quest!")
	player.nextChat(98005)	
	
def chat_98005(player):
	player.npcChat("You should talk to Austri...", "He may be able to sort something out.")
	player.nextChat(98006)	
	
def chat_98006(player):
	player.playerChat("Where can I find him?")
	player.nextChat(98007)		
	
def chat_98007(player):
	player.npcChat("He likes to hang around the barrels in this courtyard.")
	player.nextChat(98008)	

def chat_98008(player):
	player.playerChat("I'll have a look for him.")
	player.endChat()

#Austri the dwarf
def first_click_npc_232(player):
	player.startChat(98100)
	
def chat_98100(player):
	player.playerChat("Hello, have you got any quests for me?")
	player.nextChat(98101)
	
def chat_98101(player):
	player.npcChat("I could do with some help actually.", "I'm busy at the moment though, perhaps another time.")
	player.nextChat(98102)	
	
def chat_98102(player):
	player.playerChat("Sure.")
	player.endChat()