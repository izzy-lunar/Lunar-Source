# Drogo = 579
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(579, 2973, 3311, 0, 1)

Drogo_shop = Shop("Drogo's Chainbody Emporium", 107)
Drogo_shop.addItem(ShopItem(1103, 25))
Drogo_shop.addItem(ShopItem(1101, 25))
Drogo_shop.addItem(ShopItem(1105, 25))
Drogo_shop.addItem(ShopItem(1107, 25))
Drogo_shop.addItem(ShopItem(1109, 25))
Drogo_shop.addItem(ShopItem(1111, 25))
Drogo_shop.addItem(ShopItem(1113, 25))

def first_click_npc_579(player):
    player.startChat(44405)
	
def chat_44405(player):
    player.npcChat("Welcome to my shop.", "Would you like to buy anything?")
    player.nextChat(44406)
       
def chat_44406(player):
    player.dialogueOption("Sure, I'll have a look.", 44407, "No thanks.", 44408)
       
def chat_44407(player):
    player.getShop().openShop(107)
       
def chat_44408(player):
    player.playerChat("No thanks.")

def second_click_npc_579(player):
    player.getShop().openShop(107)