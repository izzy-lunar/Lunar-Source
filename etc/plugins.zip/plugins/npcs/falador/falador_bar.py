# Fally Bar
# Bartender 733
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

#Attackable
World.addCombatNpc(3227, 2958, 3375, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3222, 2957, 3372, 0, 1, 10, 2, 2, 2)
#Non attackable
#Bartender added in One Small Favour
World.addNonCombatNpc(617, 2958, 3370, 0, 1)
World.addNonCombatNpc(615, 2956, 3372, 0, 1)

def first_click_npc_615(p):
	p.sendMessage("The student is too drunk to talk, you nod your head and walk away.")

def first_click_npc_617(p):
	p.sendMessage("The student is too drunk to talk, you nod your head and walk away.")
	
def first_click_npc_3222(p):
	p.sendMessage("The man is too drunk to talk, you nod your head and walk away.")	

def chat_18100(player):
	player.playerChat("Hey, how are you?")
	player.nextChat(18101)
	
def chat_18101(player):
	player.npcChat("Hi, I'm pretty busy at the moment.")
	player.nextChat(18102)

def chat_18102(player):
	player.dialogueOption("Okay.", 18103, "I can see that! Can I help at all?", 18104)

def chat_18103(player):
	player.playerChat("Okay.")
	player.endChat()

def chat_18104(player):
	player.playerChat("I can see that! Can I help at all?")
	player.nextChat(18105)
	
def chat_18105(player):
	player.npcChat("Not right now, maybe another time?")
	player.nextChat(18106)	
	
def chat_18106(player):
	player.playerChat("I'll come by again soon.")
	player.endChat()