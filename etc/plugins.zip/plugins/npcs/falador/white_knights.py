# Falador white knights
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Yellow (38)
World.addCombatNpc(3348, 2964, 3351, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(3348, 2965, 3347, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(3348, 2967, 3343, 0, 1, 35, 10, 15, 30)
# Green (39)
#Added in One Small Favour
# Blue (42)
World.addCombatNpc(3350, 2978, 3344, 0, 1, 40, 13, 17, 30)
World.addCombatNpc(3350, 2978, 3339, 0, 1, 40, 13, 17, 30)
World.addCombatNpc(3350, 2973, 3340, 0, 1, 40, 13, 17, 30)
# Blue talkable (36)
World.addCombatNpc(1092, 2961, 3352, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(1092, 2960, 3338, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(1092, 2988, 3335, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(1092, 2979, 3349, 0, 1, 35, 10, 15, 30)
World.addCombatNpc(1092, 2968, 3351, 0, 1, 35, 10, 15, 30)

# Non attackable (Quest start)
#World.addNonCombatNpc(605, 2957, 3337, 0, 1)
#Added in One Small Favour

#White knights
def first_click_npc_1092(player):
	player.startChat(98200)
	
def chat_98200(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(98201)
	
def chat_98201(player):
	player.npcChat("What do you want?")
	player.nextChat(98202)	
	
def chat_98202(player):
	player.dialogueOption("Nothing.", 98203, "I'm looking for a quest!", 98204)	

def chat_98203(player):
	player.playerChat("Nothing.")
	player.endChat()

def chat_98204(player):
	player.playerChat("I'm looking for a quest!")
	player.nextChat(98205)	
	
def chat_98205(player):
	player.npcChat("You should talk to Sir Vyvin...", "He may be able to sort something out.")
	player.nextChat(98206)	
	
def chat_98206(player):
	player.playerChat("Where can I find him?")
	player.nextChat(98207)		
	
def chat_98207(player):
	player.npcChat("He's normally in the west side of the Falador castle.")
	player.nextChat(98208)	

def chat_98208(player):
	player.playerChat("I'll have a look for him.")
	player.endChat()

#Sir Vyvin
#def first_click_npc_605(player):
#	player.startChat(98300)
#	
#def chat_98300(player):
#	player.playerChat("Hello, have you got any quests for me?")
#	player.nextChat(98301)
#	
#def chat_98301(player):
#	player.npcChat("I could do with some help actually.", "I'm busy at the moment though, perhaps another time.")
#	player.nextChat(98302)	
	
def chat_98302(player):
	player.playerChat("Sure.")
	player.endChat()