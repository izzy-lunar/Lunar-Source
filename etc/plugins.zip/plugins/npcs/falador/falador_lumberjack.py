# Lumberjack - 1395
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1395, 2951, 3411, 0, 0)

def first_click_npc_1395(player):
	player.startChat(99820)
	
def chat_99820(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(99821)
	
def chat_99821(player):
	player.npcChat("Hi " + str(player.playerName) + ", my name is Leif what can I help you with?")
	player.nextChat(99822)

def chat_99822(player):
	player.dialogueOption("Nothing much.", 99823, "I'm looking for a quest!", 99824)
	
def chat_99823(player):
	player.playerChat("Nothing much.")
	player.endChat()	
	
def chat_99824(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(99825)
	
def chat_99825(player):
	player.npcChat("I'm afraid I can't help you then", "Maybe if you come back another time...")
	player.nextChat(99826)	
	
def chat_99826(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()