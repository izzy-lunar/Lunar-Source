# Cassie - 577
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

cassie_shop = Shop("Cassie's Shield Shop", 97)

cassie_shop.addItem(ShopItem(1171, 100))
cassie_shop.addItem(ShopItem(1173, 100))
cassie_shop.addItem(ShopItem(1175, 100))
cassie_shop.addItem(ShopItem(1191, 100))
cassie_shop.addItem(ShopItem(1177, 100))
cassie_shop.addItem(ShopItem(1193, 100))
cassie_shop.addItem(ShopItem(1179, 100))
cassie_shop.addItem(ShopItem(1195, 100))
cassie_shop.addItem(ShopItem(1181, 100))
cassie_shop.addItem(ShopItem(1197, 100))
cassie_shop.addItem(ShopItem(1183, 100))
cassie_shop.addItem(ShopItem(1199, 100))
cassie_shop.addItem(ShopItem(1185, 100))
cassie_shop.addItem(ShopItem(1201, 100))

World.addNonCombatNpc(577, 2974, 3383, 0, 1)

def first_click_npc_577(player): 
    player.startChat(10300)
    
def chat_10300(player):
    player.npcChat("Would you like to purchase some shields?")
    player.nextChat(10301)
 
def chat_10301(player):
    player.dialogueOption("Yes, please!", 10302, "No thanks.", 10303)
 
def chat_10302(player):
    player.getShop().openShop(97)
 
def chat_10303(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def second_click_npc_577(player): 
    player.getShop().openShop(97)