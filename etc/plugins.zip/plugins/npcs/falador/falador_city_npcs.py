# Falador City NPCS (Guards, Men, Woman & Bankers)
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

#tiffy cashien
World.addNonCombatNpc(2290, 2996, 3373, 0, 0)

# North guards
World.addCombatNpc(9, 2965, 3394, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 2967, 3392, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 2966, 3395, 0, 1, 30, 7, 10, 10)

# South guards
World.addCombatNpc(9, 3006, 3323, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3008, 3322, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(9, 3007, 3325, 0, 1, 30, 7, 10, 10)

# Men
World.addCombatNpc(1, 3046, 3346, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3027, 3354, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 3040, 3365, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 2991, 3366, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3037, 3344, 0, 1, 10, 2, 2, 2)

# Women
World.addCombatNpc(4, 3037, 3363, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(5, 3049, 3342, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 3048, 3362, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(6, 3050, 3357, 0, 1, 10, 2, 2, 2)

# East Bank
World.addNonCombatNpc(494, 3010, 3353, 0, 4)
World.addNonCombatNpc(494, 3011, 3353, 0, 4)
World.addNonCombatNpc(494, 3012, 3353, 0, 4)
World.addNonCombatNpc(494, 3013, 3353, 0, 4)
World.addNonCombatNpc(494, 3014, 3353, 0, 4)
World.addNonCombatNpc(494, 3015, 3353, 0, 4)
World.addNonCombatNpc(494, 3020, 3353, 0, 4)

# West Bank
World.addNonCombatNpc(494, 2945, 3366, 0, 4)
World.addNonCombatNpc(494, 2946, 3366, 0, 4)
World.addNonCombatNpc(494, 2947, 3366, 0, 4)
World.addNonCombatNpc(494, 2948, 3366, 0, 4)
World.addNonCombatNpc(494, 2949, 3366, 0, 4)