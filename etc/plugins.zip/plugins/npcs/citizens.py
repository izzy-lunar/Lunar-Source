# Author Parrot
from com.ownxile.core import World

#Man 1
def first_click_npc_1(player):
	player.startChat(96050)
	
def chat_96050(player):
	player.npcChat("Hey stranger.")
	player.endChat()

#Man 2
def first_click_npc_2(player):
	player.startChat(96051)
	
def chat_96051(player):
	player.npcChat("Hey stranger.")
	player.endChat()
	
#Man 3
def first_click_npc_3(player):
	player.startChat(96052)
	
def chat_96052(player):
	player.npcChat("Hey stranger.")
	player.endChat()
	
#Woman 4
def first_click_npc_4(player):
	player.startChat(96053)
	
def chat_96053(player):
	player.npcChat("Do I know you?")
	player.endChat()
	
#Woman 5
def first_click_npc_5(player):
	player.startChat(96054)
	
def chat_96054(player):
	player.npcChat("Do I know you?")
	player.endChat()

#Woman 6
def first_click_npc_6(player):
	player.startChat(96055)
	
def chat_96055(player):
	player.npcChat("Do I know you?")
	player.endChat()	
	
#Woman 25
def first_click_npc_25(player):
	player.startChat(95050)
	
def chat_95050(player):
	player.npcChat("Sorry, I can't talk right now.")
	player.endChat()		