# Al-Kharid City NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Al-Kharid Guards
World.addCombatNpc(18, 3307, 3205, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3305, 3202, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3307, 3196, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3300, 3167, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3302, 3171, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3300, 3174, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3301, 3177, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3284, 3167, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3286, 3170, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3283, 3173, 0, 1, 15, 5, 7, 7)
World.addCombatNpc(18, 3283, 3176, 0, 1, 15, 5, 7, 7)
# Men
World.addCombatNpc(1, 3295, 3205, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3291, 3203, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(3, 3274, 3193, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(1, 3278, 3187, 0, 1, 10, 2, 2, 2)
World.addCombatNpc(2, 3304, 3188, 0, 1, 10, 2, 2, 2)
# Muggers
World.addCombatNpc(175, 3296, 3125, 0, 1, 13, 3, 3, 3)
World.addCombatNpc(175, 3296, 3122, 0, 1, 13, 3, 3, 3)
# Shantay guard
World.addCombatNpc(837, 3304, 3118, 0, 1, 30, 7, 10, 10)
World.addCombatNpc(837, 3302, 3119, 0, 1, 30, 7, 10, 10)
# Scorpions
World.addCombatNpc(107, 3285, 3140, 0, 1, 17, 6, 8, 8)
World.addCombatNpc(107, 3290, 3140, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3294, 3141, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3298, 3245, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3296, 3278, 0, 1, 17, 6, 8, 8)
World.addCombatNpc(107, 3302, 3281, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3302, 3277, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3300, 3272, 0, 1, 15, 6, 8, 8)
# General store
World.addNonCombatNpc(522, 3316, 3184, 0, 1)
World.addNonCombatNpc(523, 3314, 3179, 0, 1)
# Bank
World.addNonCombatNpc(494, 3267, 3169, 0, 3)
World.addNonCombatNpc(494, 3267, 3168, 0, 3)
World.addNonCombatNpc(494, 3267, 3167, 0, 3)
World.addNonCombatNpc(494, 3267, 3166, 0, 3)
World.addNonCombatNpc(494, 3267, 3164, 0, 3)
# Camels
World.addNonCombatNpc(80, 3297, 3227, 0, 1)
World.addNonCombatNpc(80, 3294, 3221, 0, 1)

#Shantay guard
def first_click_npc_837(player):
	player.startChat(97000)
	
def chat_97000(player):
	player.npcChat("Go away!")
	player.endChat()

#Camel
def first_click_npc_80(player):
	player.startChat(97050)
	
def chat_97050(player):
	player.sendMessage("The camel just looks at you as you try and talk to it.")
	player.endChat()