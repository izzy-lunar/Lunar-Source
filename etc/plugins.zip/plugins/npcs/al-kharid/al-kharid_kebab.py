# Ali the Kebab seller
# Ali the Kebab seller = 1865
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1865, 3274, 3182, 0, 1)

Dommik_shop = Shop("Ali's kebab house", 177)
Dommik_shop.addItem(ShopItem(1971, 100))
Dommik_shop.addItem(ShopItem(2011, 100))
Dommik_shop.addItem(ShopItem(1917, 100))

def first_click_npc_1865(player):
	player.startChat(72915)

def chat_72915(player):
	player.npcChat("Welcome to my kebab house,", "Would you like anything to eat?")
	player.nextChat(72916)

def chat_72916(player):
	player.dialogueOption("Sure, I'll have a look at the menu.", 72917, "No thanks.", 72918)

def chat_72917(player):
	player.getShop().openShop(177)

def chat_72918(player):
	player.playerChat("No thanks.")
	player.endChat()