# NPC Config Script
# Daga - 1434
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

daga_shop = Shop("Daga's Scimitar Shop", 99)

daga_shop.addItem(ShopItem(1321, 100))
daga_shop.addItem(ShopItem(1323, 100))
daga_shop.addItem(ShopItem(1325, 100))
daga_shop.addItem(ShopItem(1327, 100))
daga_shop.addItem(ShopItem(1329, 100))
daga_shop.addItem(ShopItem(1331, 100))
daga_shop.addItem(ShopItem(1333, 100))
daga_shop.addItem(ShopItem(4587, 100))

World.addNonCombatNpc(1434, 3288, 3189, 0, 1)

def first_click_npc_1434(player): 
	player.startChat(11600)
	
def chat_11600(player):
	player.npcChat("Ook Ook!")
	player.nextChat(11601)
 
def chat_11601(player):
	player.playerChat("I think he's trying to sell me something.")
	player.endChat()

def second_click_npc_1434(player): 
	player.getShop().openShop(99)