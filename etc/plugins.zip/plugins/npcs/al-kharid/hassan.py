# Hassan Al-Kharid
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary

World.addNonCombatNpc(923, 3298, 3162, 0, 1)

def first_click_npc_923(player):
	player.startChat(97300)

def chat_97300(player):
	player.playerChat("Hello, have you got any quests for me?")
	player.nextChat(97301)

def chat_97301(player):
	player.npcChat("I could do with some help actually.", "I'm busy at the moment though, perhaps another time.")
	player.nextChat(97302)	

def chat_97302(player):
	player.playerChat("Sure.")
	player.endChat()