# Gemstall
# Author Parrot
from com.ownxile.core import World

market_seller = World.addNonCombatNpc(1866, 3286, 3210, 0, 1)

def first_click_npc_1866(player): 
	market_seller.forceChat("Selling the highest quality gems!")

def second_click_npc_1866(player): 
	player.sendMessage("There's something wrong with these gems..")