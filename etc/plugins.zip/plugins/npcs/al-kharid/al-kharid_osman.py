# Osman
# Osman - 924
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(924, 3288, 3180, 0, 1)

def first_click_npc_924(player):
	player.startChat(83650)
	
def chat_83650(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(83651)
	
def chat_83651(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(83652)

def chat_83652(player):
	player.dialogueOption("Nothing much.", 83653, "I'm looking for quests!", 83654)
	
def chat_83653(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_83654(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(83655)
	
def chat_83655(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(83656)	
	
def chat_83656(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()