# Camel quest layout
# Camel 1873
# Ali the camel keeper 1367
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1873, 3287, 3232, 0, 1)
World.addNonCombatNpc(1867, 3292, 3235, 0, 1)

def second_click_npc_1873(player): 
	player.sendMessage("The camel attempts to bite you!")
	
def second_click_npc_1867(player): 
	player.sendMessage("Ali has nothing to offer at the moment.")	
	
def first_click_npc_1867(player):
	player.startChat(18170)
	
def chat_18170(player):
	player.playerChat("Hey, how are you?")
	player.nextChat(18171)
	
def chat_18171(player):
	player.npcChat("Hi, I'm pretty busy at the moment.")
	player.nextChat(18172)
	
def chat_18172(player):
	player.dialogueOption("Okay.", 18173, "I can see that! Can I help at all?", 18174)
	
def chat_18173(player):
	player.playerChat("Okay.")
	player.endChat()
	
def chat_18174(player):
	player.playerChat("I can see that! Can I help at all?")
	player.nextChat(18175)
	
def chat_18175(player):
	player.npcChat("Not right now, maybe another time?")
	player.nextChat(18176)	
	
def chat_18176(player):
	player.playerChat("I'll come by again soon.")
	player.endChat()