# Dommik's Crafting Store
# Dommik = 545
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(545, 3321, 3194, 0, 1)

Dommik_shop = Shop("Dommik's Crafting Store", 247)
Dommik_shop.addItem(ShopItem(1755, 100))
Dommik_shop.addItem(ShopItem(1592, 10))
Dommik_shop.addItem(ShopItem(1597, 10))
Dommik_shop.addItem(ShopItem(1595, 10))
Dommik_shop.addItem(ShopItem(1599, 10))
Dommik_shop.addItem(ShopItem(1592, 10))
Dommik_shop.addItem(ShopItem(2976, 10))
Dommik_shop.addItem(ShopItem(1734, 1000))
Dommik_shop.addItem(ShopItem(1741, 50))
Dommik_shop.addItem(ShopItem(1059, 10))
Dommik_shop.addItem(ShopItem(1061, 10))
Dommik_shop.addItem(ShopItem(1095, 10))
Dommik_shop.addItem(ShopItem(1167, 10))

def second_click_npc_545(player):
	player.getShop().openShop(247)

def first_click_npc_545(player):
	player.startChat(30915)

def chat_30915(player):
	player.npcChat("Welcome to my shop,", "Would you like to buy anything?")
	player.nextChat(30916)

def chat_30916(player):
	player.dialogueOption("Sure, I'll have a look.", 30917, "No thanks.", 30918)

def chat_30917(player):
	player.getShop().openShop(247)

def chat_30918(player):
    player.playerChat("No thanks.")
    player.endChat()