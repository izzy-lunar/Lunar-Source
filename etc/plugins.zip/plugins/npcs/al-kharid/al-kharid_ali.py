# Ali Morrisane's item emporium
# Ali M = 1862
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1862, 3304, 3212, 0, 1)

AliM_shop = Shop("Ali Morrisane's item emporium", 477)
AliM_shop.addItem(ShopItem(1931, 30))
AliM_shop.addItem(ShopItem(1935, 10))
AliM_shop.addItem(ShopItem(1825, 30))
AliM_shop.addItem(ShopItem(1833, 10))
AliM_shop.addItem(ShopItem(1837, 10))
AliM_shop.addItem(ShopItem(1925, 30))
AliM_shop.addItem(ShopItem(4593, 10))
AliM_shop.addItem(ShopItem(4591, 10))
AliM_shop.addItem(ShopItem(970, 50))
AliM_shop.addItem(ShopItem(946, 10))
AliM_shop.addItem(ShopItem(590, 25))
AliM_shop.addItem(ShopItem(468, 3))
AliM_shop.addItem(ShopItem(6382, 5))
AliM_shop.addItem(ShopItem(689, 2))

def first_click_npc_1862(player):
	player.startChat(77915)

def chat_77915(player):
	player.npcChat("Welcome to my shop.", "Would you like to buy anything?")
	player.nextChat(77916)

def chat_77916(player):
	player.dialogueOption("Sure, I'll have a look.", 77917, "No thanks.", 77918)

def chat_77917(player):
	player.getShop().openShop(477)

def chat_77918(player):
	player.playerChat("No thanks.")
	player.endChat()