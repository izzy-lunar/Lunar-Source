# Sorceress
# sorceress - 5531
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(5531, 3320, 3139, 0, 1)

def first_click_npc_5531(player):
	player.startChat(337490)
	
def chat_337490(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(337491)
	
def chat_337491(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(337492)

def chat_337492(player):
	player.dialogueOption("Nothing much.", 337493, "I'm looking for quests!", 337494)
	
def chat_337493(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_337494(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(337495)
	
def chat_337495(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(337496)	
	
def chat_337496(player):
	player.playerChat("I'll look forward to it.")
	player.endChat()