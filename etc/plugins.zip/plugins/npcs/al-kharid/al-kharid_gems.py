# Gem Shop Shop
# Gem Trader = 540
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(540, 2945, 3335, 0, 1)

Gem_shop = Shop("Gem Shop", 117)
Gem_shop.addItem(ShopItem(1625, 25))
Gem_shop.addItem(ShopItem(1609, 25))
Gem_shop.addItem(ShopItem(1611, 25))
Gem_shop.addItem(ShopItem(1627, 25))
Gem_shop.addItem(ShopItem(1613, 25))
Gem_shop.addItem(ShopItem(1629, 25))
Gem_shop.addItem(ShopItem(413, 25))

def first_click_npc_540(player):
    player.startChat(69105)
	
def chat_69105(player):
    player.npcChat("Welcome to the gem shop,", "Would you like to buy anything?")
    player.nextChat(69106)
       
def chat_69106(player):
    player.dialogueOption("Sure, I'll have a look.", 69107, "No thanks.", 69108)
       
def chat_69107(player):
    player.getShop().openShop(117)
       
def chat_69108(player):
    player.playerChat("No thanks.")
    player.endChat()