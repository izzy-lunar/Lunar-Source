# NPC Config Script
# Ranael - 544
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

ranael_shop = Shop("Ranael's Plateskirt Shop", 101)

ranael_shop.addItem(ShopItem(1087, 10))
ranael_shop.addItem(ShopItem(1081, 10))
ranael_shop.addItem(ShopItem(1083, 10))
ranael_shop.addItem(ShopItem(1089, 10))
ranael_shop.addItem(ShopItem(1085, 10))
ranael_shop.addItem(ShopItem(1091, 10))
ranael_shop.addItem(ShopItem(1093, 10))

World.addNonCombatNpc(544, 3315, 3163, 0, 1)

def first_click_npc_544(player): 
	player.startChat(11750)
	
def chat_11750(player):
	player.npcChat("Would you like to purchase some plateskirts?")
	player.nextChat(11751)
 
def chat_11751(player):
    player.dialogueOption("Yes, please!", 11752, "No thanks.", 11753)
 
def chat_11752(player):
	player.getShop().openShop(101)
 
def chat_11753(player):
	player.playerChat("No thanks.")
	player.endChat()

def second_click_npc_544(player): 
	player.getShop().openShop(101)