# Ellis the Tanner - 2824
# Author Cam

World.addNonCombatNpc(2824, 3274, 3191, 0, 1)

def first_click_npc_2824(player):
	player.startChat(54120)
	
def second_click_npc_2824(player):
    player.getTan().setupInterface()
	
def chat_54120(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(54121)
	
def chat_54121(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with", "this fine day?")
	player.nextChat(54122)

def chat_54122(player):
	player.dialogueOption("Nothing much.", 54123, "Can you tan my hides?", 54124)
	
def chat_54123(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_54124(player):
	player.playerChat("Can you tan my hides?")
	player.nextChat(54125)
	
def chat_54125(player):
	player.npcChat("Certainly!")
	player.nextChat(54126)	
	
def chat_54126(player):
	player.getTan().setupInterface()
	player.endChat()