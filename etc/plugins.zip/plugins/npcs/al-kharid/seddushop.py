# NPC Config Script
# Seddu - 3038
# Author Ferret
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

seddu_shop = Shop("Seddu's Platelegs Shop", 100)

seddu_shop.addItem(ShopItem(1075, 10))
seddu_shop.addItem(ShopItem(1067, 10))
seddu_shop.addItem(ShopItem(1069, 10))
seddu_shop.addItem(ShopItem(1077, 10))
seddu_shop.addItem(ShopItem(1071, 10))
seddu_shop.addItem(ShopItem(1073, 10))
seddu_shop.addItem(ShopItem(1079, 10))

World.addNonCombatNpc(3038, 3316, 3175, 0, 1)

def first_click_npc_3038(player): 
	player.startChat(11650)
	
def chat_11650(player):
	player.npcChat("Would you like to purchase some platelegs?")
	player.nextChat(11651)
 
def chat_11651(player):
    player.dialogueOption("Yes, please!", 11652, "No thanks.", 11653)
 
def chat_11652(player):
	player.getShop().openShop(100)
 
def chat_11653(player):
	player.playerChat("No thanks.")
	player.endChat()

def second_click_npc_3038(player): 
	player.getShop().openShop(100)