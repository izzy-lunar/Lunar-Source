
from com.ownxile.core import World

World.addNonCombatNpc(592, 2596, 3406, 0, 1)

World.addNonCombatNpc(495, 2584, 3422, 0, 3)
World.addNonCombatNpc(494, 2584, 3421, 0, 3)
World.addNonCombatNpc(495, 2584, 3419, 0, 3)
World.addNonCombatNpc(494, 2584, 3418, 0, 3)
