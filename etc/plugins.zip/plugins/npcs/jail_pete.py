# Prison Pete - 3118
# Author Cam

World.addNonCombatNpc(3118, 2091, 4428, 0, 1)

def first_click_npc_3118(player):
	player.startChat(877210)
	
def chat_877210(player):
	player.playerChat("How do I get out of here?!")
	player.nextChat(877211)
	
def chat_877211(player):
	player.npcChat("Ah, " + str(player.playerName) + ", it appears you've been breaking", "the OwnXile rules!")
	player.nextChat(877212)
	
def chat_877212(player):
	player.npcChat("In order for you to get released you need to make an", " appeal on the official OwnXile forums.")
	player.nextChat(877213)
	
def chat_877213(player):
	player.npcChat("Whilst your appeal is being processed, please read the","official OwnXile rules.")
	player.nextChat(877214)
		
def chat_877214(player):
	player.playerChat("Thanks for your help.")
	player.endChat()