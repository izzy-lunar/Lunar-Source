##################################
###      Author: Eisenhower    ###
###       Date:12.11.2013      ###
##################################

#Guards
World.addCombatNpc(253, 2565, 3149, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2568, 3148, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2565, 3143, 0, 1, 15, 5, 10, 7)

#Barman
World.addNonCombatNpc(259, 2565, 3140, 0, 1)

def first_click_npc_253(player):
    player.startChat(1933987899)

def chat_1933987899(player):
    player.playerChat("Hello!")
    player.nextChat(1933987900)

def chat_1933987900(player):
    player.npcChat("I don't know you, stranger! Get off our land.")
    player.endChat()
    
def first_click_npc_259(player):
    player.startChat(1933987901)
    
def chat_1933987901(player):
    player.playerChat("Hello")
    player.nextChat(1933987902)

def chat_1933987902(player):
    player.npcChat("Hi, what can I get you? We have a range of quality", "brews.")
    player.nextChat(1933987903)

def chat_1933987903(player):
    player.dialogueOption("I'll have a beer please.", 1933987904, "Got any news?", 1933987905)

# Have a beer    
def chat_1933987904(player):
    player.playerChat("I'll have a beer please.")
    player.nextChat(1933987906)

def chat_1933987906(player):
    if player.hasItem(995, 2):
        player.deleteItem(995, 2)
        player.addItem(1917, 1)
        player.npcChat("There you go, that'll be two gold coins.")
        player.nextChat(1933987908)     
    else:
        player.npcChat("That'll be 2 coins please.")
        player.nextChat(1933987907)         

def chat_1933987907(player):
    player.playerChat("Oh, sorry. I don't have enough money on me.")
    player.endChat()    
    
def chat_1933987908(player):
    player.playerChat("Thank you.")
    player.endChat()    
            
# Ask about news   
def chat_1933987905(player):
    player.playerChat("Got any news?")
    player.nextChat(1933987909)

def chat_1933987909(player):
    player.npcChat("If you want to see the action around here you should", "visit the famous Khazard fight arena. I've seen some grand battles in my time. Ogres, goblins, even dragons", "have fought there.")
    player.nextChat(1933987910)

def chat_1933987910(player):
    player.npcChat("Although you have to feel sorry for some of the slaves", "sent in there.")
    player.endChat()

