##################################
###      Author: Eisenhower    ###
###       Date:12.11.2013      ###
##################################

#Guards
World.addCombatNpc(253, 2577, 3156, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2580, 3146, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2606, 3174, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2594, 3177, 0, 1, 15, 5, 10, 7)

World.addCombatNpc(254, 2582, 3142, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2588, 3140, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2597, 3140, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2617, 3141, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2615, 3150, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2610, 3149, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2608, 3146, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2618, 3157, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2618, 3162, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2618, 3129, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(254, 2616, 3174, 0, 1, 15, 5, 10, 7)

#Prisoners
def first_click_npc_263(player):
    player.startChat(481410044)
World.addNonCombatNpc(263, 2598, 3143, 0, 1)
def first_click_npc_262(player):
    player.startChat(481410045)
World.addNonCombatNpc(262, 2594, 3143, 0, 1)
World.addNonCombatNpc(262, 2615, 3159, 0, 1)
World.addNonCombatNpc(262, 2615, 3164, 0, 1)
def first_click_npc_260(player):
    player.startChat(481410046)
World.addNonCombatNpc(260, 2589, 3143, 0, 1)
def first_click_npc_265(player):
    player.startChat(481410047)
World.addNonCombatNpc(265, 2615, 3168, 0, 1)

def first_click_object_82(player):
    player.lastClickedNpcId = 253
    player.startChat(481410040)
    
def first_click_object_81(player):
    player.lastClickedNpcId = 253
    player.startChat(481410040)    
    
def first_click_object_79(player):
    player.lastClickedNpcId = 253
    player.startChat(481410041)    

def first_click_object_80(player):
    player.lastClickedNpcId = 253
    player.startChat(481410041)   
    
def chat_481410040(player):
    player.npcChat("Oi! It's private in there.")
    player.endChat()

def chat_481410041(player):
    player.npcChat("Stay away from the prisoners!")
    player.endChat()
  
# Restricted Guards
def first_click_npc_254(player):
    player.startChat(481410042)
                
def chat_481410042(player):
    player.npcChat("This is a restricted area, leave now!")
    player.nextChat(481410043)

def chat_481410043(player):
    player.npcChat("OUT! And don't come back.")
    player.endChat()

# Prisoners
def chat_481410044(player):
    player.npcChat("Help! Get me out of here.")
    player.endChat()

def chat_481410045(player):
    player.npcChat("Psst. Help me!")
    player.endChat()

def chat_481410046(player):
    player.npcChat("I've had enough in here. Help!")
    player.endChat()

def chat_481410047(player):
    player.npcChat("Please, get me out of here.")
    player.endChat()

