##################################
###      Author: Eisenhower    ###
###       Date:12.11.2013      ###
##################################

#Ogres
World.addCombatNpc(270, 2609, 3166, 0, 1, 50, 10, 50, 45)
World.addCombatNpc(270, 2609, 3163, 0, 1, 50, 10, 50, 45)
World.addCombatNpc(270, 2609, 3159, 0, 1, 50, 10, 50, 45)

World.addCombatNpc(253, 2589, 3193, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2601, 3194, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2610, 3193, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2608, 3185, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2607, 3182, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2611, 3182, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2597, 3182, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2599, 3183, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2594, 3186, 0, 1, 15, 5, 10, 7)
World.addCombatNpc(253, 2591, 3182, 0, 1, 15, 5, 10, 7)

