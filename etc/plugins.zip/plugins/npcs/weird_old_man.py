def first_click_npc_1152(player):
    player.startChat(16)