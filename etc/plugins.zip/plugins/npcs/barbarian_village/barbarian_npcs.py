# Barbarian Village
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Male Barbarian
World.addCombatNpc(12, 3097, 3421, 0, 1, 30, 4, 20, 20)
World.addCombatNpc(12, 3089, 3422, 0, 1, 30, 4, 25, 25)
World.addCombatNpc(12, 3086, 3420, 0, 1, 30, 4, 25, 25)
World.addCombatNpc(12, 3083, 3415, 0, 1, 30, 4, 25, 25)
World.addCombatNpc(12, 3078, 3419, 0, 1, 30, 4, 25, 25)
World.addCombatNpc(12, 3080, 3425, 0, 1, 30, 4, 25, 25)
World.addCombatNpc(12, 3086, 3424, 0, 1, 30, 4, 25, 25)

# Female Barbarian
World.addCombatNpc(3261, 3096, 3420, 0, 1, 30, 5, 25, 25)
World.addCombatNpc(3261, 3084, 3408, 0, 1, 30, 5, 25, 25)
World.addCombatNpc(3261, 3076, 3414, 0, 1, 30, 5, 25, 25)
World.addCombatNpc(3261, 3072, 3418, 0, 1, 30, 5, 25, 25)

# Fishing spots
World.addNonCombatNpc(309, 3110, 3432, 0, 0)
World.addNonCombatNpc(310, 3110, 3433, 0, 0)
World.addNonCombatNpc(309, 3104, 3425, 0, 0)
World.addNonCombatNpc(310, 3104, 3424, 0, 0)

# Male Barbarian

def first_click_npc_3246(player):
	player.startChat(87050)
def first_click_npc_3250(player):
	player.startChat(87050)
	
def first_click_npc_12(player):
	player.startChat(87050)
	
def chat_87050(player):
	player.npcChat("What do you want outsider?")
	player.nextChat(87051)
	
def chat_87051(player):
	player.playerChat("Nothing.")
	player.endChat()
	
# Female Barbarian
def first_click_npc_3261(player):
	player.startChat(87090)
	
def chat_87090(player):
	player.npcChat("What are you looking at?")
	player.endChat()