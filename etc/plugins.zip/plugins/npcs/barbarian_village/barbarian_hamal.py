# Hamal the Chieftain
# Hamal the Chieftain - 1807
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1807, 3079, 3444, 0, 1)
World.addCombatNpc(5364, 3079, 3440, 0, 1, 99, 40, 85, 90)

def first_click_npc_1807(player):
	player.startChat(6451200)
	
def chat_6451200(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(6451201)
	
def chat_6451201(player):
	player.npcChat("Hi " + str(player.playerName) + ", What can I help you with, outlander?")
	player.nextChat(6451202)

def chat_6451202(player):
	player.dialogueOption("Nothing much.", 6451203, "I'm looking for quests!", 6451204)
	
def chat_6451203(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_6451204(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(6451205)
	
def chat_6451205(player):
	player.npcChat("Defeat my champion", "and you will prove yourself worthy!")
	player.nextChat(6451206)	
	
def chat_6451206(player):
	player.playerChat("It will be done, Hamal")
	player.endChat()