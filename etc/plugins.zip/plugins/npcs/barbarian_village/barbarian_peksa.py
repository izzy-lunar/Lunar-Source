# Peksa
# Peksa = 538
# Author Cam

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(538, 3077, 3431, 0, 1)

Peksa_shop = Shop("Helmet Shop", 248)
Peksa_shop.addItem(ShopItem(3755, 100))
Peksa_shop.addItem(ShopItem(3751, 100))
Peksa_shop.addItem(ShopItem(3753, 100))
Peksa_shop.addItem(ShopItem(3749, 100))

def second_click_npc_538(player):
    player.getShop().openShop(248)

def first_click_npc_538(player):
    player.startChat(17891315)
    
def chat_17891315(player):
    player.npcChat("Welcome to my stall,", "Would you like to buy anything?")
    player.nextChat(17891316)
       
def chat_17891316(player):
    player.dialogueOption("Sure, I'll have a look.", 17891317, "No thanks.", 17891318)
       
def chat_17891317(player):
    player.getShop().openShop(248)
       
def chat_17891318(player):
    player.playerChat("No thanks.")
    player.endChat()