def first_click_npc_5613(player):
    player.npcTalk("wat")
    player.endChat()
	
def second_click_npc_5613(player):
    player.npcChat("i got no food 4 u kid")
    player.endChat()