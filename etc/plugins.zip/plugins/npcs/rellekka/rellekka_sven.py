World.addNonCombatNpc(4716, 2649, 3673, 0, 1)
RelSig_shop = Shop("Sven The Merchant", 1779)

RelSig_shop.addItem(ShopItem(1931, 30))
RelSig_shop.addItem(ShopItem(1935, 10))
RelSig_shop.addItem(ShopItem(1825, 30))
RelSig_shop.addItem(ShopItem(1925, 30))
RelSig_shop.addItem(ShopItem(946, 10))
RelSig_shop.addItem(ShopItem(590, 25))
	
def first_click_npc_4716(player):
	player.startChat(684580)
	
def chat_684580(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(684581)
	
def chat_684581(player):
	player.npcChat("Hi " + str(player.playerName) + ", would you like to buy any items?")
	player.nextChat(684582)
	
def chat_684582(player):
	player.dialogueOption("Sure, I'll take a look.", 684583, "No thank you.", 6845804)
	
def chat_684583(player):
	player.getShop().openShop(1779)
	
def chat_6845804(player):
	player.npcChat("Looks like I'll be seeing you around, goodbye.")
	player.endChat()    