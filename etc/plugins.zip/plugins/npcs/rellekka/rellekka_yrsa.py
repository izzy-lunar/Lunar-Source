World.addNonCombatNpc(1301, 2623, 3673, 0, 1)
RelYrsa_shop = Shop("Yrsa's boots", 762)

RelYrsa_shop.addItem(ShopItem(4119, 25))
RelYrsa_shop.addItem(ShopItem(4121, 25))
RelYrsa_shop.addItem(ShopItem(4123, 25))
RelYrsa_shop.addItem(ShopItem(4125, 25))
RelYrsa_shop.addItem(ShopItem(4127, 25))
RelYrsa_shop.addItem(ShopItem(4129, 25))

def second_click_npc_1301(player):
	player.getShop().openShop(762)
	
def first_click_npc_1301(player):
	player.startChat(694580)
	
def chat_694580(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(694581)
	
def chat_694581(player):
	player.npcChat("Hi " + str(player.playerName) + ", would you like to buy any boots?")
	player.nextChat(694582)
	
def chat_694582(player):
	player.dialogueOption("Sure.", 694583, "No thank you.", 6945804)
	
def chat_694583(player):
	player.getShop().openShop(762)
	
def chat_6945804(player):
	player.npcChat("Looks like I'll be seeing you around, goodbye.")
	player.endChat()    