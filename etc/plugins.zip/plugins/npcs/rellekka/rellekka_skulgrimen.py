World.addNonCombatNpc(1303, 2663, 3693, 0, 1)

Skulgrimen_shop = Shop("Helmet Shop", 244)
Skulgrimen_shop.addItem(ShopItem(3755, 1))
Skulgrimen_shop.addItem(ShopItem(3751, 1))
Skulgrimen_shop.addItem(ShopItem(3753, 1))
Skulgrimen_shop.addItem(ShopItem(3749, 1))
Skulgrimen_shop.addItem(ShopItem(10828, 1))

def second_click_npc_1303(player):
	player.getShop().openShop(244)

def first_click_npc_1303(player):
    player.startChat(1789115)
	
def first_click_npc_581(player):
    player.startChat(1789115)
	
def chat_1789115(player):
    player.npcChat("Welcome to my shop,", "would you like to buy a helmet?")
    player.nextChat(1789116)
       
def chat_1789116(player):
    player.dialogueOption("Sure, I'll have a look.", 1789117, "Is that a euphemism?", 1789118)
       
def chat_1789117(player):
    player.getShop().openShop(244)
       
def chat_1789118(player):
    player.playerChat("Is that a euphemism?")