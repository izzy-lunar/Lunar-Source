World.addNonCombatNpc(1294, 2658, 3673, 0, 1)

def first_click_npc_1294(player):
	player.startChat(645600)
	
def chat_645600(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(645601)
	
def chat_645601(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with", "this fine day?")
	player.nextChat(645602)

def chat_645602(player):
	player.dialogueOption("Nothing much.", 645603, "I'm looking for quests!", 645604)
	
def chat_645603(player):
	player.playerChat("Nothing much.")
	
def chat_645604(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(645605)
	
def chat_645605(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(645606)	
	
def chat_645606(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()