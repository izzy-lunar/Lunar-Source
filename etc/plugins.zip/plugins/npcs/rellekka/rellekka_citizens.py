World.addNonCombatNpc(2939, 2660, 3670, 0, 1)
World.addNonCombatNpc(2940, 2662, 3669, 0, 1)
World.addNonCombatNpc(2438, 2647, 3710, 0, 1)
World.addNonCombatNpc(1304, 2629, 3693, 0, 1)

def first_click_npc_2939(player):
	player.startChat(381720)
	
def chat_381720(player):
	player.npcChat("Hey there, outlander.")
	player.endChat()

def first_click_npc_2940(player):
	player.startChat(3817120)
	
def chat_3817120(player):
	player.npcChat("Hey there, outlander.")
	player.endChat()

def first_click_npc_2438(player):
	player.startChat(3817430)
	
def second_click_npc_2438(player):
	player.startChat(3817440)
	
def chat_3817440(player):
	player.npcChat("My ship has been stolen!")
	player.endChat()
	
def chat_3817430(player):
	player.npcChat("Hey there, outlander.")
	player.endChat()