

# Market Guard
World.addCombatNpc(1317, 2641, 3673, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1317, 2646, 3680, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1317, 2646, 3673, 0, 1, 50, 7, 50, 70)

# frem warriors
World.addCombatNpc(1318, 2666, 3667, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1318, 2668, 3677, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1318, 2674, 3697, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1318, 2657, 3700, 0, 1, 50, 7, 50, 70)
World.addCombatNpc(1318, 2632, 2677, 0, 1, 50, 7, 50, 70)

#guards
World.addNonCombatNpc(1296, 2659, 3645, 0, 0)
World.addNonCombatNpc(1296, 2665, 3645, 0, 0)


#Cows
World.addCombatNpc(81, 2679, 3664, 0, 1, 10, 3, 5, 5)
World.addCombatNpc(81, 2681, 3663, 0, 1, 10, 3, 5, 5)
World.addCombatNpc(81, 2683, 3667, 0, 1, 10, 3, 5, 5)
World.addCombatNpc(81, 2683, 3671, 0, 1, 10, 3, 5, 5)
World.addCombatNpc(81, 2680, 3671, 0, 1, 10, 3, 5, 5)

#Shops
World.addNonCombatNpc(1316, 2637, 3677, 0, 1)

#Wolves
World.addCombatNpc(95, 2615, 3621, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2623, 3636, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2655, 3620, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2691, 3617, 0, 1, 35, 10, 35, 35)
World.addCombatNpc(95, 2718, 3611, 0, 1, 35, 10, 35, 35)