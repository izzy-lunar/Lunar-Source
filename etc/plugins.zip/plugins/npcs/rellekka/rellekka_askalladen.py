World.addNonCombatNpc(1295, 2659, 3660, 0, 1)

def first_click_npc_1295(player):
	player.startChat(7745600)
	
def chat_7745600(player):
	player.playerChat("Hello little buddy.")
	player.nextChat(7745601)
	
def chat_7745601(player):
	player.npcChat("I'm not allowed to talk to strangers.")
	player.endChat()