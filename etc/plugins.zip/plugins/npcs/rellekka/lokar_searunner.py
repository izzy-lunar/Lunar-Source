World.addNonCombatNpc(4537, 2621, 3683, 0, 1)

def first_click_npc_4537(p):
    p.startChat(825156545)

def chat_825156545(player):
    player.npcChat("Hey there outerlander, can I help you?")
    player.nextChat(825156546)

def chat_825156546(player):
    player.dialogueOption("Do you have any quests?", 825156547, "Can you take me somewhere?", 825156549)

def chat_825156547(player):
    player.playerChat("Do you have any quests?")
    player.nextChat(825156548)

def chat_825156548(player):
    player.npcChat("Not at this moment in time but", "I may do soon.")
    player.nextChat(825156546)

def chat_825156549(player):
    player.playerChat("Can you take me somewhere in that longboat of", "yours Lokar?")
    player.nextChat(825156550)

def chat_825156550(player):
    player.npcChat("Yes, I usually head over to the Pirates cove", "around this time of day, would you like to go?")
    player.nextChat(825156551)

def chat_825156551(player):
    player.playerChat("Sounds good to me.")
    player.nextChat(825156552)

def chat_825156552(player):
    Sailing.startTravel(player, 20)

