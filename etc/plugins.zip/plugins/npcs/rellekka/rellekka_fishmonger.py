World.addNonCombatNpc(1369, 2649, 3676, 0, 1)
RelFish_shop = Shop("Fishmonger", 478)

RelFish_shop.addItem(ShopItem(317, 25))
RelFish_shop.addItem(ShopItem(327, 25))
RelFish_shop.addItem(ShopItem(331, 25))
RelFish_shop.addItem(ShopItem(335, 25))
RelFish_shop.addItem(ShopItem(341, 25))

def second_click_npc_1369(player):
	player.getShop().openShop(478)
	
def first_click_npc_1369(player):
	player.startChat(694570)
	
def chat_694570(player):
	player.playerChat("Hello there!")
	player.nextChat(694571)
	
def chat_694571(player):
	player.npcChat("Hi " + str(player.playerName) + " would you like to buy any raw fish?")
	player.nextChat(694572)
	
def chat_694572(player):
	player.dialogueOption("Sure.", 694573, "No thank you.", 6945704)
	
def chat_694573(player):
	player.getShop().openShop(478)
	
def chat_6945704(player):
	player.npcChat("I'll be seeing you around, goodbye.")