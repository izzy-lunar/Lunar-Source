from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem

donor_shop = Shop("Credit Store", 40)


donor_shop.addItem(ShopItem(4447, 1))
donor_shop.addItem(ShopItem(10586, 1))
donor_shop.addItem(ShopItem(8299, 1))#pet smoke
donor_shop.addItem(ShopItem(10835, 1))#dice bag
donor_shop.addItem(ShopItem(1029, 1))
donor_shop.addItem(ShopItem(4024, 1))
donor_shop.addItem(ShopItem(4029, 1))
donor_shop.addItem(ShopItem(4027, 1))


donor_shop.addItem(ShopItem(1053, 1))
donor_shop.addItem(ShopItem(1055, 1))
donor_shop.addItem(ShopItem(1057, 1))
donor_shop.addItem(ShopItem(1050, 1))
#donor_shop.addItem(ShopItem(12371, 1))#lava mask
#donor_shop.addItem(ShopItem(12399, 1))#partyhat and specs

donor_shop.addItem(ShopItem(11795, 1))
donor_shop.addItem(ShopItem(11694, 1))
donor_shop.addItem(ShopItem(11777, 1))

#new cosmetics

