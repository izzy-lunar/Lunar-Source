

#Donator Main Dungeon
#2509 10245 0
#Made by Cam

from com.ownxile.core import World
#Hole to Mine rock 15186

#Slayer Master
World.addNonCombatNpc(1599, 2518, 10263, 0, 1)
#Main Shop
World.addNonCombatNpc(1972, 2508, 10251, 0, 1)
#General Store
World.addNonCombatNpc(522, 2507, 10258, 0, 1)
#Donator Store
World.addNonCombatNpc(947, 2529, 10248, 0, 1)
#Aubury
World.addNonCombatNpc(553, 2529, 10258, 0, 0)
#Lowe
World.addNonCombatNpc(550, 2518, 10251, 0, 1)
#Bank
World.addNonCombatNpc(5383, 2525, 10265, 0, 1)
#Rune Ore
#World.addObject(14860, 2507, 10287)
#World.addObject(14860, 2504, 10287)
#Magic Tree 1306
#World.addObject(1306, 2517, 10268)