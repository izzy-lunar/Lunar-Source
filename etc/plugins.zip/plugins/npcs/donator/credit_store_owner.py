#finances NPC
from com.ownxile.core import World

World.addNonCombatNpc(947, 3096, 3509, 0, 1)

def first_click_npc_947(
    player
	):
	player.startChat(
	1751686957
	)

def chat_1751686957(player):
    player.playerChat(
	"Hi there, I heard you exchange credits."
	)
    player.nextChat(
	1751686958
	)

def chat_1751686958(player):
    player.npcChat(
	"That's right, perhaps I can help you out."
	)
    player.nextChat(1751686959)

def chat_1751686959(player):
    player.dialogueOption(
	"Ask about obtaining credits", 699562175, 
    "View credit store", 1203767326,
	"No thanks.", 58
	)
def chat_699562175(player):
    player.playerChat("How can I obtain credits?")
    player.nextChat(699562176)

def chat_699562176(player):
    player.npcChat("There are many different ways to obtain credits.")
    player.nextChat(699562177)

def chat_699562177(player):
    player.npcChat("The OwnXile administration will award them for contributing", "to OwnXile in some way. This includes creating plugins,", "donating, creating a good guide or wikipedia article", "and even creating youtube videos or other graphics.")
    player.nextChat(699562178)
	
def chat_699562178(player):
    player.npcChat("For more information visit the official website.")
    player.endChat()
def chat_699562179(player):
    player.npcChat("Pets are at ::zoo.", "You may do ::kills to see your kills.")
    player.endChat()