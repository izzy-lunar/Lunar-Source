#Donator Combat Dungeon
#2509 10245 0
#Made by Cam
from com.ownxile.core import World
#hole to sea queen
15196

#Abysall Demons
World.addCombatNpc(5363, 2567, 10279, 0, 1, 150, 7, 90, 90)
World.addCombatNpc(5363, 2570, 10281, 0, 1, 150, 7, 90, 90)
World.addCombatNpc(5363, 2574, 10279, 0, 1, 150, 7, 90, 90)
World.addCombatNpc(5363, 2574, 10279, 0, 1, 150, 7, 90, 90)
World.addCombatNpc(5363, 2574, 10270, 0, 1, 150, 7, 90, 90)
#Dark Beasts
World.addCombatNpc(5363, 2586, 10294, 0, 1, 150, 15, 90, 150)
World.addCombatNpc(5363, 2592, 10292, 0, 1, 150, 15, 90, 150)
World.addCombatNpc(5363, 2590, 10285, 0, 1, 150, 15, 90, 150)
World.addCombatNpc(5363, 2596, 10283, 0, 1, 150, 15, 90, 150)
World.addCombatNpc(5363, 2594, 10276, 0, 1, 150, 15, 90, 150)
#Mithril Dragons
World.addCombatNpc(5363, 2598, 10257, 0, 1, 200, 25, 150,250)
World.addCombatNpc(5363, 2602, 10253, 0, 1, 200, 25, 150,250)
World.addCombatNpc(5363, 2609, 10250, 0, 1, 200, 25, 150,250)
#Wyvern
World.addCombatNpc(3068, 2612, 10258, 0, 1, 100, 18, 350,350)
World.addCombatNpc(3068, 2618, 10260, 0, 1, 100, 18, 350,350)
World.addCombatNpc(3068, 2616, 10266, 0, 1, 100, 18, 350,350)
#Tank Rock Crabs (Easy training)
World.addCombatNpc(1267, 2511, 10268, 0, 1, 100, 2, 15,15)
World.addCombatNpc(1267, 2508, 10267, 0, 1, 100, 2, 15,15)
World.addCombatNpc(1267, 2512, 10271, 0, 1, 100, 2, 15,15)
World.addCombatNpc(1267, 2505, 10272, 0, 1, 100, 2, 15,15)
World.addCombatNpc(1267, 2510, 10275, 0, 1, 100, 2, 15,15)
World.addCombatNpc(1267, 2504, 10266, 0, 1, 100, 2, 15,15)
#Sea queen
World.addCombatNpc(3847, 2613, 10280, 0, 1, 500, 70, 500,400)#douevenboss