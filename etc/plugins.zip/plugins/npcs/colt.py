def first_click_npc_5896(player):
    player.npcChat("try me kid, i dare u")