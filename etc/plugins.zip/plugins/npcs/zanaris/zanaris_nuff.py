# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(3303, 2390, 4469, 0, 1)

def first_click_npc_3303(player):
	player.startChat(34745670)
	
def chat_34745670(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(34745671)
	
def chat_34745671(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
	player.nextChat(34745672)

def chat_34745672(player):
	player.dialogueOption("Nothing much.", 34745673, "I'm looking for quests!", 34745674)
	
def chat_34745673(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_34745674(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(34745675)
	
def chat_34745675(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(34745676)	
	
def chat_34745676(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()