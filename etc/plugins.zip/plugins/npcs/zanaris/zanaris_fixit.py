# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(4455, 2410, 4436, 0, 1)

def first_click_npc_4455(player):
	player.startChat(24652150)
	
def chat_24652150(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(24652151)
	
def chat_24652151(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
	player.nextChat(24652152)

def chat_24652152(player):
	player.dialogueOption("Nothing much.", 24652153, "I'm looking for quests!", 24652154)
	
def chat_24652153(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_24652154(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(24652155)
	
def chat_24652155(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(24652156)	
	
def chat_24652156(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()