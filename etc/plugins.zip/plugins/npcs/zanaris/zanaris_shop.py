# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(534, 2376, 4444, 0, 1)
World.addNonCombatNpc(535, 2377, 4448, 0, 1)

def second_click_npc_534(player):
	player.getShop().openShop(47)
	
def first_click_npc_534(player):
	player.getShop().openShop(47)

def second_click_npc_535(player):
	player.getShop().openShop(47)
	
def first_click_npc_535(player):
	player.getShop().openShop(47)