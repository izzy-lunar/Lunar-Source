from com.ownxile.core import World

diamond = 1601

def handle_east_barrier(player):     
    if player.getX() > 2469:
        player.getFunction().movePlayer(2470, player.getY(), 0)
        player.gfx100(867)
    else:
        player.getFunction().movePlayer(2469, player.getY(), 0)
        player.gfx100(867)
        
def handle_south_barrier(player):     
    if player.getY() > 4433:
        player.getFunction().movePlayer(player.getX(), 4433, 0)
        player.gfx100(867)
    else:
        player.getFunction().movePlayer(player.getX(), 4434, 0)
        player.gfx100(867)
        
def first_click_object_12045(player):
    player.startChat(872132489)

def first_click_object_12047(player):
    player.startChat(872132489)
    
def chat_872132489(player):
    if player.hasItem(diamond):
        player.deleteItem(diamond)    
        player.boxMessage("You pay one diamond to pass through the barrier.")
        if player.getY() > 3504:
            handle_north_barrier(player)
        else:
            handle_west_barrier(player)
    else:
        player.boxMessage("You need a diamond to pass through the barrier.")
        player.endChat()    