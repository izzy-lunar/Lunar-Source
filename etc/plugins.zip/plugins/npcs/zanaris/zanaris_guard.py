# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(567, 2465, 4436, 0, 1)

def first_click_npc_567(player):
	player.startChat(24655150)
	
def chat_24655150(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(24655151)
	
def chat_24655151(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
	player.nextChat(24655152)

def chat_24655152(player):
	player.dialogueOption("Nothing much.", 24655153, "I'm looking for quests!", 24655154)
	
def chat_24655153(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_24655154(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(24655155)
	
def chat_24655155(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(24655156)	
	
def chat_24655156(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()