# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addCombatNpc(126, 2388, 4428, 0, 1, 40, 7, 15, 20)
World.addCombatNpc(126, 2386, 4421, 0, 1, 40, 7, 15, 20)
World.addCombatNpc(126, 2381, 4420, 0, 1, 40, 7, 15, 20)
World.addCombatNpc(126, 2380, 4427, 0, 1, 40, 7, 15, 20)

World.addNonCombatNpc(57, 2402, 4457, 0, 1)
World.addNonCombatNpc(4446, 2399, 4445, 0, 1)
World.addNonCombatNpc(4445, 2418, 4461, 0, 1)
World.addNonCombatNpc(4444, 2439, 4452, 0, 1)
World.addNonCombatNpc(4443, 2455, 4447, 0, 1)
World.addNonCombatNpc(57, 2421, 4425, 0, 1)

def first_click_npc_4443(player):
	player.startChat(2164273)
	
def chat_2164273(player):
	player.npcChat("Hello!")
	player.endChat()

def first_click_npc_4444(player):
	player.startChat(2164275)
	
def chat_2164275(player):
	player.npcChat("Good day!")
	player.endChat()

def first_click_npc_4445(player):
	player.startChat(2164276)
	
def chat_2164276(player):
	player.npcChat("It's nice to see a new face around here!")
	player.endChat()

def first_click_npc_4446(player):
	player.startChat(2164277)
	
def chat_2164277(player):
	player.npcChat("Hey there!")
	player.endChat()

def first_click_npc_57(player):
	player.startChat(2164287)
	
def chat_2164287(player):
	player.npcChat("We don't get many humans around here!")
	player.endChat()