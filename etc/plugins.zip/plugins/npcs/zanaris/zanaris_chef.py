# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(3322, 2385, 4439, 0, 1)

def first_click_npc_3322(player):
	player.startChat(364746670)
	
def chat_364746670(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(364746671)
	
def chat_364746671(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with?")
	player.nextChat(364746672)

def chat_364746672(player):
	player.dialogueOption("Nothing much.", 364746673, "I'm looking for quests!", 364746674)
	
def chat_364746673(player):
	player.playerChat("Nothing much.")
	player.endChat()
	
def chat_364746674(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(364746675)
	
def chat_364746675(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(364746676)	
	
def chat_364746676(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()