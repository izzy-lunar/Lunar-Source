# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(498, 2382, 4458, 0, 1)

def second_click_npc_498(player):
	player.getFunction().openUpBank()
	
def first_click_npc_498(player):
	player.getFunction().openUpBank()