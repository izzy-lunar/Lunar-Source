World.addNonCombatNpc(725, 2531, 3304, 0, 1)#jethick
World.addNonCombatNpc(711, 2533, 3314, 0, 1)#bravek
World.addNonCombatNpc(713, 2527, 3315, 0, 1)#clerk
