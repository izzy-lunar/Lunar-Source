# NPC Config Script
# Gundai the Banker - 902
# Author OwnXile
#need correct co-rds
World.addNonCombatNpc(902, 2534, 4716, 0, 1)

def first_click_npc_902(player):
	player.startChat(433200)

def second_click_npc_902(player):
	player.getFunction().openUpBank()
	
def chat_433200(player):
	player.npcChat("I didn't know a noob could find their way here!")
	player.nextChat(433201)
	
def chat_433201(player):
	player.playerChat("How did you get here then?")
	player.nextChat(433202)
	
def chat_433202(player):
	player.npcChat("I... ummm...")
	player.nextChat(433203)
	
def chat_433203(player):
	player.npcChat("... very funny kid.")
	player.endChat()
	
	