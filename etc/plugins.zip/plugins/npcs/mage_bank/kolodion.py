def first_click_npc_905(player):
  player.startChat(5)