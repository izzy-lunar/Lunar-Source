# NPC Config Script
# Chamber Guardian - 904
# Author Skunk

chamber_guardian = Shop("Mage Arena Rewards", 66)
 
chamber_guardian.addItem(ShopItem(6199, 1))
chamber_guardian.addItem(ShopItem(2415, 1))
chamber_guardian.addItem(ShopItem(2416, 1))
chamber_guardian.addItem(ShopItem(2417, 1))
chamber_guardian.addItem(ShopItem(6916, 1))
chamber_guardian.addItem(ShopItem(6918, 1))
chamber_guardian.addItem(ShopItem(6920, 1))
chamber_guardian.addItem(ShopItem(6922, 1))
chamber_guardian.addItem(ShopItem(6924, 1))

def first_click_npc_904(player):
	player.startChat(133200)

def second_click_npc_904(player):
	player.getShop().openShop(66)
	
def chat_133200(player):
	player.npcChat("Do you want to buy a god staff?")
	player.nextChat(133201)
	
def chat_133201(player):
    player.dialogueOption("Yes please!", 133202, "No thank you.", 133203)
	
def chat_133202(player):
	player.getShop().openShop(66)
	
def chat_133203(player):
	player.playerChat("No thank you.")
	player.endChat()
	
	