# Author Eisenhower

World.addNonCombatNpc(3044, 3426, 2928, 0, 1)