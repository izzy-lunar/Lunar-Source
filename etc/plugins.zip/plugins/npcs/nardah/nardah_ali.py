# Author Eisenhower

World.addNonCombatNpc(3030, 3421, 2915, 0, 1)