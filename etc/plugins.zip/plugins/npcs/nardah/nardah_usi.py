# Author Eisenhower

World.addNonCombatNpc(3031, 3439, 2890, 0, 1)