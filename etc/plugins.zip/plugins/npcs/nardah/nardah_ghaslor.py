# Author Eisenhower

World.addNonCombatNpc(3029, 3441, 2933, 0, 1)