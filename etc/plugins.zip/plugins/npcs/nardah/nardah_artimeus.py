# Author Eisenhower

World.addNonCombatNpc(5109, 3443, 2904, 0, 1)