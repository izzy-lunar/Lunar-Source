# Author Eisenhower

World.addNonCombatNpc(3039, 3414, 2905, 0, 1)