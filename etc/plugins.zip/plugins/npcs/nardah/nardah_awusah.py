# Author Eisenhower

World.addNonCombatNpc(3040, 3442, 2914, 0, 1)