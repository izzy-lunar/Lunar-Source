# Author Eisenhower

World.addNonCombatNpc(3033, 3435, 2897, 0, 1)