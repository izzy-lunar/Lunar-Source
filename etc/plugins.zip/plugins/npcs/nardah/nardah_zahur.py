# Author Eisenhower

World.addNonCombatNpc(3037, 3426, 2906, 0, 1)