# Author Eisenhower

World.addNonCombatNpc(3035, 3429, 2899, 0, 1)