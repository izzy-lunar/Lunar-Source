# Author Eisenhower

World.addNonCombatNpc(3036, 3449, 2898, 0, 1)