##################################
###      Author: Eisenhower    ###
###       Date:12.11.2013      ###
##################################

halberd_shop = Shop("Halberd Supplies", 56)
halberd_shop.addItem(ShopItem(3190, 5))
halberd_shop.addItem(ShopItem(3192, 5))
halberd_shop.addItem(ShopItem(3194, 5))
halberd_shop.addItem(ShopItem(3196, 5))
halberd_shop.addItem(ShopItem(3198, 5))
halberd_shop.addItem(ShopItem(3200, 5))
halberd_shop.addItem(ShopItem(3202, 5))
halberd_shop.addItem(ShopItem(3204, 1))

World.addCombatNpc(1203, 2182, 3149, 0, 1, 80, 10, 70, 70)
World.addCombatNpc(1203, 2179, 3142, 0, 1, 80, 10, 70, 70)
World.addCombatNpc(1203, 2185, 3145, 0, 1, 80, 10, 70, 70)
World.addCombatNpc(1203, 2193, 3144, 0, 1, 80, 10, 70, 70)
World.addCombatNpc(1203, 2188, 3153, 0, 1, 80, 10, 70, 70)

def first_click_object_3980(player):
    player.lastClickedNpcId = 1203
    player.startChat(160815516)
def first_click_object_787(player):
    player.lastClickedNpcId = 1203
    player.startChat(160815516)
    
def chat_160815516(player):
    player.npcChat("Oi you! Don't touch that.")
    player.endChat()

World.addNonCombatNpc(1208, 2194, 3140, 0, 1)
World.addNonCombatNpc(1208, 2199, 3255, 0, 1)

def first_click_npc_1208(player):
    player.startChat(160815517)
	
def chat_160815517(player):
    player.npcChat("Hey there would you like to buy a halberd?")
    player.nextChat(160815518)

def chat_160815518(player):
    player.playerChat("Show me what you have to offer!")
    player.nextChat(160815519)

def chat_160815519(player):
    player.getShop().openShop(56)
    player.endChat()

def chat_160815520(player):
    player.playerChat("Hello there!")
    player.nextChat(160815521)
	
def chat_160815521(player):
    player.npcChat("such guarding")
    player.nextChat(160815522)
	
def chat_160815522(player):
    player.playerChat("...erm what?")
    player.nextChat(160815523)
	
def chat_160815523(player):
    player.npcChat("many guard")
    player.endChat()
	
def first_click_npc_1203(player):
    player.startChat(160815520)