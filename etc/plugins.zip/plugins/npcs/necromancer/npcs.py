World.addNonCombatNpc(2066, 2667, 3244, 0, 1)
World.addNonCombatNpc(194, 2670, 3241, 0, 1)
World.addNonCombatNpc(173, 2672, 3241, 1, 1)

def first_click_npc_2066(player):
    player.startChat(657554488)

def chat_657554488(player):
    player.playerChat("What are you doing here?")
    player.nextChat(657554489)

def chat_657554489(player):
    player.npcChat("None of your business, keep away!")
    player.endChat()

