# Author Eisenhower
from com.ownxile.core import World

# Scorpians 
World.addCombatNpc(107, 3225, 3102, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3221, 3108, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3228, 3112, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3231, 3109, 0, 1, 15, 6, 8, 8)

#Wolf
World.addCombatNpc(107, 3236, 3115, 0, 1, 20, 7, 8, 8)
World.addCombatNpc(107, 3245, 3120, 0, 1, 20, 7, 8, 8)
World.addCombatNpc(107, 3225, 3122, 0, 1, 20, 7, 8, 8)
World.addCombatNpc(107, 3217, 3127, 0, 1, 20, 7, 8, 8)