##################################
###       Author: Nixon        ###
###        Date:7.11.2013      ###
##################################

def first_click_npc_1982(player):
	player.startChat(1119777725)

def chat_1119777725(player):
    player.npcChat("Selling! Selling!")
    player.nextChat(1119777726)
    
def chat_1119777726(player):
    player.playerChat("Selling what?")
    player.nextChat(1119777727)
    
def chat_1119777727(player):
    player.boxMessage("Raetul looks around in confusion.")
    player.nextChat(1119777728)

def chat_1119777728(player):
    player.npcChat("Hee-hee-hee! It's mine!")
    player.nextChat(1119777729)

def chat_1119777729(player):
    player.npcChat("Oh...noo! WHERE IS IT?")
    player.nextChat(1119777730)

def chat_1119777730(player):
    player.playerChat("This is getting weird.")
    player.nextChat(1119777731)

def chat_1119777731(player):
    player.boxMessage("You decide to leave Raetul alone.")
    player.nextChat(1119777732)

