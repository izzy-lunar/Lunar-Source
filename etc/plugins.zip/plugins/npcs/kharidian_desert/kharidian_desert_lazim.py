# Author Eisenhower
from com.ownxile.core import World

# Scorpians 
World.addCombatNpc(107, 3184, 2904, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3190, 2911, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3188, 2918, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3172, 2923, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3166, 2906, 0, 1, 15, 6, 8, 8)
World.addCombatNpc(107, 3170, 2902, 0, 1, 15, 6, 8, 8)

World.addNonCombatNpc(3147, 3191, 2923, 0, 1)

def first_click_npc_3147(player):
    player.startChat(1841743640)
    
def chat_1841743640(player):
    player.npcChat("This heat is unbearable! ")
    player.nextChat(1841743641)

def chat_1841743641(player):
    player.playerChat("Wear a hat!")
    player.nextChat(1841743642)

def chat_1841743642(player):
    player.npcChat("That is a sensible suggestion my friend.", "With the absence of hair on my head...")
    player.nextChat(1841743643)

def chat_1841743643(player):
    player.npcChat("I have to say, it tends to get a", "little red from time to time.")
    player.nextChat(1841743644)

def chat_1841743644(player):
    player.npcChat("Do you know what I really need?")
    player.nextChat(1841743645)

def chat_1841743645(player):
    player.playerChat("What do you really need?")
    player.nextChat(1841743646)

def chat_1841743646(player):
    player.npcChat("A little building to offer some shade.")
    player.nextChat(1841743647)

def chat_1841743647(player):
    player.npcChat("But you see... I don't know what to make it out of.")
    player.nextChat(1841743648)

def chat_1841743648(player):
    player.playerChat("Wood!")
    player.nextChat(1841743649)

def chat_1841743649(player):
    player.npcChat("No. That wouldn't work, it's not sturdy enough.")
    player.nextChat(1841743650)

def chat_1841743650(player):
    player.npcChat("Eureka! I know what would work.")
    player.nextChat(1841743651)

def chat_1841743651(player):
    player.playerChat("What?!")
    player.nextChat(1841743652)

def chat_1841743652(player):
    player.npcChat("Sandstone! It's perfect for what I'm looking for.")
    player.nextChat(1841743653)

def chat_1841743653(player):
    player.playerChat("How would you get that?")
    player.nextChat(1841743654)

def chat_1841743654(player):
    player.npcChat("Well my friend,", "it's not exactly an area of my profession.")
    player.nextChat(1841743655)

def chat_1841743655(player):
    player.playerChat("Perhaps I could help you.")
    player.nextChat(1841743656)

def chat_1841743656(player):
    player.npcChat("That sounds fantastic!", " All I know is that there's a lot of sandstone here.")
    player.nextChat(1841743657)

def chat_1841743657(player):
    player.playerChat("Shall I get started then?")
    player.nextChat(1841743658)

def chat_1841743658(player):
    player.npcChat("Well... I would need to plan my building first.")
    player.nextChat(1841743659)

def chat_1841743659(player):
    player.playerChat("Perhaps I'll come back later and see", "if you've come up with a plan then.")
    player.nextChat(1841743660)

def chat_1841743660(player):
    player.npcChat("Good idea! See you later.")
    player.endChat()
