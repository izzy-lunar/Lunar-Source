#Sophanem Guards
#Created by Nixon

def first_click_npc_5272(player):
	player.startChat(1944275833)

def chat_1944275833(player):
    player.npcChat("Welcome to the city of Sophanem.")
    player.nextChat(1944275834)

def chat_1944275834(player):
    player.playerChat("Can I enter?")
    player.nextChat(1944275835)

def chat_1944275835(player):
    player.npcChat("Go away!")
    player.nextChat(1944275836)

def chat_1944275836(player):
    player.playerChat("So I get welcomed, then shooed away...")
    player.nextChat(1944275837)

