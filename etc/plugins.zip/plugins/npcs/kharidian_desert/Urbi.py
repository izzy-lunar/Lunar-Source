# NPC Config Script
# Urbi - 5266
# Author Nixon
from com.ownxile.core import World

blades_by_urbi = Shop("Blades by Urbi", 300)

blades_by_urbi.addItem(ShopItem(1205, 25))
blades_by_urbi.addItem(ShopItem(1203, 25))
blades_by_urbi.addItem(ShopItem(1207, 25))
blades_by_urbi.addItem(ShopItem(1217, 25))
blades_by_urbi.addItem(ShopItem(1209, 25))
blades_by_urbi.addItem(ShopItem(1211, 25))
blades_by_urbi.addItem(ShopItem(1213, 25))
blades_by_urbi.addItem(ShopItem(1333, 25))

World.addNonCombatNpc(5266, 3298, 2804, 0, 1)

def first_click_npc_5266(player): 
	player.startChat(344515893)
	
def chat_344515893(player):
    player.npcChat("Would you like to buy some weapons?")
    player.nextChat(344515894)
 
def chat_344515894(player):
    player.dialogueOption("Yes, please!", 344515895, "No, thank you.", 344515896)
 
def chat_344515895(player):
	player.getShop().openShop(300)
 
def chat_344515896(player):
	player.playerChat("No, thank you.")
	player.endChat()
	
def second_click_npc_5266(player): 
	player.getShop().openShop(300)
