#Author Kennedy
from com.ownxile.core import World

World.addNonCombatNpc(836, 3304, 3123, 0, 1)

shanty_shop = Shop("Shanty's Passes", 6285)
shanty_shop.addItem(ShopItem(1854, 420))

def chat_268555974(player):
    player.playerChat("May I buy a Shantay Pass?")
    player.nextChat(268555975)    
    
def chat_268555975(player):
    player.npcChat("Yes you may, however, I must warn you","the desert is very dangerous","do you understand?")
    player.nextChat(268555976)    

def chat_268555976(player):
    player.dialogueOption("Actually, nevermind", 268555977, "Yes, I understand.", 268555978)        

def chat_268555977(player):
    player.playerChat("Actually, nevermind")
    player.endChat()    

def chat_268555978(player):
    player.playerChat("Yes, I understand.")
    player.nextChat(268555979)        
    
def chat_268555979(player):
    player.npcChat("That will be 10,000 please.")
    player.nextChat(268675970)    
    
def chat_268675970(player):
    player.playerChat("Thanks!")
    player.nextChat(268675971)    

def chat_268675971(player):
    if player.hasItem(995, 10000):
        player.npcChat("Here you go.")
        player.deleteItem(995, 10000)
        player.addItem(1854, 1)
        player.endChat()
    else:    
        player.playerChat("Oh wait... Sorry, I don't have 10,000 coins on me.")
        player.endChat()
    

def second_click_npc_836(player):
    player.getShop().openShop(6285)

def first_click_npc_836(player):
    player.startChat(268555875)

def third_click_npc_836(player):
    player.startChat(268555974)
    
def chat_268555875(player):
    player.npcChat("Welcome to my shop.", "Would you like to buy anything?")
    player.nextChat(268555876)
    
def chat_268555876(player):
    player.dialogueOption("Sure, I'll have a look.", 268555879, "No thanks.", 268555878)
    
def chat_268555879(player):
    player.getShop().openShop(6285)
    
def chat_268555878(player):
    player.playerChat("No thanks.")
    player.endChat()
    
def first_click_object_4031(player):
    y = player.getY()
    if y > 3116:
        handle_shanty_pass(player)
    else:
        player.getFunction().movePlayer(player.getX(), player.getY() + 2, 0)

def handle_shanty_pass(player):
    if player.hasItem(1854):
        player.deleteItem(1854)
        player.getFunction().movePlayer(player.getX(), player.getY() - 2, 0)
    else:
        player.boxMessage("You need a shanty pass to enter through here.")