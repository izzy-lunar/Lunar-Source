# NPC Config Script
# Nathofa - 5264
# Author Nixon
from com.ownxile.core import World

bake_stall = Shop("Nathifa's Bake Shop", 303)

bake_stall.addItem(ShopItem(2309, 100))
bake_stall.addItem(ShopItem(1891, 100))
bake_stall.addItem(ShopItem(1901, 100))
bake_stall.addItem(ShopItem(1972, 1000))

World.addNonCombatNpc(5264, 3303, 2771, 0, 1)

def first_click_npc_5264(player): 
	player.startChat(1859232880)
	
def chat_1859232880(player):
    player.npcChat("Bake sale! Take a look!")
    player.nextChat(1859232881)
 
def chat_1859232881(player):
    player.dialogueOption("Yes, please!", 1859232882, "No, thank you.", 1859232883)
 
def chat_1859232882(player):
	player.getShop().openShop(303)
 
def chat_1859232883(player):
	player.playerChat("No, thank you.")
	player.endChat()
	
def second_click_npc_5264(player): 
	player.getShop().openShop(303)