
from com.ownxile.core import World

World.addNonCombatNpc(833, 3173, 3037, 0, 1)
World.addNonCombatNpc(833, 3166, 3032, 0, 1)
World.addNonCombatNpc(833, 3164, 3035, 0, 1)
World.addNonCombatNpc(833, 3162, 3041, 0, 1)
World.addNonCombatNpc(833, 3171, 3042, 0, 1)
World.addNonCombatNpc(833, 3172, 3033, 0, 1)
World.addNonCombatNpc(834, 3170, 3045, 0, 0)

World.addNonCombatNpc(80, 3174, 3038, 0, 0)

World.addCombatNpc(839, 3157, 3049, 0, 1, 30, 4, 30, 30)
World.addCombatNpc(839, 3151, 3040, 0, 1, 30, 4, 30, 30)

World.addNonCombatNpc(833, 3177, 3037, 0, 1)

World.addCombatNpc(1239, 3164, 3035, 0, 1, 50, 6, 50, 50)
World.addCombatNpc(1239, 3166, 3045, 0, 1, 50, 6, 50, 50)
World.addCombatNpc(1239, 3177, 3038, 0, 1, 50, 6, 50, 50)
World.addCombatNpc(1239, 3172, 3034, 0, 1, 50, 6, 50, 50)
World.addCombatNpc(1239, 3164, 3035, 0, 1, 50, 6, 50, 50)