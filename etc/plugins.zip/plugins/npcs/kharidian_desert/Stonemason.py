# NPC Config Script
# Stonemason - 4248
# Author Nixon
from com.ownxile.core import World

World.addNonCombatNpc(4248, 3310, 2775, 0, 1)

def first_click_npc_4248(player): 
	player.startChat(778335667)
	
def chat_778335667(player):
    player.boxMessage("Stonemason does not want to speak")
    player.endchat()
	
def second_click_npc_4248(player): 
	player.startChat(778335668)

def chat_778335668(player):
    player.npcChat("I have nothing to trade at the moment!")
    player.endchat()
