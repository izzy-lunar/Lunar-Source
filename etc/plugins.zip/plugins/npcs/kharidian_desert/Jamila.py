# NPC Config Script
# Jamila - 5268
# Author Nixon
from com.ownxile.core import World

jamila_shop = Shop("Jamila's Crafting Shop", 301)

jamila_shop.addItem(ShopItem(1755, 50))
jamila_shop.addItem(ShopItem(1592, 50))
jamila_shop.addItem(ShopItem(1597, 50))
jamila_shop.addItem(ShopItem(1595, 50))
jamila_shop.addItem(ShopItem(1733, 50))
jamila_shop.addItem(ShopItem(1734, 50))
jamila_shop.addItem(ShopItem(1599, 50))
jamila_shop.addItem(ShopItem(5523, 50))

World.addNonCombatNpc(5268, 3315, 2773, 0, 1)

def first_click_npc_5268(player): 
	player.startChat(1339518632)
	
def chat_1339518632(player):
    player.npcChat("Would you like to buy any crafting supplies?")
    player.nextChat(1339518633)
 
def chat_1339518633(player):
    player.dialogueOption("Yes, please!", 1339518634, "No, thank you.", 1339518635)
 
def chat_1339518634(player):
	player.getShop().openShop(301)
 
def chat_1339518635(player):
	player.playerChat("No, thank you.")
	player.endChat()
	
def second_click_npc_5268(player): 
	player.getShop().openShop(301)