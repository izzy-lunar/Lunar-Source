##################################
###       Author: Nixon        ###
###        Date:7.11.2013      ###
##################################

World.addNonCombatNpc(1986, 3281, 2773, 0, 1)

def first_click_npc_1986(player):
	player.startChat(95269244)

def chat_95269244(player):
    player.npcChat("Hello adventurer! What brings you here?")
    player.nextChat(95269245)

def chat_95269245(player):
    player.dialogueOption("Nothing, just passing by", 95269245, "I'm looking for a quest!", 95269246)
    
def chat_95269245(player):
    player.playerChat("Nothing, just passing by.")
    player.nextChat(95269247)

def chat_95269246(player):
    player.playerChat("I'm looking for a quest!")
    player.nextChat(95269247)

def chat_95269249(player):
    player.npcChat("I don't have any right now.")
    player.nextChat(95269250)

