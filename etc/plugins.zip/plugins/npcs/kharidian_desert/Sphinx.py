##################################
###       Author: Nixon        ###
###        Date:7.11.2013      ###
##################################

def first_click_npc_1990(player):
	player.startChat(1995552634)
	
def chat_1995552634(player):
    player.playerChat("He doesn't need to be bothered right now.")
    player.nextChat(1995552635)

