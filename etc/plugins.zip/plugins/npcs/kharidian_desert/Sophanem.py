#Sophanem
#Created by Nixon

World.addNonCombatNpc(1982, 3309, 2787, 0, 1)
World.addNonCombatNpc(1986, 3281, 2773, 0, 1)
World.addNonCombatNpc(1988, 3278, 2771, 0, 1)
World.addNonCombatNpc(1989, 3280, 2770, 0, 1)
World.addNonCombatNpc(1988, 3284, 2770, 0, 1)
World.addNonCombatNpc(1988, 3280, 2767, 0, 1)
World.addNonCombatNpc(1989, 3283, 2766, 0, 1)
World.addNonCombatNpc(1990, 3301, 2792, 0, 1)
World.addNonCombatNpc(5270, 3283, 2807, 0, 1)
World.addNonCombatNpc(5272, 3284, 2807, 0, 1)
World.addNonCombatNpc(5270, 3284, 2811, 0, 1)
World.addNonCombatNpc(5272, 3283, 2811, 0, 1)
World.addNonCombatNpc(2294, 3287, 2814, 0, 0)