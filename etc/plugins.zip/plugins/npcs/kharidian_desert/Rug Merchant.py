#Rug Merchant 
#Created by Nixon

def first_click_npc_2294(player):
	player.startChat(1924275833)

def chat_1924275833(player):
    player.npcChat("My carpet isn't working right now.")
    player.nextChat(1924275834)
    
def chat_1924275834(player):
    player.playerChat("How am I supposed to get around?")
    player.nextChat(1924275835)

def chat_679172942(player):
    player.npcChat("Walk!")
    player.nextChat(679172943)

def chat_679172943(player):
    player.playerChat("Asshole.")
    player.nextChat(679172944)

