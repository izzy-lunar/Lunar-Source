# NPC Config Script
# Embalmer - 1980
# Author Nixon
from com.ownxile.core import World

potion_shop = Shop("Potion Shop", 304)

potion_shop.addItem(ShopItem(145, 10))
potion_shop.addItem(ShopItem(157, 10))
potion_shop.addItem(ShopItem(163, 10))
potion_shop.addItem(ShopItem(139, 10))
potion_shop.addItem(ShopItem(169, 10))
potion_shop.addItem(ShopItem(3042, 10))

World.addNonCombatNpc(1980, 3285, 2759, 0, 1)

def first_click_npc_1980(player): 
	player.startChat(216813736)
	
def chat_216813736(player):
    player.npcChat("Would you like to buy some potions?")
    player.nextChat(216813737)
 
def chat_216813737(player):
    player.dialogueOption("Yes, please!", 216813738, "No, thank you.", 216813739)
 
def chat_216813738(player):
	player.getShop().openShop(304)
 
def chat_216813739(player):
	player.playerChat("No, thank you.")
	player.endChat()

def second_click_npc_1980(player): 
	player.getShop().openShop(304)