# NPC Config Script
# Siamun - 1983
# Author Nixon
from com.ownxile.core import World

World.addNonCombatNpc(1983, 3315, 2789, 0, 1)

def first_click_npc_1983(player): 
	player.startChat(344517489)
	
def chat_344517489(player):
    player.npcChat("What store to make?!", "What food to sell! I don't know!")
    player.endchat()
