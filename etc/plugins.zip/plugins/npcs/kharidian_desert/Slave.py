# NPC Config Script
# Slave - 979
# Author Nixon

World.addNonCombatNpc(979, 3232, 2780, 0, 1)

def first_click_npc_979(player): 
	player.startChat(344517489)
	
def chat_344517489(player):
    player.npcChat("The end is near.")
    player.endchat()
