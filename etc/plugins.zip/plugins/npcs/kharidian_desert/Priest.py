##################################
###       Author: Nixon        ###
###        Date:7.11.2013      ###
##################################

def first_click_npc_1988(player):
	player.startChat(72915)



def chat_374582990(player):
    player.npcChat("We're busy right now.")
    player.nextChat(374582991)

