#Menaphos
#Created by Nixon

World.addNonCombatNpc(2291, 3243, 2813, 0, 0)
World.addNonCombatNpc(5277, 3247, 2812, 0, 1)
World.addNonCombatNpc(5277, 3246, 2812, 0, 1)