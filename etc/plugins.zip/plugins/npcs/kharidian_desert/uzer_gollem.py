#Author Kennedy

World.addNonCombatNpc(1908, 3487, 3092, 0, 0)

def first_click_npc_1908(player):
	player.startChat(51287920)
	
def chat_51287920(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(51287921)
	
def chat_51287921(player):
	player.npcChat("Error 404, brain not found")
	player.nextChat(51287922)
	
def chat_51287922(player):
	player.playerChat("I wonder if I can help him...")
	player.endChat()	