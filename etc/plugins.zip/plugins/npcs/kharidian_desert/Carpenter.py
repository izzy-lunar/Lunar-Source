# NPC Config Script
# Carpenter - 1981
# Author Nixon
from com.ownxile.core import World

supplies_shop = Shop("Logs Shop", 302)

supplies_shop.addItem(ShopItem(1511, 100))
supplies_shop.addItem(ShopItem(1521, 100))
supplies_shop.addItem(ShopItem(1519, 100))
supplies_shop.addItem(ShopItem(1517, 100))
supplies_shop.addItem(ShopItem(1515, 100))
supplies_shop.addItem(ShopItem(1513, 100))

World.addNonCombatNpc(1981, 3314, 2783, 0, 1)

def first_click_npc_1981(player): 
	player.startChat(1350131964)
	
def chat_1350131964(player):
    player.npcChat("Would you like to buy some logs?")
    player.nextChat(1350131965)
 
def chat_1350131965(player):
    player.dialogueOption("Yes, please!", 1350131966, "No, thank you.", 1350131967)
 
def chat_1350131966(player):
	player.getShop().openShop(302)
 
def chat_1350131967(player):
	player.playerChat("No, thank you.")
	player.endChat()
	
def second_click_npc_1981(player): 
	player.getShop().openShop(302)
