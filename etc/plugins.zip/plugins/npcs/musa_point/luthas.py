World.addNonCombatNpc(379, 2939, 3153, 0, 1) # luthas

def first_click_npc_379(player):
    player.startChat(304014481)

def chat_304014481(player):
    player.playerChat("Hey there, so you like bananas?")
    player.nextChat(304014482)

def chat_304014482(player):
    player.npcChat("Well I do own the biggest banana", "plantation on OwnXile.")
    player.nextChat(304014483)

def chat_304014483(player):
    player.playerChat("Can I pick some bananas pleaseeee?", "I'm very hungry you know.")
    player.nextChat(304014484)

def chat_304014484(player):
    player.npcChat("Absolutely not! Keep away from my bananas!")
    player.nextChat(304014485)

def chat_304014485(player):
    player.playerChat("Okay, chill out dude I don't even", "like bananas.")
    player.nextChat(304014486)

def chat_304014486(player):
    player.npcChat("Just leave me alone, you fool.")
    player.nextChat(304014487)

def chat_304014487(player):
    player.playerChat("Fool? I'll have you know....")
    player.nextChat(304014488)

def chat_304014488(player):
    player.playerChat("MOMMA DIDN'T RAISE NO FOOL.")
    player.nextChat(304014489)

def chat_304014489(player):
    player.npcChat("You're new aren't you.")
    player.nextChat(304014490)

def chat_304014490(player):
    player.npcChat("...every year, the newfags turn up here.")
    player.nextChat(304014491)

def chat_304014491(player):
    player.npcChat("Asking me stupid questions...")
    player.nextChat(304014492)

def chat_304014492(player):
    player.npcChat("I can't take it anymore....")
    player.nextChat(304014493)

def chat_304014493(player):
    player.playerChat("Maybe if you weren't such a total noob",  "yourself, you might not get so mad. Look at", "your clothing kid, no wonder you don't get laid.")
    player.nextChat(304014494)

def chat_304014494(player):
    player.npcChat("That's a good point!")
    player.nextChat(304014495)

def chat_304014495(player):
    player.playerChat("Maybe I could go on a quest to help you?")
    player.nextChat(304014496)

def chat_304014496(player):
    player.npcChat("Maybe later, I don't feel like giving you", "a quest at the moment.")
    player.nextChat(304014497)

def chat_304014497(player):
    player.playerChat("Alright, I'll be back soon.")
    player.endChat()