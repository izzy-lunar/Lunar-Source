# NPC Config Script
# Jossik - 1334
# Author Robbie

lighthouse_store = Shop("The Lighthouse Store", 235)

lighthouse_store.addItem(ShopItem(7754, 10))
lighthouse_store.addItem(ShopItem(7750, 10))
lighthouse_store.addItem(ShopItem(7752, 10))

def first_click_npc_1334(player): 
	player.startChat(4768530)
	
def second_click_npc_1334(player): 
	player.getShop().openShop(235)
	
def chat_4768530(player):
	player.npcChat("Would you like to browse the Lighthouse", "shop?")
	player.nextChat(4768531)
 
def chat_4768531(player):
    player.dialogueOption("Yes, please!", 4768532, "No, thank you.", 4768533)
 
def chat_4768532(player):
	player.getShop().openShop(235)
 
def chat_4768533(player):
	player.playerChat("No, thank you.")
	player.endChat()
	

