##################################
###      Cats plugin           ###
###    Created by OwnXile      ###
###    18th September 2013     ###
##################################
from com.ownxile.rs2.npcs import PetHandler
from com.ownxile.core import World

def chat_905500(player): #talk to cat
 player.npcChat("You killed my father.")
 player.nextChat(905501)

def chat_905501(player):
 player.playerChat("Yeah, don't take it personally.")
 player.nextChat(905510)
  
def chat_905510(player): #interact with cat
 player.npcChat("In his dying moment, my father poured his last ounce of", 
 "strength into my creation. My being is formed from his remains.")
 player.nextChat(905511)
 
def chat_905511(player): #talk to cat
 player.playerChat("No, I am your father.")
 player.nextChat(905512)

def chat_905512(player):
 player.npcChat("No you're not.")
 player.endChat()