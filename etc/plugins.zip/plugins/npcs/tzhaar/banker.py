from com.ownxile.core import World

World.addNonCombatNpc(5383, 2446, 5178, 0, 1)