World.addCombatNpc(78, 2752, 3409, 0, 1, 30, 5, 45,45)
World.addCombatNpc(78, 2754, 3403, 0, 1, 30, 5, 45,45)
World.addCombatNpc(78, 2751, 3397, 0, 1, 30, 5, 45,45)
World.addCombatNpc(78, 2752, 3402, 0, 1, 30, 5, 45,45)
