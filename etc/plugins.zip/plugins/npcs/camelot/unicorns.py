World.addCombatNpc(89, 2777, 3469, 0, 1, 35, 4, 30,30)
World.addCombatNpc(89, 2782, 3456, 0, 1, 35, 4, 30,30)
World.addCombatNpc(89, 2792, 3464, 0, 1, 35, 4, 30,30)
World.addCombatNpc(89, 2782, 3474, 0, 1, 35, 4, 30,30)
