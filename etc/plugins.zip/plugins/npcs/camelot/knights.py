World.addNonCombatNpc(251, 2763, 3515, 0, 1)#king arthur

World.addNonCombatNpc(239, 2763, 3509, 0, 1)#sir lancelot

World.addNonCombatNpc(240, 2754, 3507, 0, 1)
World.addNonCombatNpc(241, 2757, 3496, 0, 1)
World.addNonCombatNpc(242, 2763, 3488, 0, 1)
World.addNonCombatNpc(243, 2755, 3486, 0, 1)
World.addNonCombatNpc(244, 2752, 3502, 1, 1)
World.addNonCombatNpc(245, 2753, 3512, 0, 1)
World.addNonCombatNpc(249, 2767, 3500, 1, 1)
World.addNonCombatNpc(246, 2754, 3510, 1, 1)
