# NPC Config Script
# High Priest - 216
# Author Badger and Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(216, 2699, 3462, 0, 1)

def first_click_npc_216(player):
	player.startChat(8825000)
	
def chat_8825000(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(8825001)
	
def chat_8825001(player):
	player.npcChat("Hi " + str(player.playerName) + ", How can I help you", "on this fine day?")
	player.nextChat(8825002)

def chat_8825002(player):
	player.dialogueOption("I was wondering if you had any tasks.", 8825003, "I'm looking for quests!", 8825004)
	
def chat_8825003(player):
	player.playerChat("I was wondering if you had any tasks..")
	player.nextChat(8825005)
	
def chat_8825004(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(8825005)
	
def chat_8825005(player):
	player.npcChat("Hmm...I might have a quest for you", "but it is not necessary now, come back later.")
	player.nextChat(8825006)	
	
def chat_8825006(player):
	player.playerChat("Okay that sounds great.")
	player.endChat()