# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(209, 3010, 3451, 0, 1)

dwarf_nulodion = Shop("Nulodion's Supplies", 54)
dwarf_nulodion.addItem(ShopItem(6, 5)) #Base
dwarf_nulodion.addItem(ShopItem(8, 5)) #Stand
dwarf_nulodion.addItem(ShopItem(10, 5)) #Barrels
dwarf_nulodion.addItem(ShopItem(12, 5)) #Furnace
dwarf_nulodion.addItem(ShopItem(2, 100000)) #Cannon balls

def first_click_npc_209(player):
    player.startChat(1127884037)
    
def second_click_npc_209(player):
    player.getShop().openShop(54)
    
def chat_1127884037(player):
    player.npcChat("Hello, would you be interested in purchasing", "one of the most powerful weapons I can supply?!")
    player.nextChat(1127884038)

def chat_1127884038(player):
    player.playerChat("Show me what you have to offer.")
    player.nextChat(1127884039)

def chat_1127884039(player):
    player.npcChat("Sure, take a look.")
    player.nextChat(1127884040)

def chat_1127884040(player):
    player.getShop().openShop(54)
    player.endChat()