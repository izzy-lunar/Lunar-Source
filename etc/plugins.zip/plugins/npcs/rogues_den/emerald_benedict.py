World.addNonCombatNpc(2271, 3042, 4969, 1, 1)#banker

World.addNonCombatNpc(2270, 3051, 4977, 1, 1)#martin