# NPC Config Script
# Olivia - 2233
# Author Hawk
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(2233, 3076, 3246, 0, 1)
Farmer_shop = Shop("Olivia's Farming Shop", 978)

Farmer_shop.addItem(ShopItem(5340, 100))
Farmer_shop.addItem(ShopItem(5341, 100))
Farmer_shop.addItem(ShopItem(5343, 100))
Farmer_shop.addItem(ShopItem(952, 100))
Farmer_shop.addItem(ShopItem(5291, 500))
Farmer_shop.addItem(ShopItem(5292, 500))
Farmer_shop.addItem(ShopItem(5293, 500))
Farmer_shop.addItem(ShopItem(5294, 500))
Farmer_shop.addItem(ShopItem(5295, 500))
Farmer_shop.addItem(ShopItem(5296, 500))
Farmer_shop.addItem(ShopItem(5297, 500))
Farmer_shop.addItem(ShopItem(5298, 500))
Farmer_shop.addItem(ShopItem(5299, 500))
Farmer_shop.addItem(ShopItem(5300, 500))
Farmer_shop.addItem(ShopItem(5301, 500))
Farmer_shop.addItem(ShopItem(5302, 500))
Farmer_shop.addItem(ShopItem(5303, 500))
Farmer_shop.addItem(ShopItem(5304, 500))

def second_click_npc_2233(player):
	player.getShop().openShop(978)
	
def first_click_npc_2233(player):
	player.startChat(840000)
	
def chat_840000(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(840001)
	
def chat_840001(player):
	player.npcChat("Hi " + str(player.playerName) + "!", "Would you like to buy any farming supplies?")
	player.nextChat(840002)
	
def chat_840002(player):
	player.dialogueOption("Sure.", 840003, "No thank you.", 8400004)
	
def chat_840003(player):
	player.getShop().openShop(978)
	
def chat_8400004(player):
	player.npcChat("Looks like I'll be seeing you around, goodbye.")