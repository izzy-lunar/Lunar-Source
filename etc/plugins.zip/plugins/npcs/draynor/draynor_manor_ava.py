ava_shop = Shop("Ava's Devices", 70)
ava_shop.addItem(ShopItem(10498, 1))
ava_shop.addItem(ShopItem(10499, 1))

def chat_169100(player):
    player.npcChat("Hey there, how can I help you?")
    player.nextChat(169101)
    
def chat_169101(player):
    player.dialogueOption("About the device",169102, "Do you have anything for sale?", 169110, "Never mind", 0)

def chat_169102(player):
    player.playerChat("About the device... what does it do?")
    player.nextChat(169103)
    
def chat_169103(player):
    player.npcChat("Ah, my genius invention! It uses magnetism to", "attract arrows when they leave your", "quiver. It's not perfect but should save you", "some money on ammo.")
    player.nextChat(169104)
    
def chat_169104(player):
    player.playerChat("Great, thanks!")
    player.nextChat(169105)

def chat_169105(player):
    player.dialogueOption("Do you have anything for sale?", 169110, "Never mind", 169106)
   
def chat_169106(player):
    player.playerChat("Never mind.")
    player.endChat()

def chat_169110(player):
    player.getShop().openShop(70)