# Draynor NPC Config
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

#Bankers
World.addNonCombatNpc(494, 3088, 3246, 3, 0)
World.addNonCombatNpc(494, 3090, 3244, 3, 0)
World.addNonCombatNpc(494, 3088, 3240, 3, 0)

#Men
World.addCombatNpc(1, 3093, 3266, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 3091, 3275, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(3, 3101, 3280, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 3090, 3266, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(4, 3098, 3280, 0, 1, 10, 2, 1, 1)

#Misc
World.addNonCombatNpc(922, 3086, 3258, 0, 1)

#imps

World.addCombatNpc(708, 3104, 3216, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(708, 3091, 3224, 0, 1, 10, 2, 1, 1)

World.addCombatNpc(709, 3094, 3236, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(709, 3097, 3253, 0, 1, 10, 2, 1, 1)