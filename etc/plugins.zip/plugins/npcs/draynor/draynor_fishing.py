# Edgeville NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Draynor fishing spots
World.addNonCombatNpc(313, 3085, 3222, 0, 0) # Anchovies
World.addNonCombatNpc(316, 3085, 3230, 0, 0) # Sardines
World.addNonCombatNpc(309, 3086, 3227, 0, 0) # Herring