# Martin the farmer
# Martin 3299
# 2242 Piglet	
# 2243 Piglet	
# 2316 Pig	
# 2317 Pig
# Author Hawk

from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(3299, 3078, 3258, 0, 0)
World.addNonCombatNpc(2242, 3079, 3261, 0, 1)
World.addNonCombatNpc(2317, 3079, 3259, 0, 1)
World.addNonCombatNpc(2243, 3075, 3259, 0, 1)
World.addNonCombatNpc(2316, 3075, 3261, 0, 1)
	
def second_click_npc_3299(player):
	player.startChat(1817330)
	
def chat_1817330(player):
	player.npcChat("Get out of my pockets!")
	player.endChat()
	
def first_click_npc_3299(player):
	player.startChat(1814770)
	
def chat_1814770(player):
	player.playerChat("Hey, how are you?")
	player.nextChat(1814771)
	
def chat_1814771(player):
	player.npcChat("Hi, I'm pretty busy at the moment.")
	player.nextChat(1814772)
	
def chat_1814772(player):
	player.dialogueOption("Okay.", 1814773, "I can see that! Can I help at all?", 1814774)
	
def chat_1814773(player):
	player.playerChat("Okay.")
	player.endChat()
	
def chat_1814774(player):
	player.playerChat("I can see that! Can I help at all?")
	player.nextChat(1814775)
	
def chat_1814775(player):
	player.npcChat("Not right now, maybe another time?")
	player.nextChat(1814776)	
	
def chat_1814776(player):
	player.playerChat("I'll come by again soon.")
	player.endChat()