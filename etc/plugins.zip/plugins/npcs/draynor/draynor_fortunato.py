# NPC Config Script
# Fortunato - 3671
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(3671, 3085, 3252, 0, 0)
For_shop = Shop("Fortunato's Emporium", 1379)

For_shop.addItem(ShopItem(1931, 30))
For_shop.addItem(ShopItem(1935, 10))
For_shop.addItem(ShopItem(1825, 30))
For_shop.addItem(ShopItem(1925, 30))
For_shop.addItem(ShopItem(946, 10))
For_shop.addItem(ShopItem(590, 25))
For_shop.addItem(ShopItem(954, 250))
	
def first_click_npc_3671(player):
	player.startChat(6874580)
	
def second_click_npc_3671(player):
	player.getShop().openShop(1379)
	
def chat_6874580(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(6874581)
	
def chat_6874581(player):
	player.npcChat("Hi " + str(player.playerName) + " Would you like to buy any items?")
	player.nextChat(6874582)
	
def chat_6874582(player):
	player.dialogueOption("Sure.", 6874583, "No thank you.", 68745804)
	
def chat_6874583(player):
	player.getShop().openShop(1379)
	
def chat_68745804(player):
	player.npcChat("Looks like I'll be seeing you around, goodbye.")