

World.addNonCombatNpc(4288, 2855, 3541, 0, 1)
World.addNonCombatNpc(4289, 2843, 3540, 2, 1)
World.addNonCombatNpc(4296, 2841, 3543, 0, 3)
World.addNonCombatNpc(4293, 2840, 3550, 0, 0)
World.addNonCombatNpc(4294, 2846, 3553, 0, 0)

World.addCombatNpc(4292, 2844, 3550, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2849, 3546, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2854, 3538, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2857, 3543, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2863, 3548, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2870, 3550, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2869, 3542, 2, 1, 100, 9, 80, 80)
World.addCombatNpc(4292, 2854, 3550, 2, 1, 100, 9, 80, 80)