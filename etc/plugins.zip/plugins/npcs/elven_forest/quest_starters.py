World.addNonCombatNpc(1185, 2242, 3272, 0, 1)

World.addNonCombatNpc(1187, 2268, 3223, 0, 1)
World.addNonCombatNpc(1188, 2259, 3146, 0, 1)

def first_click_npc_1185(player):
    rv2_stage = player.getQuest(32).getStage()
    if rv2_stage == 11:
        player.startChat(800000060)
    elif rv2_stage == 12 and player.getQuest(33).getStage() == 0:
        player.startChat(650444442)
    elif rv2_stage == 12 and player.getQuest(33).getStage() == 1 and not player.hasItem(11042):
        player.startChat(650444455)
    elif rv2_stage == 12 and player.getQuest(33).getStage() == 1:
        player.startChat(650444457)
    else:
        player.sendMessage("The city guard looks busy.")