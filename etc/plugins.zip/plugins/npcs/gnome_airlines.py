def chat_1258831998(player):
    player.playerChat("What's Gnome Air?")
    player.nextChat(1258831999)

def chat_1258831999(player):
    player.npcChat("Gnome Air is the finest airline in OwnXile!")
    player.nextChat(1258832000)

def chat_1258832000(player):
    player.npcChat("Well...it's the only real airline in OwnXile.")
    player.nextChat(1258832001)

def chat_1258832001(player):
    player.npcChat("Ha!")
    player.nextChat(1258832002)

def chat_1258832002(player):
    player.playerChat("What do you mean by real airline?")
    player.nextChat(1258832003)

def chat_1258832003(player):
    player.npcChat("Well there's a dodgy magic carpet operating in the", "desert, I doubt it will ever take off... Ha!")
    player.nextChat(1258832004)

def chat_1258832004(player):
    player.playerChat("Where can you take me?")
    player.nextChat(1258832005)

def chat_1258832005(player):
    player.npcChat("We currently fly to 5 different air bases,", "would you like to see?")
    player.nextChat(1258832006)
	
def chat_1258832006(player):
    player.dialogueOption("Sure, fly me away!", 1258832007,"No way, I'm scared of heights.", 1258832008)
	
def chat_1258832007(player):
    player.getFunction().showInterface(802)
    player.endChat()
	
def chat_1258832008(player):
    player.playerChat("No way, I'm scared of heights.")
    player.endChat()