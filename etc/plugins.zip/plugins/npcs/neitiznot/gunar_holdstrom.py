#Gunnar Holdstrom
#5511
#trades yak hide

World.addNonCombatNpc(5511, 2321, 3791, 0, 1)
yak_shop = Shop("Holdstroms Hides", 1154)
yak_shop.sell = 1
#iron
yak_shop.addItem(ShopItem(10818, 0))
yak_shop.addItem(ShopItem(10822, 0))
yak_shop.addItem(ShopItem(10824, 0))

def first_click_npc_5511(player):
    player.getShop().openShop(1154)