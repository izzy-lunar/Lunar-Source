
World.addCombatNpc(5529, 2322, 3797, 0, 1, 50, 4, 30, 15)

World.addCombatNpc(5529, 2325, 3798, 0, 1, 50, 4, 30, 15)

World.addCombatNpc(5529, 2328, 3794, 0, 1, 50, 4, 30, 15)

World.addCombatNpc(5529, 2325, 3791, 0, 1, 50, 4, 30, 15)

World.addCombatNpc(5529, 2317, 3788, 0, 1, 50, 4, 30, 15)

World.addCombatNpc(5529, 2319, 3794, 0, 1, 50, 4, 30, 15)