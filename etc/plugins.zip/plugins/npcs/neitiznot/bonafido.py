# NPC Config Script
# Bonafido - 5580
# Author Numpty

World.addNonCombatNpc(5580, 2317, 3804, 0, 0)

