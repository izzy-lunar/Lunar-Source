# Entrana NPC
# Author Cam

#Sailor
World.addNonCombatNpc(3801, 3039, 3202, 0, 1)

def first_click_npc_3801(player):
	player.startChat(33075100)
	
def chat_33075100(player):
	player.npcChat("Hey, how can I help you?")
	player.nextChat(33075101)
	
def chat_33075101(player):
    player.dialogueOption("I wish to go to Pest Control!", 33075102, "Nevermind", 33075103)
	
def chat_33075102(player):
	player.npcChat("Enjoy your trip!")
	Sailing.startTravel(player, 14)
	
def chat_33075103(player):
	player.playerChat("Nevermind")
	player.nextChat(33075104)
	
def chat_33075104(player):
	player.npcChat("Alright then!")
	player.endChat()
