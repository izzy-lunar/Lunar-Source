# Port Sarim NPC
# Author Cam
#Tool Leprachaun
World.addNonCombatNpc(3021, 3061, 3260, 0, 1)

#Karamja seamen
World.addNonCombatNpc(376, 3028, 3215, 0, 1)
World.addNonCombatNpc(377, 3027, 3219, 0, 1)

#BarTender
World.addNonCombatNpc(731, 3045, 3256, 0, 1)

#Fishing
#World.addNonCombatNpc(, 3015, 3228, 0, 1)

#Grum
World.addNonCombatNpc(556, 3013, 3246, 0, 1)

#Betty
World.addNonCombatNpc(583, 3012, 3257, 0, 1)

#Shopkeeper
World.addNonCombatNpc(522, 3013, 3206, 0, 1)

#Battleaxe
World.addNonCombatNpc(519, 3027, 3252, 0, 1)

#Men
World.addCombatNpc(1, 3048, 3258, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 3011, 3236, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(3, 3023, 3260, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 3048, 3255, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(5, 3017, 3238, 0, 1, 10, 2, 1, 1)

#Grum
def first_click_npc_556(player):
    player.startChat(69105)
    
def second_click_npc_556(player):
    player.getShop().openShop(117)
    
#Betty
Betty_superior_staves = Shop("Betty's magical emporium", 6817)
Betty_superior_staves.addItem(ShopItem(1381, 100))
Betty_superior_staves.addItem(ShopItem(1383, 100))
Betty_superior_staves.addItem(ShopItem(1385, 100))
Betty_superior_staves.addItem(ShopItem(1387, 100))
Betty_superior_staves.addItem(ShopItem(2415, 100))
Betty_superior_staves.addItem(ShopItem(2416, 100))
Betty_superior_staves.addItem(ShopItem(2417, 100))
Betty_superior_staves.addItem(ShopItem(4675, 100))

def first_click_npc_583(player):
    player.startChat(6910555)
    
def chat_6910555(player):
    player.npcChat("Welcome to the gem shop.", "Would you like to buy anything?")
    player.nextChat(6910556)
       
def chat_6910556(player):
    player.dialogueOption("Sure, I'll have a look.", 6910557, "No thanks.", 6910558)
       
def chat_6910557(player):
    player.getShop().openShop(6817)
       
def chat_6910558(player):
    player.playerChat("No thanks.")
    player.endChat()

def second_click_npc_583(player):
    player.getShop().openShop(6817)    