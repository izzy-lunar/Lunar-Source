from com.ownxile.rs2.world.transport import Sailing

def chat_1683977493(player):
    player.npcChat("Would you like to take a trip", "to Karamja? Free of charge.")
    player.nextChat(1683977494)

def chat_1683977494(player):
    player.dialogueOption("Sure, sounds exotic!", 1683977495, "No thanks", 1683977496)
 
def chat_1683977495(player):
    player.playerChat("Sure, sounds exotic!")
    player.nextChat(1683977497)

def chat_1683977496(player):
    player.npcChat("No thanks")
    player.endChat()

def chat_1683977497(player):
    player.npcChat("All aboard!")
    player.nextChat(1683977498)

def chat_1683977498(player):
    Sailing.startTravel(player, 5)
    player.endChat()

def first_click_npc_376(player):
    player.startChat(1683977493)

def first_click_npc_377(player):
    player.startChat(1683977493)

def second_click_npc_376(player):
    Sailing.startTravel(player, 5)

def second_click_npc_377(player):
    Sailing.startTravel(player, 5)