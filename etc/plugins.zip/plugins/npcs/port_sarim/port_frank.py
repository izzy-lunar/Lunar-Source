# Frank - 375
# Author Cam

World.addNonCombatNpc(375, 3050, 3245, 0, 1)

def first_click_npc_375(player):
	player.startChat(4745670)
	
def chat_4745670(player):
	player.playerChat("Hello there, I'm called " + str(player.playerName) + "!")
	player.nextChat(4745671)
	
def chat_4745671(player):
	player.npcChat("Hi " + str(player.playerName) + ", what can I help you with today?")
	player.nextChat(4745672)

def chat_4745672(player):
	player.dialogueOption("Nothing.", 4745673, "I'm looking for quests!", 4745674)
	
def chat_4745673(player):
	player.playerChat("Nothing.")
	player.endChat()
    
def chat_4745674(player):
	player.playerChat("I'm looking for quests!")
	player.nextChat(4745675)
	
def chat_4745675(player):
	player.npcChat("Maybe if you come back another time", "I'll have a quest for you!")
	player.nextChat(4745676)	
	
def chat_4745676(player):
	player.playerChat("Okay sure.")
	player.endChat()