#Entrana Monk
#Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World
from com.ownxile.rs2.Point import Position
from com.ownxile.rs2.world.transport import Sailing

Emonk_spawn = World.addNonCombatNpc(657, 3050, 3235, 0, 1)

def first_click_npc_657(player):
	player.startChat(1075100)
	
def second_click_npc_657(player):
	Sailing.startTravel(player, 1)
	
def chat_1075100(player):
	player.npcChat("Hello there, how can I help you?")
	player.nextChat(1075101)
	
def chat_1075101(player):
    player.dialogueOption("I wish to go to Entrana!", 1075102, "Nevermind.", 1075103)
	
def chat_1075102(player):
	player.endChat()
	Sailing.startTravel(player, 1)
	
def chat_1075103(player):
	player.playerChat("Nevermind.")
	player.nextChat(1075104)
	
def chat_1075104(player):
	player.npcChat("Okay then!")
	player.endChat()