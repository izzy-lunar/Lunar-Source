                                                                #Author Aram
World.addNonCombatNpc(1182, 2207, 3258, 0, 1)#lord

World.addNonCombatNpc(1199, 2175, 3280, 0, 1)#tracker


                            
                            