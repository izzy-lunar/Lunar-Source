World.addCombatNpc(2552, 3106, 3810, 0, 1, 600, 99, 550,250)#callisto

World.addCombatNpc(4173, 3219, 3679, 0, 1, 600, 77, 550,250)#venet
World.addCombatNpc(4172, 3236, 3946, 0, 1, 600, 77, 550,250)#scorp
World.addCombatNpc(4175, 2985, 3878, 0, 1, 600, 77, 550,250)#vetion
