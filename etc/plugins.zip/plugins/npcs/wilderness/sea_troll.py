from com.ownxile.core import World

World.addCombatNpc(3847, 3324, 3916, 0, 1, 600, 80, 550,350)#madstats
