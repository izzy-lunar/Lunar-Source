#hellhounds
World.addCombatNpc(49, 3215, 3923, 0, 1, 100, 11, 120,120)
World.addCombatNpc(49, 3208, 3914, 0, 1, 100, 11, 120,120)
World.addCombatNpc(49, 3206, 3920, 0, 1, 100, 11, 120,120)

#wolves
World.addCombatNpc(95, 3244, 3920, 0, 1, 75, 8, 80,80)
World.addCombatNpc(95, 3251, 3910, 0, 1, 75, 8, 80,80)
World.addCombatNpc(95, 3259, 3922, 0, 1, 75, 8, 80,80)
