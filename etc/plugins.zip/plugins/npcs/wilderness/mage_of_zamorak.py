from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

mages_store = Shop("Mage of Zamoraks Runecrafting Equipment", 51)
mages_store.addItem(ShopItem(5537, 1))
mages_store.addItem(ShopItem(5535, 1))
mages_store.addItem(ShopItem(5533, 1))
mages_store.addItem(ShopItem(5539, 1))
mages_store.addItem(ShopItem(5541, 1))
mages_store.addItem(ShopItem(5543, 1))
mages_store.addItem(ShopItem(5545, 1))
mages_store.addItem(ShopItem(5547, 1))
mages_store.addItem(ShopItem(5531, 1))
mages_store.addItem(ShopItem(5527, 1))
mages_store.addItem(ShopItem(5529, 1))
mages_store.addItem(ShopItem(5549, 1))
mage_of_zamorak = 2259
mage_of_zamorak_spawn = World.addNonCombatNpc(mage_of_zamorak, 3106, 3558, 0, 1)

def first_click_npc_2259(player):
	player.startChat(10200)

def second_click_npc_2259(player):
	player.getShop().openShop(51)

def third_click_npc_2259(player):
	mage_of_zamorak_spawn.startAnimation(1818)
	mage_of_zamorak_spawn.gfx0(343)
	mage_of_zamorak_spawn.turnNpc(player.getX(), player.getY())
	mage_of_zamorak_spawn.forceChat("Veniens! Sallakar! Rinnesset!")
	player.isSkulled = True
	player.skullTimer = 1600
	player.headIconPk = 0
	player.getFunction().requestUpdates()
	player.getTask().teleport(3039, 4834, 0)

