# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(1783, 3079, 3518, 0, 1) #Richard
World.addNonCombatNpc(1787, 3069, 3647, 0, 1) #Sam
World.addNonCombatNpc(1784, 3028, 3715, 0, 1) #Neil

World.addNonCombatNpc(1779, 2974, 3794, 0, 1) #Ian
World.addNonCombatNpc(1785, 3095, 3795, 0, 1) #Edmond
World.addNonCombatNpc(1781, 3021, 3890, 0, 1) #Darren

World.addNonCombatNpc(1778, 3169, 3888, 0, 1) #William
World.addNonCombatNpc(1782, 3374, 3893, 0, 1) #Edward
World.addNonCombatNpc(1786, 3244, 3611, 0, 1) #Simon

richard_cape = Shop("Richard's Wilderness Cape Shop", 13)
richard_cape.addItem(ShopItem(4325, 50))
richard_cape.addItem(ShopItem(4345, 50))
richard_cape.addItem(ShopItem(4365, 50))
richard_cape.addItem(ShopItem(4385, 50))
richard_cape.addItem(ShopItem(4405, 50))

sam_cape = Shop("Sam's Wilderness Cape Shop", 14)
sam_cape.addItem(ShopItem(4333, 50))
sam_cape.addItem(ShopItem(4353, 50))
sam_cape.addItem(ShopItem(4373, 50))
sam_cape.addItem(ShopItem(4393, 50))
sam_cape.addItem(ShopItem(4413, 50))

neil_cape = Shop("Neil's Wilderness Cape Shop", 15)
neil_cape.addItem(ShopItem(4327, 50))
neil_cape.addItem(ShopItem(4347, 50))
neil_cape.addItem(ShopItem(4367, 50))
neil_cape.addItem(ShopItem(4387, 50))
neil_cape.addItem(ShopItem(4407, 50))

ian_cape = Shop("Ian's Wilderness Cape Shop", 16)
ian_cape.addItem(ShopItem(4317, 50))
ian_cape.addItem(ShopItem(4337, 50))
ian_cape.addItem(ShopItem(4357, 50))
ian_cape.addItem(ShopItem(4377, 50))
ian_cape.addItem(ShopItem(4397, 50))

edmond_cape = Shop("Edmond's Wilderness Cape Shop", 27)
edmond_cape.addItem(ShopItem(4329, 50))
edmond_cape.addItem(ShopItem(4349, 50))
edmond_cape.addItem(ShopItem(4369, 50))
edmond_cape.addItem(ShopItem(4389, 50))
edmond_cape.addItem(ShopItem(4409, 50))

darren_cape = Shop("Darren's Wilderness Cape Shop", 30)
darren_cape.addItem(ShopItem(4321, 50))
darren_cape.addItem(ShopItem(4341, 50))
darren_cape.addItem(ShopItem(4361, 50))
darren_cape.addItem(ShopItem(4381, 50))
darren_cape.addItem(ShopItem(4401, 50))

william_cape = Shop("William's Wilderness Cape Shop", 31)
william_cape.addItem(ShopItem(4315, 50))
william_cape.addItem(ShopItem(4335, 50))
william_cape.addItem(ShopItem(4355, 50))
william_cape.addItem(ShopItem(4375, 50))
william_cape.addItem(ShopItem(4395, 50))

edward_cape = Shop("Edward's Wilderness Cape Shop", 32)
edward_cape.addItem(ShopItem(4323, 50))
edward_cape.addItem(ShopItem(4343, 50))
edward_cape.addItem(ShopItem(4363, 50))
edward_cape.addItem(ShopItem(4383, 50))
edward_cape.addItem(ShopItem(4403, 50))

simon_cape = Shop("Simon's Wilderness Cape Shop", 33)
simon_cape.addItem(ShopItem(4331, 50))
simon_cape.addItem(ShopItem(4351, 50))
simon_cape.addItem(ShopItem(4371, 50))
simon_cape.addItem(ShopItem(4391, 50))
simon_cape.addItem(ShopItem(4411, 50))

# Richard
def first_click_npc_1783(player):
    player.startChat(675615)

def second_click_npc_1783(player):
    player.getShop().openShop(13)

# Sam    
def first_click_npc_1787(player):
    player.startChat(675625)
	
def second_click_npc_1787(player):
    player.getShop().openShop(14)

# Neil
def first_click_npc_1784(player):
    player.startChat(675635)

# Ian
def first_click_npc_1779(player):
    player.startChat(675645)
    
# Edmond
def first_click_npc_1785(player):
    player.startChat(675655)

# Darren
def first_click_npc_1781(player):
    player.startChat(675665)

# William
def first_click_npc_1778(player):
    player.startChat(675675)

# Edward
def first_click_npc_1782(player):
    player.startChat(675685)

# Simon
def first_click_npc_1786(player):
    player.startChat(675695)    

# Richard
def chat_675615(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675616)
       
def chat_675616(player):
    player.dialogueOption("Look at Richard's stock", 675617, "Leave", 675618)
       
def chat_675617(player):
    player.getShop().openShop(13)
       
def chat_675618(player):
    player.playerChat("No thanks.")
    player.endChat()
# Richard

# Sam
def chat_675625(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675626)
       
def chat_675626(player):
    player.dialogueOption("Look at Sam's stock", 675627, "Leave", 675628)
       
def chat_675627(player):
    player.getShop().openShop(14)
       
def chat_675628(player):
    player.playerChat("No thanks.")
    player.endChat()
# Sam

# Neil
def chat_675635(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675636)
       
def chat_675636(player):
    player.dialogueOption("Look at Neil's stock", 675637, "Leave", 675638)
       
def chat_675637(player):
    player.getShop().openShop(15)
       
def chat_675638(player):
    player.playerChat("No thanks.")
    player.endChat()
# Neil

# Ian
def chat_675645(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675646)
       
def chat_675646(player):
    player.dialogueOption("Look at Ian's stock", 675647, "Leave", 675648)
       
def chat_675647(player):
    player.getShop().openShop(16)
       
def chat_675648(player):
    player.playerChat("No thanks.")
    player.endChat()    
# Ian

# Edmond
def chat_675655(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675656)
       
def chat_675656(player):
    player.dialogueOption("Look at Edmond's stock", 675657, "Leave", 675658)
       
def chat_675657(player):
    player.getShop().openShop(27)
       
def chat_675658(player):
    player.playerChat("No thanks.")
    player.endChat()    
# Edmond

# Darren
def chat_675665(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675666)
       
def chat_675666(player):
    player.dialogueOption("Look at Darren's stock", 675667, "Leave", 675668)
       
def chat_675667(player):
    player.getShop().openShop(30)
       
def chat_675668(player):
    player.playerChat("No thanks.")
    player.endChat()    
# Darren

# William
def chat_675675(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675676)
       
def chat_675676(player):
    player.dialogueOption("Look at William's stock", 675677, "Leave", 675678)
       
def chat_675677(player):
    player.getShop().openShop(31)
       
def chat_675678(player):
    player.playerChat("No thanks.")
    player.endChat()    
# William

# Edward
def chat_675685(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675686)
       
def chat_675686(player):
    player.dialogueOption("Look at Edward's stock", 675687, "Leave", 675688)
       
def chat_675687(player):
    player.getShop().openShop(32)
       
def chat_675688(player):
    player.playerChat("No thanks.")
    player.endChat()    
# Edward

# Simon
def chat_675695(player):
    player.npcChat("Hi, would you like to buy any of my capes?")
    player.nextChat(675696)
       
def chat_675696(player):
    player.dialogueOption("Look at Simon's stock", 675697, "Leave", 675698)
       
def chat_675697(player):
    player.getShop().openShop(33)
       
def chat_675698(player):
    player.playerChat("No thanks.")
    player.endChat()    
# Simon