World.addCombatNpc(117, 2549, 3147, 0, 1, 30, 4, 30,15)
World.addCombatNpc(117, 2548, 3149, 0, 1, 30, 4, 30,15)
World.addCombatNpc(95, 2548, 3178, 0, 1, 50, 5, 45,30)
World.addCombatNpc(61, 2542, 3179, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2540, 3180, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2538, 3179, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2536, 3180, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2535, 3181, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2537, 3183, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2540, 3182, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2542, 3183, 0, 1, 3, 1, 1,1)
World.addCombatNpc(100, 2545, 3184, 0, 1, 5, 1, 3,1)
World.addCombatNpc(61, 2546, 3187, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2544, 3187, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2541, 3185, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2541, 3185, 0, 1, 3, 1, 1,1)
World.addCombatNpc(61, 2541, 3191, 0, 1, 3, 1, 1,1)
World.addCombatNpc(100, 2554, 3198, 0, 1, 5, 1, 1,1)
World.addCombatNpc(100, 2553, 3185, 0, 1, 5, 1, 1,1)
World.addCombatNpc(115, 2553, 3188, 0, 1, 58, 8, 50,40)
World.addCombatNpc(101, 2552, 3195, 0, 1, 10, 2, 8,1)
World.addCombatNpc(100, 2552, 3196, 0, 1, 5, 1, 1,1)
World.addCombatNpc(100, 2543, 3194, 0, 1, 5, 1, 1,1)
World.addCombatNpc(47, 2523, 3193, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2517, 3191, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2512, 3194, 0, 1, 2, 1, 1,1)
World.addCombatNpc(95, 2512, 3194, 0, 1, 50, 5, 45,30)
World.addCombatNpc(86, 2523, 3188, 0, 1, 6, 2, 5,1)
World.addCombatNpc(101, 2544, 3153, 0, 1, 10, 2, 8,1)
World.addNonCombatNpc(486, 2515, 3177, 0, 1)

def first_click_npc_486(player):
    player.startChat(767094782)

def chat_767094782(player):
    player.playerChat("Hello.")
    player.nextChat(767094783)
    
def chat_767094783(player):
    player.npcChat("Gotta find a way out. We built this maze for protection","but I can't get used to it. I'm always getting lost.")
    player.endChat()

World.addCombatNpc(47, 2500, 3172, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2502, 3167, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2501, 3162, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2498, 3161, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2497, 3165, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2502, 3153, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2506, 3150, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2507, 3145, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2505, 3145, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2501, 3148, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2498, 3142, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2501, 3138, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2506, 3138, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2512, 3141, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2517, 3141, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2526, 3142, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2529, 3145, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2521, 3144, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2514, 3148, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2510, 3154, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2510, 3157, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2512, 3166, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2508, 3168, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2510, 3175, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2504, 3170, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2505, 3160, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2504, 3154, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2501, 3151, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2511, 3147, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2525, 3152, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2531, 3152, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2536, 3151, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2543, 3139, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2547, 3142, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2554, 3161, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2510, 3164, 0, 1, 2, 1, 1,1)
World.addCombatNpc(47, 2512, 3174, 0, 1, 2, 1, 1,1)


World.addCombatNpc(138, 2508, 3140, 0, 1, 30, 4, 30,1)
World.addCombatNpc(138, 2502, 3141, 0, 1, 30, 4, 30,1)
World.addCombatNpc(101, 2513, 3146, 0, 1, 8, 1, 5,1)
World.addCombatNpc(117, 2508, 3151, 0, 1, 30, 4, 25,20)
World.addCombatNpc(708, 2505, 3153, 0, 1, 8, 1, 1,1)
World.addCombatNpc(101, 2528, 3155, 0, 1, 8, 1, 5,1)
World.addCombatNpc(101, 2523, 3155, 0, 1, 8, 1, 5,1)
World.addCombatNpc(101, 2537, 3155, 0, 1, 8, 1, 5,1)
World.addCombatNpc(106, 2501, 3153, 0, 1, 18, 4, 18,5)
World.addCombatNpc(106, 2502, 3175, 0, 1, 18, 4, 18,5)
World.addCombatNpc(101, 2511, 3185, 0, 1, 8, 1, 5,1)
World.addNonCombatNpc(473, 2504, 3191, 0, 1)

def first_click_npc_473(player):
    player.startChat(1481554627)
    
def chat_1481554627(player):
    player.playerChat("Hello!")
    player.nextChat(1481554628)
    
def chat_1481554628(player):
    player.npcChat("Hello, welcome to our maze. I'm Elkoy the tree gnome.")
    player.nextChat(1481554629)

def chat_1481554629(player):
    player.playerChat("I haven't heard of your sort.")
    player.nextChat(1481554630)

def chat_1481554630(player):
    player.npcChat("There's not many of us left. Once you could find tree","gnomes anywhere in the world, now we hide in small"," groups to avoid capture.")
    player.nextChat(1481554631)

def chat_1481554631(player):
    player.playerChat("Captured by whom?")
    player.nextChat(1481554632)
    
def chat_1481554632(player):
    player.npcChat("Tree gnomes have been hunted for so called 'fun' since","as long as I can remember.")
    player.nextChat(1481554633)

def chat_1481554633(player):
    player.npcChat("Our main threat nowadays are General Khazard's","troops. They know no mercy, but are also very dense","They'll never find their way through our maze.")
    player.nextChat(1481554634)

def chat_1481554634(player):
    player.npcChat("Have fun.")
    player.endChat()
     
     

World.addCombatNpc(86, 2518, 3183, 0, 1, 5, 1, 3,1)

World.addCombatNpc(101, 2545, 3161, 0, 1, 8, 1, 5,1)
World.addCombatNpc(101, 2550, 3157, 0, 1, 8, 1, 5,1)
World.addNonCombatNpc(473, 2515, 3160, 0, 1)

    
World.addCombatNpc(66, 2520, 3173, 0, 1, 3, 1, 1,1)

def second_click_npc_66(player):
    player.startChat(1481554635)

def chat_1481554635(player):
    player.playerChat("Hello.")
    player.nextChat(1481554636)
    
def chat_1481554636(player):
    player.npcChat("How's life treating you?")
    player.nextChat(1481554637)

def chat_1481554637(player):
    player.playerChat("Not bad, not bad at all.")
    player.nextChat(1481554638)

def chat_1481554638(player):
    player.npcChat("It's good to see a human with a positive attitude.")
    player.endChat()
    
World.addCombatNpc(66, 2528, 3171, 0, 1, 3, 1, 1,1)
World.addCombatNpc(66, 2530, 3167, 0, 1, 3, 1, 1,1)
World.addCombatNpc(66, 2534, 3165, 0, 1, 3, 1, 1,1)
World.addCombatNpc(66, 2538, 3159, 0, 1, 3, 1, 1,1)
World.addCombatNpc(66, 2524, 3163, 0, 1, 3, 1, 1,1)
World.addCombatNpc(66, 2518, 3167, 0, 1, 3, 1, 1,1)
World.addNonCombatNpc(472, 2525, 3168, 0, 1)

def second_click_npc_472(player):
    player.startChat(1481554639)
    
def chat_1481554639(player):
    player.playerChat("Hello.")
    player.nextChat(1481554640)

def chat_1481554640(player):
    player.npcChat("Well done, well done. Not many find their way in here.")
    player.nextChat(1481554641)

def chat_1481554641(player):
    player.npcChat("I'm Remsai, a tree gnome. We live in this maze for our","protection. Have a look around and enjoy.")
    player.nextChat(1481554642)

def first_click_npc_484(player):
    player.startChat(1481554642)
    
def chat_1481554642(player):
    player.playerChat("Hello!")
    player.nextChat(1481554643)

def chat_1481554643(player):
    player.npcChat("Lardi dee, lardi da.")
    player.nextChat(1481554644)

def chat_1481554644(player):
    player.playerChat("Are you alright?")
    player.nextChat(1481554645)

def chat_1481554645(player):
    player.npcChat("Hee hee, lardi da, lardi dee. (The gnome appears to be","singing.)")
    player.endChat()

World.addNonCombatNpc(484, 2542, 3167, 0, 2)
World.addNonCombatNpc(484, 2541, 3171, 0, 2)
World.addNonCombatNpc(484, 2542, 3172, 0, 2)
World.addNonCombatNpc(484, 2541, 3168, 0, 2)

World.addNonCombatNpc(469, 2543, 3169, 0, 1)

def first_click_npc_469(player):
    player.startChat(1481554646)
    
def chat_1481554646(player):
    player.playerChat("Hello.")
    player.nextChat(1481554647)
       
def chat_1481554647(player):
    player.npcChat("Well hello stranger. My name's Bolren, I'm the king of","the tree gnomes.")
    player.nextChat(1481554648)

def chat_1481554648(player):
    player.npcChat("I'm surprised you made it in, maybe I made the maze","too easy.")
    player.nextChat(1481554649)

def chat_1481554649(player):
    player.playerChat("Maybe.")
    player.nextChat(1481554650)

def chat_1481554650(player):
    player.npcChat("I'm afraid I have more serious concerns at the","moment. Very serious.")
    player.nextChat(1481554651)

def chat_1481554651(player):
    player.playerChat("I'll leave you to it then.")
    player.endChat()

def second_click_npc_471(player):
    player.getShop().openShop(88)
	
def first_click_npc_471(player):
    player.startChat(1481554652)

def chat_1481554652(player):
    player.playerChat("Hello there.")
    player.nextChat(1481554653)

def chat_1481554653(player):
    player.npcChat("Hello stranger, new to these parts?")
    player.nextChat(1481554654)

def chat_1481554654(player):
    player.npcChat("I'm Bolkoy by the way. I'm the village shopkeeper.","Would you like to buy something?")
    player.nextChat(1481554655)

def chat_1481554655(player):
    player.playerChat("Sure I'll have a look.")
    player.nextChat(1481554658)

def chat_1481554658(player):
    player.getShop().openShop(88)
    player.endChat()

bolkoy_shop = Shop("Bolkoy's Village Shop", 88)
bolkoy_shop.addItem(ShopItem(1931, 3))
bolkoy_shop.addItem(ShopItem(1265, 5))
bolkoy_shop.addItem(ShopItem(1935, 2))
bolkoy_shop.addItem(ShopItem(1735, 2))
bolkoy_shop.addItem(ShopItem(1925, 2))
bolkoy_shop.addItem(ShopItem(590, 2))
bolkoy_shop.addItem(ShopItem(1755, 2))
bolkoy_shop.addItem(ShopItem(2347, 5))
bolkoy_shop.addItem(ShopItem(39, 30))
bolkoy_shop.addItem(ShopItem(2142, 2))