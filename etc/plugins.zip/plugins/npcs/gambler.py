from com.ownxile.rs2.world.games import Gambling
from com.ownxile.core import World
gambler = World.addNonCombatNpc(2998, 2741, 3474, 0, 1)

def gambler_announce(s):
    gambler.forceChat(str(s))
    
def first_click_npc_2998(player):
    if player.isGambling or player.playerRights > 1:
        player.sendMessage("That NPC is busy.")
    else:
        player.startChat(1926215663)

def second_click_npc_2998(player):
    if player.isGambling or player.playerRights > 1:
        player.sendMessage("That NPC is busy.")
    elif player.hasItem(995, 100000):
        Gambling.getInstance().submit(player)
        player.endChat()
    else:
        player.boxMessage("You need 100,000 coins to gamble.")

def chat_1926215663(player):
    player.npcChat("Come to gamble, have you?", "The current pot stands at " + str(Gambling.getInstance().getPot()) + ".")
    player.nextChat(1926215664)

def chat_1926215664(player):
    player.dialogueOption("Gamble 100k coins", 1926215665, "No", 1926215670)

def chat_1926215665(player):
    if player.hasItem(995, 100000):
        player.playerChat("Yes, hit me geezer.")
        player.nextChat(1926215666)
    else:
        player.npcChat("You don't have enough money to play.")
        player.endChat()

def chat_1926215666(player):
    player.npcChat("Very well, I'll start the countdown...")
    player.nextChat(1926215667)

def chat_1926215667(player):
    Gambling.getInstance().submit(player)
    player.endChat()

