# Taverley sword shop
# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(586, 2885, 3450, 0, 1)

t_sword_shop = Shop("Taverley Sword Shop", 96)
t_sword_shop.addItem(ShopItem(1307, 15))
t_sword_shop.addItem(ShopItem(1309, 15))
t_sword_shop.addItem(ShopItem(1311, 10))
t_sword_shop.addItem(ShopItem(1313, 10))
t_sword_shop.addItem(ShopItem(1315, 10))
t_sword_shop.addItem(ShopItem(1317, 7))
t_sword_shop.addItem(ShopItem(1319, 5))

def first_click_npc_586(player):
    player.startChat(5870020)

def second_click_npc_586(player):
    player.getShop().openShop(96)
    
def chat_5870020(player):
    player.npcChat("Hi there, would you like to have", "a look at my supplies?")
    player.nextChat(5870021)

def chat_5870021(player):
    player.playerChat("Sure.")
    player.nextChat(5870022)

def chat_5870022(player):
    player.getShop().openShop(96)