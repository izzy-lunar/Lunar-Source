# Taverley herb shop
# Author Parrot
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.core import World

World.addNonCombatNpc(587, 2897, 3427, 0, 1)

t_herb_shop = Shop("Taverley Herb Shop", 98)
t_herb_shop.addItem(ShopItem(221, 100))
t_herb_shop.addItem(ShopItem(233, 100))
t_herb_shop.addItem(ShopItem(229, 5000))

def first_click_npc_587(player):
    player.startChat(5870000)

def second_click_npc_587(player):
    player.getShop().openShop(98)
    
def chat_5870000(player):
    player.npcChat("Hi there, would you like to have", "a look at my supplies?")
    player.nextChat(5870001)

def chat_5870001(player):
    player.playerChat("Sure.")
    player.nextChat(5870002)

def chat_5870002(player):
    player.getShop().openShop(98)