# Taverley NPCS
# Author Parrot
from com.ownxile.core import World

# npc id, x, y, height, stationary, hp, maxhit, attack, defence

# Druids
World.addCombatNpc(14, 2890, 3450, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2895, 3447, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2895, 3442, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2894, 3438, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2898, 3437, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2893, 3434, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2890, 3433, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2889, 3438, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2887, 3441, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2884, 3431, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2882, 3423, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2886, 3418, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2893, 3419, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2887, 3409, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2899, 3407, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2908, 3418, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2905, 3449, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2910, 3449, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2905, 3441, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2909, 3440, 0, 1, 30, 5, 20, 20)

# Henge
World.addCombatNpc(14, 2922, 3486, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(455, 2926, 3487, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2929, 3486, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2930, 3483, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2928, 3480, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2925, 3480, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2923, 3481, 0, 1, 30, 5, 20, 20)
World.addCombatNpc(14, 2922, 3483, 0, 1, 30, 5, 20, 20)

# Non combat
World.addNonCombatNpc(1213, 2914, 3418, 0, 0) #Tegid

def first_click_npc_1213(player):
    player.startChat(5870090)

def chat_5870090(player):
    player.npcChat("What a lovely day to wash my robes!")
    player.endChat()