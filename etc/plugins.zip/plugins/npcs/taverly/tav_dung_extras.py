#some extra ghosts when you first enter - 103
World.addCombatNpc(103, 2882, 9809, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(103, 2886, 9811, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(103, 2882, 9820, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(103, 2886, 9817, 0, 1, 30, 4, 25, 20)
World.addCombatNpc(103, 2889, 9848, 0, 1, 30, 4, 25, 20)

#some extra level 45 skeletons
World.addCombatNpc(93, 2882, 9827, 0, 1, 50, 6, 45, 30)
World.addCombatNpc(93, 2885, 9830, 0, 1, 50, 6, 45, 30)
World.addCombatNpc(93, 2883, 9835, 0, 1, 50, 6, 45, 30)
World.addCombatNpc(93, 2884, 9842, 0, 1, 50, 6, 45, 30)

#chaos druids
World.addCombatNpc(181, 2893, 9829, 0, 1, 20, 6, 25, 10)
World.addCombatNpc(181, 2891, 9832, 0, 1, 20, 6, 25, 10)
World.addCombatNpc(181, 2895, 9833, 0, 1, 20, 6, 25, 10)

#rogues
World.addCombatNpc(187, 2894, 9823, 0, 1, 15, 4, 15, 10)
World.addCombatNpc(187, 2901, 9819, 0, 1, 15, 4, 15, 10)
World.addCombatNpc(187, 2908, 9820, 0, 1, 15, 4, 15, 10)
World.addCombatNpc(187, 2914, 9818, 0, 1, 15, 4, 15, 10)
