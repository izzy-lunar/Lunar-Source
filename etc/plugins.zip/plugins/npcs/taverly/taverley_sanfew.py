# Taverley sanfew
# Author Parrot
from com.ownxile.core import World

World.addNonCombatNpc(454, 2897, 3427, 1, 1)

def first_click_npc_454(player):
    stage = player.getQuest(25).getStage()
    if stage == 1:
        player.startChat(1085684074)
    elif stage == 2:
        player.startChat(1543042786)
    elif stage == 3:
        player.startChat(1543042791)
    else:
        player.startChat(5870040)

def chat_5870040(player):
    player.npcChat("Hi there, what are you doing up here?")
    player.nextChat(5870041)

def chat_5870041(player):
    player.playerChat("Nothing really, just wondering around.")
    player.nextChat(5870042)
    
def chat_5870042(player):
    player.npcChat("Okay then.")
    player.endChat()
    