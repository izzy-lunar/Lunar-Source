# Taverley Alain
# Author Parrot
from com.ownxile.core import World

World.addNonCombatNpc(2339, 2935, 3442, 0, 1)

def first_click_npc_2339(player):
    player.startChat(5870060)

def second_click_npc_586(player):
    player.startChat(5870064)
    
def chat_5870060(player):
    player.playerChat("What a lovely day it is today!")
    player.nextChat(5870061)    
    
def chat_5870061(player):
    player.npcChat("Isn't it beautiful?")
    player.nextChat(5870062)

def chat_5870062(player):
    player.dialogueOption("It certainly is. Happy gardening!", 5870063, "Do you have a watering can I can buy?", 5870064)    
    
def chat_5870063(player):
    player.playerChat("It certainly is. Happy gardening!")
    player.endChat()
    
def chat_5870064(player):
    player.playerChat("Do you have a watering can I can buy?")
    player.nextChat(5870065)    
    
def chat_5870065(player):
    player.npcChat("Not really.")
    player.nextChat(5870066)    

def chat_5870066(player):
    player.dialogueOption("Oh okay.", 5870067, "Please! I'll pay 10,000 coins.", 5870068)        

def chat_5870067(player):
    player.playerChat("Oh okay.")
    player.endChat()    
    
def chat_5870068(player):
    player.playerChat("Please! I'll pay 10,000 coins.")
    player.nextChat(5870069)        
    
def chat_5870069(player):
    player.npcChat("Hmm... okay then.")
    player.nextChat(5870070)    
    
def chat_5870070(player):
    player.playerChat("Thanks!")
    player.nextChat(5870071)    

def chat_5870071(player):
    if player.hasItem(995, 10000):
        player.npcChat("Here you go.")
        player.deleteItem(995, 10000)
        player.addItem(5331, 1)
        player.endChat()
    else:    
        player.playerChat("Oh wait... Sorry I don't have 10,000 coins on me.")
        player.endChat()
    