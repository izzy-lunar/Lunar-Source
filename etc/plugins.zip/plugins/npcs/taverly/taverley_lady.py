# Taverley sanfew
# Author Parrot
from com.ownxile.core import World

World.addNonCombatNpc(250, 2924, 3406, 0, 1)

def first_click_npc_250(player):
    player.startChat(5870100)
    
def chat_5870100(player):
    player.npcChat("What are you doinh here?")
    player.nextChat(5870101)

def chat_5870101(player):
    player.playerChat("Nothing really, just exploring.", "What are you doing here...?")
    player.nextChat(5870102)
    
def chat_5870102(player):
    player.npcChat("Well, I am the lady of the lake!", "This is my favourite spot.")
    player.nextChat(5870103)

def chat_5870103(player):
    player.playerChat("Well, have a good day!")
    player.endChat()