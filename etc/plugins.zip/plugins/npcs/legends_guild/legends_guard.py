
World.addNonCombatNpc(398, 2730, 3349, 0, 0)

