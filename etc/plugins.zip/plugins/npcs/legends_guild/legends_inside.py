##################################
###      Author: Eisenhower    ###
###       Date:12.11.2013      ###
##################################

World.addNonCombatNpc(400, 2729, 3380, 0, 1)
World.addNonCombatNpc(932, 2729, 3378, 1, 1)
World.addNonCombatNpc(933, 2724, 3369, 0, 1)

legend_shop = Shop("Legend's Supplies", 57)
legend_shop.addItem(ShopItem(373, 30))
legend_shop.addItem(ShopItem(2323, 10))
legend_shop.addItem(ShopItem(2428, 15))
legend_shop.addItem(ShopItem(886, 100))
legend_shop.addItem(ShopItem(1052, 1))

def first_click_npc_400(player):
    player.startChat(1158150306)

def first_click_npc_932(player):
    player.startChat(1158150315)
def first_click_npc_933(player):
    player.startChat(1158150315)
    
def second_click_npc_932(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        player.getShop().openShop(57)
    else:
        player.npcChat("wat?")
        player.endChat() 
def second_click_npc_933(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        player.getShop().openShop(57)
    else:
        player.npcChat("wat?")
        player.endChat()
    
def chat_1158150306(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        player.playerChat("Hey there, what is this place?")
        player.nextChat(1158150307)
    else:
        player.npcChat("wat?")
        player.endChat()

def chat_1158150307(player):
    player.npcChat("Hello! Welcome to the Legends Guild.")
    player.nextChat(1158150308)

def chat_1158150308(player):
    player.playerChat("What's the Legends Guild?")
    player.nextChat(1158150309)

def chat_1158150309(player):
    player.npcChat("The clue is in the name really...")
    player.nextChat(1158150310)

def chat_1158150310(player):
    player.npcChat("It's a guild for the legends of OwnXile. ")
    player.nextChat(1158150311)

def chat_1158150311(player):
    player.playerChat("Can I become a member please?")
    player.nextChat(1158150312)

def chat_1158150312(player):
    player.npcChat("It's not really quite that simple.")
    player.nextChat(1158150313)

def chat_1158150313(player):
    player.playerChat("Tell me how then!")
    player.nextChat(1158150314)

def chat_1158150314(player):
    player.npcChat("Maybe another time.")
    player.endChat()

def chat_1158150315(player):
    player.playerChat("Hi, what are you doing here?")
    player.nextChat(1158150316)

def chat_1158150316(player):
    player.npcChat("I'm here to sell some important items!")
    player.nextChat(1158150317)

def chat_1158150317(player):
    player.playerChat("Can I have a look at what you're selling?")
    player.nextChat(1158150318)

def chat_1158150318(player):
    player.npcChat("Sure...")
    player.nextChat(1158150319)

def chat_1158150319(player):
    quest_stage = player.getQuest(23).getStage()
    if quest_stage == 7:
        player.getShop().openShop(57)
        player.endChat()
    else:
        player.npcChat("wat?")
        player.endChat()
