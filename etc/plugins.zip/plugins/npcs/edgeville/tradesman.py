World.addNonCombatNpc(1972, 3092, 3492, 0, 1)
#def command_shop(player):
#   player.startChat(21765)

def first_click_npc_1972(player):
    player.startChat(21765)
	
def second_click_npc_1972(player):
    player.startChat(21766)
    
def chat_21765(player):
    player.npcChat("I have all manner of things for sale.", "What are you looking for?")
    player.nextChat(21766)
       
def chat_21766(player):
    if player.isIronman() or player.isUltimateIronman():
        player.getShop().openShop(4004)
    else:
        player.dialogueOption("Buy Swords, Bows and Staffs", 217607, "Buy Armour Sets", 217608, "Buy Food, Potions, Runes and Ammo", 217610, "Buy Robes and Hides", 217609, "Buy Clothes and Jewellery", 217611)
       
def chat_217607(player):
    player.getShop().openShop(61)#weapons
       
def chat_217608(player):
    player.getShop().openShop(659)#armour
       
def chat_217609(player):
    player.getShop().openShop(8335)#mage
       
def chat_217610(player):
    player.getShop().openShop(8334)#range
       
def chat_217611(player):
    player.getShop().openShop(8333)#supplies