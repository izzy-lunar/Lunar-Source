#ox_guide = World.addNonCombatNpc(2244, 3087, 3495, 0, 0)#home crier

def first_click_npc_2245(player):
    if player.playerTitle == 1:
        player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(0))
        player.startChat(981638031)
    else:
        player.startChat(1900604143)
	
def second_click_npc_2245(player):
    player.startChat(650000)

def chat_1900604143(player):##regular dialogue
    if player.playerTitle > 1:#greater than novice
	    player.dialogueOption("Frequently asked questions", 650000, "Teleport to N.E.W.B dungeon", 1900604144, "Change appearance", 205436, "Lower difficulty", 7853)
    else:
	    player.dialogueOption("Frequently asked questions", 650000, "Teleport to N.E.W.B dungeon", 1900604144, "Change appearance", 205436)

def chat_1900604144(player):
    player.playerChat("Can you take me to the N.E.W.B dungeon?")
    player.nextChat(1900604145)

def chat_1900604145(player):
    player.npcChat("I certainly can.")
    player.nextChat(1900604146)

def chat_1900604146(player):
    crier_teleport(player, 2783, 10074, 0)
    player.endChat()

def crier_teleport(p, x, y, z):
    crier.startAnimation(1818)
    crier.gfx0(343)
    crier.forceChat("See you there " + " " + p.playerName + "!")
    crier.turnNpc(p.getX(), p.getY())
    p.getTask().teleport(x, y, z)
    p.endChat()
	
def chat_981638031(player):
    player.playerChat("Hello, my name is " + str(player.playerName) + "!")
    player.nextChat(981638032)

def chat_981638032(player):
    player.npcChat("Welcome to OwnXile " + str(player.playerName) + ", I'm Ed and it's", "my job to help newcomers like you get started.")
    player.nextChat(981638033)

def chat_981638033(player):
    player.npcChat("It will only take a few seconds.")
    player.nextChat(981638034)

def chat_981638034(player):
    player.npcChat("Firstly, you'll need to select your difficulty level. This will", "impact upon your experience gained in combat skills", "including prayer. These range from @blu@easy@bla@ to @blu@legend@bla@.")
    player.nextChat(981638035)

def chat_981638035(player):
    player.npcChat("Easy mode will allow you to gain level 99 in combat skills",  "quickly. Players often choose this option so they can", "get straight into the wilderness to fight others. We", "also give them an improved starter pack to assist this.")
    player.nextChat(981638036)

def chat_981638036(player):
    player.npcChat("Alternatively you can play on a harder difficulty, these", "options are recommended for players who prefer a challenge.")
    player.nextChat(981638037)

def chat_981638037(player):
    player.npcChat("Remember; your difficulty does not affect other skills.")
    player.nextChat(89458)
	
def chat_89458(p):
    p.dialogueOption("Easy Mode @blu@Instant 99s", 982638036, "Champion mode @blu@1000 EXP per hit", 982638037, "Hero mode @blu@400 EXP per hit", 982638038, "Legend mode @blu@75 EXP per hit", 982638039)

def chat_982638036(player):
    player.npcChat("Ah you picked Easy difficulty mode. A good", "choice " + str(player.playerName) + "! That will make a lot life easier for you.")
    player.playerTitle = 1
    player.nextChat(981638039)
	
def chat_982638037(player):
    player.npcChat("Ah you picked Champion difficulty mode. An exquisite", "choice " + str(player.playerName) + "! Champion is my favorite mode to play.")
    player.playerTitle = 2
    player.nextChat(981638041)

def chat_982638038(player):
    player.npcChat("Ah you picked Hero difficulty mode. An excellent", "choice " + str(player.playerName) + "! This world needs Hero's.")
    player.playerTitle = 3
    player.nextChat(981638042)
	
def chat_982638039(player):
    player.npcChat("Ah you picked Legend difficulty mode. A brave", "choice " + str(player.playerName) + "! You must be a tough bugger.")
    player.playerTitle = 4
    player.nextChat(981638043)

def chat_981638039(player):
    player.npcChat("On easy mode we allow you to receive instant", "99 attack, strength, defence, magic, hitpoints and range.")
    player.nextChat(981638040)

def chat_981638040(player):
    player.npcChat("Just type the command @dre@::pure@bla@ into the chatbox.")
    player.sendMessage("@grd@For instant 99 stats except defence and prayer, type ::pure.");
    player.nextChat(979514554)

def chat_981638041(player):
    player.npcChat("On Champion mode your experience rate is 1000", "experience per hit. If you ever want to change your", "difficulty level just come and speak to me.")
    player.nextChat(979514554)
	
def chat_981638042(player):
    player.npcChat("On Hero mode your experience rate 400", "experience per hit. If you ever want to change your", "difficulty level just come and speak to me.")
    player.nextChat(979514554)
    
def chat_981638043(player):
    player.npcChat("On Legend mode your experience rate is 1000", "experience per hit. If you ever want to change your", "difficulty level just come and speak to me.")
    player.nextChat(979514554)

def chat_981638044(player):
    player.npcChat("Would you like to head over to the beginner dungeon?")
    player.nextChat(981638045)
	
def chat_981638045(player):
    player.dialogueQuestion("Teleport?", "Yes I'd like to visit the beginner dungeon", 981638046, "No I'd like to explore more first.", 58)
	
def chat_981638046(player):
    crier_teleport(player, 2783, 10074, 0)
    player.endChat()

def chat_979514554(player):
    player.playerChat("Do I get that starter pack now?")
    player.nextChat(979514555)

def chat_979514555(player):
    player.npcChat("Oh I almost forgot... here you go!")
    player.nextChat(979514556)

def chat_979514556(player):
    player.boxMessage("You receive some items.")
    player.nextChat(981638044)
    player.handleNewPlayer();
	