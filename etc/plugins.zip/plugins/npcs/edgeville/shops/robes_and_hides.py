
rah_shop = Shop("Robes and Hides", 8335)


rah_shop.addItem(ShopItem(579, 10))
rah_shop.addItem(ShopItem(577, 10))
rah_shop.addItem(ShopItem(1169, 10))
rah_shop.addItem(ShopItem(1129, 10))
rah_shop.addItem(ShopItem(1133, 10))
rah_shop.addItem(ShopItem(1097, 10))

rah_shop.addItem(ShopItem(6322, 10))
rah_shop.addItem(ShopItem(6324, 10))
rah_shop.addItem(ShopItem(6328, 10))

rah_shop.addItem(ShopItem(1135, 10))
rah_shop.addItem(ShopItem(1099, 10))
rah_shop.addItem(ShopItem(1065, 10))

rah_shop.addItem(ShopItem(2499, 10))
rah_shop.addItem(ShopItem(2493, 10))
rah_shop.addItem(ShopItem(2487, 10))

rah_shop.addItem(ShopItem(2501, 10))
rah_shop.addItem(ShopItem(2495, 10))
rah_shop.addItem(ShopItem(2489, 10))

rah_shop.addItem(ShopItem(2503, 10))
rah_shop.addItem(ShopItem(2497, 10))
rah_shop.addItem(ShopItem(2491, 10))


rah_shop.addItem(ShopItem(6106, 10))
rah_shop.addItem(ShopItem(6107, 10))
rah_shop.addItem(ShopItem(6108, 10))
rah_shop.addItem(ShopItem(6109, 10))
rah_shop.addItem(ShopItem(6110, 10))
rah_shop.addItem(ShopItem(6111, 10))
rah_shop.addItem(ShopItem(4089, 10))
rah_shop.addItem(ShopItem(4091, 10))
rah_shop.addItem(ShopItem(4093, 10))
rah_shop.addItem(ShopItem(4095, 10))
rah_shop.addItem(ShopItem(4097, 10))