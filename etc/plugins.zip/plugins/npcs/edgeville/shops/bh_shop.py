
wildy_shop = Shop("Wilderness Rewards", 988)

#scroll
#wildy_shop.addItem(ShopItem(12846, 1))

#caviar
wildy_shop.addItem(ShopItem(11326, 1))
#hometabs
wildy_shop.addItem(ShopItem(8013, 1))
#ammo nd supplies
wildy_shop.addItem(ShopItem(11230, 1))
wildy_shop.addItem(ShopItem(9244, 1))
wildy_shop.addItem(ShopItem(9245, 1))
wildy_shop.addItem(ShopItem(4740, 1))
wildy_shop.addItem(ShopItem(13879, 1))
wildy_shop.addItem(ShopItem(13883, 1))


#necklaces
wildy_shop.addItem(ShopItem(6585, 1))
wildy_shop.addItem(ShopItem(8284, 1))
wildy_shop.addItem(ShopItem(1478, 1))

#wards
wildy_shop.addItem(ShopItem(11924, 1))
wildy_shop.addItem(ShopItem(11926, 1))

#wildy rings
wildy_shop.addItem(ShopItem(12601, 1))
wildy_shop.addItem(ShopItem(12603, 1))
wildy_shop.addItem(ShopItem(12605, 1))

#osrs weapons
wildy_shop.addItem(ShopItem(8285, 1))
wildy_shop.addItem(ShopItem(11795, 1))
wildy_shop.addItem(ShopItem(8294, 1))

#pvp weapons
wildy_shop.addItem(ShopItem(12928, 1))
wildy_shop.addItem(ShopItem(13899, 1))
wildy_shop.addItem(ShopItem(13902, 1))
wildy_shop.addItem(ShopItem(13905, 1))
#crystal maul
wildy_shop.addItem(ShopItem(11863, 1))

#dclaws
wildy_shop.addItem(ShopItem(11777, 1))
#ags
wildy_shop.addItem(ShopItem(11694, 1))
#black cape
wildy_shop.addItem(ShopItem(1029, 1))
#d defender
wildy_shop.addItem(ShopItem(8844, 1))
#vesta
wildy_shop.addItem(ShopItem(13887, 1))
wildy_shop.addItem(ShopItem(13893, 1))
#stat
wildy_shop.addItem(ShopItem(13884, 1))
wildy_shop.addItem(ShopItem(13890, 1))
#ranger set
wildy_shop.addItem(ShopItem(2581, 1))
wildy_shop.addItem(ShopItem(2577, 1))

#coolhats
wildy_shop.addItem(ShopItem(12855, 1))
wildy_shop.addItem(ShopItem(12856, 1))
#cracker
wildy_shop.addItem(ShopItem(962, 1))








