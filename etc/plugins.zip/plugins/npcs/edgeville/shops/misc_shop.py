
jew_shop = Shop("Miscellaneous Store", 8333)

jew_shop.addItem(ShopItem(1704, 5))
jew_shop.addItem(ShopItem(1725, 5))
jew_shop.addItem(ShopItem(1727, 5))
jew_shop.addItem(ShopItem(1729, 5))
jew_shop.addItem(ShopItem(1731, 5))
jew_shop.addItem(ShopItem(3853, 5))
jew_shop.addItem(ShopItem(2552, 5))
jew_shop.addItem(ShopItem(2550, 10))
jew_shop.addItem(ShopItem(2570, 10))
jew_shop.addItem(ShopItem(11118, 5))
jew_shop.addItem(ShopItem(3105, 100))
jew_shop.addItem(ShopItem(660, 100))
jew_shop.addItem(ShopItem(662, 100))

jew_shop.addItem(ShopItem(10663, 1))
jew_shop.addItem(ShopItem(10664, 1))

jew_shop.addItem(ShopItem(9069, 1))
jew_shop.addItem(ShopItem(9072, 1))
jew_shop.addItem(ShopItem(9073, 1))
jew_shop.addItem(ShopItem(9074, 1))

jew_shop.addItem(ShopItem(542, 1))
jew_shop.addItem(ShopItem(544, 1))

