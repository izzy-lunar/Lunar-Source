

weapon_shop = Shop("Weapon Store", 61)
weapon_shop.addItem(ShopItem(1323, 10))
weapon_shop.addItem(ShopItem(1325, 10))
weapon_shop.addItem(ShopItem(1327, 10))
weapon_shop.addItem(ShopItem(1329, 10))
weapon_shop.addItem(ShopItem(1331, 10))
weapon_shop.addItem(ShopItem(1333, 10))

weapon_shop.addItem(ShopItem(4587, 10))
weapon_shop.addItem(ShopItem(1305, 10))
weapon_shop.addItem(ShopItem(5698, 10))
weapon_shop.addItem(ShopItem(1434, 10))
weapon_shop.addItem(ShopItem(1377, 10))


weapon_shop.addItem(ShopItem(1381, 10))
weapon_shop.addItem(ShopItem(1383, 10))
weapon_shop.addItem(ShopItem(1385, 10))
weapon_shop.addItem(ShopItem(1387, 10))
weapon_shop.addItem(ShopItem(2415, 1))
weapon_shop.addItem(ShopItem(2416, 1))
weapon_shop.addItem(ShopItem(2417, 1))


weapon_shop.addItem(ShopItem(841, 10))
weapon_shop.addItem(ShopItem(849, 10))
weapon_shop.addItem(ShopItem(853, 10))
weapon_shop.addItem(ShopItem(857, 10))
weapon_shop.addItem(ShopItem(861, 10))
weapon_shop.addItem(ShopItem(9185, 1))


