sup_shop = Shop("Supplies Store", 8334)



sup_shop.addItem(ShopItem(113, 500))
sup_shop.addItem(ShopItem(2428, 500))
sup_shop.addItem(ShopItem(113, 500))
sup_shop.addItem(ShopItem(2432, 500))
sup_shop.addItem(ShopItem(2434, 500))
sup_shop.addItem(ShopItem(2444, 500))
sup_shop.addItem(ShopItem(3040, 500))


sup_shop.addItem(ShopItem(7947, 5000))
sup_shop.addItem(ShopItem(374, 15000))

sup_shop.addItem(ShopItem(554, 10000))
sup_shop.addItem(ShopItem(555, 10000))
sup_shop.addItem(ShopItem(556, 10000))
sup_shop.addItem(ShopItem(557, 10000))
sup_shop.addItem(ShopItem(558, 10000))
sup_shop.addItem(ShopItem(559, 10000))
sup_shop.addItem(ShopItem(560, 10000))
sup_shop.addItem(ShopItem(562, 10000))
sup_shop.addItem(ShopItem(563, 10000))
sup_shop.addItem(ShopItem(564, 10000))
sup_shop.addItem(ShopItem(565, 10000))
sup_shop.addItem(ShopItem(566, 10000))
sup_shop.addItem(ShopItem(9075, 10000))
sup_shop.addItem(ShopItem(884, 5000))
sup_shop.addItem(ShopItem(888, 5000))
sup_shop.addItem(ShopItem(890, 5000))
sup_shop.addItem(ShopItem(892, 2000))
sup_shop.addItem(ShopItem(9140, 5000))
sup_shop.addItem(ShopItem(9142, 5000))
sup_shop.addItem(ShopItem(9144, 5000))

sup_shop.addItem(ShopItem(868, 10000))
sup_shop.addItem(ShopItem(2, 250000))