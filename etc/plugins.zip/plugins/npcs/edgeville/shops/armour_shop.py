

armour_shop = Shop("Armour Shop", 659)
#iron
armour_shop.addItem(ShopItem(1153, 10))
armour_shop.addItem(ShopItem(1115, 10))
armour_shop.addItem(ShopItem(1067, 10))
armour_shop.addItem(ShopItem(1191, 10))
#steel
armour_shop.addItem(ShopItem(1157, 10))
armour_shop.addItem(ShopItem(1119, 10))
armour_shop.addItem(ShopItem(1069, 10))
armour_shop.addItem(ShopItem(1193, 10))
#black
armour_shop.addItem(ShopItem(1165, 10))
armour_shop.addItem(ShopItem(1125, 10))
armour_shop.addItem(ShopItem(1077, 10))
armour_shop.addItem(ShopItem(1195, 10))
#mithril
armour_shop.addItem(ShopItem(1159, 10))
armour_shop.addItem(ShopItem(1121, 10))
armour_shop.addItem(ShopItem(1071, 10))
armour_shop.addItem(ShopItem(1197, 10))
#adamant
armour_shop.addItem(ShopItem(1161, 10))
armour_shop.addItem(ShopItem(1123, 10))
armour_shop.addItem(ShopItem(1073, 10))
armour_shop.addItem(ShopItem(1199, 10))
#rune
armour_shop.addItem(ShopItem(1163, 10))
armour_shop.addItem(ShopItem(1127, 10))
armour_shop.addItem(ShopItem(1079, 10))
armour_shop.addItem(ShopItem(1201, 10))
#granite
armour_shop.addItem(ShopItem(10589, 10))
armour_shop.addItem(ShopItem(10564, 10))
armour_shop.addItem(ShopItem(6809, 10))
armour_shop.addItem(ShopItem(3122, 10))
#other
armour_shop.addItem(ShopItem(3749, 5))
armour_shop.addItem(ShopItem(3755, 5))
armour_shop.addItem(ShopItem(3751, 5))
armour_shop.addItem(ShopItem(3753, 5))
#boots
armour_shop.addItem(ShopItem(4119, 5))
armour_shop.addItem(ShopItem(4121, 5))
armour_shop.addItem(ShopItem(4123, 5))
armour_shop.addItem(ShopItem(4125, 5))
armour_shop.addItem(ShopItem(4127, 5))
armour_shop.addItem(ShopItem(4129, 5))
armour_shop.addItem(ShopItem(4131, 0))
armour_shop.addItem(ShopItem(1540, 50))
