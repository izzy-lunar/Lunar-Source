World.addNonCombatNpc(3155, 3092, 3503, 0, 1)

def first_click_npc_3155(player): 
    player.startChat(7850)
    
def second_click_npc_3155(player):
    player.getShop().openShop(988)
    
def third_click_npc_3155(player):
    if not player.isSkulled:
        player.isSkulled = True
        player.skullTimer = 1600
        player.headIconPk = 0
        player.getFunction().requestUpdates()
        player.boxMessage("You are now skulled and will lose all items on death.")
    else:
        player.boxMessage("You are already skulled.")
    
def chat_7850(player):
    player.playerChat("Hi there, who are you?")
    player.nextChat(7851)
    
def chat_7851(player):
    player.npcChat("I'm the wilderness trader.")
    player.nextChat(7852)
    
def chat_7852(player):
    player.npcChat("You can raise your rating level by killing players and bosses.,", "the portal over there provides some useful teleports!")
    player.nextChat(7853)
    
def chat_7853(player):
    player.endChat()
    player.getShop().openShop(988)