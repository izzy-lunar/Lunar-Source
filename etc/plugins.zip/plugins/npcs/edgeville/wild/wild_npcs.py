
 
World.addCombatNpc(92, 3117, 3530, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3113, 3537, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3104, 3552, 0, 1, 35, 7, 30,30)


World.addCombatNpc(93, 3100, 3567, 0, 1, 45, 9, 50,50)
World.addCombatNpc(93, 3106, 3570, 0, 1, 45, 9, 50,50)
World.addCombatNpc(93, 3098, 3562, 0, 1, 45, 9, 50,50)


World.addCombatNpc(92, 3066, 3527, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3060, 3532, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3047, 3526, 0, 1, 35, 7, 30,30)


World.addCombatNpc(92, 3088, 3550, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3077, 3555, 0, 1, 35, 7, 30,30)
World.addCombatNpc(92, 3061, 3551, 0, 1, 35, 7, 30,30)
World.addCombatNpc(105, 3051, 3554, 0, 1, 35, 7, 30,30)

#guards
World.addCombatNpc(9, 3094, 3517, 0, 1, 21, 4, 20,20)
World.addCombatNpc(9, 3116, 3519, 0, 1, 21, 4, 20,20)