
World.addNonCombatNpc(5383, 3087, 3517, 0, 1)

def first_click_npc_5383(player):
    player.startChat(1009305985)