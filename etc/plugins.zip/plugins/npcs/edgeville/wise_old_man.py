# NPC Config Script
# Wise Old Man - 2566
# Author Wildy

#Dis guy needs dialogues

wise_old = World.addNonCombatNpc(2567, 3106, 3501, 0, 1)

def first_click_npc_2567(player): 
    player.startChat(60876)

def second_click_npc_2567(player):
    player.getShop().openShop(69)
    
def third_click_npc_2567(player):
    if player.hasItem(962):
        player.startChat(579700039)
    else:
        player.sendMessage("You don't have a christmas cracker to open.")
    
	
def reset_skill_man(player, level):
    skill_name = player.getLevelName(level)
    if player.isWieldingItems():
        player.boxMessage("You must not be wielding any items to do this.")
        player.endChat()
    else:
        player.getFunction().resetLevel(level)
        player.boxMessage("You have reset your " + skill_name + " level to 1.")
        player.endChat()

def chat_60876(player):
    player.npcChat("Hello there! how may I be of service?")
    player.nextChat(2050)

def chat_2050(player):
    player.dialogueOption("View cape shop", 2051, "Enquire about Partyhat", 1203767319)
		
def chat_1203767330(player):
    player.dialogueOption("Attack", 1203767331, "Strength", 1203767332, "Defence", 1203767333, "Prayer", 1203767334)
def chat_1203767331(player):
    reset_skill_man(player, 0)
def chat_1203767332(player):
    reset_skill_man(player, 2)
def chat_1203767333(player):
    reset_skill_man(player, 1)
def chat_1203767334(player):
    reset_skill_man(player, 5)
	
def chat_579700039(player):
    player.playerChat("I have a christmas cracker and word on the", "street says you know what to do with one!")
    player.nextChat(579700040)

def chat_579700040(player):
    player.npcChat("Ah yes, the old christmas cracker.", "I know them well...")
    player.nextChat(579700041)

def chat_579700041(player):
    player.npcChat("Would you like me to help you open it...?")
    player.nextChat(579700044)

def chat_579700044(player):
    player.dialogueQuestion("Open cracker?", "Hell yeah!", 579700042, "No way.", 2050)

def chat_579700042(player):
    player.playerChat("Hell yeah, lets do it!")
    player.nextChat(579700043)

def chat_579700043(player):
    partyhat = player.getTask().getPartyhat()
    wise_old.forceChat("Wow a " + str(partyhat) + ", here you go " + str(player.playerName) + "!")
    player.npcChat("Nice one, you won a @dre@" + str(partyhat) + "@bla@!")
    if 2 > player.playerRights:
        World.sendMessage("@grd@" + str(player.playerName) + " won a " + str(partyhat) + " from a Christmas cracker.")
    player.endChat()

def chat_2051(player):
    player.getShop().openShop(69)
 
def chat_2052(player):
    player.dialogueQuestion("Reset?", "Yes reset all my combat levels.", 2053, "No thanks.", 2050)

def chat_2053(player):
    if player.isWieldingItems():
        player.boxMessage("You must not be wielding any items to do this.")
        player.endChat()
    else:
        player.getFunction().resetCombatLevels()
        player.boxMessage("You have reset your combat levels to 1.")
        player.endChat()    

def chat_1203767319(player):
    player.playerChat("I like your hat.....")
    player.nextChat(1203767320)

def chat_1203767320(player):
    player.playerChat("Where did you get it from?")
    player.nextChat(1203767321)

def chat_1203767321(player):
    player.npcChat("It's cracking, wouldn't you say?")
    player.nextChat(1203767322)

def chat_1203767322(player):
    player.playerChat("Can I have it?")
    player.nextChat(1203767323)

def chat_1203767323(player):
    player.npcChat("Hah! you won't be getting one from me.")
    player.endChat()
	
def chat_1203767326(player):
    player.getShop().openShop(40)

def chat_1203767340(player):
    player.dialogueQuestion("Reset?", "Yes reset my quests.", 1203767341, "No thanks.", 58)
	
def chat_1203767341(player):
    player.getFunction().resetQuests()