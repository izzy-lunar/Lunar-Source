from com.ownxile.core import World

def chat_650000(player):
	player.dialogueOption("Ask about obtaining items", 650001, "Ask about shops", 650009, "Ask about teleports", 650013,   "@dre@More questions", 650003)
	
def chat_650001(player):
	player.playerChat("Where can you obtain items?")
	player.nextChat(650002)

def chat_650002(player):
	player.npcChat("There's many ways to obtain items. You can kill monsters,", " buy items from shops, buy items from other players,", " you can also obtain items my exchange for OwnXile Points.")
	player.nextChat(650008)	

def chat_650003(player):
	player.dialogueOption("Ask about monsters", 650004,   "Ask about training skills", 650016, "Ask about quests", 650021, "@dre@Previous questions", 650000)	
	
def chat_650004(player):
	player.playerChat("What monsters are there and where are they located?")
	player.nextChat(650005)

def chat_650005(player):
	player.npcChat("There's many monsters ranging from big bosses", "to smaller monsters used for training combat levels.")
	player.nextChat(650006)
	
def chat_650006(player):
	player.npcChat("You should begin training in the @blu@Training cave@bla@ or", "@blu@Taverly dungeon@bla@ by clicking the @blu@Dungeon teleport", "that is available in your spellbook.")
	player.nextChat(650003)			

def chat_650007(player):
	player.playerChat("Thanks for the information, I'll check it out.")
	player.nextChat(650008)	

def chat_650008(player):
	player.npcChat("Have you got any other questions?")
	player.nextChat(650000)	

def chat_650009(player):
	player.playerChat("Where are the shops located and what can", "I purchase from the shops?")
	player.nextChat(650010)

def chat_650010(player):
	player.npcChat("Shops are situated all over the map in the main cities.", "You can find most items at the @dre@Tradesmen@bla@ in the bank." )
	player.nextChat(650003)
	
def chat_650011(player):
	player.playerChat("What are OwnXile Points?")
	player.nextChat(650012)
	
def chat_650012(player):
	player.npcChat("OwnXile Points are special points that are", "gained through completing challenges. Including questing, ", "slayer tasks, boss killing, minigame victories and voting!")
	player.nextChat(342094445)	
	
# Ask about teleports
def chat_650013(player):
	player.playerChat("What teleports are there and how do I use them?")
	player.nextChat(650014)	
	
def chat_650014(player):
	player.npcChat("There's different ways to teleport to many areas of the map.", "Your spellbook provides around 50 unique teleports.")
	player.nextChat(650015)	
	
def chat_650015(player):
	player.npcChat("The fairy ring in northern edgeville has teleports too", "plus you can use gnome airlines or even travel", "via ship at one of the many sea ports")
	player.nextChat(650008)	

# Ask about training skills
def chat_650016(player):
	player.playerChat("How can I train skills?")
	player.nextChat(650017)		
	
def chat_650017(player):
	player.npcChat("You can train various different skills all over the map.")
	player.nextChat(650018)		

def chat_650018(player):
	player.npcChat("As you increase your levels you may wish to consider", "training your combat skills through slayer tasks and by", "killing higher levelled monsters whilst receiving good drops.")
	player.nextChat(650020)		
	
def chat_650019(player):
	player.npcChat("Speak to the @blu@Penguin@bla@ to visit one of the Agility training courses ", "the other skills you will find areas all around the map.")
	player.nextChat(650020)	
	
def chat_650020(player):
	player.npcChat("Entrana and Catherby are key towns for working on skills.", "For more information on how to train skills", "check out player-made guides on at @dre@www.ownxile.com@bla@.")
	player.nextChat(650008)		

# Ask about quests
def chat_650021(player):
	player.playerChat("How can I start a quest?")
	player.nextChat(650022)
	
def chat_650022(player):
	player.npcChat("If you find the quest tab, select the quest you want to", " start. A dialogue should appear informing you on where", "to start that particular quest!")
	player.nextChat(650023)			
	
def chat_650023(player):
	player.npcChat("If you're struggling with a quest perhaps check out", "the OwnXile website for guides and help from other players!")
	player.nextChat(650008)		

def chat_650046(player):
	player.playerChat("Hmmm....")
	player.nextChat(650003)
	
def chat_650047(player):
	player.playerChat("Ermm....")
	player.nextChat(650000)
	
def chat_650045(player):
	player.getFunction().showInterface(3559)
	player.canChangeAppearance = True