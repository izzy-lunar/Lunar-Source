# NPC Config Script
# Wise Old Man - 2676
# Author Steve
#World.addNonCombatNpc(2676, 3094, 3472, 0, 1)

def first_click_npc_2676(player):
	player.startChat(205432)

def chat_205432(player):
	player.npcChat("Hello here! I am known as the Make-over Mage! I", "have spent many years researching magics that can", "change your physical appearance.")
	player.nextChat(205433)

def chat_205433(player):
	player.npcChat("I can alter your appearance for a small fee of", "only 5000 coins. Would you like me to perform my", "magics on you?")
	player.nextChat(205434)

def chat_205434(player):
	player.dialogueOption("Sure, do it.", 205435, "No, thanks.", 0)

def chat_205435(player):
	player.playerChat("Sure, do it.")
	player.nextChat(205436)

def chat_205436(player):
	if player.hasItem(995, 5000):
		player.deleteItem(995, 5000)
		player.getFunction().showInterface(3559)
		player.canChangeAppearance = True
	else:
		player.npcChat("Looks like you can't afford to change your appearance,", "come see me again when you have enough money.")
		player.endChat()
	
def click_button_14067(player):
	player.npcChat("Two arms, two legs, one head; it seems that spell finally", "worked okay.")
	player.nextChat(205437)
	
def chat_205437(player):
	player.playerChat("Um thanks, I guess.")
	player.endChat()