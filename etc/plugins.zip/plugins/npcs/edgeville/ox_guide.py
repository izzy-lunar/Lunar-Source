#The OwnXile guide
#by Robbie

guide_npc = World.addNonCombatNpc(2244, 3087, 3495, 0, 1)


def first_click_npc_2244(player):
    player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(0))
    player.startChat(342094439)
	
def second_click_npc_2244(player):
    player.getFunction().createNpcHint(NPCHandler.getSlotForNpc(0))
    player.startChat(342094442)

def third_click_npc_2244(player):
    player.getShop().openShop(18)

def chat_342094439(player):
    player.playerChat("Hey I'm " + str(player.playerName) + ", who are you?")
    player.nextChat(342094440)

def chat_342094440(player):
    player.npcChat("Hey there " + str(player.playerName) + ", I'm the Edgeville guide", "and it's my job to provide you with all the essential", "OwnXile serivces! Let me know what you require.")
    player.nextChat(342094442)
	
def chat_342094442(player):
    player.dialogueOption("Ask question...", 650000,  "Character management services", 342094444, "Exchange points", 342094443, "What are OwnXile points?", 650011)
	
def chat_342094444(player):
    player.dialogueOption("Reset all quests", 1203767340, "Change character appearance or gender", 205436, "Lower account difficulty level", 484848435, "Reset specific combat level", 1203767330,  "Reset all combat levels", 2052, )

def chat_342094443(player):
	player.getShop().openShop(18)
	
def chat_342094445(player):
    player.dialogueOption("Ask question...", 650000,  "Character management services", 342094444, "View point shop", 342094443, "Ask a different question", 650000)
	
def chat_484848435(player):
    if player.playerTitle > 4:#legend or ironman reset
        player.dialogueOption("Regular", 89454, "Champion", 89455, "Hero", 89456, "Legend", 89457)
    elif player.playerTitle == 3:
        player.dialogueOption("Regular", 89454, "Champion", 89455, "Hero", 89456)
    elif player.playerTitle == 3:
        player.dialogueOption("Regular", 89454, "Champion", 89455)
    else: 
        player.dialogueOption("Regular", 89454, "No thanks", 58)