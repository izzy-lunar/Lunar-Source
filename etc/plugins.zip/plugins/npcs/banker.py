def chat_1009305985(player):
    player.npcChat("Hello, welcome to the bank of OwnXile.", "How may I help you today?")
    player.nextChat(1009305986)

def chat_1009305986(player):
    player.dialogueOption("I'd like to access my bank account please.", 1009305987, "Actually I don't need any help.", 58)

def chat_1009305987(player):
    player.getFunction().openUpBank()
    player.endChat()
