

def chat_36434340(player):
    player.playerChat("Hello monk.")
    player.nextChat(36434341)

def chat_36434341(player):
    player.npcChat("Hello adventurer. My name is Brother Kojo. Do you", "happen to know the time?")
    player.nextChat(36434342)

def chat_36434342(player):
    player.playerChat("No, sorry, I don't.")
    player.nextChat(36434343)

def chat_36434343(player):
    player.npcChat("Exactly! This clock tower has recently broken down,", "and without it nobody can tell the correct time. I must", "fix it before the town people become too angry!")
    player.nextChat(36434344)

def chat_36434344(player):
    player.npcChat("I don't suppose you could assist me in the repairs? I'll", "pay you for your help.")
    player.nextChat(36434345)
    
def chat_36434345(player):
    player.dialogueOption("Not now I'm busy.", 3094489, "Okay, what can I do?", 3094490)

def chat_3094489(player):
    player.playerChat("Not now old monk.")
    player.endChat()
    
def chat_3094490(player):
    player.playerChat("Okay old monk, what can I do?")
    player.nextChat(3094491)

def chat_3094491(player):
    player.npcChat("Oh thank you kind sir!", "In the cellar below, you'll find four cogs.")
    player.nextChat(3094492)

def chat_3094492(player):
    player.npcChat("They're too heavy for me, but you should be able to", "carry them on at a time.")
    player.nextChat(3094493)

def chat_3094493(player):
    player.npcChat("I know ones goes on each floor... but I can't exactly", "remember which goes where specifically. Oh well, I'm", "sure you can figure it out fairly easily.")
    player.nextChat(3094494)

def chat_3094494(player):
    player.playerChat("Well, I'll do my best.")
    player.getQuest(39).setStage(1)
    player.refreshQuestTab()
    player.nextChat(3094495)

def chat_3094495(player):
    player.npcChat("Thank you again!")
    player.endChat()
    
def chat_943405614(player):
    player.playerChat("I have replaced all the cogs!")
    player.nextChat(943405615)

def chat_943405615(player):
    player.npcChat("Really...? Wait, listen! Well done, well done! Yes yes", "yes, you've done it! You ARE clever!")
    player.nextChat(943405616)

def chat_943405616(player):
    player.npcChat("The townsfolk will all be able to know the correct time", "now! Thank you so much for all of your help! And as", "promised, here is your reward!")
    player.nextChat(943405617)
    
def chat_3094496(player):
    player.npcChat("Have you fixed the clock yet?")
    player.nextChat(3094497)

def chat_3094497(player):
    player.playerChat("I'm still working on it.")
    player.endChat()



