# Entrana NPC
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.rs2.world.transport import Sailing
from com.ownxile.core import World

#Aub
World.addNonCombatNpc(553, 2658, 2652, 0, 1)

#Horvik
World.addNonCombatNpc(549, 2650, 2659, 0, 1)

#Lowe
World.addNonCombatNpc(550, 2667, 2661, 0, 1)

#Sailor
World.addNonCombatNpc(3797, 2658, 2676, 0, 0)

#Banker
World.addNonCombatNpc(494, 2665, 2651, 0, 0)
World.addNonCombatNpc(494, 2666, 2651, 0, 0)
World.addNonCombatNpc(494, 2667, 2651, 0, 0)
World.addNonCombatNpc(494, 2668, 2651, 0, 0)

def first_click_npc_3797(player):
	player.startChat(69077100)
	
def chat_69077100(player):
	player.npcChat("Hey, how can I help you?")
	player.nextChat(69077101)
	
def chat_69077101(player):
    player.dialogueOption("I wish to go to Port Sarim!", 69077102, "Nevermind", 69077103)
	
def chat_69077102(player):
	player.npcChat("Enjoy your trip!")
	Sailing.startTravel(player, 15)
	
def chat_69077103(player):
	player.playerChat("Nevermind")
	player.nextChat(69077104)
	
def chat_69077104(player):
	player.npcChat("Alright then!")
	player.endChat()
