# Entrana NPC
# Author Cam
from com.ownxile.rs2.world.shops import Shop
from com.ownxile.rs2.world.shops import ShopItem
from com.ownxile.rs2.world.transport import Sailing
from com.ownxile.core import World

#banker
World.addNonCombatNpc(5383, 2846, 3334, 0, 1)

#Fishing
World.addNonCombatNpc(576, 2876, 3336, 0, 1)

#Bob
World.addNonCombatNpc(519, 2830, 3352, 0, 0)

#Men
World.addCombatNpc(1, 2847, 3370, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(2, 2819, 3353, 0, 1, 10, 2, 1, 1)

#Women
World.addCombatNpc(6, 2845, 3368, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(5, 2820, 3359, 0, 1, 10, 2, 1, 1)

#Chicken
World.addCombatNpc(41, 2853, 3373, 0, 1, 3, 1, 1, 1)
World.addCombatNpc(41, 2850, 3373, 0, 1, 3, 1, 1, 1)
World.addCombatNpc(41, 2850, 3370, 0, 1, 3, 1, 1, 1)

#Monk
World.addCombatNpc(222, 2852, 3352, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(222, 2851, 3345, 0, 1, 10, 2, 1, 1)
World.addCombatNpc(222, 2851, 3349, 0, 1, 10, 2, 1, 1)

#Sailor
World.addNonCombatNpc(658, 2834, 3335, 0, 1)

def first_click_npc_658(player):
	player.startChat(31075100)
	
def second_click_npc_658(player):
	Sailing.startTravel(player, 2)
	
def chat_31075100(player):
	player.npcChat("Hi, how can I help you?")
	player.nextChat(31075101)
	
def chat_31075101(player):
    player.dialogueOption("I wish to go to Port Sarim!", 31075102, "Nevermind.", 31075103)
	
def chat_31075102(player):
	player.endChat()
	Sailing.startTravel(player, 2)
	
def chat_31075103(player):
	player.playerChat("Nevermind.")
	player.nextChat(31075104)
	
def chat_31075104(player):
	player.npcChat("Okay then!")
	player.endChat()
