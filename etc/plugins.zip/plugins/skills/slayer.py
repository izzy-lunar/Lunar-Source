##################################
###    Slayer master plugin    ###
###    Created by OwnXile      ###
###    18th September 2013     ###
##################################

from com.ownxile.rs2.npcs import NPCHandler
from com.ownxile.core import World
slayer_masters = [70, 1596, 1597, 1598, 1599, 5939]
slayer_requirements = [1, 30, 55, 70, 90, 95]

def first_click_npc_70(player):
 player.startChat(603870)
def first_click_npc_1596(player):
 player.startChat(603870)
def first_click_npc_1597(player):
 player.startChat(603870)
def first_click_npc_1598(player):
 player.startChat(603870)
def first_click_npc_1599(player):
 player.startChat(603870)
def first_click_npc_5939(player):
 player.startChat(603870)

 #around the map
World.addNonCombatNpc(1596, 2354, 3801, 0, 1)
World.addNonCombatNpc(1596, 3511, 3508, 0, 1)
World.addNonCombatNpc(1597, 3146, 9913, 0, 1)
World.addNonCombatNpc(1598, 2445, 4432, 0, 1)
World.addNonCombatNpc(1599, 2869, 2982, 1, 1)
World.addNonCombatNpc(1599, 2697, 9558, 1, 1)

#torcs
World.addNonCombatNpc(5939, 3422, 3523, 0, 1)

#home masters
World.addNonCombatNpc(70, 3107, 3513, 0, 1)
World.addNonCombatNpc(1596, 3110, 3517, 0, 1)
World.addNonCombatNpc(1597, 3110, 3512, 0, 1)
World.addNonCombatNpc(1598, 3110, 3514, 0, 1)

def third_click_npc_1596(player):
 player.getShop().openShop(11)
def third_click_npc_70(player):
 player.getShop().openShop(11)
def third_click_npc_1597(player):
 player.getShop().openShop(11)
def third_click_npc_1598(player):
 player.getShop().openShop(11)
def third_click_npc_1599(player):
 player.getShop().openShop(11)

def give_slayer_task(player):
 player.boxMessage(player.getSlayer().assignTask(slayer_masters.index(player.lastClickedNpcId)))
 
def chat_603870(player):
 npc_name = World.getNpcHandler().getNPCName(player.lastClickedNpcId)
 player.npcChat("My name is " + str(npc_name) + ",", "one of the many masters of slayer", "in the land of OwnXile. How can I help you?")
 player.nextChat(603871)

def chat_603871(player):
 has_task = False
 if player.getSlayer().playerHasTask():
  option = "What is my current task?"
  optionid = 603874
  has_task = True
 else:
  option = "Assign me a Slayer task."
  optionid = 603885
 if has_task:
  player.dialogueOption("What is Slayer?", 603872, "Do you have any items for sale?", 603880, option, optionid, "Can you give me a different task?", 603888)
 else:
  player.dialogueOption("What is Slayer?", 603872, "Do you have any items for sale?", 603880, option, optionid)

def chat_603872(player):
 player.playerChat("What is Slayer?")
 player.nextChat(603873)

def chat_603873(player):
 player.npcChat("Slayer is an ability to slay certain monsters ranging", "from the weak cave crawlers to the great dark beasts!", "I can teach you to slay such things however I", "will warn you that it will not be easy.")
 player.nextChat(603871)
 
def chat_603874(player):
 player.playerChat("What is my current task?")
 player.nextChat(603875)
 
def chat_603875(player):
 task = player.getSlayer().toString()
 player.npcChat("You need to kill " + str(task) + ",", "should be a piece of cake!")
 player.endChat()

def chat_603880(player):
 player.playerChat("Do you have any items for sale?")
 player.nextChat(603881)

def chat_603881(player):
 player.npcChat("Yes I certainly do,", "I currently have various slayer equipment in stock.")
 player.nextChat(603882)

def chat_603882(player):
 player.getShop().openShop(11)

def chat_603885(player):
 player.playerChat("Could you assign me a Slayer task?")
 player.nextChat(603886)

def chat_603886(player):
 slayer_req = slayer_requirements[slayer_masters.index(player.lastClickedNpcId)]
 slayer_level = player.getLevel("slayer")
 if slayer_level >= slayer_req:
  player.npcChat("Sure thing.")
  player.nextChat(603887)
 else:
  player.npcChat("You need a slayer level of " + str(slayer_req) + " to do my tasks.")
  player.endChat()

def chat_603887(player):
 give_slayer_task(player)

def chat_603888(player):
 player.playerChat("Can you give me a new task?")
 if player.lastClickedNpcId == 70:
  player.nextChat(603892)
 else:
  player.nextChat(603889)
 
 
def chat_603889(player): 
 slayer_req = slayer_requirements[slayer_masters.index(player.lastClickedNpcId)]
 slayer_level = player.getLevel("slayer")
 if slayer_level >= slayer_req:
   player.npcChat("I can but it will cost you a fee", "of 100,000 coins. Is that acceptable?")
   player.nextChat(603890)
 else:
  player.npcChat("You need a slayer level of " + str(slayer_req) + " to receive my tasks.")
  player.endChat()

def chat_603890(player):
 if player.hasItem(995, 100000):
  player.dialogueQuestion("Pay 100,000?", "Yes", 603891, "No", 0)
 else:
  player.playerChat("I'm afraid I can't afford to pay that.")
  player.endChat()

def chat_603891(player):
  player.boxMessage(player.getSlayer().resetTask(slayer_masters.index(player.lastClickedNpcId)))
  player.deleteItem(995, 100000)
  player.endChat()

def chat_603892(player):
  player.npcChat("Seen as you're new to slayer I'm quite happy", "to reset your task. Please bare in mind that", "the other slayer masters won't be so kind.")
  player.nextChat(603893)
  
def chat_603893(player):
  player.boxMessage(player.getSlayer().resetTask(slayer_masters.index(player.lastClickedNpcId)))
  player.endChat()